"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import type { SearchResult } from "@/lib/data";

export function SearchCommand() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function shortcut(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen(true);
        window.setTimeout(() => inputRef.current?.focus(), 0);
      }
      if (event.key === "Escape") {
        setOpen(false);
        inputRef.current?.blur();
      }
    }
    window.addEventListener("keydown", shortcut);
    return () => window.removeEventListener("keydown", shortcut);
  }, []);

  useEffect(() => {
    setActive(0);
    if (query.trim().length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    const timeout = window.setTimeout(async () => {
      setLoading(true);
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query.trim())}`, { signal: controller.signal });
        if (!response.ok) throw new Error("Search failed");
        const data = (await response.json()) as { results: SearchResult[] };
        setResults(data.results);
      } catch (error) {
        if ((error as Error).name !== "AbortError") setResults([]);
      } finally {
        setLoading(false);
      }
    }, 220);
    return () => {
      window.clearTimeout(timeout);
      controller.abort();
    };
  }, [query]);

  function close() {
    setOpen(false);
    setQuery("");
    setResults([]);
  }

  return (
    <div className="relative min-w-0 flex-1 max-w-xl">
      <div className={`relative transition ${open ? "ring-brand rounded-xl" : ""}`}>
        <input
          ref={inputRef}
          className="input h-10 pl-10 pr-20"
          aria-label="Search all learning content"
          aria-expanded={open}
          aria-controls="global-search-results"
          role="combobox"
          autoComplete="off"
          placeholder="Search lessons, words, resources…"
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "ArrowDown") {
              event.preventDefault();
              setActive((index) => Math.min(results.length - 1, index + 1));
            }
            if (event.key === "ArrowUp") {
              event.preventDefault();
              setActive((index) => Math.max(0, index - 1));
            }
            if (event.key === "Enter" && results[active]) {
              window.location.assign(results[active].href);
            }
          }}
        />
        <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm muted">⌕</span>
        <kbd className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 rounded-md border px-1.5 py-0.5 font-mono text-[10px] muted" style={{ borderColor: "var(--border)" }}>
          Ctrl K
        </kbd>
      </div>

      {open ? (
        <>
          <button aria-label="Close search" className="fixed inset-0 z-20 cursor-default bg-transparent" onClick={close} />
          <div id="global-search-results" className="card absolute left-0 right-0 top-[calc(100%+8px)] z-30 max-h-[440px] overflow-y-auto scroll-thin p-2 animate-pop">
            {query.trim().length < 2 ? (
              <div className="p-4">
                <p className="text-xs font-bold">Search the complete catalogue</p>
                <p className="mt-1 text-[11px] muted">Type at least 2 characters. Try “conditionals”, “API”, “memory” or a Persian meaning.</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {["TOEFL", "polymorphism", "pronunciation", "passive voice"].map((term) => (
                    <button key={term} className="chip transition hover:ring-brand" onClick={() => setQuery(term)}>{term}</button>
                  ))}
                </div>
              </div>
            ) : loading ? (
              <div className="space-y-2 p-2">
                {[0, 1, 2].map((item) => (
                  <div key={item} className="h-14 animate-pulse rounded-xl" style={{ background: "color-mix(in srgb,var(--text) 6%,transparent)" }} />
                ))}
              </div>
            ) : results.length > 0 ? (
              <ul>
                {results.map((result, index) => (
                  <li key={`${result.type}-${result.href}-${result.title}`}>
                    <Link
                      href={result.href}
                      onClick={close}
                      onMouseEnter={() => setActive(index)}
                      className="flex items-start gap-3 rounded-xl px-3 py-2.5 transition"
                      style={{ background: active === index ? "color-mix(in srgb,var(--brand) 11%,transparent)" : "transparent" }}
                    >
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl" style={{ background: "color-mix(in srgb,var(--brand) 12%,transparent)" }}>{result.icon}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold">{result.title}</span>
                        <span className="block truncate text-[11px] muted">{result.subtitle}</span>
                      </span>
                      <span className="chip shrink-0 text-[9px]">{result.type}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="grid place-items-center gap-1 p-8 text-center">
                <span className="text-2xl">🧭</span>
                <p className="text-sm font-semibold">No result found</p>
                <p className="text-[11px] muted">Try a broader term or search in Persian.</p>
              </div>
            )}
            <div className="mt-1 flex justify-between border-t px-3 pt-2 text-[9px] muted" style={{ borderColor: "var(--border)" }}>
              <span>↑↓ navigate · Enter open</span>
              <span>Esc close</span>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
