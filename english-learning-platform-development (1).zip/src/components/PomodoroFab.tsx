"use client";

import { useEffect, useRef, useState } from "react";
import { logStudyMinutes } from "@/lib/actions";

const PRESETS = [
  { label: "Focus 25", minutes: 25, xp: 50 },
  { label: "Deep 50", minutes: 50, xp: 110 },
  { label: "Break 5", minutes: 5, xp: 0 },
];

export function PomodoroFab() {
  const [open, setOpen] = useState(false);
  const [preset, setPreset] = useState(PRESETS[0]);
  const [left, setLeft] = useState(PRESETS[0].minutes * 60);
  const [running, setRunning] = useState(false);
  const [cycles, setCycles] = useState(0);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!running) return;
    timer.current = setInterval(() => {
      setLeft((l) => {
        if (l <= 1) {
          setRunning(false);
          setCycles((c) => c + 1);
          if (preset.xp > 0) void logStudyMinutes(preset.minutes, preset.xp);
          return 0;
        }
        return l - 1;
      });
    }, 1000);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [running, preset]);

  const pct = 1 - left / (preset.minutes * 60);

  return (
    <div className="fixed bottom-24 right-5 z-40 print:hidden lg:bottom-5">
      {open ? (
        <div className="card mb-3 w-64 p-4 animate-pop">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold">🍅 Pomodoro</p>
            <button className="btn btn-ghost px-2 py-0.5 text-xs" onClick={() => setOpen(false)}>✕</button>
          </div>

          <div className="relative my-3 grid place-items-center">
            <svg viewBox="0 0 110 110" className="h-28 w-28 -rotate-90">
              <circle cx="55" cy="55" r="46" fill="none" strokeWidth="8" stroke="color-mix(in srgb, var(--text) 10%, transparent)" />
              <circle
                cx="55" cy="55" r="46" fill="none" strokeWidth="8" strokeLinecap="round" stroke="var(--brand)"
                strokeDasharray={`${(2 * Math.PI * 46 * pct).toFixed(1)} ${(2 * Math.PI * 46).toFixed(1)}`}
              />
            </svg>
            <p className="absolute font-mono text-xl font-extrabold">
              {String(Math.floor(left / 60)).padStart(2, "0")}:{String(left % 60).padStart(2, "0")}
            </p>
          </div>

          <div className="mb-2 flex gap-1">
            {PRESETS.map((p) => (
              <button
                key={p.label}
                className={`btn flex-1 px-1 py-1 text-[10px] ${preset.label === p.label ? "btn-primary" : "btn-ghost"}`}
                onClick={() => { setPreset(p); setLeft(p.minutes * 60); setRunning(false); }}
              >
                {p.label}
              </button>
            ))}
          </div>

          <div className="flex gap-2">
            <button className="btn btn-primary flex-1 py-1.5 text-xs" onClick={() => setRunning((r) => !r)}>
              {running ? "⏸ Pause" : "▶️ Start"}
            </button>
            <button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => { setRunning(false); setLeft(preset.minutes * 60); }}>↺</button>
          </div>
          <p className="mt-2 text-center text-[10px] muted">{cycles} sessions completed today</p>
        </div>
      ) : null}

      <button
        onClick={() => setOpen((o) => !o)}
        className="grid h-13 w-13 place-items-center rounded-full brand-bg p-4 text-xl text-white shadow-2xl transition hover:scale-110"
        aria-label="Pomodoro timer"
        title="Pomodoro focus timer"
      >
        {running ? `${Math.floor(left / 60)}′` : "🍅"}
      </button>
    </div>
  );
}
