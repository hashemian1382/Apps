"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { updateTheme } from "@/lib/actions";
import { PomodoroFab } from "@/components/PomodoroFab";
import { SearchCommand } from "@/components/SearchCommand";

type NavItem = { href: string; label: string; icon: string; badge?: number };
type NavGroup = { label?: string; items: NavItem[] };

export function AppShell({
  user,
  dueCount,
  children,
}: {
  user: { name: string; streak: number; xp: number; level: number; rank: string; icon: string; theme: string };
  dueCount: number;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [open, setOpen] = useState(false);
  const [theme, setTheme] = useState(user.theme);

  useEffect(() => setOpen(false), [pathname]);

  const groups: NavGroup[] = useMemo(
    () => [
      { items: [{ href: "/", label: "Dashboard", icon: "🏠" }] },
      {
        label: "General English",
        items: [
          { href: "/general", label: "Overview", icon: "📚" },
          { href: "/grammar", label: "Grammar", icon: "📝" },
          { href: "/vocabulary", label: "Vocabulary", icon: "🔤" },
          { href: "/reading", label: "Reading", icon: "📖" },
          { href: "/listening", label: "Listening", icon: "🎧" },
          { href: "/writing", label: "Writing", icon: "✍️" },
          { href: "/speaking", label: "Speaking", icon: "🗣️" },
        ],
      },
      {
        label: "Technical English",
        items: [
          { href: "/tech", label: "CS Hub", icon: "💻" },
          { href: "/vocabulary?deck=tech", label: "Tech Vocab", icon: "🧩" },
          { href: "/reading?module=tech", label: "Docs & Papers", icon: "📄" },
          { href: "/speaking?module=tech", label: "Interview Prep", icon: "💬" },
        ],
      },
      {
        label: "TOEFL",
        items: [
          { href: "/toefl", label: "Prep Center", icon: "🎯" },
          { href: "/reading?module=toefl", label: "TOEFL Reading", icon: "📘" },
          { href: "/listening?module=toefl", label: "TOEFL Listening", icon: "🎙️" },
          { href: "/toefl/mock", label: "Mock Tests", icon: "📋" },
        ],
      },
      {
        items: [
          { href: "/review", label: "Smart Review", icon: "🧠", badge: dueCount },
          { href: "/games", label: "Games", icon: "🎮" },
          { href: "/progress", label: "Progress", icon: "📊" },
          { href: "/library", label: "Library", icon: "📕" },
          { href: "/notes", label: "My Notes", icon: "📌" },
        ],
      },
      { items: [{ href: "/settings", label: "Settings", icon: "⚙️" }] },
    ],
    [dueCount],
  );

  async function toggleTheme() {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.setAttribute("data-theme", next);
    await updateTheme(next);
  }

  const isActive = (href: string) => {
    const [clean, queryString] = href.split("?");
    if (clean === "/") return pathname === "/";
    if (pathname.startsWith(clean + "/")) return !queryString;
    if (pathname !== clean) return false;
    if (queryString) {
      const expected = new URLSearchParams(queryString);
      return Array.from(expected.entries()).every(([key, value]) => searchParams.get(key) === value);
    }
    if (clean === "/reading" || clean === "/listening" || clean === "/writing" || clean === "/speaking") {
      return !searchParams.get("module");
    }
    if (clean === "/vocabulary") return !searchParams.get("deck");
    return true;
  };

  return (
    <div className="min-h-screen lg:flex">
      <a href="#main-content" className="fixed left-3 top-3 z-[100] -translate-y-20 rounded-xl brand-bg px-4 py-2 text-sm font-bold text-white transition focus:translate-y-0">
        Skip to main content
      </a>
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-[272px] overflow-y-auto scroll-thin border-r px-4 py-5 transition-transform lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
        style={{ borderColor: "var(--border)", background: "var(--card-2)" }}
      >
        <Link href="/" className="mb-6 flex items-center gap-3 px-2">
          <span className="grid h-10 w-10 place-items-center rounded-xl brand-bg text-lg shadow-lg">🎓</span>
          <span>
            <span className="block text-lg font-extrabold tracking-tight">EngMaster</span>
            <span className="block text-[11px] muted">English · Tech · TOEFL</span>
          </span>
        </Link>

        <nav className="space-y-5 pb-24">
          {groups.map((group, gi) => (
            <div key={gi}>
              {group.label ? (
                <p className="mb-1.5 px-3 text-[10px] font-bold uppercase tracking-[0.14em] muted">{group.label}</p>
              ) : null}
              <ul className="space-y-0.5">
                {group.items.map((item) => {
                  const active = isActive(item.href);
                  return (
                    <li key={item.href + item.label}>
                      <Link
                        href={item.href}
                        aria-current={active ? "page" : undefined}
                        className={`group flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition ${
                          active ? "brand-bg text-white shadow-lg" : "hover:bg-[color-mix(in_srgb,var(--text)_7%,transparent)]"
                        }`}
                      >
                        <span className="text-base">{item.icon}</span>
                        <span className="flex-1 truncate">{item.label}</span>
                        {item.badge ? (
                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                              active ? "bg-white/25" : "bg-[color-mix(in_srgb,var(--brand)_18%,transparent)] text-[var(--brand)]"
                            }`}
                          >
                            {item.badge}
                          </span>
                        ) : null}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        <div className="card absolute bottom-4 left-4 right-4 p-3">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-base">{user.icon}</span>
            <div className="flex-1">
              <p className="font-bold">Level {user.level}</p>
              <p className="muted text-[10px]">{user.rank}</p>
            </div>
            <span className="chip">🔥 {user.streak}</span>
          </div>
        </div>
      </aside>

      {open ? <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setOpen(false)} /> : null}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col lg:ml-[272px]">
        <header
          className="sticky top-0 z-20 flex items-center gap-3 border-b px-4 py-3 backdrop-blur-xl"
          style={{ borderColor: "var(--border)", background: "color-mix(in srgb, var(--bg) 78%, transparent)" }}
        >
          <button className="btn btn-ghost px-2 py-1.5 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            ☰
          </button>

          <SearchCommand />

          <div className="ml-auto flex items-center gap-2">
            <span className="chip hidden sm:inline-flex">🔥 {user.streak} days</span>
            <span className="chip hidden md:inline-flex">🏆 {user.xp.toLocaleString()} XP</span>
            <Link href="/review" className="btn btn-primary hidden px-3 py-1.5 text-xs sm:inline-flex">
              🧠 Review {dueCount}
            </Link>
            <button className="btn btn-ghost px-2.5 py-1.5" onClick={toggleTheme} aria-label="Toggle theme">
              {theme === "dark" ? "🌙" : "☀️"}
            </button>
            <Link href="/settings" className="grid h-9 w-9 place-items-center rounded-full brand-bg text-sm font-bold text-white">
              {user.name.slice(0, 1).toUpperCase()}
            </Link>
          </div>
        </header>

        <main id="main-content" className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 pb-28 sm:px-6 lg:pb-8">{children}</main>

        <footer className="hidden px-6 py-6 text-center text-xs muted lg:block">
          <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-emerald-500" />
          EngMaster · PostgreSQL persistence · Real progress tracking
        </footer>

        <nav className="fixed inset-x-3 bottom-3 z-30 grid grid-cols-5 rounded-2xl border p-1.5 shadow-2xl backdrop-blur-xl lg:hidden" style={{ borderColor: "var(--border)", background: "color-mix(in srgb,var(--card-solid) 88%,transparent)" }} aria-label="Mobile navigation">
          {[
            { href: "/", icon: "⌂", label: "Home" },
            { href: "/review", icon: "🧠", label: "Review" },
            { href: "/games", icon: "🎮", label: "Games" },
            { href: "/progress", icon: "📊", label: "Progress" },
            { href: "/settings", icon: "⚙", label: "Settings" },
          ].map((item) => {
            const active = isActive(item.href);
            return (
              <Link key={item.href} href={item.href} aria-current={active ? "page" : undefined} className="flex flex-col items-center rounded-xl px-1 py-2 text-[9px] font-semibold transition" style={{ color: active ? "var(--brand)" : "var(--muted)", background: active ? "color-mix(in srgb,var(--brand) 10%,transparent)" : "transparent" }}>
                <span className="mb-0.5 text-base">{item.icon}</span>{item.label}
              </Link>
            );
          })}
        </nav>
        <PomodoroFab />
      </div>
    </div>
  );
}
