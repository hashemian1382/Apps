import { db } from "@/db";
import { users } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const startedAt = performance.now();
  try {
    await db.execute(sql`select 1`);
    const [catalogue] = await db.select({ users: sql<number>`count(*)::int` }).from(users);
    return Response.json(
      {
        ok: true,
        service: "engmaster-web",
        database: "ready",
        initialised: (catalogue?.users ?? 0) > 0,
        latencyMs: Math.round(performance.now() - startedAt),
        uptimeSeconds: Math.round(process.uptime()),
        timestamp: new Date().toISOString(),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json(
      {
        ok: false,
        service: "engmaster-web",
        database: "unavailable",
        timestamp: new Date().toISOString(),
      },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  }
}
