import { and, eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { userWords, words } from "@/db/schema";
import { getUser } from "@/lib/data";
import { extractImportWords } from "@/lib/importer";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return NextResponse.json({ ok: false, error: "Choose a CSV or JSON file." }, { status: 400 });
    if (file.size > 2_000_000) return NextResponse.json({ ok: false, error: "File exceeds the 2 MB limit." }, { status: 413 });
    if (!/\.(csv|json)$/i.test(file.name)) return NextResponse.json({ ok: false, error: "Only .csv and .json files are accepted." }, { status: 415 });

    const imported = extractImportWords(await file.text(), file.name);
    const user = await getUser();
    let created = 0;
    let linked = 0;

    await db.transaction(async (tx) => {
      for (const item of imported) {
        const [existing] = await tx
          .select()
          .from(words)
          .where(and(sql`lower(${words.word}) = lower(${item.word})`, eq(words.deck, item.deck)))
          .limit(1);
        const word = existing ?? (
          await tx
            .insert(words)
            .values({
              word: item.word,
              pos: item.pos,
              definitionEn: item.definitionEn,
              definitionFa: item.definitionFa,
              examples: item.example ? [item.example] : [],
              deck: item.deck,
              topic: item.topic,
              level: "B1",
              difficulty: 2,
            })
            .returning()
        )[0];
        if (!existing) created += 1;
        const relation = await tx
          .insert(userWords)
          .values({ userId: user.id, wordId: word.id, dueAt: new Date() })
          .onConflictDoNothing()
          .returning({ id: userWords.id });
        if (relation.length > 0) linked += 1;
      }
    });

    return NextResponse.json({ ok: true, rows: imported.length, created, linked });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Import failed.";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
