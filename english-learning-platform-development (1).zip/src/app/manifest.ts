import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "EngMaster — English Learning Studio",
    short_name: "EngMaster",
    description: "General English, Technical English and TOEFL preparation with real progress tracking.",
    start_url: "/",
    display: "standalone",
    background_color: "#070b1a",
    theme_color: "#4f46e5",
    orientation: "any",
    categories: ["education", "productivity"],
  };
}
