import Link from "next/link";
import { getListeningLogs, getUser, listTracks } from "@/lib/data";
import { Card, Chip, PageHeader } from "@/components/ui";

export const dynamic = "force-dynamic";

const MODULES = [
  { key: "", label: "All audio", icon: "🎧" },
  { key: "general", label: "General", icon: "🎙️" },
  { key: "tech", label: "Tech", icon: "💻" },
  { key: "toefl", label: "TOEFL", icon: "🎯" },
];

export default async function ListeningPage({ searchParams }: { searchParams: Promise<{ module?: string }> }) {
  const sp = await searchParams;
  const user = await getUser();
  const [items, logs] = await Promise.all([listTracks(sp.module), getListeningLogs(user.id)]);
  const average = logs.length ? Math.round(logs.reduce((sum, item) => sum + (item.log.total > 0 ? (item.log.score / item.log.total) * 100 : 0), 0) / logs.length) : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        icon="🎧"
        title="Listening"
        subtitle="Conversations, academic lectures, podcasts and dictation drills with 0.5×–2× speed control and hidden transcripts."
        meta={
          <>
            <Chip>{items.length} audio items</Chip>
            <Chip color="#10B981">{logs.length} completed · {average || "—"}% avg</Chip>
            <Chip color="#8B5CF6">saved attempt history</Chip>
          </>
        }
      />

      <div className="flex flex-wrap gap-2">
        {MODULES.map((m) => (
          <Link key={m.key} href={m.key ? `/listening?module=${m.key}` : "/listening"} className={`btn px-3 py-1.5 text-xs ${(sp.module ?? "") === m.key ? "btn-primary" : "btn-ghost"}`}>
            {m.icon} {m.label}
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
        <div className="grid gap-3 sm:grid-cols-2">
          {items.map((t) => (
            <Link key={t.id} href={`/listening/${t.slug}`} className="card p-5 transition hover:-translate-y-1 hover:shadow-xl">
              <div className="flex items-center gap-2">
                <span className="chip">{t.kind}</span>
                <span className="ml-auto text-[11px] muted">⏱ {t.minutes}m</span>
              </div>
              <h3 className="mt-3 text-base font-bold leading-snug">{t.title}</h3>
              <p className="mt-1 text-xs muted">{t.level} · {t.transcript.length} segments · {t.questions.length} questions</p>
              <p className="mt-2 line-clamp-2 text-xs muted">{t.transcript[0]?.text}</p>
            </Link>
          ))}
        </div>

        <aside className="space-y-4">
          <Card title="Listening Skills" icon="🎯">
            <ul className="space-y-1.5 text-xs muted">
              <li>▸ Note-taking practice (Cornell / two-column)</li>
              <li>▸ Detail catching &amp; number accuracy</li>
              <li>▸ Main idea recognition</li>
              <li>▸ Speaker attitude &amp; tone</li>
              <li>▸ Dictation exercises</li>
            </ul>
          </Card>
          <Card title="Recent Attempts" icon="📈">
            {logs.length > 0 ? (
              <ul className="space-y-2">
                {logs.slice(0, 6).map((item) => (
                  <li key={item.log.id} className="rounded-lg px-2 py-1.5" style={{ background: "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                    <p className="truncate text-xs font-semibold">{item.track.title}</p>
                    <p className="text-[10px] muted">{item.log.score}/{item.log.total} · dictation {item.log.accuracy}% · {new Date(item.log.createdAt).toLocaleDateString()}</p>
                  </li>
                ))}
              </ul>
            ) : <p className="text-xs muted">Complete a track to start your real history.</p>}
          </Card>
          <Card title="Tools" icon="🔧">
            <ul className="space-y-1.5 text-xs muted">
              <li>▸ Speed controller (0.5× – 2×)</li>
              <li>▸ Replay any single line</li>
              <li>▸ Transcript toggle after first attempt</li>
              <li>▸ Dictation accuracy saved per attempt</li>
            </ul>
          </Card>
        </aside>
      </div>
    </div>
  );
}
