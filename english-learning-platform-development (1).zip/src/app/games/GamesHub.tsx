"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { saveGameScore } from "@/lib/actions";
import { Card, Chip } from "@/components/ui";
import { speakText } from "@/components/Speak";

export type GameWord = { id: number; word: string; definitionEn: string; definitionFa: string; examples: string[] };

const GRAMMAR_QUESTIONS = [
  { q: "If I ___ you, I would apply now.", o: ["was", "were", "am", "be"], a: "were" },
  { q: "She ___ here since 2019.", o: ["works", "is working", "has worked", "worked"], a: "has worked" },
  { q: "The report ___ yesterday.", o: ["was written", "was wrote", "is written", "writes"], a: "was written" },
  { q: "Never ___ such a clean codebase.", o: ["I have seen", "have I seen", "I saw", "did I saw"], a: "have I seen" },
  { q: "Each of the students ___ a laptop.", o: ["have", "has", "are having", "were"], a: "has" },
  { q: "He asked me where I ___.", o: ["live", "lived", "do live", "am living"], a: "lived" },
  { q: "Python, ___ was released in 1991, is popular.", o: ["that", "which", "who", "what"], a: "which" },
  { q: "It took me ___ hour to finish.", o: ["a", "an", "the", "—"], a: "an" },
  { q: "Not only ___ he write code, but he also teaches.", o: ["do", "does", "did", "is"], a: "does" },
  { q: "I look forward to ___ from you.", o: ["hear", "hearing", "heard", "be heard"], a: "hearing" },
];

type GameKey = "word-match" | "speed-quiz" | "sentence-builder" | "dictation-race" | "word-chain" | "grammar-arena";

const GAMES: { key: GameKey; name: string; icon: string; desc: string; color: string }[] = [
  { key: "word-match", name: "Word Match", icon: "🔤", desc: "Match each word to its definition against the clock.", color: "#4F46E5" },
  { key: "speed-quiz", name: "Speed Vocab Quiz", icon: "⏱️", desc: "60 seconds — how many meanings can you nail?", color: "#06B6D4" },
  { key: "sentence-builder", name: "Sentence Builder", icon: "📝", desc: "Rebuild scrambled sentences word by word.", color: "#10B981" },
  { key: "dictation-race", name: "Dictation Race", icon: "🎧", desc: "Listen and type exactly what you hear.", color: "#F59E0B" },
  { key: "word-chain", name: "Word Chain", icon: "🔗", desc: "Each word starts with the previous word's last letter.", color: "#8B5CF6" },
  { key: "grammar-arena", name: "Grammar Arena", icon: "🎪", desc: "Rapid-fire grammar questions, no second chances.", color: "#EF4444" },
];

function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

export function GamesHub({ words }: { words: GameWord[] }) {
  const [active, setActive] = useState<GameKey | null>(null);

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {GAMES.map((g) => (
          <button
            key={g.key}
            onClick={() => setActive(g.key)}
            className="card group p-5 text-left transition hover:-translate-y-1 hover:shadow-xl"
            style={{ borderColor: active === g.key ? g.color : "var(--border)" }}
          >
            <span className="grid h-11 w-11 place-items-center rounded-xl text-xl" style={{ background: `color-mix(in srgb, ${g.color} 20%, transparent)` }}>
              {g.icon}
            </span>
            <h3 className="mt-3 text-sm font-bold">{g.name}</h3>
            <p className="mt-1 text-xs muted">{g.desc}</p>
            <span className="mt-3 inline-block text-xs font-bold" style={{ color: g.color }}>
              {active === g.key ? "Playing ↓" : "Play →"}
            </span>
          </button>
        ))}
      </div>

      {active === "word-match" ? <WordMatch words={words} /> : null}
      {active === "speed-quiz" ? <SpeedQuiz words={words} /> : null}
      {active === "sentence-builder" ? <SentenceBuilder words={words} /> : null}
      {active === "dictation-race" ? <DictationRace words={words} /> : null}
      {active === "word-chain" ? <WordChain words={words} /> : null}
      {active === "grammar-arena" ? <GrammarArena /> : null}
    </div>
  );
}

function useCountdown(initial: number, running: boolean, onEnd: () => void) {
  const [left, setLeft] = useState(initial);
  const cb = useRef(onEnd);
  cb.current = onEnd;
  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => {
      setLeft((l) => {
        if (l <= 1) {
          clearInterval(t);
          cb.current();
          return 0;
        }
        return l - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [running]);
  return [left, setLeft] as const;
}

function WordMatch({ words }: { words: GameWord[] }) {
  const [round, setRound] = useState(0);
  const pool = useMemo(() => shuffle(words).slice(0, 5), [words, round]);
  const [defs, setDefs] = useState(() => shuffle(pool));
  const [picked, setPicked] = useState<number | null>(null);
  const [matched, setMatched] = useState<number[]>([]);
  const [wrong, setWrong] = useState(0);
  const [running, setRunning] = useState(true);
  const [left, setLeft] = useCountdown(60, running, () => setRunning(false));

  useEffect(() => setDefs(shuffle(pool)), [pool]);

  useEffect(() => {
    if (matched.length === pool.length && pool.length > 0) {
      setRunning(false);
      void saveGameScore("word-match", Math.max(10, left * 10 - wrong * 20), Math.round((pool.length / (pool.length + wrong)) * 100));
    }
  }, [matched, pool.length, left, wrong]);

  return (
    <Card title="🔤 Word Match" icon="" action={<Chip color={left < 15 ? "#EF4444" : "#10B981"}>⏱ {left}s</Chip>}>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          {pool.map((w) => (
            <button
              key={w.id}
              disabled={matched.includes(w.id)}
              onClick={() => setPicked(w.id)}
              className="w-full rounded-xl border px-3 py-2 text-left text-sm transition"
              style={{
                borderColor: matched.includes(w.id) ? "#10B981" : picked === w.id ? "var(--brand)" : "var(--border)",
                background: matched.includes(w.id) ? "color-mix(in srgb,#10B981 14%,transparent)" : picked === w.id ? "color-mix(in srgb,var(--brand) 12%,transparent)" : "transparent",
                opacity: matched.includes(w.id) ? 0.6 : 1,
              }}
            >
              {w.word}
            </button>
          ))}
        </div>
        <div className="space-y-2">
          {defs.map((d) => (
            <button
              key={d.id}
              disabled={matched.includes(d.id)}
              onClick={() => {
                if (picked === null) return;
                if (picked === d.id) setMatched((m) => [...m, d.id]);
                else setWrong((w) => w + 1);
                setPicked(null);
              }}
              className="w-full rounded-xl border px-3 py-2 text-left text-xs transition"
              style={{
                borderColor: matched.includes(d.id) ? "#10B981" : "var(--border)",
                opacity: matched.includes(d.id) ? 0.5 : 1,
              }}
            >
              {d.definitionEn}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-3 flex items-center gap-2 text-xs">
        <Chip color="#10B981">✓ {matched.length}/{pool.length}</Chip>
        <Chip color="#EF4444">✗ {wrong}</Chip>
        <button className="btn btn-ghost ml-auto px-3 py-1 text-xs" onClick={() => { setRound((r) => r + 1); setMatched([]); setPicked(null); setWrong(0); setLeft(60); setRunning(true); }}>
          ↻ New round
        </button>
      </div>
      {matched.length === pool.length ? <p className="mt-2 text-center font-bold" style={{ color: "#10B981" }}>🎉 All matched! Score saved.</p> : null}
    </Card>
  );
}

function SpeedQuiz({ words }: { words: GameWord[] }) {
  const [running, setRunning] = useState(true);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [left, setLeft] = useCountdown(60, running, () => {
    setRunning(false);
    void saveGameScore("speed-quiz", score, attempts ? Math.round((score / attempts) * 100) : 0);
  });
  const deck = useMemo(() => shuffle(words), [words]);
  const current = deck[index % deck.length];
  const options = useMemo(() => {
    const others = shuffle(deck.filter((w) => w.id !== current?.id)).slice(0, 3);
    return shuffle([current, ...others]);
  }, [current, deck]);

  if (!current) return null;

  return (
    <Card title="⏱️ Speed Vocab Quiz" action={<Chip color={left < 15 ? "#EF4444" : "#06B6D4"}>⏱ {left}s</Chip>}>
      {running ? (
        <>
          <p className="text-center text-2xl font-extrabold brand-text">{current.word}</p>
          <div className="mt-4 grid gap-2">
            {options.map((o) => (
              <button
                key={o.id}
                className="rounded-xl border px-3 py-2 text-left text-xs transition hover:ring-brand"
                style={{ borderColor: "var(--border)" }}
                onClick={() => {
                  setAttempts((a) => a + 1);
                  if (o.id === current.id) setScore((s) => s + 1);
                  setIndex((i) => i + 1);
                }}
              >
                {o.definitionEn}
              </button>
            ))}
          </div>
          <p className="mt-3 text-center text-xs muted">Score: {score} · Attempts: {attempts}</p>
        </>
      ) : (
        <div className="grid place-items-center gap-2 py-8 text-center">
          <span className="text-4xl">🏁</span>
          <p className="text-lg font-extrabold">{score} correct in 60 seconds</p>
          <p className="text-xs muted">Accuracy {attempts ? Math.round((score / attempts) * 100) : 0}%</p>
          <button className="btn btn-primary mt-2" onClick={() => { setScore(0); setAttempts(0); setIndex(0); setLeft(60); setRunning(true); }}>↻ Play again</button>
        </div>
      )}
    </Card>
  );
}

function SentenceBuilder({ words }: { words: GameWord[] }) {
  const sentences = useMemo(() => words.filter((w) => w.examples.length > 0).map((w) => w.examples[0]), [words]);
  const [i, setI] = useState(0);
  const target = sentences[i % Math.max(1, sentences.length)] ?? "Practice makes perfect";
  const [pool, setPool] = useState(() => shuffle(target.split(" ")));
  const [built, setBuilt] = useState<string[]>([]);
  const won = built.join(" ") === target;

  useEffect(() => {
    setPool(shuffle(target.split(" ")));
    setBuilt([]);
  }, [target]);

  useEffect(() => {
    if (won) void saveGameScore("sentence-builder", 100, 100);
  }, [won]);

  return (
    <Card title="📝 Sentence Builder">
      <div className="min-h-[56px] rounded-xl border border-dashed p-3 text-sm" style={{ borderColor: "var(--border)" }}>
        {built.length === 0 ? <span className="muted">Click words in the right order…</span> : built.join(" ")}
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {pool.map((w, idx) => (
          <button key={w + idx} className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => { setBuilt((b) => [...b, w]); setPool((p) => p.filter((_, x) => x !== idx)); }}>
            {w}
          </button>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => { setPool(shuffle(target.split(" "))); setBuilt([]); }}>↺ Reset</button>
        <button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => setI((x) => x + 1)}>⏭ Next sentence</button>
        {won ? <span className="ml-auto text-sm font-bold" style={{ color: "#10B981" }}>🎉 Correct!</span> : null}
      </div>
    </Card>
  );
}

function DictationRace({ words }: { words: GameWord[] }) {
  const sentences = useMemo(() => words.filter((w) => w.examples.length > 0).map((w) => w.examples[0]), [words]);
  const [i, setI] = useState(0);
  const target = sentences[i % Math.max(1, sentences.length)] ?? "Listening practice improves comprehension.";
  const [typed, setTyped] = useState("");
  const [checked, setChecked] = useState(false);

  const accuracy = (() => {
    const a = typed.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean);
    const b = target.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean);
    let hit = 0;
    b.forEach((w, idx) => {
      if (a[idx] === w) hit += 1;
    });
    return Math.round((hit / Math.max(1, b.length)) * 100);
  })();

  return (
    <Card title="🎧 Dictation Race">
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary px-3 py-1.5 text-xs" onClick={() => speakText(target, "US", 0.9)}>▶️ Play sentence</button>
        <button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => speakText(target, "US", 0.6)}>🐢 Slow</button>
        <button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => { setI((x) => x + 1); setTyped(""); setChecked(false); }}>⏭ Next</button>
      </div>
      <textarea className="input mt-3 min-h-[90px] text-sm" placeholder="Type what you hear…" value={typed} onChange={(e) => setTyped(e.target.value)} />
      <div className="mt-2 flex items-center gap-2">
        <button
          className="btn btn-primary px-3 py-1 text-xs"
          onClick={() => { setChecked(true); void saveGameScore("dictation-race", accuracy, accuracy); }}
        >
          ✅ Check
        </button>
        {checked ? (
          <>
            <Chip color={accuracy > 80 ? "#10B981" : "#F59E0B"}>{accuracy}% accurate</Chip>
            <span className="text-xs muted">{target}</span>
          </>
        ) : null}
      </div>
    </Card>
  );
}

function WordChain({ words }: { words: GameWord[] }) {
  const [chain, setChain] = useState<string[]>(["engineer"]);
  const [input, setInput] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const vocab = useMemo(() => new Set(words.map((w) => w.word.toLowerCase())), [words]);
  const last = chain[chain.length - 1];
  const needed = last[last.length - 1];

  function submit() {
    const w = input.trim().toLowerCase();
    if (!w) return;
    if (w[0] !== needed) {
      setMessage(`Must start with “${needed.toUpperCase()}”`);
    } else if (chain.includes(w)) {
      setMessage("Already used!");
    } else {
      setChain((c) => [...c, w]);
      setMessage(vocab.has(w) ? "✨ Bonus: that word is in your deck!" : null);
      void saveGameScore("word-chain", chain.length + 1, 100);
    }
    setInput("");
  }

  return (
    <Card title="🔗 Word Chain">
      <p className="text-xs muted">Next word must start with <strong className="brand-text">{needed.toUpperCase()}</strong>. Chain length: {chain.length}</p>
      <div className="my-3 flex flex-wrap gap-1.5">
        {chain.map((c, i) => (
          <span key={c + i} className="chip">{c}</span>
        ))}
      </div>
      <div className="flex gap-2">
        <input className="input" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="Your word…" />
        <button className="btn btn-primary px-4" onClick={submit}>Add</button>
      </div>
      {message ? <p className="mt-2 text-xs" style={{ color: message.startsWith("✨") ? "#10B981" : "#EF4444" }}>{message}</p> : null}
    </Card>
  );
}

function GrammarArena() {
  const deck = useMemo(() => shuffle(GRAMMAR_QUESTIONS), []);
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const done = i >= deck.length;

  useEffect(() => {
    if (done) void saveGameScore("grammar-arena", score, Math.round((score / deck.length) * 100));
  }, [done, score, deck.length]);

  if (done) {
    return (
      <Card title="🎪 Grammar Arena">
        <div className="grid place-items-center gap-2 py-8 text-center">
          <span className="text-4xl">🏆</span>
          <p className="text-lg font-extrabold">{score}/{deck.length} correct</p>
          <button className="btn btn-primary mt-2" onClick={() => { setI(0); setScore(0); setFeedback(null); }}>↻ Play again</button>
        </div>
      </Card>
    );
  }

  const q = deck[i];
  return (
    <Card title="🎪 Grammar Arena" action={<Chip>{i + 1}/{deck.length}</Chip>}>
      <p className="text-sm font-semibold">{q.q}</p>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {q.o.map((o) => (
          <button
            key={o}
            className="rounded-xl border px-3 py-2 text-left text-xs transition hover:ring-brand"
            style={{ borderColor: "var(--border)" }}
            onClick={() => {
              const right = o === q.a;
              if (right) setScore((s) => s + 1);
              setFeedback(right ? "✅ Correct!" : `❌ Answer: ${q.a}`);
              window.setTimeout(() => { setFeedback(null); setI((x) => x + 1); }, 700);
            }}
          >
            {o}
          </button>
        ))}
      </div>
      {feedback ? <p className="mt-3 text-center text-sm font-bold">{feedback}</p> : null}
    </Card>
  );
}
