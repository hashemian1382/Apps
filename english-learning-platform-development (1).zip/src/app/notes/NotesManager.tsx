"use client";

import { useMemo, useState } from "react";
import { createNote, deleteNote, updateNote } from "@/lib/actions";
import { Card, Chip } from "@/components/ui";

export type NoteRow = {
  id: number;
  title: string;
  content: string;
  tags: string[];
  refType: string;
  refId: number | null;
  createdAt: string | Date;
  updatedAt: string | Date;
};

const EMPTY = { title: "", content: "", tags: "" };

export function NotesManager({ initialNotes }: { initialNotes: NoteRow[] }) {
  const [notes, setNotes] = useState(initialNotes);
  const [selectedId, setSelectedId] = useState<number | null>(initialNotes[0]?.id ?? null);
  const [draft, setDraft] = useState(() => {
    const first = initialNotes[0];
    return first ? { title: first.title, content: first.content, tags: first.tags.join(", ") } : EMPTY;
  });
  const [query, setQuery] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return notes;
    return notes.filter((note) => `${note.title} ${note.content} ${note.tags.join(" ")}`.toLowerCase().includes(q));
  }, [notes, query]);

  function select(note: NoteRow) {
    setSelectedId(note.id);
    setDraft({ title: note.title, content: note.content, tags: note.tags.join(", ") });
    setMessage(null);
  }

  function addNew() {
    setSelectedId(null);
    setDraft(EMPTY);
    setMessage(null);
  }

  async function save() {
    if (!draft.title.trim() || !draft.content.trim()) {
      setMessage("Title and content are required.");
      return;
    }
    setSaving(true);
    const tags = draft.tags.split(",").map((tag) => tag.trim()).filter(Boolean).slice(0, 10);
    if (selectedId) {
      const result = await updateNote(selectedId, { title: draft.title, content: draft.content, tags });
      if (result.ok) {
        setNotes((all) => all.map((note) => note.id === selectedId ? { ...note, title: draft.title.trim(), content: draft.content.trim(), tags, updatedAt: new Date() } : note));
        setMessage("Note updated ✓");
      }
    } else {
      const result = await createNote({ title: draft.title, content: draft.content, tags });
      const created: NoteRow = {
        id: result.id,
        title: draft.title.trim(),
        content: draft.content.trim(),
        tags,
        refType: "general",
        refId: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      setNotes((all) => [created, ...all]);
      setSelectedId(result.id);
      setMessage("Note created ✓");
    }
    setSaving(false);
  }

  async function remove() {
    if (!selectedId || !window.confirm("Delete this note permanently?")) return;
    const result = await deleteNote(selectedId);
    if (result.ok) {
      const remaining = notes.filter((note) => note.id !== selectedId);
      setNotes(remaining);
      const next = remaining[0];
      setSelectedId(next?.id ?? null);
      setDraft(next ? { title: next.title, content: next.content, tags: next.tags.join(", ") } : EMPTY);
      setMessage("Note deleted.");
    }
  }

  const selected = notes.find((note) => note.id === selectedId);
  const wordCount = draft.content.trim() ? draft.content.trim().split(/\s+/).length : 0;

  return (
    <div className="grid min-h-[620px] gap-4 lg:grid-cols-[300px_1fr]">
      <Card title="All Notes" icon="🗂️" action={<button className="btn btn-primary px-3 py-1 text-xs" onClick={addNew}>＋ New</button>}>
        <input className="input mb-3" placeholder="Search notes…" value={query} onChange={(event) => setQuery(event.target.value)} />
        <div className="max-h-[510px] space-y-2 overflow-y-auto pr-1 scroll-thin">
          {filtered.map((note) => (
            <button
              key={note.id}
              onClick={() => select(note)}
              className="w-full rounded-xl border p-3 text-left transition hover:-translate-y-0.5"
              style={{
                borderColor: selectedId === note.id ? "var(--brand)" : "var(--border)",
                background: selectedId === note.id ? "color-mix(in srgb,var(--brand) 10%,transparent)" : "transparent",
              }}
            >
              <p className="truncate text-sm font-bold">{note.title}</p>
              <p className="mt-1 line-clamp-2 text-[11px] muted">{note.content}</p>
              <div className="mt-2 flex items-center justify-between gap-2">
                <span className="truncate text-[9px] muted">{new Date(note.updatedAt).toLocaleDateString()}</span>
                <span className="truncate text-[9px] muted">{note.tags.slice(0, 2).join(" · ")}</span>
              </div>
            </button>
          ))}
          {filtered.length === 0 ? <p className="py-8 text-center text-xs muted">No notes found.</p> : null}
        </div>
      </Card>

      <Card title={selectedId ? "Edit Note" : "New Note"} icon="📌" action={selected ? <Chip>{selected.refType}</Chip> : undefined}>
        <div className="flex h-full flex-col">
          <input className="input mb-3 text-lg font-bold" placeholder="A clear note title…" value={draft.title} onChange={(event) => setDraft((value) => ({ ...value, title: event.target.value }))} />
          <textarea
            className="input min-h-[410px] flex-1 resize-y font-mono text-sm leading-relaxed"
            placeholder={"Write your note here…\n\nTip: use # headings, - bullets and **emphasis** to keep it scannable."}
            value={draft.content}
            onChange={(event) => setDraft((value) => ({ ...value, content: event.target.value }))}
          />
          <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_auto]">
            <input className="input" placeholder="Tags, separated, by commas" value={draft.tags} onChange={(event) => setDraft((value) => ({ ...value, tags: event.target.value }))} />
            <div className="flex gap-2">
              {selectedId ? <button className="btn px-3 text-xs" style={{ color: "#EF4444" }} onClick={remove}>🗑 Delete</button> : null}
              <button className="btn btn-primary min-w-28" disabled={saving} onClick={save}>{saving ? "Saving…" : "💾 Save"}</button>
            </div>
          </div>
          <div className="mt-2 flex items-center justify-between text-[10px] muted">
            <span>{wordCount} words · autosave is intentionally off to prevent accidental overwrites</span>
            {message ? <span style={{ color: message.includes("required") ? "#EF4444" : "#10B981" }}>{message}</span> : null}
          </div>
        </div>
      </Card>
    </div>
  );
}
