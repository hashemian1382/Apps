import { getUser, listNotes } from "@/lib/data";
import { Chip, PageHeader } from "@/components/ui";
import { NotesManager, type NoteRow } from "./NotesManager";

export const dynamic = "force-dynamic";

export default async function NotesPage() {
  const user = await getUser();
  const notes = await listNotes(user.id);
  const tags = new Set(notes.flatMap((note) => note.tags));

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📌"
        title="My Notes"
        subtitle="A persistent notebook for grammar rules, vocabulary, essay ideas and technical interview reminders."
        meta={
          <>
            <Chip>{notes.length} notes</Chip>
            <Chip color="#8B5CF6">{tags.size} tags</Chip>
            <Chip color="#10B981">stored in PostgreSQL</Chip>
          </>
        }
      />
      <NotesManager initialNotes={notes as unknown as NoteRow[]} />
    </div>
  );
}
