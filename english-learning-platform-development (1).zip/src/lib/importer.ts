import { DECKS, cleanText, oneOf } from "./validation";

export type ImportWord = {
  word: string;
  pos: string;
  definitionEn: string;
  definitionFa: string;
  example: string;
  deck: (typeof DECKS)[number];
  topic: string;
};

export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"' && quoted && next === '"') {
      field += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(field.trim());
      field = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i += 1;
      row.push(field.trim());
      field = "";
      if (row.some(Boolean)) rows.push(row);
      row = [];
    } else {
      field += char;
    }
  }
  row.push(field.trim());
  if (row.some(Boolean)) rows.push(row);
  if (rows.length < 2) return [];

  const headers = rows[0].map((header) => header.toLowerCase().replace(/\s+/g, "_"));
  return rows.slice(1).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])),
  );
}

function normaliseRow(input: unknown): ImportWord {
  if (!input || typeof input !== "object") throw new Error("Every imported row must be an object.");
  const outer = input as Record<string, unknown>;
  const row = outer.word && typeof outer.word === "object" ? outer.word as Record<string, unknown> : outer;
  const examples = Array.isArray(row.examples) ? row.examples : [];
  const rawDeck = typeof row.deck === "string" && DECKS.includes(row.deck as (typeof DECKS)[number]) ? row.deck : "general";

  return {
    word: cleanText(row.word, "Word", 1, 120),
    pos: typeof row.pos === "string" && row.pos.trim() ? cleanText(row.pos, "Part of speech", 1, 60) : "noun",
    definitionEn: cleanText(row.definitionEn ?? row.definition_en ?? row.meaning, "English definition", 1, 4_000),
    definitionFa: typeof (row.definitionFa ?? row.definition_fa) === "string" ? String(row.definitionFa ?? row.definition_fa).trim().slice(0, 4_000) : "",
    example: typeof row.example === "string" ? row.example.trim().slice(0, 1_000) : typeof examples[0] === "string" ? examples[0].slice(0, 1_000) : "",
    deck: oneOf(rawDeck, "Deck", DECKS),
    topic: typeof row.topic === "string" && row.topic.trim() ? row.topic.trim().slice(0, 64) : "Imported",
  };
}

export function extractImportWords(content: string, fileName: string): ImportWord[] {
  const rawRows: unknown[] = fileName.toLowerCase().endsWith(".csv")
    ? parseCsv(content)
    : (() => {
        const parsed = JSON.parse(content) as unknown;
        if (Array.isArray(parsed)) return parsed;
        if (parsed && typeof parsed === "object" && Array.isArray((parsed as { words?: unknown[] }).words)) return (parsed as { words: unknown[] }).words;
        throw new Error("JSON must be an array or an EngMaster export with a words array.");
      })();

  if (rawRows.length === 0) throw new Error("The file contains no word rows.");
  if (rawRows.length > 2_000) throw new Error("A single import is limited to 2,000 words.");
  return rawRows.map(normaliseRow);
}
