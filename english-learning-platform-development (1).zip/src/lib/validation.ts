export class ValidationError extends Error {
  readonly code = "VALIDATION_ERROR";

  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

export function boundedInteger(value: unknown, name: string, min: number, max: number): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed) || !Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new ValidationError(`${name} must be an integer between ${min} and ${max}.`);
  }
  return parsed;
}

export function boundedNumber(value: unknown, name: string, min: number, max: number): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new ValidationError(`${name} must be between ${min} and ${max}.`);
  }
  return parsed;
}

export function cleanText(value: unknown, name: string, min: number, max: number): string {
  if (typeof value !== "string") throw new ValidationError(`${name} must be text.`);
  const cleaned = value.replace(/\0/g, "").replace(/\r\n/g, "\n").trim();
  if (cleaned.length < min || cleaned.length > max) {
    throw new ValidationError(`${name} must contain ${min}–${max} characters.`);
  }
  return cleaned;
}

export function optionalText(value: unknown, name: string, max: number): string {
  if (value === null || value === undefined || value === "") return "";
  return cleanText(value, name, 0, max);
}

export function oneOf<T extends string>(value: unknown, name: string, allowed: readonly T[]): T {
  if (typeof value !== "string" || !allowed.includes(value as T)) {
    throw new ValidationError(`${name} must be one of: ${allowed.join(", ")}.`);
  }
  return value as T;
}

export function optionalId(value: unknown, name: string): number | null {
  if (value === null || value === undefined || value === "") return null;
  return boundedInteger(value, name, 1, 2_147_483_647);
}

export function isoDate(value: unknown, name: string): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new ValidationError(`${name} must use YYYY-MM-DD format.`);
  }
  const date = new Date(`${value}T12:00:00Z`);
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    throw new ValidationError(`${name} is not a valid calendar date.`);
  }
  return value;
}

export const GRADES = ["again", "hard", "good", "easy"] as const;
export const DECKS = ["general", "academic", "toefl", "tech", "idiom"] as const;
export const GAME_KEYS = ["word-match", "speed-quiz", "sentence-builder", "dictation-race", "word-chain", "grammar-arena"] as const;
export const THEMES = ["light", "dark"] as const;
export const ACCENTS = ["indigo", "green", "purple", "amber"] as const;
export const FONT_SIZES = ["small", "medium", "large"] as const;
export const VOICES = ["US", "UK"] as const;
export const ENGLISH_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"] as const;
export const TECH_LEVELS = ["Junior", "Mid", "Senior"] as const;

export type SettingsInput = {
  name: string;
  englishLevel: (typeof ENGLISH_LEVELS)[number];
  techLevel: (typeof TECH_LEVELS)[number];
  targetScore: number;
  examDate: string | null;
  dailyGoalMinutes: number;
  newWordsPerDay: number;
  reviewsPerDay: number;
  showPersian: boolean;
  theme: (typeof THEMES)[number];
  accent: (typeof ACCENTS)[number];
  fontSize: (typeof FONT_SIZES)[number];
  voice: (typeof VOICES)[number];
  autoPlayAudio: boolean;
  soundEffects: boolean;
  reminderTime: string;
};

export function parseSettings(input: unknown): SettingsInput {
  if (!input || typeof input !== "object") throw new ValidationError("Settings payload is required.");
  const data = input as Record<string, unknown>;
  const reminderTime = cleanText(data.reminderTime, "Reminder time", 5, 5);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(reminderTime)) {
    throw new ValidationError("Reminder time must use 24-hour HH:MM format.");
  }
  return {
    name: cleanText(data.name, "Name", 1, 120),
    englishLevel: oneOf(data.englishLevel, "English level", ENGLISH_LEVELS),
    techLevel: oneOf(data.techLevel, "Technical level", TECH_LEVELS),
    targetScore: boundedInteger(data.targetScore, "TOEFL target score", 0, 120),
    examDate: isoDate(data.examDate, "Exam date"),
    dailyGoalMinutes: boundedInteger(data.dailyGoalMinutes, "Daily goal", 10, 180),
    newWordsPerDay: boundedInteger(data.newWordsPerDay, "New words limit", 1, 100),
    reviewsPerDay: boundedInteger(data.reviewsPerDay, "Review limit", 5, 500),
    showPersian: Boolean(data.showPersian),
    theme: oneOf(data.theme, "Theme", THEMES),
    accent: oneOf(data.accent, "Accent", ACCENTS),
    fontSize: oneOf(data.fontSize, "Font size", FONT_SIZES),
    voice: oneOf(data.voice, "Voice", VOICES),
    autoPlayAudio: Boolean(data.autoPlayAudio),
    soundEffects: Boolean(data.soundEffects),
    reminderTime,
  };
}
