export type Grade = "again" | "hard" | "good" | "easy";

export type SrsState = {
  ease: number;
  intervalDays: number;
  repetitions: number;
  lapses: number;
  status: string;
};

const MULTIPLIER: Record<Grade, number> = {
  again: 0,
  hard: 1.2,
  good: 2.5,
  easy: 3.5,
};

export function statusFor(intervalDays: number, repetitions: number): string {
  if (repetitions === 0) return "new";
  if (intervalDays < 7) return "learning";
  if (intervalDays < 30) return "young";
  return "mature";
}

/** SM-2 flavoured scheduler: Again→1 day, Hard ×1.2, Good ×2.5, Easy ×3.5 */
export function schedule(state: SrsState, grade: Grade) {
  let { ease, intervalDays, repetitions, lapses } = state;

  if (grade === "again") {
    lapses += 1;
    repetitions = 0;
    ease = Math.max(1.3, ease - 0.2);
    intervalDays = 1;
  } else {
    repetitions += 1;
    if (grade === "hard") ease = Math.max(1.3, ease - 0.15);
    if (grade === "easy") ease = Math.min(3.2, ease + 0.15);
    const base = intervalDays === 0 ? 1 : intervalDays;
    intervalDays = Math.min(365, Math.round(base * MULTIPLIER[grade] * (ease / 2.5) * 10) / 10);
    if (intervalDays < 1) intervalDays = 1;
  }

  const dueAt = new Date(Date.now() + intervalDays * 24 * 60 * 60 * 1000);
  if (grade === "again") dueAt.setTime(Date.now() + 60 * 1000);

  return {
    ease,
    intervalDays,
    repetitions,
    lapses,
    status: grade === "again" ? "learning" : statusFor(intervalDays, repetitions),
    dueAt,
  };
}

export function nextIntervalLabel(state: SrsState, grade: Grade): string {
  if (grade === "again") return "<1 min";
  const next = schedule(state, grade).intervalDays;
  if (next < 1) return "<1 day";
  if (next < 30) return `${Math.round(next)} day${Math.round(next) === 1 ? "" : "s"}`;
  return `${(next / 30).toFixed(1)} mo`;
}

/* ------------------------------- XP / levels ------------------------------- */
export const LEVEL_TIERS: { min: number; max: number; name: string; icon: string }[] = [
  { min: 1, max: 5, name: "Beginner", icon: "🌱" },
  { min: 6, max: 10, name: "Elementary", icon: "🌿" },
  { min: 11, max: 15, name: "Intermediate Scholar", icon: "📖" },
  { min: 16, max: 20, name: "Upper-Intermediate", icon: "📚" },
  { min: 21, max: 25, name: "Advanced", icon: "🎓" },
  { min: 26, max: 30, name: "Expert", icon: "👑" },
  { min: 31, max: 999, name: "Master", icon: "🏆" },
];

export function levelFromXp(xp: number) {
  const level = Math.max(1, Math.floor(xp / 250) + 1);
  const currentFloor = (level - 1) * 250;
  const nextFloor = level * 250;
  const tier = LEVEL_TIERS.find((t) => level >= t.min && level <= t.max) ?? LEVEL_TIERS[0];
  return {
    level,
    xpInLevel: xp - currentFloor,
    xpForLevel: nextFloor - currentFloor,
    progress: Math.round(((xp - currentFloor) / (nextFloor - currentFloor)) * 100),
    rank: tier.name,
    icon: tier.icon,
  };
}
