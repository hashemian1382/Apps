"use server";

import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  articles,
  dailyStats,
  gameScores,
  listeningLogs,
  mockResults,
  notes,
  readingLogs,
  speakingAttempts,
  tasks,
  tracks,
  userLessons,
  userWords,
  users,
  words,
  writings,
} from "@/db/schema";
import { getUser } from "./data";
import { schedule, type Grade } from "./srs";
import { calculateAccuracy, calculateWpm, countWords, sectionTotal } from "./scoring";
import { localIsoDay, yesterdayIso } from "./dates";
import { syncAchievementUnlocks } from "./gamification";
import {
  ACCENTS,
  DECKS,
  FONT_SIZES,
  GAME_KEYS,
  GRADES,
  THEMES,
  boundedInteger,
  boundedNumber,
  cleanText,
  oneOf,
  optionalId,
  optionalText,
  parseSettings,
} from "./validation";

type StatsPatch = Partial<{
  minutes: number;
  wordsLearned: number;
  wordsReviewed: number;
  lessonsCompleted: number;
  quizzes: number;
  xp: number;
  accuracy: number;
}>;

async function bumpStats(userId: number, patch: StatsPatch, checkAchievements = true) {
  const day = localIsoDay();
  const minutes = Math.max(0, Math.round(patch.minutes ?? 0));
  const wordsLearned = Math.max(0, Math.round(patch.wordsLearned ?? 0));
  const wordsReviewed = Math.max(0, Math.round(patch.wordsReviewed ?? 0));
  const lessonsCompleted = Math.max(0, Math.round(patch.lessonsCompleted ?? 0));
  const quizzes = Math.max(0, Math.round(patch.quizzes ?? 0));
  const xp = Math.round(patch.xp ?? 0);
  const accuracy = patch.accuracy === undefined ? null : Math.max(0, Math.min(100, Math.round(patch.accuracy)));

  await db.transaction(async (tx) => {
    await tx
      .insert(dailyStats)
      .values({ userId, day, minutes, wordsLearned, wordsReviewed, lessonsCompleted, quizzes, xp, accuracy: accuracy ?? 0 })
      .onConflictDoUpdate({
        target: [dailyStats.userId, dailyStats.day],
        set: {
          minutes: sql`${dailyStats.minutes} + ${minutes}`,
          wordsLearned: sql`${dailyStats.wordsLearned} + ${wordsLearned}`,
          wordsReviewed: sql`${dailyStats.wordsReviewed} + ${wordsReviewed}`,
          lessonsCompleted: sql`${dailyStats.lessonsCompleted} + ${lessonsCompleted}`,
          quizzes: sql`${dailyStats.quizzes} + ${quizzes}`,
          xp: sql`greatest(0, ${dailyStats.xp} + ${xp})`,
          ...(accuracy === null ? {} : { accuracy }),
        },
      });

    if (xp !== 0) {
      await tx.update(users).set({ totalXp: sql`greatest(0, ${users.totalXp} + ${xp})` }).where(eq(users.id, userId));
    }

    const [user] = await tx.select().from(users).where(eq(users.id, userId)).limit(1);
    if (user && user.lastStudyDate !== day && (minutes > 0 || xp > 0 || wordsReviewed > 0 || quizzes > 0)) {
      const nextStreak = user.lastStudyDate === yesterdayIso() ? user.streak + 1 : 1;
      await tx
        .update(users)
        .set({ streak: nextStreak, longestStreak: Math.max(user.longestStreak, nextStreak), lastStudyDate: day })
        .where(eq(users.id, userId));
    }
  });

  return checkAchievements ? syncAchievementUnlocks(userId) : [];
}

export async function gradeCard(userWordIdInput: number, gradeInput: Grade) {
  const user = await getUser();
  const userWordId = boundedInteger(userWordIdInput, "Card", 1, 2_147_483_647);
  const grade = oneOf(gradeInput, "Grade", GRADES);
  const [row] = await db
    .select()
    .from(userWords)
    .where(and(eq(userWords.id, userWordId), eq(userWords.userId, user.id)))
    .limit(1);
  if (!row) return { ok: false as const, error: "Card not found." };

  const next = schedule(
    { ease: row.ease, intervalDays: row.intervalDays, repetitions: row.repetitions, lapses: row.lapses, status: row.status },
    grade,
  );
  await db
    .update(userWords)
    .set({
      ease: next.ease,
      intervalDays: next.intervalDays,
      repetitions: next.repetitions,
      lapses: next.lapses,
      status: next.status,
      dueAt: next.dueAt,
      lastReviewedAt: new Date(),
      timesCorrect: grade === "again" ? row.timesCorrect : row.timesCorrect + 1,
      timesWrong: grade === "again" ? row.timesWrong + 1 : row.timesWrong,
    })
    .where(and(eq(userWords.id, userWordId), eq(userWords.userId, user.id)));
  await bumpStats(user.id, { wordsReviewed: 1, xp: 5 }, false);
  return { ok: true as const, intervalDays: next.intervalDays, status: next.status };
}

export async function finishReviewSession(cardsInput: number, correctInput: number, secondsInput: number) {
  const user = await getUser();
  const cards = boundedInteger(cardsInput, "Cards reviewed", 0, 500);
  const correct = boundedInteger(correctInput, "Correct cards", 0, cards || 0);
  const seconds = boundedInteger(secondsInput, "Session duration", 0, 86_400);
  const accuracy = calculateAccuracy(correct, cards);
  const unlocked = await bumpStats(user.id, { minutes: Math.max(1, Math.round(seconds / 60)), accuracy, xp: 20 });
  revalidatePath("/");
  revalidatePath("/review");
  return { ok: true as const, accuracy, unlocked };
}

export async function toggleTask(taskIdInput: number) {
  const user = await getUser();
  const taskId = boundedInteger(taskIdInput, "Task", 1, 2_147_483_647);
  const [row] = await db
    .update(tasks)
    .set({ done: sql`not ${tasks.done}` })
    .where(and(eq(tasks.id, taskId), eq(tasks.userId, user.id)))
    .returning();
  if (!row) return { ok: false as const, error: "Task not found." };

  const unlocked = await bumpStats(user.id, { xp: row.done ? row.xp : -row.xp, minutes: row.done ? row.minutes : 0 });
  revalidatePath("/");
  revalidatePath("/games");
  return { ok: true as const, done: row.done, unlocked };
}

export async function saveLessonResult(lessonIdInput: number, scoreInput: number, totalInput: number, progressInput: number) {
  const user = await getUser();
  const lessonId = boundedInteger(lessonIdInput, "Lesson", 1, 2_147_483_647);
  const total = boundedInteger(totalInput, "Question total", 1, 100);
  const score = boundedInteger(scoreInput, "Score", 0, total);
  const progress = boundedInteger(progressInput, "Progress", 0, 100);
  const [existing] = await db
    .select()
    .from(userLessons)
    .where(and(eq(userLessons.userId, user.id), eq(userLessons.lessonId, lessonId)))
    .limit(1);
  const status = progress >= 100 ? "completed" : "in_progress";

  await db
    .insert(userLessons)
    .values({ userId: user.id, lessonId, score, total, progress, status })
    .onConflictDoUpdate({
      target: [userLessons.userId, userLessons.lessonId],
      set: {
        score: sql`greatest(${userLessons.score}, ${score})`,
        total,
        progress: sql`greatest(${userLessons.progress}, ${progress})`,
        status: sql`case when ${userLessons.status} = 'completed' or ${status} = 'completed' then 'completed' else 'in_progress' end`,
        updatedAt: new Date(),
      },
    });

  const firstCompletion = status === "completed" && existing?.status !== "completed";
  const perfect = score === total;
  const xp = firstCompletion ? (perfect ? 100 : 50) : 0;
  const unlocked = await bumpStats(user.id, {
    quizzes: 1,
    lessonsCompleted: firstCompletion ? 1 : 0,
    xp,
    minutes: 8,
    accuracy: calculateAccuracy(score, total),
  });
  revalidatePath("/grammar");
  revalidatePath("/");
  return { ok: true as const, xp, unlocked, alreadyCompleted: !firstCompletion && existing?.status === "completed" };
}

export async function saveReadingLog(articleIdInput: number, scoreInput: number, totalInput: number, _clientWpm: number, secondsInput: number) {
  const user = await getUser();
  const articleId = boundedInteger(articleIdInput, "Article", 1, 2_147_483_647);
  const total = boundedInteger(totalInput, "Question total", 1, 100);
  const score = boundedInteger(scoreInput, "Score", 0, total);
  const seconds = boundedInteger(secondsInput, "Reading duration", 1, 86_400);
  const [article] = await db.select({ wordCount: articles.wordCount }).from(articles).where(eq(articles.id, articleId)).limit(1);
  if (!article) return { ok: false as const, error: "Article not found." };
  const wpm = calculateWpm(article.wordCount, seconds);

  await db.insert(readingLogs).values({ userId: user.id, articleId, score, total, wpm, seconds });
  const unlocked = await bumpStats(user.id, {
    minutes: Math.max(1, Math.round(seconds / 60)),
    xp: 100,
    quizzes: 1,
    accuracy: calculateAccuracy(score, total),
  });
  revalidatePath("/reading");
  revalidatePath("/");
  return { ok: true as const, wpm, unlocked };
}

export async function saveListeningResult(trackIdInput: number, scoreInput: number, totalInput: number, secondsInput: number, dictationAccuracyInput = 0) {
  const user = await getUser();
  const trackId = boundedInteger(trackIdInput, "Track", 1, 2_147_483_647);
  const total = boundedInteger(totalInput, "Question total", 1, 100);
  const score = boundedInteger(scoreInput, "Score", 0, total);
  const seconds = boundedInteger(secondsInput, "Listening duration", 1, 86_400);
  const dictationAccuracy = boundedInteger(dictationAccuracyInput, "Dictation accuracy", 0, 100);
  const [track] = await db.select({ id: tracks.id }).from(tracks).where(eq(tracks.id, trackId)).limit(1);
  if (!track) return { ok: false as const, error: "Listening track not found." };

  await db.insert(listeningLogs).values({ userId: user.id, trackId, score, total, accuracy: dictationAccuracy, seconds });
  const unlocked = await bumpStats(user.id, {
    minutes: Math.max(1, Math.round(seconds / 60)),
    xp: 90,
    quizzes: 1,
    accuracy: calculateAccuracy(score, total),
  });
  revalidatePath("/listening");
  revalidatePath("/progress");
  return { ok: true as const, unlocked };
}

export async function saveWriting(input: { promptId?: number | null; title: string; content: string; taskType: string; seconds: number; selfScore: number }) {
  const user = await getUser();
  const content = cleanText(input.content, "Writing content", 20, 50_000);
  const title = optionalText(input.title, "Title", 240) || "Untitled draft";
  const taskType = cleanText(input.taskType, "Task type", 1, 60);
  const promptId = optionalId(input.promptId, "Prompt");
  const seconds = boundedInteger(input.seconds, "Writing duration", 0, 86_400);
  const selfScore = boundedInteger(input.selfScore, "Self score", 0, 10);
  const wordCount = countWords(content);

  const [created] = await db
    .insert(writings)
    .values({ userId: user.id, promptId, title, content, taskType, wordCount, selfScore, seconds })
    .returning({ id: writings.id });
  const unlocked = await bumpStats(user.id, { minutes: Math.max(1, Math.round(seconds / 60)), xp: 150 });
  revalidatePath("/writing");
  return { ok: true as const, id: created.id, wordCount, unlocked };
}

export async function deleteWriting(writingIdInput: number) {
  const user = await getUser();
  const writingId = boundedInteger(writingIdInput, "Writing", 1, 2_147_483_647);
  const deleted = await db.delete(writings).where(and(eq(writings.id, writingId), eq(writings.userId, user.id))).returning({ id: writings.id });
  revalidatePath("/writing");
  return { ok: deleted.length > 0 };
}

export async function saveSpeaking(promptIdInput: number | null, secondsInput: number, selfScoreInput: number, notesInput: string) {
  const user = await getUser();
  const promptId = optionalId(promptIdInput, "Prompt");
  const seconds = boundedInteger(secondsInput, "Speaking duration", 1, 3_600);
  const selfScore = boundedInteger(selfScoreInput, "Self score", 0, 10);
  const attemptNotes = optionalText(notesInput, "Notes", 4_000) || null;
  await db.insert(speakingAttempts).values({ userId: user.id, promptId, seconds, selfScore, notes: attemptNotes });
  const unlocked = await bumpStats(user.id, { minutes: Math.max(1, Math.round(seconds / 60)), xp: 80 });
  revalidatePath("/speaking");
  return { ok: true as const, unlocked };
}

export async function saveGameScore(gameInput: string, scoreInput: number, accuracyInput: number) {
  const user = await getUser();
  const game = oneOf(gameInput, "Game", GAME_KEYS);
  const score = boundedInteger(scoreInput, "Game score", 0, 1_000_000);
  const accuracy = boundedInteger(accuracyInput, "Accuracy", 0, 100);
  await db.insert(gameScores).values({ userId: user.id, game, score, accuracy });
  const unlocked = await bumpStats(user.id, { xp: Math.max(10, Math.min(250, Math.round(score / 2))), minutes: 3, accuracy });
  revalidatePath("/games");
  return { ok: true as const, unlocked };
}

export async function saveMockResult(input: { testId?: number | null; reading: number; listening: number; speaking: number; writing: number; minutes: number }) {
  const user = await getUser();
  const scores = {
    reading: boundedInteger(input.reading, "Reading score", 0, 30),
    listening: boundedInteger(input.listening, "Listening score", 0, 30),
    speaking: boundedInteger(input.speaking, "Speaking score", 0, 30),
    writing: boundedInteger(input.writing, "Writing score", 0, 30),
  };
  const minutes = boundedInteger(input.minutes, "Test duration", 0, 300);
  const testId = optionalId(input.testId, "Test");
  const total = sectionTotal(scores);
  await db.insert(mockResults).values({ userId: user.id, testId, ...scores, total, minutes });
  const unlocked = await bumpStats(user.id, { minutes, xp: 300 });
  revalidatePath("/toefl");
  revalidatePath("/progress");
  return { ok: true as const, total, unlocked };
}

export async function toggleFavorite(userWordIdInput: number) {
  const user = await getUser();
  const userWordId = boundedInteger(userWordIdInput, "Card", 1, 2_147_483_647);
  const [row] = await db
    .update(userWords)
    .set({ favorite: sql`not ${userWords.favorite}` })
    .where(and(eq(userWords.id, userWordId), eq(userWords.userId, user.id)))
    .returning({ favorite: userWords.favorite });
  revalidatePath("/vocabulary");
  return row ? { ok: true as const, favorite: row.favorite } : { ok: false as const, error: "Card not found." };
}

export async function suspendCard(userWordIdInput: number, suspend: boolean) {
  const user = await getUser();
  const userWordId = boundedInteger(userWordIdInput, "Card", 1, 2_147_483_647);
  const updated = await db
    .update(userWords)
    .set({ status: suspend ? "suspended" : "learning", dueAt: suspend ? undefined : new Date() })
    .where(and(eq(userWords.id, userWordId), eq(userWords.userId, user.id)))
    .returning({ id: userWords.id });
  revalidatePath("/vocabulary");
  return { ok: updated.length > 0 };
}

export async function addWord(input: { word: string; pos: string; definitionEn: string; definitionFa: string; example: string; deck: string; topic: string }) {
  const user = await getUser();
  const term = cleanText(input.word, "Word", 1, 120);
  const pos = optionalText(input.pos, "Part of speech", 60) || "noun";
  const definitionEn = cleanText(input.definitionEn, "English definition", 2, 4_000);
  const definitionFa = optionalText(input.definitionFa, "Persian definition", 4_000);
  const example = optionalText(input.example, "Example", 1_000);
  const deck = oneOf(input.deck, "Deck", DECKS);
  const topic = optionalText(input.topic, "Topic", 64) || "My Words";

  const [existing] = await db
    .select()
    .from(words)
    .where(and(sql`lower(${words.word}) = lower(${term})`, eq(words.deck, deck)))
    .limit(1);
  const wordRow = existing ?? (
    await db
      .insert(words)
      .values({ word: term, pos, definitionEn, definitionFa, examples: example ? [example] : [], deck, topic, level: "B1", difficulty: 2 })
      .returning()
  )[0];

  const linked = await db
    .insert(userWords)
    .values({ userId: user.id, wordId: wordRow.id, dueAt: new Date() })
    .onConflictDoNothing()
    .returning({ id: userWords.id });
  const isNewToUser = linked.length > 0;
  const unlocked = isNewToUser ? await bumpStats(user.id, { wordsLearned: 1, xp: 15 }) : [];
  revalidatePath("/vocabulary");
  revalidatePath("/review");
  return { ok: true as const, id: wordRow.id, userWordId: linked[0]?.id ?? null, created: !existing, linked: isNewToUser, unlocked };
}

export async function updateSettings(input: unknown) {
  const user = await getUser();
  const settings = parseSettings(input);
  await db.update(users).set(settings).where(eq(users.id, user.id));
  revalidatePath("/", "layout");
  return { ok: true as const };
}

export async function updateTheme(themeInput: string) {
  const user = await getUser();
  const theme = oneOf(themeInput, "Theme", THEMES);
  await db.update(users).set({ theme }).where(eq(users.id, user.id));
  revalidatePath("/", "layout");
  return { ok: true as const, theme };
}

export async function updateAppearance(input: { accent?: string; fontSize?: string }) {
  const user = await getUser();
  const values: { accent?: string; fontSize?: string } = {};
  if (input.accent !== undefined) values.accent = oneOf(input.accent, "Accent", ACCENTS);
  if (input.fontSize !== undefined) values.fontSize = oneOf(input.fontSize, "Font size", FONT_SIZES);
  await db.update(users).set(values).where(eq(users.id, user.id));
  revalidatePath("/", "layout");
  return { ok: true as const };
}

export async function logStudyMinutes(minutesInput: number, xpInput = 0) {
  const user = await getUser();
  const minutes = boundedInteger(minutesInput, "Study minutes", 1, 300);
  const xp = boundedInteger(xpInput, "XP", 0, 1_000);
  const unlocked = await bumpStats(user.id, { minutes, xp });
  revalidatePath("/");
  revalidatePath("/progress");
  return { ok: true as const, unlocked };
}

export async function createNote(input: { title: string; content: string; tags?: string[]; refType?: string; refId?: number | null }) {
  const user = await getUser();
  const title = cleanText(input.title, "Note title", 1, 200);
  const content = cleanText(input.content, "Note content", 1, 20_000);
  const tags = (input.tags ?? []).map((tag) => cleanText(tag, "Tag", 1, 30)).slice(0, 10);
  const refType = optionalText(input.refType, "Reference type", 32) || "general";
  const refId = optionalId(input.refId, "Reference");
  const [created] = await db.insert(notes).values({ userId: user.id, title, content, tags, refType, refId }).returning({ id: notes.id });
  revalidatePath("/notes");
  return { ok: true as const, id: created.id };
}

export async function updateNote(noteIdInput: number, input: { title: string; content: string; tags?: string[] }) {
  const user = await getUser();
  const noteId = boundedInteger(noteIdInput, "Note", 1, 2_147_483_647);
  const title = cleanText(input.title, "Note title", 1, 200);
  const content = cleanText(input.content, "Note content", 1, 20_000);
  const tags = (input.tags ?? []).map((tag) => cleanText(tag, "Tag", 1, 30)).slice(0, 10);
  const updated = await db
    .update(notes)
    .set({ title, content, tags, updatedAt: new Date() })
    .where(and(eq(notes.id, noteId), eq(notes.userId, user.id)))
    .returning({ id: notes.id });
  revalidatePath("/notes");
  return { ok: updated.length > 0 };
}

export async function deleteNote(noteIdInput: number) {
  const user = await getUser();
  const noteId = boundedInteger(noteIdInput, "Note", 1, 2_147_483_647);
  const deleted = await db.delete(notes).where(and(eq(notes.id, noteId), eq(notes.userId, user.id))).returning({ id: notes.id });
  revalidatePath("/notes");
  return { ok: deleted.length > 0 };
}
