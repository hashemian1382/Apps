export function countWords(text: string): number {
  return text.trim() ? text.trim().split(/\s+/u).filter(Boolean).length : 0;
}

export function calculateAccuracy(correct: number, total: number): number {
  if (!Number.isFinite(correct) || !Number.isFinite(total) || total <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((correct / total) * 100)));
}

export function calculateWpm(wordCount: number, seconds: number): number {
  if (!Number.isFinite(wordCount) || !Number.isFinite(seconds) || wordCount <= 0 || seconds <= 0) return 0;
  return Math.max(0, Math.min(1200, Math.round(wordCount / (seconds / 60))));
}

export function normaliseAnswer(value: string): string {
  return value
    .normalize("NFKC")
    .toLocaleLowerCase("en-US")
    .replace(/[“”‘’]/g, "'")
    .replace(/[.,!?;:()[\]{}]/g, "")
    .replace(/\s*\/\s*/g, " / ")
    .replace(/\s+/g, " ")
    .trim();
}

const RAW_TO_SCALED = [
  0, 1, 2, 3, 4, 5, 7, 8, 10, 11, 12, 14, 15, 16, 17, 19,
  20, 21, 22, 23, 25, 26, 27, 28, 29, 29, 30, 30, 30, 30, 30,
] as const;

export function rawToScaled(raw: number): number {
  const safe = Math.max(0, Math.min(30, Math.round(Number.isFinite(raw) ? raw : 0)));
  return RAW_TO_SCALED[safe];
}

export function toeflBand(total: number): { label: string; cefr: string; color: string } {
  if (total >= 95) return { label: "Advanced", cefr: "C1", color: "#10B981" };
  if (total >= 72) return { label: "High-Intermediate", cefr: "B2", color: "#06B6D4" };
  if (total >= 42) return { label: "Low-Intermediate", cefr: "B1", color: "#F59E0B" };
  return { label: "Basic", cefr: "A2", color: "#EF4444" };
}

export function sectionTotal(scores: { reading: number; listening: number; speaking: number; writing: number }): number {
  return scores.reading + scores.listening + scores.speaking + scores.writing;
}
