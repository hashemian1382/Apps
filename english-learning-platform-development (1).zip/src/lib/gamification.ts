import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements,
  dailyStats,
  gameScores,
  listeningLogs,
  mockResults,
  readingLogs,
  userAchievements,
  userLessons,
  userWords,
  users,
  words,
  writings,
} from "@/db/schema";
import { levelFromXp } from "./srs";
import { localIsoDay } from "./dates";

export type AchievementMetrics = Record<string, number>;

export async function getAchievementMetrics(userId: number): Promise<AchievementMetrics> {
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return {};

  const [[wordStats], [reads], [essays], [lessonStats], [listens], [games], [mock], [techMature]] = await Promise.all([
    db
      .select({
        studied: sql<number>`sum(case when ${userWords.repetitions} > 0 then 1 else 0 end)::int`,
        mature: sql<number>`sum(case when ${userWords.status} = 'mature' then 1 else 0 end)::int`,
        correct: sql<number>`coalesce(sum(${userWords.timesCorrect}), 0)::int`,
        wrong: sql<number>`coalesce(sum(${userWords.timesWrong}), 0)::int`,
      })
      .from(userWords)
      .where(eq(userWords.userId, userId)),
    db.select({ n: sql<number>`count(*)::int` }).from(readingLogs).where(eq(readingLogs.userId, userId)),
    db.select({ n: sql<number>`count(*)::int` }).from(writings).where(eq(writings.userId, userId)),
    db
      .select({
        completed: sql<number>`sum(case when ${userLessons.status} = 'completed' then 1 else 0 end)::int`,
        perfect: sql<number>`sum(case when ${userLessons.total} > 0 and ${userLessons.score} = ${userLessons.total} then 1 else 0 end)::int`,
      })
      .from(userLessons)
      .where(eq(userLessons.userId, userId)),
    db.select({ n: sql<number>`count(*)::int` }).from(listeningLogs).where(eq(listeningLogs.userId, userId)),
    db.select({ n: sql<number>`count(distinct ${gameScores.game})::int` }).from(gameScores).where(eq(gameScores.userId, userId)),
    db.select({ n: sql<number>`coalesce(max(${mockResults.total}), 0)::int` }).from(mockResults).where(eq(mockResults.userId, userId)),
    db
      .select({ n: sql<number>`count(*)::int` })
      .from(userWords)
      .innerJoin(words, eq(words.id, userWords.wordId))
      .where(and(eq(userWords.userId, userId), eq(words.deck, "tech"), eq(userWords.status, "mature"))),
  ]);

  const totalAnswers = (wordStats?.correct ?? 0) + (wordStats?.wrong ?? 0);
  return {
    xp: user.totalXp,
    streak: user.streak,
    words: wordStats?.studied ?? 0,
    mature: wordStats?.mature ?? 0,
    readings: reads?.n ?? 0,
    writings: essays?.n ?? 0,
    lessons: lessonStats?.completed ?? 0,
    listenings: listens?.n ?? 0,
    games: games?.n ?? 0,
    estimate: mock?.n ?? 0,
    level: levelFromXp(user.totalXp).level,
    accuracy: totalAnswers > 0 ? Math.round(((wordStats?.correct ?? 0) / totalAnswers) * 100) : 0,
    perfect: lessonStats?.perfect ?? 0,
    techMature: techMature?.n ?? 0,
    hidden: new Date().getHours() < 4 ? 1 : 0,
  };
}

/** Persist every newly earned badge exactly once and apply its XP reward atomically. */
export async function syncAchievementUnlocks(userId: number) {
  const metrics = await getAchievementMetrics(userId);
  const [catalogue, unlockedRows] = await Promise.all([
    db.select().from(achievements),
    db.select({ achievementId: userAchievements.achievementId }).from(userAchievements).where(eq(userAchievements.userId, userId)),
  ]);
  const unlockedIds = new Set(unlockedRows.map((row) => row.achievementId));
  const eligible = catalogue.filter((achievement) => !unlockedIds.has(achievement.id) && (metrics[achievement.metric] ?? 0) >= achievement.threshold);
  if (eligible.length === 0) return [];

  const newlyUnlocked: typeof eligible = [];
  await db.transaction(async (tx) => {
    for (const achievement of eligible) {
      const inserted = await tx
        .insert(userAchievements)
        .values({ userId, achievementId: achievement.id })
        .onConflictDoNothing()
        .returning({ id: userAchievements.id });
      if (inserted.length > 0) newlyUnlocked.push(achievement);
    }
    const reward = newlyUnlocked.reduce((sum, achievement) => sum + achievement.xpReward, 0);
    if (reward > 0) {
      await tx.update(users).set({ totalXp: sql`${users.totalXp} + ${reward}` }).where(eq(users.id, userId));
      await tx
        .insert(dailyStats)
        .values({ userId, day: localIsoDay(), xp: reward })
        .onConflictDoUpdate({
          target: [dailyStats.userId, dailyStats.day],
          set: { xp: sql`${dailyStats.xp} + ${reward}` },
        });
    }
  });
  return newlyUnlocked.map(({ id, name, icon, xpReward }) => ({ id, name, icon, xpReward }));
}
