const DAY_MS = 86_400_000;

export function localIsoDay(date = new Date()): string {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 10);
}

export function yesterdayIso(date = new Date()): string {
  return localIsoDay(new Date(date.getTime() - DAY_MS));
}

export function daysUntil(isoDate: string | null, now = new Date()): number | null {
  if (!isoDate) return null;
  const target = new Date(`${isoDate}T12:00:00`);
  const today = new Date(now);
  today.setHours(12, 0, 0, 0);
  return Math.max(0, Math.ceil((target.getTime() - today.getTime()) / DAY_MS));
}

export function formatDuration(minutes: number): string {
  const safe = Math.max(0, Math.round(minutes));
  const hours = Math.floor(safe / 60);
  return hours > 0 ? `${hours}h ${safe % 60}m` : `${safe}m`;
}
