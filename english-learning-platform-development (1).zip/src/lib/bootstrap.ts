import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements,
  articles,
  dailyStats,
  gameScores,
  lessons,
  listeningLogs,
  mockResults,
  mockTests,
  prompts,
  readingLogs,
  resources,
  speakingAttempts,
  tasks,
  tracks,
  userAchievements,
  userLessons,
  userWords,
  users,
  words,
  writings,
} from "@/db/schema";
import { SEED_WORDS } from "./content/words";
import { SEED_LESSONS } from "./content/lessons";
import { SEED_ARTICLES } from "./content/reading";
import { SEED_TRACKS, SEED_PROMPTS, SEED_MOCKS } from "./content/media";
import { SEED_RESOURCES, SEED_ACHIEVEMENTS } from "./content/library";

let bootstrapPromise: Promise<void> | null = null;

function futureIsoDay(offsetDays: number) {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

async function seed() {
  await db.transaction(async (tx) => {
    // Prevent two server instances from racing on first boot.
    await tx.execute(sql`select pg_advisory_xact_lock(44961027)`);
    const existing = await tx.select({ id: users.id }).from(users).limit(1);
    if (existing.length > 0) return;

    const [user] = await tx
      .insert(users)
      .values({
        name: "Learner",
        englishLevel: "B1",
        techLevel: "Mid",
        targetScore: 100,
        examDate: futureIsoDay(60),
        dailyGoalMinutes: 45,
        streak: 0,
        longestStreak: 0,
        totalXp: 0,
        freezeCards: 2,
      })
      .returning();

    const insertedWords = await tx.insert(words).values(SEED_WORDS).returning({ id: words.id });
    await tx.insert(lessons).values(SEED_LESSONS);
    await tx.insert(articles).values(
      SEED_ARTICLES.map((article) => ({
        ...article,
        wordCount: article.paragraphs.join(" ").split(/\s+/).filter(Boolean).length,
      })),
    );
    await tx.insert(tracks).values(SEED_TRACKS);
    await tx.insert(prompts).values(SEED_PROMPTS);
    await tx.insert(mockTests).values(SEED_MOCKS);
    await tx.insert(resources).values(SEED_RESOURCES);
    await tx.insert(achievements).values(SEED_ACHIEVEMENTS);

    // Content is ready for real study immediately; progress starts honestly at zero.
    await tx.insert(userWords).values(
      insertedWords.map((word) => ({
        userId: user.id,
        wordId: word.id,
        ease: 2.5,
        intervalDays: 0,
        repetitions: 0,
        lapses: 0,
        status: "new",
        dueAt: new Date(),
        timesCorrect: 0,
        timesWrong: 0,
        favorite: false,
      })),
    );
  });
}

/** Idempotent and concurrency-safe: safe to call on every request. */
export async function ensureSeeded(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = seed().catch((error) => {
      bootstrapPromise = null;
      throw error;
    });
  }
  return bootstrapPromise;
}

/** Clear user-generated progress while preserving the learning catalogue and notes. */
export async function resetProgress(userId: number) {
  await db.transaction(async (tx) => {
    await tx.delete(dailyStats).where(sql`${dailyStats.userId} = ${userId}`);
    await tx.delete(userLessons).where(sql`${userLessons.userId} = ${userId}`);
    await tx.delete(readingLogs).where(sql`${readingLogs.userId} = ${userId}`);
    await tx.delete(listeningLogs).where(sql`${listeningLogs.userId} = ${userId}`);
    await tx.delete(gameScores).where(sql`${gameScores.userId} = ${userId}`);
    await tx.delete(userAchievements).where(sql`${userAchievements.userId} = ${userId}`);
    await tx.delete(mockResults).where(sql`${mockResults.userId} = ${userId}`);
    await tx.delete(speakingAttempts).where(sql`${speakingAttempts.userId} = ${userId}`);
    await tx.delete(writings).where(sql`${writings.userId} = ${userId}`);
    await tx.delete(tasks).where(sql`${tasks.userId} = ${userId}`);
    await tx
      .update(userWords)
      .set({
        ease: 2.5,
        intervalDays: 0,
        repetitions: 0,
        lapses: 0,
        status: "new",
        dueAt: new Date(),
        lastReviewedAt: null,
        timesCorrect: 0,
        timesWrong: 0,
        favorite: false,
      })
      .where(sql`${userWords.userId} = ${userId}`);
    await tx
      .update(users)
      .set({ totalXp: 0, streak: 0, longestStreak: 0, lastStudyDate: null, freezeCards: 2 })
      .where(sql`${users.id} = ${userId}`);
  });
}
