import { describe, expect, it } from "vitest";
import { calculateAccuracy, calculateWpm, countWords, normaliseAnswer, rawToScaled, sectionTotal, toeflBand } from "@/lib/scoring";

describe("learning metrics", () => {
  it.each([
    ["", 0],
    ["one", 1],
    ["  one   two\nthree ", 3],
    ["فارسی و English", 3],
  ])("counts words in %j", (text, expected) => expect(countWords(text)).toBe(expected));

  it("calculates and clamps accuracy", () => {
    expect(calculateAccuracy(4, 5)).toBe(80);
    expect(calculateAccuracy(9, 5)).toBe(100);
    expect(calculateAccuracy(-1, 5)).toBe(0);
    expect(calculateAccuracy(0, 0)).toBe(0);
  });

  it("calculates WPM from trusted time and word count", () => {
    expect(calculateWpm(300, 120)).toBe(150);
    expect(calculateWpm(142, 60)).toBe(142);
    expect(calculateWpm(100, 0)).toBe(0);
    expect(calculateWpm(10_000, 1)).toBe(1200);
  });

  it("normalises punctuation, case, whitespace and unicode quotes", () => {
    expect(normaliseAnswer("  Have  I seen it? ")).toBe("have i seen it");
    expect(normaliseAnswer("Knew/Would Tell.")).toBe("knew / would tell");
    expect(normaliseAnswer("“Hello” — WORLD!" )).toContain("'hello'");
  });
});

describe("TOEFL scoring", () => {
  it.each([[0, 0], [6, 7], [15, 19], [24, 29], [30, 30], [99, 30], [-4, 0]])("scales raw %s to %s", (raw, scaled) => {
    expect(rawToScaled(raw)).toBe(scaled);
  });

  it("adds the four section scores", () => {
    expect(sectionTotal({ reading: 22, listening: 20, speaking: 18, writing: 18 })).toBe(78);
  });

  it.each([[41, "A2"], [42, "B1"], [72, "B2"], [95, "C1"]])("assigns score %s to %s", (score, cefr) => {
    expect(toeflBand(score).cefr).toBe(cefr);
  });
});
