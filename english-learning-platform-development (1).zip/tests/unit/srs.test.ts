import { describe, expect, it, vi } from "vitest";
import { levelFromXp, nextIntervalLabel, schedule, statusFor, type SrsState } from "@/lib/srs";

const NEW_CARD: SrsState = { ease: 2.5, intervalDays: 0, repetitions: 0, lapses: 0, status: "new" };

describe("spaced repetition scheduler", () => {
  it("schedules Again as an immediate relearning step", () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T12:00:00Z"));
    const result = schedule({ ...NEW_CARD, repetitions: 4, intervalDays: 20, status: "young" }, "again");
    expect(result.intervalDays).toBe(1);
    expect(result.repetitions).toBe(0);
    expect(result.lapses).toBe(1);
    expect(result.status).toBe("learning");
    expect(result.dueAt.getTime() - Date.now()).toBe(60_000);
    vi.useRealTimers();
  });

  it("uses ×1.2 for Hard and lowers ease", () => {
    const result = schedule(NEW_CARD, "hard");
    expect(result.intervalDays).toBe(1.1);
    expect(result.ease).toBeCloseTo(2.35);
    expect(result.repetitions).toBe(1);
  });

  it("uses ×2.5 for Good", () => {
    const result = schedule(NEW_CARD, "good");
    expect(result.intervalDays).toBe(2.5);
    expect(result.ease).toBe(2.5);
  });

  it("uses ×3.5 for Easy and increases ease", () => {
    const result = schedule(NEW_CARD, "easy");
    expect(result.intervalDays).toBe(3.7);
    expect(result.ease).toBeCloseTo(2.65);
  });

  it("never allows ease to fall below 1.3", () => {
    let state = { ...NEW_CARD, ease: 1.35, intervalDays: 10, repetitions: 5 };
    state = { ...state, ...schedule(state, "hard") };
    expect(state.ease).toBe(1.3);
    state = { ...state, ...schedule(state, "again") };
    expect(state.ease).toBe(1.3);
  });

  it("caps long intervals at one year", () => {
    const result = schedule({ ...NEW_CARD, ease: 3.2, intervalDays: 300, repetitions: 12 }, "easy");
    expect(result.intervalDays).toBe(365);
    expect(result.status).toBe("mature");
  });

  it.each([
    [0, 0, "new"],
    [2, 1, "learning"],
    [7, 2, "young"],
    [29, 5, "young"],
    [30, 6, "mature"],
  ])("maps interval %s and repetitions %s to %s", (interval, repetitions, expected) => {
    expect(statusFor(interval, repetitions)).toBe(expected);
  });

  it("produces human-readable interval labels", () => {
    expect(nextIntervalLabel(NEW_CARD, "again")).toBe("<1 min");
    expect(nextIntervalLabel(NEW_CARD, "good")).toBe("3 days");
    expect(nextIntervalLabel({ ...NEW_CARD, intervalDays: 30, repetitions: 5 }, "easy")).toMatch(/mo$/);
  });
});

describe("XP levels", () => {
  it.each([
    [0, 1, 0],
    [249, 1, 99],
    [250, 2, 0],
    [2500, 11, 0],
  ])("maps %s XP to level %s", (xp, expectedLevel, expectedProgress) => {
    const result = levelFromXp(xp);
    expect(result.level).toBe(expectedLevel);
    expect(result.progress).toBe(expectedProgress);
  });

  it("maps levels to the intended rank tier", () => {
    expect(levelFromXp(0).rank).toBe("Beginner");
    expect(levelFromXp(2500).rank).toBe("Intermediate Scholar");
    expect(levelFromXp(7500).rank).toBe("Master");
  });
});
