import { describe, expect, it } from "vitest";
import { extractImportWords, parseCsv } from "@/lib/importer";

describe("CSV parser", () => {
  it("parses quoted commas and escaped quotes", () => {
    const rows = parseCsv('word,definition_en,definition_fa\n"elaborate","explain, in detail","توضیح"\n"quote","say ""hello""","قول"');
    expect(rows).toHaveLength(2);
    expect(rows[0].definition_en).toBe("explain, in detail");
    expect(rows[1].definition_en).toBe('say "hello"');
  });

  it("supports CRLF files and missing optional columns", () => {
    const rows = parseCsv("word,definition_en\r\nhello,greeting\r\n");
    expect(rows).toEqual([{ word: "hello", definition_en: "greeting" }]);
  });
});

describe("word import extraction", () => {
  it("reads a simple JSON array", () => {
    const rows = extractImportWords(JSON.stringify([{ word: "robust", definitionEn: "strong and reliable", deck: "tech" }]), "words.json");
    expect(rows[0]).toMatchObject({ word: "robust", definitionEn: "strong and reliable", deck: "tech", pos: "noun" });
  });

  it("reads the nested shape produced by EngMaster export", () => {
    const rows = extractImportWords(JSON.stringify({ words: [{ word: { word: "coherent", pos: "adjective", definitionEn: "logical", definitionFa: "منسجم", examples: ["A coherent essay."] } }] }), "backup.json");
    expect(rows[0].example).toBe("A coherent essay.");
    expect(rows[0].definitionFa).toBe("منسجم");
  });

  it("reads exported CSV column names", () => {
    const rows = extractImportWords("word,pos,definition_en,definition_fa,deck,topic\nlatency,noun,delay,تاخیر,tech,Networking", "words.csv");
    expect(rows[0]).toEqual({ word: "latency", pos: "noun", definitionEn: "delay", definitionFa: "تاخیر", example: "", deck: "tech", topic: "Networking" });
  });

  it("falls back to the general deck for unknown decks", () => {
    const rows = extractImportWords(JSON.stringify([{ word: "sample", definitionEn: "an example", deck: "unknown" }]), "words.json");
    expect(rows[0].deck).toBe("general");
  });

  it("rejects empty, malformed and oversized imports", () => {
    expect(() => extractImportWords("[]", "words.json")).toThrow("no word rows");
    expect(() => extractImportWords("not json", "words.json")).toThrow();
    const tooMany = Array.from({ length: 2001 }, (_, index) => ({ word: `w${index}`, definitionEn: "definition" }));
    expect(() => extractImportWords(JSON.stringify(tooMany), "words.json")).toThrow("2,000");
  });
});
