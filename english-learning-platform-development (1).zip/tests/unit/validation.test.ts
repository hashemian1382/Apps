import { describe, expect, it } from "vitest";
import { ValidationError, boundedInteger, cleanText, isoDate, oneOf, parseSettings } from "@/lib/validation";

const VALID_SETTINGS = {
  name: "Sara",
  englishLevel: "B2",
  techLevel: "Senior",
  targetScore: 105,
  examDate: "2027-03-15",
  dailyGoalMinutes: 45,
  newWordsPerDay: 15,
  reviewsPerDay: 50,
  showPersian: true,
  theme: "dark",
  accent: "indigo",
  fontSize: "medium",
  voice: "US",
  autoPlayAudio: false,
  soundEffects: true,
  reminderTime: "08:00",
};

describe("input validation", () => {
  it("accepts a complete valid settings payload", () => {
    expect(parseSettings(VALID_SETTINGS)).toEqual(VALID_SETTINGS);
  });

  it.each([
    ["targetScore", 121],
    ["targetScore", -1],
    ["dailyGoalMinutes", 9],
    ["newWordsPerDay", 101],
    ["reviewsPerDay", 501],
    ["reminderTime", "25:90"],
    ["theme", "neon"],
    ["englishLevel", "B9"],
  ])("rejects invalid %s", (key, value) => {
    expect(() => parseSettings({ ...VALID_SETTINGS, [key]: value })).toThrow(ValidationError);
  });

  it("rejects invalid calendar dates", () => {
    expect(() => isoDate("2026-02-31", "Date")).toThrow(ValidationError);
    expect(isoDate("2028-02-29", "Date")).toBe("2028-02-29");
    expect(isoDate("", "Date")).toBeNull();
  });

  it("strips null bytes and surrounding whitespace", () => {
    expect(cleanText("  hel\0lo  ", "Text", 1, 10)).toBe("hello");
  });

  it("requires actual integers within bounds", () => {
    expect(boundedInteger("15", "Value", 0, 20)).toBe(15);
    expect(() => boundedInteger(2.5, "Value", 0, 20)).toThrow(ValidationError);
    expect(() => boundedInteger(Number.NaN, "Value", 0, 20)).toThrow(ValidationError);
  });

  it("enforces an explicit allow-list", () => {
    expect(oneOf("good", "Grade", ["again", "hard", "good", "easy"] as const)).toBe("good");
    expect(() => oneOf("perfect", "Grade", ["good"] as const)).toThrow(ValidationError);
  });
});
