import { useRef, useState } from 'react';
import {
  User, Palette, Coins, Database, Download, Upload, RefreshCw,
  Trash2, ShieldCheck, Moon, Sun, Monitor, Check,
} from 'lucide-react';
import { useApp } from '../lib/store';
import type { MoneyUnit, ThemeMode } from '../lib/types';
import { Card, CardHead, Btn, Field, inputCls, Confirm } from '../components/ui';
import { downloadJson, readJsonFile, cx } from '../lib/utils';
import { toFa } from '../lib/jalali';

export default function Settings() {
  const {
    state, setTheme, setUnit, setName, importState, resetDemo, clearAll,
  } = useApp();
  const [name, setNameLocal] = useState(state.profile.name);
  const [msg, setMsg] = useState<{ ok: boolean; txt: string } | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const flash = (ok: boolean, txt: string) => {
    setMsg({ ok, txt });
    setTimeout(() => setMsg(null), 3500);
  };

  const counts = [
    { l: 'تراکنش', v: state.transactions.length },
    { l: 'وظیفه', v: state.tasks.length },
    { l: 'رویداد', v: state.events.length },
    { l: 'عادت', v: state.habits.length },
    { l: 'یادداشت', v: state.notes.length },
  ];

  const doExport = () => {
    downloadJson(`hamrah-backup-${new Date().toISOString().slice(0, 10)}.json`, state);
    flash(true, 'فایل پشتیبان دانلود شد');
  };

  const doImport = async (f: File | undefined) => {
    if (!f) return;
    try {
      const data = await readJsonFile(f);
      const ok = importState(data as never);
      flash(ok, ok ? 'داده‌ها با موفقیت بازیابی شدند' : 'فایل معتبر نیست — بازیابی انجام نشد');
      if (ok) setNameLocal((data as { profile?: { name?: string } }).profile?.name ?? '');
    } catch {
      flash(false, 'خطا در خواندن فایل');
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const themes: Array<{ v: ThemeMode; label: string; icon: React.ReactNode }> = [
    { v: 'light', label: 'روشن', icon: <Sun size={16} /> },
    { v: 'dark', label: 'تیره', icon: <Moon size={16} /> },
    { v: 'system', label: 'خودکار', icon: <Monitor size={16} /> },
  ];
  const units: Array<{ v: MoneyUnit; label: string; sub: string }> = [
    { v: 'toman', label: 'تومان', sub: 'نمایش کامل مبلغ' },
    { v: 'heazar', label: 'هزار تومان', sub: 'خلاصه و جمع‌وجور' },
  ];

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      {msg && (
        <div className={cx(
          'rounded-2xl px-4 py-3 text-[13px] font-bold',
          msg.ok ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'bg-rose-500/10 text-rose-600 dark:text-rose-300',
        )}>
          {msg.txt}
        </div>
      )}

      {/* پروفایل */}
      <Card>
        <CardHead title="پروفایل" sub="نامی که در داشبورد به شما سلام می‌کند" />
        <div className="flex flex-wrap items-end gap-3 px-5 pb-5">
          <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-600 text-white">
            <User size={24} />
          </div>
          <div className="min-w-[200px] flex-1">
            <Field label="نام شما">
              <input
                value={name}
                onChange={(e) => setNameLocal(e.target.value)}
                placeholder="مثلاً سارا محمدی"
                className={inputCls}
              />
            </Field>
          </div>
          <Btn onClick={() => { setName(name.trim()); flash(true, 'نام ذخیره شد'); }}>
            <Check size={15} /> ذخیره
          </Btn>
        </div>
      </Card>

      {/* ظاهر */}
      <Card>
        <CardHead title="ظاهر" sub="تم روشن، تیره یا هماهنگ با سیستم" />
        <div className="grid grid-cols-3 gap-2 px-5 pb-5">
          {themes.map((t) => (
            <button
              key={t.v}
              onClick={() => setTheme(t.v)}
              className={cx(
                'flex flex-col items-center gap-1.5 rounded-2xl border-2 py-4 text-[13px] font-black transition',
                state.settings.theme === t.v
                  ? 'border-emerald-500 bg-emerald-500/5 text-emerald-700 dark:text-emerald-300'
                  : 'border-slate-100 text-slate-500 hover:border-slate-200 dark:border-white/5 dark:text-slate-300',
              )}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>
      </Card>

      {/* واحد پول */}
      <Card>
        <CardHead title="واحد نمایش پول" sub="در همه بخش‌ها اعمال می‌شود" />
        <div className="grid gap-2 px-5 pb-5 sm:grid-cols-2">
          {units.map((u) => (
            <button
              key={u.v}
              onClick={() => setUnit(u.v)}
              className={cx(
                'flex items-center gap-3 rounded-2xl border-2 p-3.5 text-right transition',
                state.settings.unit === u.v
                  ? 'border-emerald-500 bg-emerald-500/5'
                  : 'border-slate-100 hover:border-slate-200 dark:border-white/5',
              )}
            >
              <span className={cx(
                'grid h-10 w-10 shrink-0 place-items-center rounded-xl',
                state.settings.unit === u.v ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-400 dark:bg-white/10',
              )}>
                <Coins size={18} />
              </span>
              <span>
                <span className="block text-[13px] font-black text-slate-700 dark:text-slate-100">{u.label}</span>
                <span className="block text-[11px] text-slate-400">{u.sub}</span>
              </span>
              {state.settings.unit === u.v && <Check size={16} className="mr-auto text-emerald-500" />}
            </button>
          ))}
        </div>
        <div className="mx-5 mb-5 flex items-center gap-2 rounded-2xl bg-slate-50 px-3.5 py-3 text-[11px] text-slate-500 dark:bg-white/5 dark:text-slate-400">
          <Palette size={15} className="shrink-0 text-slate-400" />
          مثال: ۱۲٬۵۰۰٬۰۰۰ {state.settings.unit === 'heazar' ? '← «۱۲٬۵۰۰ هزار تومان» نمایش داده می‌شود' : '← «۱۲٬۵۰۰٬۰۰۰ تومان» نمایش داده می‌شود'}
        </div>
      </Card>

      {/* داده‌ها */}
      <Card>
        <CardHead title="مدیریت داده‌ها" sub="همه اطلاعات فقط در مرورگر شما ذخیره می‌شود" />
        <div className="px-5 pb-5">
          <div className="mb-4 flex flex-wrap gap-2">
            {counts.map((c) => (
              <span key={c.l} className="tabular rounded-full bg-slate-100 px-3 py-1.5 text-[11px] font-bold text-slate-500 dark:bg-white/5 dark:text-slate-300">
                {c.l}: {toFa(c.v)}
              </span>
            ))}
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <Btn variant="outline" onClick={doExport}><Download size={15} /> دانلود پشتیبان (JSON)</Btn>
            <Btn variant="outline" onClick={() => fileRef.current?.click()}><Upload size={15} /> بازیابی از فایل</Btn>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => doImport(e.target.files?.[0])}
            />
            <Btn variant="soft" onClick={() => setConfirmReset(true)}><RefreshCw size={15} /> بازگشت به داده نمایشی</Btn>
            <Btn variant="ghost" onClick={() => setConfirmClear(true)} className="text-rose-500 hover:bg-rose-500/10"><Trash2 size={15} /> پاک کردن همه داده‌ها</Btn>
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-2xl bg-emerald-500/[0.06] p-3.5 text-[11px] leading-6 text-slate-500 ring-1 ring-emerald-500/15 dark:text-slate-400">
            <ShieldCheck size={17} className="mt-0.5 shrink-0 text-emerald-500" />
            <span>
              حریم خصوصی شما محترم است: هیچ داده‌ای به سرور ارسال نمی‌شود و همه‌چیز در <b>localStorage مرورگر خودتان</b> ذخیره می‌ماند.
              برای انتقال به دستگاه دیگر، از دکمه «دانلود پشتیبان» استفاده کنید و فایل را در دستگاه جدید «بازیابی» کنید.
            </span>
          </div>
        </div>
      </Card>

      {/* درباره */}
      <Card>
        <div className="flex items-center gap-3 px-5 py-5">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-700 text-white">
            <Database size={22} />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-800 dark:text-white">همراه — نسخه ۱٫۰</h3>
            <p className="mt-0.5 text-[11px] leading-5 text-slate-400">مدیریت یکپارچه مالی، وظایف، تقویم شمسی، عادت‌ها و یادداشت‌ها • ساخته‌شده با ❤️ برای زندگی منظم‌تر</p>
          </div>
        </div>
      </Card>

      <Confirm open={confirmReset} onClose={() => setConfirmReset(false)} onYes={() => { resetDemo(); setNameLocal('دوست عزیز'); flash(true, 'داده نمایشی بازیابی شد'); }} title="بازگشت به داده نمایشی؟" desc="همه داده‌های فعلی پاک و داده‌های نمونه جایگزین می‌شوند." />
      <Confirm open={confirmClear} onClose={() => setConfirmClear(false)} onYes={() => { clearAll(); flash(true, 'همه داده‌ها پاک شدند'); }} title="پاک کردن همه داده‌ها؟" desc="تراکنش‌ها، وظایف، رویدادها، عادت‌ها و یادداشت‌ها حذف می‌شوند. این عمل قابل بازگشت نیست!" />
    </div>
  );
}
