"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { finishReviewSession, gradeCard } from "@/lib/actions";
import { SpeakButton } from "@/components/Speak";
import { nextIntervalLabel, type Grade } from "@/lib/srs";

export type Card = {
  id: number;
  ease: number;
  intervalDays: number;
  repetitions: number;
  lapses: number;
  status: string;
  word: {
    id: number; word: string; pos: string; ipaUs: string | null; definitionEn: string; definitionFa: string;
    examples: string[]; memoryTrick: string | null; deck: string; topic: string; codeExample: string | null;
  };
};

const GRADES: { g: Grade; label: string; emoji: string; color: string }[] = [
  { g: "again", label: "Again", emoji: "😫", color: "#EF4444" },
  { g: "hard", label: "Hard", emoji: "😟", color: "#F59E0B" },
  { g: "good", label: "Good", emoji: "😊", color: "#10B981" },
  { g: "easy", label: "Easy", emoji: "🎯", color: "#8B5CF6" },
];

export function ReviewSession({ cards, showPersian }: { cards: Card[]; showPersian: boolean }) {
  const [queue, setQueue] = useState(cards);
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [done, setDone] = useState(false);
  const [summary, setSummary] = useState<{ accuracy: number } | null>(null);
  const started = useRef(Date.now());

  useEffect(() => {
    const t = setInterval(() => setSeconds(Math.round((Date.now() - started.current) / 1000)), 1000);
    return () => clearInterval(t);
  }, []);

  const card = queue[index];
  const total = queue.length;

  const intervals = useMemo(() => {
    if (!card) return {} as Record<Grade, string>;
    const state = { ease: card.ease, intervalDays: card.intervalDays, repetitions: card.repetitions, lapses: card.lapses, status: card.status };
    return {
      again: nextIntervalLabel(state, "again"),
      hard: nextIntervalLabel(state, "hard"),
      good: nextIntervalLabel(state, "good"),
      easy: nextIntervalLabel(state, "easy"),
    } as Record<Grade, string>;
  }, [card]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (done) return;
      if (e.code === "Space") {
        e.preventDefault();
        setRevealed(true);
      }
      if (revealed && ["1", "2", "3", "4"].includes(e.key)) {
        void grade(GRADES[Number(e.key) - 1].g);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  async function grade(g: Grade) {
    if (!card) return;
    if (g !== "again") setCorrect((c) => c + 1);
    void gradeCard(card.id, g);
    const isLast = index + 1 >= total;
    if (g === "again") {
      setQueue((q) => [...q, { ...card, repetitions: 0, intervalDays: 1 }]);
    }
    setRevealed(false);
    if (isLast && g !== "again") {
      const res = await finishReviewSession(total, correct + 1, Math.round((Date.now() - started.current) / 1000));
      setSummary({ accuracy: res.accuracy });
      setDone(true);
    } else {
      setIndex((i) => i + 1);
    }
  }

  if (!card || done) {
    return (
      <div className="card grid place-items-center gap-3 p-12 text-center animate-pop">
        <span className="text-5xl">🎉</span>
        <h2 className="text-2xl font-extrabold">Session complete!</h2>
        <p className="text-sm muted">
          {total} cards · {Math.floor(seconds / 60)}m {seconds % 60}s · accuracy {summary?.accuracy ?? Math.round((correct / Math.max(1, total)) * 100)}%
        </p>
        <div className="mt-2 flex gap-2">
          <a href="/review" className="btn btn-primary">↻ New session</a>
          <a href="/" className="btn btn-ghost">🏠 Dashboard</a>
        </div>
      </div>
    );
  }

  const pct = Math.round((index / Math.max(1, total)) * 100);

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="card flex items-center gap-3 p-3 text-xs">
        <span className="chip">Card {index + 1}/{total}</span>
        <div className="h-1.5 flex-1 overflow-hidden rounded-full" style={{ background: "color-mix(in srgb, var(--text) 10%, transparent)" }}>
          <div className="h-full rounded-full brand-bg transition-all" style={{ width: `${pct}%` }} />
        </div>
        <span className="chip">⏱ {String(Math.floor(seconds / 60)).padStart(2, "0")}:{String(seconds % 60).padStart(2, "0")}</span>
        <span className="chip" style={{ color: "#10B981" }}>✓ {correct}</span>
      </div>

      <div className="card min-h-[360px] p-8 text-center animate-slide-up">
        <div className="mb-4 flex items-center justify-center gap-2">
          <span className="chip">{card.word.deck}</span>
          <span className="chip">{card.word.topic}</span>
          <span className="chip">{card.status}</span>
        </div>

        <h2 className="text-4xl font-extrabold tracking-tight">{card.word.word}</h2>
        {card.word.ipaUs ? <p className="mt-2 font-mono text-sm muted">{card.word.ipaUs}</p> : null}
        <div className="mt-3 flex justify-center gap-2">
          <SpeakButton text={card.word.word} accent="US" />
          <SpeakButton text={card.word.word} accent="UK" />
        </div>

        {!revealed ? (
          <button className="btn btn-primary mt-10 px-8 py-3" onClick={() => setRevealed(true)}>
            👁️ Show answer <span className="ml-1 text-[10px] opacity-70">(Space)</span>
          </button>
        ) : (
          <div className="mt-6 space-y-3 text-left animate-pop">
            <div className="card-flat p-4">
              <p className="text-sm">
                <span className="font-bold muted">({card.word.pos}) </span>
                {card.word.definitionEn}
              </p>
              {showPersian ? <p className="fa mt-1 text-sm muted">{card.word.definitionFa}</p> : null}
            </div>
            {card.word.examples[0] ? (
              <div className="card-flat flex items-start gap-2 p-4">
                <p className="flex-1 text-sm italic">“{card.word.examples[0]}”</p>
                <SpeakButton text={card.word.examples[0]} label="" />
              </div>
            ) : null}
            {card.word.codeExample ? (
              <pre className="card-flat overflow-x-auto scroll-thin p-3 text-left font-mono text-[11px]">{card.word.codeExample}</pre>
            ) : null}
            {card.word.memoryTrick ? <p className="text-xs muted">💡 {card.word.memoryTrick}</p> : null}
          </div>
        )}
      </div>

      {revealed ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {GRADES.map((b, i) => (
            <button
              key={b.g}
              onClick={() => grade(b.g)}
              className="card flex flex-col items-center gap-0.5 p-3 transition hover:-translate-y-1"
              style={{ borderColor: `color-mix(in srgb, ${b.color} 45%, transparent)` }}
            >
              <span className="text-xl">{b.emoji}</span>
              <span className="text-sm font-bold" style={{ color: b.color }}>{b.label}</span>
              <span className="text-[10px] muted">{intervals[b.g]}</span>
              <span className="text-[9px] muted">key {i + 1}</span>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
