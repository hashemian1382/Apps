import Link from "next/link";
import { getDueCards, getDeckCounts, getReviewSummary, getUser } from "@/lib/data";
import { Card, Chip, PageHeader, Stat } from "@/components/ui";
import { ReviewSession, type Card as SrsCard } from "./ReviewSession";

export const dynamic = "force-dynamic";

const DECK_META: Record<string, { icon: string; label: string }> = {
  general: { icon: "📚", label: "General Vocabulary" },
  academic: { icon: "🎓", label: "Academic Word List" },
  toefl: { icon: "🎯", label: "TOEFL Words" },
  tech: { icon: "💻", label: "Tech Terms" },
  idiom: { icon: "💬", label: "Idioms & Phrases" },
};

export default async function ReviewPage({ searchParams }: { searchParams: Promise<{ deck?: string; start?: string; limit?: string }> }) {
  const sp = await searchParams;
  const user = await getUser();
  const [summary, decks] = await Promise.all([getReviewSummary(user.id), getDeckCounts(user.id)]);

  if (sp.start) {
    const limit = Number(sp.limit ?? user.reviewsPerDay) || 30;
    const cards = await getDueCards(user.id, sp.deck, limit);
    if (cards.length > 0) {
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Link href="/review" className="btn btn-ghost px-3 py-1 text-xs">← Exit session</Link>
            <Chip color="#8B5CF6">Smart Review · spaced repetition</Chip>
          </div>
          <ReviewSession cards={cards as unknown as SrsCard[]} showPersian={user.showPersian} />
        </div>
      );
    }
  }

  const estimatedMinutes = Math.max(1, Math.round((summary.due ?? 0) * 0.5));

  return (
    <div className="space-y-6">
      <PageHeader
        icon="🧠"
        title="Smart Review"
        subtitle="An SM-2 style spaced repetition scheduler: Again resets to 1 day, Hard ×1.2, Good ×2.5, Easy ×3.5."
        meta={
          <>
            <Chip color="#8B5CF6">{summary.due ?? 0} due now</Chip>
            <Chip color="#EF4444">{summary.overdue ?? 0} overdue</Chip>
            <Chip>⏱ ~{estimatedMinutes} min</Chip>
          </>
        }
        action={
          <Link href={`/review?start=1&limit=${user.reviewsPerDay}`} className="btn btn-primary">
            ▶️ Start review session
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="🆕 New" value={summary.fresh ?? 0} sub="never seen" icon="🔵" accent="#06B6D4" />
        <Stat label="📗 Learning" value={summary.learning ?? 0} sub="interval < 7 days" icon="🟡" accent="#F59E0B" />
        <Stat label="📙 Young / Mature" value={`${summary.young ?? 0} / ${summary.mature ?? 0}`} sub="7–30d · 30d+" icon="🟢" accent="#10B981" />
        <Stat label="📕 Overdue" value={summary.overdue ?? 0} sub="review these first" icon="🔴" accent="#EF4444" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Review Decks" icon="📂" className="lg:col-span-2">
          <ul className="space-y-2">
            {decks.map((d) => {
              const meta = DECK_META[d.deck] ?? { icon: "🗂️", label: d.deck };
              return (
                <li key={d.deck} className="flex items-center gap-3 rounded-xl border px-3 py-2.5" style={{ borderColor: "var(--border)" }}>
                  <span className="text-lg">{meta.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{meta.label}</p>
                    <p className="text-[11px] muted">{d.total} cards · {d.mature ?? 0} mature</p>
                  </div>
                  <span className="chip" style={{ color: (d.due ?? 0) > 0 ? "#8B5CF6" : undefined }}>{d.due ?? 0} due</span>
                  <Link href={`/review?start=1&deck=${d.deck}`} className="btn btn-ghost px-3 py-1 text-xs">Review →</Link>
                </li>
              );
            })}
          </ul>
        </Card>

        <div className="space-y-4">
          <Card title="Custom Session" icon="⚙️">
            <div className="grid grid-cols-2 gap-2">
              {[10, 20, 30, 50].map((n) => (
                <Link key={n} href={`/review?start=1&limit=${n}`} className="btn btn-ghost py-2 text-xs">
                  {n} cards
                </Link>
              ))}
            </div>
            <Link href="/review?start=1&limit=200" className="btn btn-primary mt-3 w-full">Review everything due</Link>
          </Card>

          <Card title="How the algorithm works" icon="📊">
            <ul className="space-y-1.5 text-xs muted">
              <li>🆕 New card → review after 1 day</li>
              <li>📗 Good → interval × 2.5</li>
              <li>📙 Hard → interval × 1.2</li>
              <li>📕 Again → back to 1 day (ease −0.2)</li>
              <li>🎯 Easy → interval × 3.5 (ease +0.15)</li>
            </ul>
            <p className="mt-3 font-mono text-[11px] muted">Day 1 → 3 → 8 → 20 → 50 → 125</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
