import Link from "next/link";
import { getUser, getDeckCounts, listArticles, listPrompts } from "@/lib/data";
import { Card, Chip, PageHeader, Progress, Tile } from "@/components/ui";

export const dynamic = "force-dynamic";

const TILES = [
  { href: "/vocabulary?deck=tech", icon: "📚", title: "Tech Vocabulary", subtitle: "OOP, systems, ML and DevOps terms with runnable code examples", color: "#06B6D4" },
  { href: "/reading?module=tech", icon: "📖", title: "Reading CS Texts", subtitle: "Docs, engineering blogs and simplified research papers", color: "#4F46E5" },
  { href: "/listening?module=tech", icon: "🎧", title: "Tech Podcasts", subtitle: "Stand-ups, design reviews and conference-style talks", color: "#10B981" },
  { href: "/writing?module=tech", icon: "✏️", title: "Technical Writing", subtitle: "Bug reports, RFCs, commit messages and README structure", color: "#F59E0B" },
  { href: "/speaking?module=tech", icon: "💬", title: "Interview Prep", subtitle: "STAR answers, system-design language and self introductions", color: "#8B5CF6" },
  { href: "/reading/how-to-read-api-documentation", icon: "📋", title: "Documentation", subtitle: "A repeatable method for reading any API reference fast", color: "#0EA5E9" },
  { href: "/reading/reading-error-messages", icon: "🔧", title: "Debug in English", subtitle: "Stack traces, error vocabulary and searching effectively", color: "#EF4444" },
  { href: "/games", icon: "🎮", title: "Code & English", subtitle: "Mini games built on the technical deck", color: "#EC4899" },
];

const CATEGORIES = [
  { name: "Programming Fundamentals", items: ["Variables & functions", "Loops & recursion", "Data structures", "Algorithms", "Design patterns"] },
  { name: "Web Development", items: ["Frontend terms", "Backend terms", "API & REST", "Databases", "DevOps vocabulary"] },
  { name: "Networking & Security", items: ["Protocols", "Cybersecurity terms", "Cloud computing"] },
  { name: "AI & Data Science", items: ["Machine learning", "Statistics vocabulary", "Data engineering"] },
  { name: "Software Engineering", items: ["Agile / Scrum", "Git & version control", "Testing", "CI/CD"] },
  { name: "Academic CS", items: ["Theory of computation", "Operating systems", "Computer architecture"] },
];

export default async function TechPage() {
  const user = await getUser();
  const [decks, techArticles, interview] = await Promise.all([getDeckCounts(user.id), listArticles("tech"), listPrompts("speaking", "tech")]);
  const tech = decks.find((d) => d.deck === "tech");
  const mastery = tech ? Math.round((tech.mature / Math.max(1, tech.total)) * 100) : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        icon="💻"
        title="Technical English for Computer Science"
        subtitle="The English you actually use at work: documentation, code review, stand-ups and interviews."
        meta={
          <>
            <Chip color="#06B6D4">Level: {user.techLevel}</Chip>
            <Chip>{tech?.total ?? 0} technical terms</Chip>
            <Chip color="#10B981">{mastery}% mastered</Chip>
            <Chip>{techArticles.length} technical passages</Chip>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {TILES.map((t) => (
          <Tile key={t.href} {...t} />
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Vocabulary Categories" icon="🗂️" className="lg:col-span-2">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((c) => (
              <div key={c.name} className="card-flat p-3">
                <p className="mb-2 text-xs font-bold">{c.name}</p>
                <ul className="space-y-1 text-[11px] muted">
                  {c.items.map((i) => (
                    <li key={i}>▸ {i}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <Link href="/vocabulary?deck=tech" className="btn btn-primary mt-4 w-full">
            💻 Study the technical deck
          </Link>
        </Card>

        <div className="space-y-4">
          <Card title="Mastery" icon="📈">
            <div className="space-y-3">
              {[
                { k: "Terms seen", v: tech?.total ?? 0, p: 100 },
                { k: "Mature (mastered)", v: tech?.mature ?? 0, p: mastery },
                { k: "Due for review", v: tech?.due ?? 0, p: Math.round(((tech?.due ?? 0) / Math.max(1, tech?.total ?? 1)) * 100) },
              ].map((row) => (
                <div key={row.k}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span>{row.k}</span>
                    <span className="font-bold">{row.v}</span>
                  </div>
                  <Progress value={row.p} height={6} color="linear-gradient(90deg,#06B6D4,#4F46E5)" />
                </div>
              ))}
            </div>
          </Card>

          <Card title="Interview Prep" icon="💬">
            <ul className="space-y-2 text-xs">
              {interview.map((p) => (
                <li key={p.id}>
                  <Link href={`/speaking?module=tech&prompt=${p.id}`} className="flex items-center gap-2 rounded-lg px-2 py-1.5 transition hover:bg-[color-mix(in_srgb,var(--text)_7%,transparent)]">
                    <span>🎙️</span>
                    <span className="flex-1 truncate">{p.title}</span>
                    <span className="muted">{p.speakSeconds}s</span>
                  </Link>
                </li>
              ))}
              <li className="pt-1 text-[11px] muted">STAR method · trade-off vocabulary · whiteboard phrases</li>
            </ul>
          </Card>
        </div>
      </div>

      <Card title="Real-world Practice" icon="🛠️">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { t: "Reading error messages", d: "Decode stack traces and exception vocabulary.", h: "/reading/reading-error-messages" },
            { t: "Code review language", d: "Hedging, nits and blocking comments.", h: "/reading/anatomy-of-a-code-review" },
            { t: "Commit & PR messages", d: "Imperative mood, scope and context.", h: "/writing?module=tech" },
            { t: "Documentation reading", d: "A repeatable 5-step method.", h: "/reading/how-to-read-api-documentation" },
          ].map((x) => (
            <Link key={x.t} href={x.h} className="card-flat p-4 transition hover:-translate-y-0.5 hover:shadow-lg">
              <p className="text-sm font-bold">{x.t}</p>
              <p className="mt-1 text-xs muted">{x.d}</p>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
