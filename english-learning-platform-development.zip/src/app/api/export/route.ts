import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { dailyStats, mockResults, userWords, words, writings } from "@/db/schema";
import { getUser } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const format = searchParams.get("format") ?? "json";
  const user = await getUser();

  const rows = await db
    .select({ word: words, progress: userWords })
    .from(userWords)
    .innerJoin(words, eq(words.id, userWords.wordId))
    .where(eq(userWords.userId, user.id));

  if (format === "csv") {
    const header = "word,pos,definition_en,definition_fa,deck,topic,status,interval_days,ease,times_correct,times_wrong";
    const body = rows
      .map((r) =>
        [
          r.word.word,
          r.word.pos,
          `"${r.word.definitionEn.replaceAll('"', "'")}"`,
          `"${r.word.definitionFa.replaceAll('"', "'")}"`,
          r.word.deck,
          r.word.topic,
          r.progress.status,
          r.progress.intervalDays,
          r.progress.ease.toFixed(2),
          r.progress.timesCorrect,
          r.progress.timesWrong,
        ].join(","),
      )
      .join("\n");
    return new NextResponse(`${header}\n${body}`, {
      headers: { "Content-Type": "text/csv", "Content-Disposition": 'attachment; filename="engmaster-words.csv"' },
    });
  }

  const [stats, mocks, essays] = await Promise.all([
    db.select().from(dailyStats).where(eq(dailyStats.userId, user.id)),
    db.select().from(mockResults).where(eq(mockResults.userId, user.id)),
    db.select().from(writings).where(eq(writings.userId, user.id)),
  ]);

  return new NextResponse(JSON.stringify({ exportedAt: new Date().toISOString(), user, words: rows, stats, mocks, essays }, null, 2), {
    headers: { "Content-Type": "application/json", "Content-Disposition": 'attachment; filename="engmaster-progress.json"' },
  });
}
