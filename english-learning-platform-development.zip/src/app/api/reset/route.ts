import { NextResponse } from "next/server";
import { resetProgress } from "@/lib/bootstrap";
import { getUser } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST() {
  const user = await getUser();
  await resetProgress(user.id);
  return NextResponse.json({ ok: true });
}
