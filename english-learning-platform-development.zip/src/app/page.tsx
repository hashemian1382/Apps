import Link from "next/link";
import { getDashboard } from "@/lib/data";
import { Card, Chip, PageHeader, Progress, Stat, SECTION_COLORS } from "@/components/ui";
import { BarRow, Donut } from "@/components/charts";
import { TaskList } from "@/components/dashboard/TaskList";
import { SpeakButton } from "@/components/Speak";

export const dynamic = "force-dynamic";

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return { text: "Good Morning", icon: "🌅" };
  if (h < 18) return { text: "Good Afternoon", icon: "☀️" };
  return { text: "Good Evening", icon: "🌙" };
}

export default async function DashboardPage() {
  const d = await getDashboard();
  const g = greeting();
  const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const last7 = Array.from({ length: 7 }).map((_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const key = date.toISOString().slice(0, 10);
    const found = d.stats.find((s) => s.day === key);
    return { label: weekDays[date.getDay()], minutes: found?.minutes ?? 0, isToday: i === 6 };
  });
  const maxMinutes = Math.max(60, ...last7.map((x) => x.minutes));
  const todayStat = d.stats.find((s) => s.day === new Date().toISOString().slice(0, 10));
  const estimated = d.mock?.total ?? 0;
  const daysToExam = d.user.examDate
    ? Math.max(0, Math.round((new Date(d.user.examDate).getTime() - Date.now()) / 86400000))
    : null;
  const accuracy =
    d.summary.correct + d.summary.wrong > 0 ? Math.round((d.summary.correct / (d.summary.correct + d.summary.wrong)) * 100) : 0;
  const sessionMinutes = Math.max(10, Math.round((d.summary.due ?? 0) * 0.4) + 12);

  return (
    <div className="space-y-6">
      <PageHeader
        icon={g.icon}
        title={`${g.text}, ${d.user.name}!`}
        subtitle="Here is your personalised plan for today. Small, consistent sessions beat marathon study."
        meta={
          <>
            <Chip color="#F59E0B">🔥 {d.user.streak}-day streak</Chip>
            <Chip color="#8B5CF6">🧠 {d.summary.due ?? 0} cards due</Chip>
            <Chip color="#10B981">🏆 {d.user.totalXp.toLocaleString()} XP · Level {d.level.level}</Chip>
            {daysToExam !== null ? <Chip color="#EF4444">⏰ {daysToExam} days to exam</Chip> : null}
          </>
        }
        action={
          <Link href="/review" className="btn btn-primary">
            ▶️ Start today&apos;s session · ~{sessionMinutes} min
          </Link>
        }
      />

      {/* Module progress */}
      <div className="grid gap-4 md:grid-cols-3">
        {[
          { href: "/general", icon: "📚", title: "General English", sub: `Level: ${d.user.englishLevel}`, value: d.generalProgress, color: SECTION_COLORS.general },
          { href: "/tech", icon: "💻", title: "Technical English", sub: `Level: ${d.user.techLevel}`, value: d.techProgress, color: SECTION_COLORS.tech },
          { href: "/toefl", icon: "🎯", title: "TOEFL Prep", sub: `Estimated: ${estimated || "—"} / ${d.user.targetScore}`, value: d.toeflProgress, color: SECTION_COLORS.toefl },
        ].map((m) => (
          <Link key={m.href} href={m.href} className="card group relative overflow-hidden p-5 transition hover:-translate-y-1">
            <div className="pointer-events-none absolute -right-8 -top-10 h-24 w-24 rounded-full opacity-30 blur-2xl" style={{ background: m.color }} />
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-xl text-xl" style={{ background: `color-mix(in srgb, ${m.color} 20%, transparent)` }}>
                {m.icon}
              </span>
              <div>
                <h3 className="font-bold">{m.title}</h3>
                <p className="text-xs muted">{m.sub}</p>
              </div>
              <span className="ml-auto text-lg font-extrabold" style={{ color: m.color }}>
                {m.value}%
              </span>
            </div>
            <div className="mt-4">
              <Progress value={m.value} color={m.color} />
            </div>
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Today's plan */}
        <Card title="Today's Plan" icon="📋" className="lg:col-span-2">
          <TaskList tasks={d.todayTasks} kind="mission" />
        </Card>

        {/* Weekly overview */}
        <Card title="Weekly Overview" icon="📊">
          <div className="space-y-2.5">
            {last7.map((day) => (
              <BarRow
                key={day.label + day.minutes}
                label={day.isToday ? "Today" : day.label}
                value={day.minutes}
                max={maxMinutes}
                suffix="m"
                color={day.isToday ? "linear-gradient(90deg,#F59E0B,#EF4444)" : undefined}
              />
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 text-center">
            <div className="card-flat p-3">
              <p className="text-lg font-extrabold">{last7.reduce((a, b) => a + b.minutes, 0)}m</p>
              <p className="text-[10px] muted">this week</p>
            </div>
            <div className="card-flat p-3">
              <p className="text-lg font-extrabold">{d.user.dailyGoalMinutes}m</p>
              <p className="text-[10px] muted">daily goal</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Quick stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Words studied today" value={todayStat?.wordsLearned ?? 0} sub={`${d.summary.total} total in your bank`} icon="🔤" />
        <Stat label="Study time today" value={`${todayStat?.minutes ?? 0} min`} sub={`goal ${d.user.dailyGoalMinutes} min`} icon="⏱️" />
        <Stat label="Estimated TOEFL" value={estimated || "—"} sub={`target ${d.user.targetScore}`} icon="🎯" accent="#F59E0B" />
        <Stat label="Accuracy rate" value={`${accuracy}%`} sub={`${d.summary.correct} correct answers`} icon="✅" accent="#10B981" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Review snapshot */}
        <Card title="Smart Review" icon="🧠" action={<Link href="/review" className="btn btn-ghost px-3 py-1 text-xs">Open</Link>}>
          <div className="flex items-center gap-5">
            <Donut value={d.summary.due ?? 0} max={Math.max(1, d.summary.total)} label="due now" color="#8B5CF6" />
            <div className="flex-1 space-y-1.5 text-xs">
              {[
                { k: "🆕 New", v: d.summary.fresh, c: "#06B6D4" },
                { k: "📗 Learning", v: d.summary.learning, c: "#10B981" },
                { k: "📙 Young", v: d.summary.young, c: "#F59E0B" },
                { k: "📕 Mature", v: d.summary.mature, c: "#8B5CF6" },
              ].map((row) => (
                <div key={row.k} className="flex items-center justify-between rounded-lg px-2 py-1" style={{ background: `color-mix(in srgb, ${row.c} 10%, transparent)` }}>
                  <span>{row.k}</span>
                  <span className="font-bold" style={{ color: row.c }}>{row.v ?? 0}</span>
                </div>
              ))}
            </div>
          </div>
          <Link href="/review" className="btn btn-primary mt-4 w-full">
            ▶️ Review {d.summary.due ?? 0} cards
          </Link>
        </Card>

        {/* Daily challenges */}
        <Card title="Daily Challenges" icon="🎮" action={<Link href="/games" className="btn btn-ghost px-3 py-1 text-xs">Games</Link>}>
          <TaskList tasks={d.todayTasks} kind="challenge" />
        </Card>

        {/* Word of the day + level */}
        <div className="space-y-4">
          <Card title="Word of the Day" icon="💡">
            {d.wotd ? (
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-xl font-extrabold brand-text">{d.wotd.word}</h3>
                  <SpeakButton text={d.wotd.word} accent="US" />
                </div>
                <p className="mt-0.5 font-mono text-xs muted">{d.wotd.ipaUs}</p>
                <p className="mt-2 text-sm">{d.wotd.definitionEn}</p>
                <p className="fa mt-1 text-sm muted">{d.wotd.definitionFa}</p>
                {d.wotd.examples[0] ? <p className="mt-2 border-l-2 pl-2 text-xs italic muted" style={{ borderColor: "var(--brand)" }}>{d.wotd.examples[0]}</p> : null}
                <Link href={`/vocabulary?q=${encodeURIComponent(d.wotd.word)}`} className="btn btn-ghost mt-3 w-full py-1.5 text-xs">
                  Open word card →
                </Link>
              </div>
            ) : null}
          </Card>

          <Card>
            <div className="flex items-center gap-3">
              <span className="text-2xl">{d.level.icon}</span>
              <div className="flex-1">
                <p className="text-sm font-bold">
                  Level {d.level.level} · {d.level.rank}
                </p>
                <p className="text-[11px] muted">
                  {d.level.xpInLevel}/{d.level.xpForLevel} XP to next level
                </p>
              </div>
            </div>
            <div className="mt-3">
              <Progress value={d.level.progress} />
            </div>
          </Card>
        </div>
      </div>

      <div className="card flex items-start gap-3 p-4" style={{ borderColor: "color-mix(in srgb, #F59E0B 35%, transparent)" }}>
        <span className="text-xl">💡</span>
        <p className="text-sm">
          <span className="font-bold">Tip of the day: </span>
          {d.tip}
        </p>
      </div>
    </div>
  );
}
