import { getGameWords, getTodayTasks, getUser, listAchievements, listGameScores } from "@/lib/data";
import { levelFromXp } from "@/lib/srs";
import { Card, Chip, PageHeader, Progress } from "@/components/ui";
import { GamesHub, type GameWord } from "./GamesHub";
import { TaskList } from "@/components/dashboard/TaskList";

export const dynamic = "force-dynamic";

const XP_RULES = [
  ["Complete a lesson", "+50 XP"],
  ["Perfect quiz score", "+100 XP"],
  ["Daily streak bonus", "+25 XP × streak"],
  ["Review session", "+5 XP per card"],
  ["Achievement unlock", "+200 XP"],
  ["Reading passage", "+100 XP"],
  ["Writing draft", "+150 XP"],
  ["Mock test", "+300 XP"],
];

const TIERS = [
  ["1–5", "Beginner 🌱"],
  ["6–10", "Elementary 🌿"],
  ["11–15", "Intermediate 📖"],
  ["16–20", "Upper-Intermediate 📚"],
  ["21–25", "Advanced 🎓"],
  ["26–30", "Expert 👑"],
  ["30+", "Master 🏆"],
];

export default async function GamesPage() {
  const user = await getUser();
  const [words, scores, achievements, tasks] = await Promise.all([
    getGameWords(30),
    listGameScores(user.id),
    listAchievements(user.id),
    getTodayTasks(user.id),
  ]);
  const level = levelFromXp(user.totalXp);
  const unlocked = achievements.filter((a) => a.unlocked);

  return (
    <div className="space-y-6">
      <PageHeader
        icon="🎮"
        title="Games & Challenges"
        subtitle="Turn practice into play: six mini games built on your own vocabulary deck, plus XP, levels and badges."
        meta={
          <>
            <Chip color="#10B981">Level {level.level} · {level.rank}</Chip>
            <Chip color="#F59E0B">{user.totalXp.toLocaleString()} XP</Chip>
            <Chip color="#8B5CF6">{unlocked.length}/{achievements.length} achievements</Chip>
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Your Rank" icon="🏆">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{level.icon}</span>
            <div className="flex-1">
              <p className="text-lg font-extrabold">Level {level.level}</p>
              <p className="text-xs muted">{level.rank}</p>
            </div>
          </div>
          <div className="mt-3">
            <Progress value={level.progress} />
            <p className="mt-1 text-[11px] muted">
              {level.xpInLevel}/{level.xpForLevel} XP to level {level.level + 1}
            </p>
          </div>
        </Card>

        <Card title="Daily Challenges" icon="🎯" className="lg:col-span-2">
          <TaskList tasks={tasks} kind="challenge" />
        </Card>
      </div>

      <GamesHub words={words as unknown as GameWord[]} />

      <Card title="Achievements & Badges" icon="🏅">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {achievements.map((a) => {
            const pct = Math.min(100, Math.round((a.current / a.threshold) * 100));
            return (
              <div
                key={a.id}
                className="card-flat p-4"
                style={{ borderColor: a.unlocked ? "color-mix(in srgb,#F59E0B 45%,transparent)" : "var(--border)", opacity: a.unlocked ? 1 : 0.75 }}
              >
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{a.unlocked ? a.icon : a.hidden ? "🔒" : a.icon}</span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold">{a.hidden && !a.unlocked ? "Hidden achievement" : a.name}</p>
                    <p className="text-[10px] muted">+{a.xpReward} XP</p>
                  </div>
                </div>
                <p className="mt-2 text-[11px] muted">{a.hidden && !a.unlocked ? "Keep exploring to reveal this one." : a.description}</p>
                <div className="mt-2">
                  <Progress value={pct} height={5} color={a.unlocked ? "#F59E0B" : undefined} />
                </div>
                <p className="mt-1 text-[10px] muted">
                  {a.current}/{a.threshold}
                </p>
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="XP System" icon="📊">
          <ul className="space-y-1.5 text-xs">
            {XP_RULES.map(([k, v]) => (
              <li key={k} className="flex justify-between rounded-lg px-2 py-1" style={{ background: "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                <span>{k}</span>
                <span className="font-bold brand-text">{v}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Level System" icon="🎖️">
          <ul className="space-y-1.5 text-xs">
            {TIERS.map(([range, name]) => (
              <li key={range} className="flex justify-between rounded-lg px-2 py-1" style={{ background: "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                <span className="font-mono">{range}</span>
                <span>{name}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Recent Scores" icon="🕹️">
          {scores.length === 0 ? (
            <p className="text-xs muted">No games played yet.</p>
          ) : (
            <ul className="space-y-1.5 text-xs">
              {scores.slice(0, 8).map((s) => (
                <li key={s.id} className="flex items-center justify-between">
                  <span className="capitalize">{s.game.replace("-", " ")}</span>
                  <span className="font-bold">{s.score} pts · {s.accuracy}%</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
