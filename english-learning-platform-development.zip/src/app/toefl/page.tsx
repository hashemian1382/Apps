import Link from "next/link";
import { getUser, getLatestMock, getMockHistory, listArticles, listTracks } from "@/lib/data";
import { Card, Chip, PageHeader, Progress, Tile } from "@/components/ui";
import { LineChart } from "@/components/charts";

export const dynamic = "force-dynamic";

const QUESTION_TYPES = [
  "Factual Information", "Negative Factual (EXCEPT/NOT)", "Inference", "Rhetorical Purpose", "Vocabulary in Context",
  "Reference", "Sentence Simplification", "Insert Text [■]", "Prose Summary", "Category Chart",
];

const LISTENING_TYPES = ["Main idea / Gist", "Detail", "Function ('Why does the professor say…')", "Attitude", "Organization", "Connecting content"];

export default async function ToeflPage() {
  const user = await getUser();
  const [mock, history, passages, lectures] = await Promise.all([
    getLatestMock(user.id),
    getMockHistory(user.id),
    listArticles("toefl"),
    listTracks("toefl"),
  ]);

  const sections = [
    { key: "Reading", icon: "📖", score: mock?.reading ?? 0, target: 26, href: "/reading?module=toefl", color: "#4F46E5" },
    { key: "Listening", icon: "🎧", score: mock?.listening ?? 0, target: 26, href: "/listening?module=toefl", color: "#06B6D4" },
    { key: "Speaking", icon: "🗣️", score: mock?.speaking ?? 0, target: 24, href: "/speaking?module=toefl", color: "#10B981" },
    { key: "Writing", icon: "📝", score: mock?.writing ?? 0, target: 24, href: "/writing?module=toefl", color: "#F59E0B" },
  ];

  const daysLeft = user.examDate ? Math.max(0, Math.round((new Date(user.examDate).getTime() - Date.now()) / 86400000)) : null;
  const plan = [
    { w: "Week 1-2", f: "Foundation — reading speed & core academic vocabulary", done: true },
    { w: "Week 3-4", f: "Skills building — all four sections, question types", done: true },
    { w: "Week 5-6", f: "Practice tests — full length, strict timing", done: false },
    { w: "Week 7-8", f: "Review & weak points — targeted drilling", done: false },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        icon="🎯"
        title="TOEFL Preparation Center"
        subtitle="Section-by-section training, question-type drills and full simulations with score analytics."
        meta={
          <>
            <Chip color="#F59E0B">Target: {user.targetScore}</Chip>
            <Chip color="#10B981">Estimated: {mock?.total ?? "—"}</Chip>
            {daysLeft !== null ? <Chip color="#EF4444">⏰ {daysLeft} days remaining</Chip> : null}
            <Chip>{passages.length} passages · {lectures.length} lectures</Chip>
          </>
        }
        action={
          <Link href="/toefl/mock" className="btn btn-primary">
            📋 Take a mock test
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {sections.map((s) => {
          const pct = Math.round((s.score / s.target) * 100);
          return (
            <Link key={s.key} href={s.href} className="card group relative overflow-hidden p-5 transition hover:-translate-y-1">
              <div className="pointer-events-none absolute -right-8 -top-10 h-24 w-24 rounded-full opacity-25 blur-2xl" style={{ background: s.color }} />
              <div className="flex items-center justify-between">
                <span className="text-xl">{s.icon}</span>
                <span className="chip">target {s.target}</span>
              </div>
              <h3 className="mt-2 font-bold">{s.key}</h3>
              <p className="text-3xl font-extrabold" style={{ color: s.color }}>
                {s.score || "—"}
                <span className="text-sm muted"> /30</span>
              </p>
              <div className="mt-3">
                <Progress value={pct} color={s.color} height={6} />
              </div>
            </Link>
          );
        })}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Tile href="/toefl/mock" icon="📋" title="Full Mock Tests" subtitle="Full, section and mini simulations with timers" color="#4F46E5" />
        <Tile href="/progress" icon="📊" title="Score Analysis" subtitle="Track section trends and error patterns over time" color="#06B6D4" />
        <Tile href="/library?cat=TOEFL%20Resources" icon="📚" title="Strategy Guide" subtitle="Templates, rubrics and the test-day checklist" color="#10B981" />
        <Tile href="/toefl/mock#timed" icon="⏱️" title="Timed Practice" subtitle="Single-section drills at official pacing" color="#F59E0B" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Score History" icon="📈" className="lg:col-span-2">
          <LineChart
            points={history.map((h) => ({ label: new Date(h.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" }), value: h.total }))}
            suffix="total score /120"
          />
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {sections.map((s) => (
              <div key={s.key} className="card-flat p-3 text-center">
                <p className="text-[10px] uppercase tracking-wider muted">{s.key}</p>
                <p className="text-lg font-extrabold" style={{ color: s.color }}>{s.score || "—"}</p>
                <p className="text-[10px] muted">need +{Math.max(0, s.target - s.score)}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card title="8-Week Study Plan" icon="📅">
          <ol className="space-y-2">
            {plan.map((p) => (
              <li key={p.w} className="flex items-start gap-2 rounded-xl px-3 py-2" style={{ background: p.done ? "color-mix(in srgb,#10B981 12%,transparent)" : "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                <span>{p.done ? "✅" : "⬜"}</span>
                <div>
                  <p className="text-xs font-bold">{p.w}</p>
                  <p className="text-[11px] muted">{p.f}</p>
                </div>
              </li>
            ))}
          </ol>
          {daysLeft !== null ? (
            <div className="mt-4 rounded-xl p-3 text-center" style={{ background: "color-mix(in srgb,#EF4444 12%,transparent)" }}>
              <p className="text-2xl font-extrabold" style={{ color: "#EF4444" }}>{daysLeft}</p>
              <p className="text-[11px] muted">days until your exam date</p>
            </div>
          ) : null}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Reading — Question Types" icon="📖">
          <ol className="grid gap-1.5 sm:grid-cols-2">
            {QUESTION_TYPES.map((q, i) => (
              <li key={q} className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs" style={{ background: "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                <span className="grid h-5 w-5 place-items-center rounded-md text-[10px] font-bold brand-bg text-white">{i + 1}</span>
                {q}
              </li>
            ))}
          </ol>
          <Link href="/reading?module=toefl" className="btn btn-primary mt-4 w-full">📖 Practice TOEFL passages</Link>
        </Card>

        <Card title="Listening — Question Types & Notes" icon="🎧">
          <ul className="space-y-1.5">
            {LISTENING_TYPES.map((q) => (
              <li key={q} className="rounded-lg px-2 py-1.5 text-xs" style={{ background: "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                ▸ {q}
              </li>
            ))}
          </ul>
          <div className="mt-3 card-flat p-3 text-[11px] muted">
            <p className="mb-1 font-bold" style={{ color: "var(--text)" }}>Note-taking system</p>
            Use arrows (→ cause), symbols (↑ increase, ≠ contrast), abbreviations (b/c, w/, ex) and a two-column layout: claims on the left,
            examples on the right.
          </div>
          <Link href="/listening?module=toefl" className="btn btn-primary mt-4 w-full">🎧 Practice lectures & conversations</Link>
        </Card>
      </div>
    </div>
  );
}
