"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { saveMockResult } from "@/lib/actions";
import { Card } from "@/components/ui";

type Test = { id: number; title: string; kind: string; minutes: number; blurb: string | null; sections: string[] };

const RAW_TO_SCALED: Record<number, number> = {
  0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 7, 7: 8, 8: 10, 9: 11, 10: 12,
  11: 14, 12: 15, 13: 16, 14: 17, 15: 19, 16: 20, 17: 21, 18: 22, 19: 23, 20: 25,
  21: 26, 22: 27, 23: 28, 24: 29, 25: 29, 26: 30, 27: 30, 28: 30, 29: 30, 30: 30,
};

function fmt(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

export function MockPanel({ tests }: { tests: Test[] }) {
  const [active, setActive] = useState<Test | null>(null);
  const [remaining, setRemaining] = useState(0);
  const [running, setRunning] = useState(false);
  const [scores, setScores] = useState({ reading: 22, listening: 20, speaking: 18, writing: 18 });
  const [rawReading, setRawReading] = useState(15);
  const [saved, setSaved] = useState<string | null>(null);
  const tick = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (running) {
      tick.current = setInterval(() => setRemaining((r) => (r > 0 ? r - 1 : 0)), 1000);
    }
    return () => {
      if (tick.current) clearInterval(tick.current);
    };
  }, [running]);

  const total = scores.reading + scores.listening + scores.speaking + scores.writing;
  const band = useMemo(() => {
    if (total >= 95) return { label: "Advanced (C1)", color: "#10B981" };
    if (total >= 72) return { label: "High-Intermediate (B2)", color: "#06B6D4" };
    if (total >= 42) return { label: "Low-Intermediate (B1)", color: "#F59E0B" };
    return { label: "Basic (A2)", color: "#EF4444" };
  }, [total]);

  function start(t: Test) {
    setActive(t);
    setRemaining(t.minutes * 60);
    setRunning(true);
    setSaved(null);
  }

  async function save() {
    const res = await saveMockResult({ ...scores, minutes: active ? active.minutes - Math.round(remaining / 60) : 60 });
    setSaved(`Saved — total ${res.total}/120`);
    setRunning(false);
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="lg:col-span-2 space-y-4">
        <Card title="Available Tests" icon="📋">
          <div className="grid gap-3 sm:grid-cols-2">
            {tests.map((t) => (
              <div
                key={t.id}
                className="card-flat flex flex-col gap-2 p-4 transition hover:-translate-y-0.5 hover:shadow-lg"
                style={{ borderColor: active?.id === t.id ? "var(--brand)" : "var(--border)" }}
              >
                <div className="flex items-center justify-between">
                  <span className="chip">{t.kind}</span>
                  <span className="text-xs font-bold muted">⏱ {t.minutes} min</span>
                </div>
                <p className="text-sm font-bold">{t.title}</p>
                <p className="text-xs muted">{t.blurb}</p>
                <div className="flex flex-wrap gap-1">
                  {t.sections.map((s) => (
                    <span key={s} className="chip text-[10px]">{s}</span>
                  ))}
                </div>
                <button className="btn btn-primary mt-auto py-1.5 text-xs" onClick={() => start(t)}>
                  ▶️ Start with timer
                </button>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Raw → Scaled Score Calculator" icon="🧮" >
          <p className="text-xs muted">Convert a raw reading/listening score (out of 30 points) to the official 0–30 scaled score.</p>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <input
              type="range"
              min={0}
              max={30}
              value={rawReading}
              onChange={(e) => setRawReading(Number(e.target.value))}
              className="h-2 flex-1 min-w-[180px] cursor-pointer appearance-none rounded-full"
              style={{ background: "color-mix(in srgb, var(--text) 12%, transparent)", accentColor: "var(--brand)" }}
            />
            <span className="chip">raw {rawReading}/30</span>
            <span className="chip" style={{ color: "#10B981" }}>scaled {RAW_TO_SCALED[rawReading]}</span>
          </div>
        </Card>
      </div>

      <div className="space-y-4">
        <Card title="Session Timer" icon="⏱️">
          {active ? (
            <>
              <p className="text-xs muted">{active.title}</p>
              <p className="my-2 text-center font-mono text-4xl font-extrabold" style={{ color: remaining < 300 ? "#EF4444" : "var(--brand)" }}>
                {fmt(remaining)}
              </p>
              <div className="flex gap-2">
                <button className="btn btn-ghost flex-1 py-1.5 text-xs" onClick={() => setRunning((r) => !r)}>
                  {running ? "⏸ Pause" : "▶️ Resume"}
                </button>
                <button className="btn btn-ghost flex-1 py-1.5 text-xs" onClick={() => { setRunning(false); setRemaining(active.minutes * 60); }}>
                  ↺ Reset
                </button>
              </div>
            </>
          ) : (
            <p className="py-6 text-center text-xs muted">Pick a test to start the official countdown.</p>
          )}
        </Card>

        <Card title="Record Your Result" icon="📝">
          {(["reading", "listening", "speaking", "writing"] as const).map((k) => (
            <div key={k} className="mb-3">
              <div className="mb-1 flex justify-between text-xs">
                <span className="capitalize">{k}</span>
                <span className="font-bold">{scores[k]}/30</span>
              </div>
              <input
                type="range"
                min={0}
                max={30}
                value={scores[k]}
                onChange={(e) => setScores((s) => ({ ...s, [k]: Number(e.target.value) }))}
                className="h-2 w-full cursor-pointer appearance-none rounded-full"
                style={{ background: "color-mix(in srgb, var(--text) 12%, transparent)", accentColor: "var(--brand)" }}
              />
            </div>
          ))}
          <div className="card-flat mt-3 p-3 text-center">
            <p className="text-3xl font-extrabold" style={{ color: band.color }}>{total}</p>
            <p className="text-[11px] muted">/120 · {band.label}</p>
          </div>
          <button className="btn btn-primary mt-3 w-full" onClick={save}>
            💾 Save result (+300 XP)
          </button>
          {saved ? <p className="mt-2 text-center text-xs" style={{ color: "#10B981" }}>{saved}</p> : null}
        </Card>
      </div>
    </div>
  );
}
