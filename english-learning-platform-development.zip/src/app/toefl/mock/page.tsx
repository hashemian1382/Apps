import { getUser, listMockTests, getMockHistory } from "@/lib/data";
import { Card, Chip, PageHeader } from "@/components/ui";
import { MockPanel } from "./MockPanel";

export const dynamic = "force-dynamic";

export default async function MockPage() {
  const user = await getUser();
  const [tests, history] = await Promise.all([listMockTests(), getMockHistory(user.id)]);

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📋"
        title="Mock Tests & Timed Practice"
        subtitle="Simulate exam conditions, then log your section scores so the platform can track your trend."
        meta={
          <>
            <Chip>{tests.length} tests available</Chip>
            <Chip color="#10B981">{history.length} attempts recorded</Chip>
          </>
        }
      />

      <MockPanel tests={tests.map((t) => ({ ...t, sections: t.sections as string[] }))} />

      <Card title="Results Archive" icon="🗄️">
        {history.length === 0 ? (
          <p className="text-xs muted">No attempts yet — record your first result above.</p>
        ) : (
          <div className="overflow-x-auto scroll-thin">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="muted">
                  <th className="py-2 pr-4 font-semibold">Date</th>
                  <th className="py-2 pr-4 font-semibold">Reading</th>
                  <th className="py-2 pr-4 font-semibold">Listening</th>
                  <th className="py-2 pr-4 font-semibold">Speaking</th>
                  <th className="py-2 pr-4 font-semibold">Writing</th>
                  <th className="py-2 pr-4 font-semibold">Total</th>
                  <th className="py-2 font-semibold">Minutes</th>
                </tr>
              </thead>
              <tbody>
                {[...history].reverse().map((h) => (
                  <tr key={h.id} className="border-t" style={{ borderColor: "var(--border)" }}>
                    <td className="py-2 pr-4">{new Date(h.createdAt).toLocaleDateString()}</td>
                    <td className="py-2 pr-4">{h.reading}</td>
                    <td className="py-2 pr-4">{h.listening}</td>
                    <td className="py-2 pr-4">{h.speaking}</td>
                    <td className="py-2 pr-4">{h.writing}</td>
                    <td className="py-2 pr-4 font-bold brand-text">{h.total}</td>
                    <td className="py-2">{h.minutes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
