import Link from "next/link";
import { getUser, listLessons, getLessonStatuses } from "@/lib/data";
import { Card, Chip, PageHeader, Progress } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function GrammarPage() {
  const user = await getUser();
  const lessons = await listLessons();
  const statuses = await getLessonStatuses(user.id, lessons.map((l) => l.id));
  const byId = new Map(statuses.map((s) => [s.lessonId, s]));

  const levels = Array.from(new Set(lessons.map((l) => l.level)));
  const completed = statuses.filter((s) => s.status === "completed").length;

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📝"
        title="Grammar"
        subtitle="Structured lessons from A1 to C2, each with examples, common mistakes, Persian hints, practice and a printable reference card."
        meta={
          <>
            <Chip>{lessons.length} lessons</Chip>
            <Chip color="#10B981">{completed} completed</Chip>
            <Chip color="#F59E0B">TOEFL grammar included</Chip>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {levels.map((lvl) => {
          const items = lessons.filter((l) => l.level === lvl);
          const done = items.filter((i) => byId.get(i.id)?.status === "completed").length;
          return (
            <div key={lvl} className="card p-4">
              <p className="text-xs font-bold">{lvl}</p>
              <p className="mt-1 text-2xl font-extrabold brand-text">
                {done}/{items.length}
              </p>
              <div className="mt-2">
                <Progress value={(done / Math.max(1, items.length)) * 100} height={6} />
              </div>
            </div>
          );
        })}
      </div>

      {levels.map((lvl) => (
        <Card key={lvl} title={lvl} icon="📂">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {lessons
              .filter((l) => l.level === lvl)
              .map((l) => {
                const st = byId.get(l.id);
                const pct = st?.progress ?? 0;
                return (
                  <Link key={l.id} href={`/grammar/${l.slug}`} className="card-flat group p-4 transition hover:-translate-y-0.5 hover:shadow-lg">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-bold leading-snug">{l.title}</h3>
                      <span className="chip shrink-0">{l.minutes}m</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs muted">{l.subtitle}</p>
                    <div className="mt-3 flex items-center gap-2">
                      <span className="text-[10px] muted">{"⭐".repeat(Math.min(5, l.difficulty))}</span>
                      <span className="ml-auto text-[10px] font-bold" style={{ color: pct === 100 ? "#10B981" : "var(--muted)" }}>
                        {pct === 100 ? "✅ Completed" : pct > 0 ? `${pct}%` : "Not started"}
                      </span>
                    </div>
                    <div className="mt-2">
                      <Progress value={pct} height={5} color={pct === 100 ? "#10B981" : undefined} />
                    </div>
                  </Link>
                );
              })}
          </div>
        </Card>
      ))}
    </div>
  );
}
