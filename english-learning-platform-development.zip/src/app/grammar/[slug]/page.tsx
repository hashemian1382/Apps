import Link from "next/link";
import { notFound } from "next/navigation";
import { getLesson, getLessonProgress, getUser } from "@/lib/data";
import { Chip, PageHeader } from "@/components/ui";
import { LessonViewer, type LessonData } from "../LessonViewer";

export const dynamic = "force-dynamic";

export default async function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const lesson = await getLesson(slug);
  if (!lesson) notFound();
  const user = await getUser();
  const progress = await getLessonProgress(user.id, lesson.id);

  const data: LessonData = {
    id: lesson.id,
    title: lesson.title,
    subtitle: lesson.subtitle,
    structure: lesson.structure,
    level: lesson.level,
    minutes: lesson.minutes,
    difficulty: lesson.difficulty,
    persianHint: lesson.persianHint,
    body: lesson.body,
    examples: lesson.examples,
    mistakes: lesson.mistakes,
    quickCard: lesson.quickCard,
    questions: lesson.questions,
  };

  return (
    <div className="space-y-4">
      <Link href="/grammar" className="btn btn-ghost px-3 py-1 text-xs">
        ← All grammar lessons
      </Link>
      <PageHeader
        icon="📝"
        title={lesson.title}
        subtitle={lesson.subtitle ?? undefined}
        meta={
          <>
            <Chip>⏱ ~{lesson.minutes} min</Chip>
            <Chip color="#F59E0B">{"⭐".repeat(Math.min(5, lesson.difficulty))}</Chip>
            <Chip>{lesson.level}</Chip>
            <Chip color="#10B981">Progress: {progress?.progress ?? 0}%</Chip>
          </>
        }
      />
      <LessonViewer lesson={data} initialProgress={progress?.progress ?? 0} />
    </div>
  );
}
