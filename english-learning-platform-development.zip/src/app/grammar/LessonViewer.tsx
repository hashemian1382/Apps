"use client";

import { useMemo, useState } from "react";
import { saveLessonResult } from "@/lib/actions";
import { SpeakButton } from "@/components/Speak";

type Question = { type: string; prompt: string; options?: string[]; answer: string; explain?: string };

export type LessonData = {
  id: number;
  title: string;
  subtitle: string | null;
  structure: string | null;
  level: string;
  minutes: number;
  difficulty: number;
  persianHint: string | null;
  body: { heading: string; text: string }[];
  examples: { en: string; fa: string; note?: string }[];
  mistakes: { wrong: string; right: string; why: string }[];
  quickCard: string[];
  questions: Question[];
};

const TABS = [
  { key: "lesson", label: "📖 Lesson" },
  { key: "examples", label: "📊 Examples" },
  { key: "practice", label: "✏️ Practice" },
  { key: "game", label: "🎮 Game" },
  { key: "card", label: "📋 Card" },
] as const;

function renderBold(text: string) {
  const parts = text.split(/\*\*(.+?)\*\*/g);
  return parts.map((p, i) => (i % 2 === 1 ? <strong key={i} className="brand-text">{p}</strong> : <span key={i}>{p}</span>));
}

function normalise(s: string) {
  return s.toLowerCase().replace(/[.,!?;]/g, "").replace(/\s*\/\s*/g, " / ").replace(/\s+/g, " ").trim();
}

export function LessonViewer({ lesson, initialProgress }: { lesson: LessonData; initialProgress: number }) {
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("lesson");
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [checked, setChecked] = useState<Record<number, boolean>>({});
  const [progress, setProgress] = useState(initialProgress);
  const [flash, setFlash] = useState<string | null>(null);

  const correctCount = useMemo(
    () => lesson.questions.filter((q, i) => checked[i] && normalise(answers[i] ?? "") === normalise(q.answer)).length,
    [answers, checked, lesson.questions],
  );
  const checkedCount = Object.keys(checked).length;

  function check(i: number) {
    setChecked((c) => ({ ...c, [i]: true }));
    const done = Object.keys({ ...checked, [i]: true }).length;
    setProgress(Math.round((done / lesson.questions.length) * 100));
  }

  async function finish() {
    const res = await saveLessonResult(lesson.id, correctCount, lesson.questions.length, 100);
    setProgress(100);
    setFlash(`Lesson completed · +${res.xp} XP · ${correctCount}/${lesson.questions.length} correct`);
  }

  /* Simple drag-free "game": reorder-by-click sentence builder from example sentences */
  const gameSentence = lesson.examples[0]?.en.replace(/\*\*/g, "") ?? "Practice makes perfect";
  const [pool, setPool] = useState<string[]>(() => [...gameSentence.split(" ")].sort(() => Math.random() - 0.5));
  const [built, setBuilt] = useState<string[]>([]);
  const gameWon = built.join(" ") === gameSentence;

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="flex flex-wrap items-center gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`btn px-3 py-1.5 text-xs ${tab === t.key ? "btn-primary" : "btn-ghost"}`}
            >
              {t.label}
            </button>
          ))}
          <span className="ml-auto chip">Progress {progress}%</span>
        </div>
      </div>

      {tab === "lesson" ? (
        <div className="space-y-4 animate-slide-up">
          {lesson.structure ? (
            <div className="card p-5" style={{ borderColor: "color-mix(in srgb, var(--brand) 35%, transparent)" }}>
              <p className="text-[11px] font-bold uppercase tracking-wider muted">🔵 Structure</p>
              <p className="mt-1 font-mono text-sm font-bold brand-text">{lesson.structure}</p>
            </div>
          ) : null}

          {lesson.body.map((b) => (
            <div key={b.heading} className="card p-5">
              <h3 className="mb-2 text-sm font-bold">{b.heading}</h3>
              <p className="text-sm leading-relaxed muted">{b.text}</p>
            </div>
          ))}

          {lesson.mistakes.length > 0 ? (
            <div className="card p-5">
              <h3 className="mb-3 text-sm font-bold">⚠️ Common Mistakes</h3>
              <div className="space-y-3">
                {lesson.mistakes.map((m) => (
                  <div key={m.wrong} className="card-flat p-3">
                    <p className="text-sm" style={{ color: "#EF4444" }}>❌ {m.wrong}</p>
                    <p className="text-sm" style={{ color: "#10B981" }}>✅ {m.right}</p>
                    <p className="mt-1 text-xs muted">{m.why}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : null}

          {lesson.persianHint ? (
            <div className="card p-5" style={{ borderColor: "color-mix(in srgb, #10B981 30%, transparent)" }}>
              <p className="text-[11px] font-bold uppercase tracking-wider muted">🇮🇷 Persian Hint</p>
              <p className="fa mt-2 text-sm leading-loose">{lesson.persianHint}</p>
            </div>
          ) : null}
        </div>
      ) : null}

      {tab === "examples" ? (
        <div className="space-y-3 animate-slide-up">
          {lesson.examples.map((ex) => (
            <div key={ex.en} className="card p-5">
              <div className="flex items-start justify-between gap-3">
                <p className="text-base leading-relaxed">{renderBold(ex.en)}</p>
                <SpeakButton text={ex.en.replace(/\*\*/g, "")} />
              </div>
              <p className="fa mt-2 text-sm muted">{ex.fa}</p>
              {ex.note ? <p className="mt-2 chip">{ex.note}</p> : null}
            </div>
          ))}
        </div>
      ) : null}

      {tab === "practice" ? (
        <div className="space-y-3 animate-slide-up">
          {lesson.questions.map((q, i) => {
            const isChecked = checked[i];
            const isCorrect = normalise(answers[i] ?? "") === normalise(q.answer);
            return (
              <div
                key={q.prompt}
                className="card p-5"
                style={{
                  borderColor: isChecked ? (isCorrect ? "color-mix(in srgb,#10B981 45%,transparent)" : "color-mix(in srgb,#EF4444 45%,transparent)") : "var(--border)",
                }}
              >
                <p className="mb-3 text-sm font-semibold">
                  <span className="mr-2 chip">{i + 1}</span>
                  {q.prompt}
                </p>
                {q.options ? (
                  <div className="grid gap-2 sm:grid-cols-2">
                    {q.options.map((opt) => {
                      const selected = answers[i] === opt;
                      const showRight = isChecked && normalise(opt) === normalise(q.answer);
                      const showWrong = isChecked && selected && !showRight;
                      return (
                        <button
                          key={opt}
                          onClick={() => !isChecked && setAnswers((a) => ({ ...a, [i]: opt }))}
                          className="rounded-xl border px-3 py-2 text-left text-xs transition"
                          style={{
                            borderColor: showRight ? "#10B981" : showWrong ? "#EF4444" : selected ? "var(--brand)" : "var(--border)",
                            background: showRight
                              ? "color-mix(in srgb,#10B981 14%,transparent)"
                              : showWrong
                              ? "color-mix(in srgb,#EF4444 14%,transparent)"
                              : selected
                              ? "color-mix(in srgb,var(--brand) 12%,transparent)"
                              : "transparent",
                          }}
                        >
                          {showRight ? "✅ " : showWrong ? "❌ " : ""}
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <input
                    className="input"
                    placeholder="Type your answer…"
                    value={answers[i] ?? ""}
                    disabled={isChecked}
                    onChange={(e) => setAnswers((a) => ({ ...a, [i]: e.target.value }))}
                  />
                )}
                <div className="mt-3 flex items-center gap-2">
                  <button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => check(i)} disabled={isChecked || !answers[i]}>
                    Check ✓
                  </button>
                  {isChecked ? (
                    <span className="text-xs font-bold" style={{ color: isCorrect ? "#10B981" : "#EF4444" }}>
                      {isCorrect ? "Correct!" : `Answer: ${q.answer}`}
                    </span>
                  ) : null}
                </div>
                {isChecked && q.explain ? <p className="mt-2 text-xs muted">💡 {q.explain}</p> : null}
              </div>
            );
          })}

          <div className="card flex flex-wrap items-center gap-3 p-4">
            <span className="text-sm font-bold">
              Score: {correctCount}/{lesson.questions.length}
            </span>
            <span className="chip">{checkedCount} answered</span>
            <button className="btn btn-primary ml-auto" onClick={finish} disabled={checkedCount < lesson.questions.length}>
              ✅ Complete lesson
            </button>
          </div>
          {flash ? <p className="text-center text-sm font-bold" style={{ color: "#10B981" }}>{flash}</p> : null}
        </div>
      ) : null}

      {tab === "game" ? (
        <div className="card p-5 animate-slide-up">
          <h3 className="text-sm font-bold">🎮 Sentence Builder</h3>
          <p className="mt-1 text-xs muted">Click the words in the correct order to rebuild the example sentence.</p>
          <div className="my-4 min-h-[56px] rounded-xl border border-dashed p-3 text-sm" style={{ borderColor: "var(--border)" }}>
            {built.length === 0 ? <span className="muted">Your sentence appears here…</span> : built.join(" ")}
          </div>
          <div className="flex flex-wrap gap-2">
            {pool.map((w, idx) => (
              <button
                key={w + idx}
                className="btn btn-ghost px-3 py-1.5 text-xs"
                onClick={() => {
                  setBuilt((b) => [...b, w]);
                  setPool((p) => p.filter((_, i) => i !== idx));
                }}
              >
                {w}
              </button>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <button
              className="btn btn-ghost px-3 py-1.5 text-xs"
              onClick={() => {
                setPool([...gameSentence.split(" ")].sort(() => Math.random() - 0.5));
                setBuilt([]);
              }}
            >
              ↺ Reset
            </button>
            {gameWon ? <span className="text-sm font-bold" style={{ color: "#10B981" }}>🎉 Perfect word order!</span> : null}
          </div>
        </div>
      ) : null}

      {tab === "card" ? (
        <div className="card p-6 animate-slide-up" style={{ borderColor: "color-mix(in srgb,var(--brand) 35%,transparent)" }}>
          <h3 className="mb-1 text-lg font-extrabold brand-text">{lesson.title}</h3>
          <p className="text-xs muted">Quick reference card · {lesson.level}</p>
          <ul className="mt-4 space-y-2">
            {lesson.quickCard.map((c) => (
              <li key={c} className="flex items-start gap-2 rounded-xl px-3 py-2 text-sm" style={{ background: "color-mix(in srgb,var(--brand) 9%,transparent)" }}>
                <span>▹</span>
                <span className="font-mono">{c}</span>
              </li>
            ))}
          </ul>
          <button className="btn btn-ghost mt-4 px-3 py-1.5 text-xs" onClick={() => window.print()}>
            🖨️ Print / save as PDF
          </button>
        </div>
      ) : null}
    </div>
  );
}
