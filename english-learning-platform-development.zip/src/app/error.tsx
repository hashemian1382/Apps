"use client";

export default function ErrorBoundary({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="card mx-auto grid max-w-lg place-items-center gap-3 p-12 text-center">
      <span className="text-5xl">🛠️</span>
      <h1 className="text-2xl font-extrabold">Something went wrong</h1>
      <p className="text-sm muted">{error.message || "An unexpected error occurred while loading this section."}</p>
      <div className="mt-2 flex gap-2">
        <button className="btn btn-primary" onClick={reset}>↻ Try again</button>
        <a className="btn btn-ghost" href="/">🏠 Dashboard</a>
      </div>
    </div>
  );
}
