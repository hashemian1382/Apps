import Link from "next/link";
import { getUser, listArticles, getReadingLogs } from "@/lib/data";
import { Card, Chip, PageHeader, Stat } from "@/components/ui";

export const dynamic = "force-dynamic";

const MODULES = [
  { key: "", label: "All texts", icon: "📚" },
  { key: "general", label: "General", icon: "📖" },
  { key: "tech", label: "Technical / CS", icon: "💻" },
  { key: "toefl", label: "TOEFL-style", icon: "🎯" },
];

const SKILLS = ["Skimming", "Scanning", "Inference", "Main Idea", "Vocabulary in Context", "Summary Writing"];

export default async function ReadingPage({ searchParams }: { searchParams: Promise<{ module?: string }> }) {
  const sp = await searchParams;
  const user = await getUser();
  const [items, logs] = await Promise.all([listArticles(sp.module), getReadingLogs(user.id)]);
  const avgWpm = logs.length ? Math.round(logs.reduce((a, b) => a + b.log.wpm, 0) / logs.length) : 0;
  const avgScore = logs.length ? (logs.reduce((a, b) => a + b.log.score, 0) / logs.length).toFixed(1) : "—";

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📖"
        title="Reading"
        subtitle="Graded texts with an interactive glossary, reading-speed tracking and TOEFL-style question sets."
        meta={
          <>
            <Chip>{items.length} passages</Chip>
            <Chip color="#10B981">{logs.length} completed</Chip>
            <Chip color="#06B6D4">avg {avgWpm || "—"} WPM</Chip>
          </>
        }
      />

      <div className="flex flex-wrap gap-2">
        {MODULES.map((m) => (
          <Link
            key={m.key}
            href={m.key ? `/reading?module=${m.key}` : "/reading"}
            className={`btn px-3 py-1.5 text-xs ${(sp.module ?? "") === m.key ? "btn-primary" : "btn-ghost"}`}
          >
            {m.icon} {m.label}
          </Link>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Passages read" value={logs.length} icon="📚" />
        <Stat label="Average WPM" value={avgWpm || "—"} sub="target: 150+" icon="⚡" accent="#06B6D4" />
        <Stat label="Average score" value={avgScore} sub="out of 5" icon="🎯" accent="#10B981" />
        <Stat label="Levels available" value="1 – 5" sub="300 → 1000+ words" icon="📊" />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
        <div className="grid gap-3 sm:grid-cols-2">
          {items.map((a) => (
            <Link key={a.id} href={`/reading/${a.slug}`} className="card group p-5 transition hover:-translate-y-1 hover:shadow-xl">
              <div className="flex items-center gap-2">
                <span className="chip">Level {a.level}</span>
                <span className="chip">{a.topic}</span>
                <span className="ml-auto text-[11px] muted">⏱ {a.minutes}m</span>
              </div>
              <h3 className="mt-3 text-base font-bold leading-snug">{a.title}</h3>
              <p className="mt-1 line-clamp-2 text-xs muted">{a.paragraphs[0]}</p>
              <div className="mt-3 flex items-center gap-2 text-[11px] muted">
                <span>{a.wordCount} words</span>·<span>{a.questions.length} questions</span>·<span>{a.glossary.length} glossary terms</span>
              </div>
            </Link>
          ))}
        </div>

        <aside className="space-y-4">
          <Card title="Reading Skills" icon="🎯">
            <div className="flex flex-wrap gap-1.5">
              {SKILLS.map((s) => (
                <span key={s} className="chip">{s}</span>
              ))}
            </div>
          </Card>

          <Card title="Reading Log" icon="🗒️">
            {logs.length === 0 ? (
              <p className="text-xs muted">No sessions logged yet.</p>
            ) : (
              <ul className="space-y-2">
                {logs.slice(0, 6).map((l) => (
                  <li key={l.log.id} className="text-xs">
                    <p className="truncate font-semibold">{l.article.title}</p>
                    <p className="muted">
                      {l.log.score}/{l.log.total} · {l.log.wpm} WPM · {new Date(l.log.createdAt).toLocaleDateString()}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </aside>
      </div>
    </div>
  );
}
