import Link from "next/link";
import { notFound } from "next/navigation";
import { getArticle } from "@/lib/data";
import { Chip, PageHeader } from "@/components/ui";
import { ArticleReader } from "../ArticleReader";

export const dynamic = "force-dynamic";

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await getArticle(slug);
  if (!article) notFound();

  return (
    <div className="space-y-4">
      <Link href={`/reading${article.module !== "general" ? `?module=${article.module}` : ""}`} className="btn btn-ghost px-3 py-1 text-xs">
        ← Back to reading library
      </Link>
      <PageHeader
        icon="📖"
        title={article.title}
        meta={
          <>
            <Chip>Level {article.level}</Chip>
            <Chip>⏱ ~{article.minutes} min</Chip>
            <Chip color="#06B6D4">{article.topic}</Chip>
            <Chip color="#F59E0B">{article.module === "toefl" ? "TOEFL-style" : article.module === "tech" ? "Technical" : "General"}</Chip>
          </>
        }
      />
      <ArticleReader
        article={{
          id: article.id,
          title: article.title,
          paragraphs: article.paragraphs,
          glossary: article.glossary,
          questions: article.questions,
          wordCount: article.wordCount,
          topic: article.topic,
          level: article.level,
        }}
      />
    </div>
  );
}
