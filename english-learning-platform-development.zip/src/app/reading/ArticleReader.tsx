"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { saveReadingLog } from "@/lib/actions";
import { SpeakButton } from "@/components/Speak";
import { Card, Chip } from "@/components/ui";

type Glossary = { term: string; en: string; fa: string };
type Question = { qType: string; prompt: string; options: string[]; answer: string; explain?: string };

export function ArticleReader({
  article,
}: {
  article: { id: number; title: string; paragraphs: string[]; glossary: Glossary[]; questions: Question[]; wordCount: number; topic: string; level: number };
}) {
  const [seconds, setSeconds] = useState(0);
  const [readingDone, setReadingDone] = useState(false);
  const [selected, setSelected] = useState<Glossary | null>(null);
  const [saved, setSelectedWords] = useState<string[]>([]);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [difficulty, setDifficulty] = useState<string | null>(null);
  const [nightMode, setNightMode] = useState(false);
  const [fontScale, setFontScale] = useState(1);
  const started = useRef(Date.now());

  useEffect(() => {
    const t = setInterval(() => setSeconds(Math.round((Date.now() - started.current) / 1000)), 1000);
    return () => clearInterval(t);
  }, []);

  const glossaryMap = useMemo(() => new Map(article.glossary.map((g) => [g.term.toLowerCase(), g])), [article.glossary]);
  const wpm = seconds > 3 ? Math.round(article.wordCount / (seconds / 60)) : 0;
  const score = article.questions.filter((q, i) => answers[i] === q.answer).length;

  function renderParagraph(text: string, key: number) {
    const tokens = text.split(/(\b[\w'-]+\b)/g);
    return (
      <p key={key} className="mb-4 leading-[1.95]" style={{ fontSize: `${fontScale}rem` }}>
        {tokens.map((tok, i) => {
          const g = glossaryMap.get(tok.toLowerCase());
          if (!g) return <span key={i}>{tok}</span>;
          return (
            <button
              key={i}
              onClick={() => setSelected(g)}
              className="rounded px-0.5 font-semibold underline decoration-dotted underline-offset-4 transition hover:opacity-80"
              style={{ color: "var(--brand)", background: "color-mix(in srgb, var(--brand) 10%, transparent)" }}
            >
              {tok}
            </button>
          );
        })}
      </p>
    );
  }

  async function submit() {
    setSubmitted(true);
    await saveReadingLog(article.id, score, article.questions.length, wpm, seconds);
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
      <div className="space-y-4">
        <div className="card flex flex-wrap items-center gap-2 p-3 text-xs">
          <Chip>⏱ {String(Math.floor(seconds / 60)).padStart(2, "0")}:{String(seconds % 60).padStart(2, "0")}</Chip>
          <Chip color="#10B981">{wpm || "—"} WPM</Chip>
          <Chip>{article.wordCount} words</Chip>
          <div className="ml-auto flex items-center gap-1.5">
            <button className="btn btn-ghost px-2 py-1 text-xs" onClick={() => setFontScale((f) => Math.max(0.85, f - 0.1))}>A−</button>
            <button className="btn btn-ghost px-2 py-1 text-xs" onClick={() => setFontScale((f) => Math.min(1.5, f + 0.1))}>A+</button>
            <button className={`btn px-2 py-1 text-xs ${nightMode ? "btn-primary" : "btn-ghost"}`} onClick={() => setNightMode((v) => !v)}>
              🌙 Night read
            </button>
            <SpeakButton text={article.paragraphs.join(" ")} label="Read aloud" />
          </div>
        </div>

        <article
          className="card p-6"
          style={nightMode ? { background: "#1a1408", color: "#f5e6c8", borderColor: "rgba(245,230,200,0.15)" } : undefined}
        >
          <h2 className="mb-4 text-xl font-extrabold">{article.title}</h2>
          {article.paragraphs.map((p, i) => renderParagraph(p, i))}
          <p className="mt-4 text-xs muted">💡 Click any highlighted word to see its meaning in the panel.</p>
        </article>

        {!readingDone ? (
          <div className="card flex flex-wrap items-center gap-3 p-4">
            <span className="text-sm font-semibold">How difficult did it feel?</span>
            {["Easy", "OK", "Hard"].map((d) => (
              <button key={d} className={`btn px-3 py-1.5 text-xs ${difficulty === d ? "btn-primary" : "btn-ghost"}`} onClick={() => setDifficulty(d)}>
                {d}
              </button>
            ))}
            <button className="btn btn-primary ml-auto" onClick={() => setReadingDone(true)}>
              📝 Go to comprehension questions →
            </button>
          </div>
        ) : (
          <Card title={`Comprehension Questions (${article.questions.length})`} icon="📝">
            <div className="space-y-4">
              {article.questions.map((q, i) => {
                const chosen = answers[i];
                return (
                  <div key={q.prompt} className="card-flat p-4">
                    <div className="mb-2 flex items-start gap-2">
                      <span className="chip shrink-0">{q.qType}</span>
                    </div>
                    <p className="mb-3 text-sm font-semibold">{i + 1}. {q.prompt}</p>
                    <div className="grid gap-2">
                      {q.options.map((opt, oi) => {
                        const isRight = submitted && opt === q.answer;
                        const isWrong = submitted && chosen === opt && opt !== q.answer;
                        return (
                          <button
                            key={opt}
                            disabled={submitted}
                            onClick={() => setAnswers((a) => ({ ...a, [i]: opt }))}
                            className="rounded-xl border px-3 py-2 text-left text-xs transition"
                            style={{
                              borderColor: isRight ? "#10B981" : isWrong ? "#EF4444" : chosen === opt ? "var(--brand)" : "var(--border)",
                              background: isRight
                                ? "color-mix(in srgb,#10B981 14%,transparent)"
                                : isWrong
                                ? "color-mix(in srgb,#EF4444 14%,transparent)"
                                : chosen === opt
                                ? "color-mix(in srgb,var(--brand) 12%,transparent)"
                                : "transparent",
                            }}
                          >
                            <span className="mr-2 font-bold muted">{String.fromCharCode(65 + oi)})</span>
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                    {submitted && q.explain ? <p className="mt-2 text-xs muted">💡 {q.explain}</p> : null}
                  </div>
                );
              })}
            </div>

            {!submitted ? (
              <button className="btn btn-primary mt-4 w-full" disabled={Object.keys(answers).length < article.questions.length} onClick={submit}>
                ✅ Check answers &amp; save result (+100 XP)
              </button>
            ) : (
              <div className="card-flat mt-4 grid grid-cols-3 gap-3 p-4 text-center">
                <div>
                  <p className="text-2xl font-extrabold brand-text">{score}/{article.questions.length}</p>
                  <p className="text-[10px] muted">score</p>
                </div>
                <div>
                  <p className="text-2xl font-extrabold">{wpm}</p>
                  <p className="text-[10px] muted">WPM</p>
                </div>
                <div>
                  <p className="text-2xl font-extrabold">{Math.floor(seconds / 60)}:{String(seconds % 60).padStart(2, "0")}</p>
                  <p className="text-[10px] muted">time</p>
                </div>
              </div>
            )}
          </Card>
        )}
      </div>

      {/* Vocabulary panel */}
      <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
        <Card title="Vocabulary Panel" icon="📋">
          {selected ? (
            <div className="card-flat mb-3 p-3 animate-pop">
              <div className="flex items-center justify-between">
                <p className="font-bold brand-text">{selected.term}</p>
                <SpeakButton text={selected.term} label="" />
              </div>
              <p className="mt-1 text-xs">{selected.en}</p>
              <p className="fa mt-0.5 text-xs muted">{selected.fa}</p>
              <button
                className="btn btn-ghost mt-2 w-full py-1 text-[11px]"
                onClick={() => setSelectedWords((s) => (s.includes(selected.term) ? s : [...s, selected.term]))}
              >
                ⭐ Add to my list
              </button>
            </div>
          ) : (
            <p className="mb-3 text-xs muted">Click a highlighted word in the text to see its definition here.</p>
          )}

          <div className="space-y-1.5">
            {article.glossary.map((g) => (
              <button
                key={g.term}
                onClick={() => setSelected(g)}
                className="flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-left text-xs transition hover:bg-[color-mix(in_srgb,var(--text)_7%,transparent)]"
              >
                <span className="font-semibold">{g.term}</span>
                <span className="fa truncate pl-2 muted">{g.fa}</span>
              </button>
            ))}
          </div>
        </Card>

        {saved.length > 0 ? (
          <Card title="My list from this text" icon="⭐">
            <div className="flex flex-wrap gap-1.5">
              {saved.map((s) => (
                <span key={s} className="chip">{s}</span>
              ))}
            </div>
          </Card>
        ) : null}

        <Card title="Strategy" icon="🎯">
          <ul className="space-y-1.5 text-[11px] muted">
            <li>▸ Skim the first sentence of each paragraph first.</li>
            <li>▸ Aim for 150+ WPM on level 3–4 texts.</li>
            <li>▸ Never stop on unknown words during the first pass.</li>
            <li>▸ Answer detail questions by locating keywords, not memory.</li>
          </ul>
        </Card>
      </aside>
    </div>
  );
}
