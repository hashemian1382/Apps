import Link from "next/link";

export default function NotFound() {
  return (
    <div className="card mx-auto grid max-w-lg place-items-center gap-3 p-12 text-center">
      <span className="text-5xl floaty">🧭</span>
      <h1 className="text-2xl font-extrabold">Page not found</h1>
      <p className="text-sm muted">
        That lesson, passage or resource does not exist (yet). Try the dashboard or jump straight into a review session.
      </p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        <Link href="/" className="btn btn-primary">🏠 Dashboard</Link>
        <Link href="/review" className="btn btn-ghost">🧠 Smart Review</Link>
        <Link href="/library" className="btn btn-ghost">📕 Library</Link>
      </div>
    </div>
  );
}
