import { getUser } from "@/lib/data";
import { Chip, PageHeader } from "@/components/ui";
import { SettingsForm } from "./SettingsForm";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getUser();

  return (
    <div className="space-y-6">
      <PageHeader
        icon="⚙️"
        title="Settings"
        subtitle="Tune the platform to your schedule, level and learning style. Changes apply instantly."
        meta={
          <>
            <Chip>{user.name}</Chip>
            <Chip color="#4F46E5">{user.englishLevel}</Chip>
            <Chip color="#F59E0B">Target {user.targetScore}</Chip>
          </>
        }
      />
      <SettingsForm
        user={{
          id: user.id,
          name: user.name,
          englishLevel: user.englishLevel,
          techLevel: user.techLevel,
          targetScore: user.targetScore,
          examDate: user.examDate,
          dailyGoalMinutes: user.dailyGoalMinutes,
          newWordsPerDay: user.newWordsPerDay,
          reviewsPerDay: user.reviewsPerDay,
          showPersian: user.showPersian,
          theme: user.theme,
          accent: user.accent,
          fontSize: user.fontSize,
          voice: user.voice,
          autoPlayAudio: user.autoPlayAudio,
          soundEffects: user.soundEffects,
          reminderTime: user.reminderTime,
        }}
      />
    </div>
  );
}
