"use client";

import { useState } from "react";
import { updateSettings } from "@/lib/actions";
import { Card } from "@/components/ui";

type Props = {
  user: {
    id: number; name: string; englishLevel: string; techLevel: string; targetScore: number; examDate: string | null;
    dailyGoalMinutes: number; newWordsPerDay: number; reviewsPerDay: number; showPersian: boolean; theme: string;
    accent: string; fontSize: string; voice: string; autoPlayAudio: boolean; soundEffects: boolean; reminderTime: string;
  };
};

export function SettingsForm({ user }: Props) {
  const [form, setForm] = useState(user);
  const [saved, setSaved] = useState<string | null>(null);
  const [resetting, setResetting] = useState(false);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    if (key === "theme") document.documentElement.setAttribute("data-theme", String(value));
    if (key === "accent") document.documentElement.setAttribute("data-accent", String(value));
    if (key === "fontSize") document.documentElement.setAttribute("data-fontsize", String(value));
  }

  async function save() {
    const { id, ...rest } = form;
    void id;
    await updateSettings(rest);
    setSaved("Settings saved ✓");
    window.setTimeout(() => setSaved(null), 2500);
  }

  async function reset() {
    setResetting(true);
    await fetch("/api/reset", { method: "POST" });
    setResetting(false);
    setSaved("Progress reset — reload to see a clean slate.");
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Profile" icon="👤">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Name">
            <input className="input" value={form.name} onChange={(e) => set("name", e.target.value)} />
          </Field>
          <Field label="English level">
            <select className="input" value={form.englishLevel} onChange={(e) => set("englishLevel", e.target.value)}>
              {["A1", "A2", "B1", "B2", "C1", "C2"].map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </Field>
          <Field label="Technical level">
            <select className="input" value={form.techLevel} onChange={(e) => set("techLevel", e.target.value)}>
              {["Junior", "Mid", "Senior"].map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </Field>
          <Field label="TOEFL target score">
            <input type="number" min={0} max={120} className="input" value={form.targetScore} onChange={(e) => set("targetScore", Number(e.target.value))} />
          </Field>
          <Field label="Exam date">
            <input type="date" className="input" value={form.examDate ?? ""} onChange={(e) => set("examDate", e.target.value)} />
          </Field>
          <Field label={`Study goal: ${form.dailyGoalMinutes} min/day`}>
            <input type="range" min={10} max={180} step={5} className="w-full" style={{ accentColor: "var(--brand)" }} value={form.dailyGoalMinutes} onChange={(e) => set("dailyGoalMinutes", Number(e.target.value))} />
          </Field>
        </div>
      </Card>

      <Card title="Learning Preferences" icon="🎯">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label={`New words/day: ${form.newWordsPerDay}`}>
            <input type="range" min={5} max={50} className="w-full" style={{ accentColor: "var(--brand)" }} value={form.newWordsPerDay} onChange={(e) => set("newWordsPerDay", Number(e.target.value))} />
          </Field>
          <Field label={`Reviews/day: ${form.reviewsPerDay}`}>
            <input type="range" min={10} max={200} step={5} className="w-full" style={{ accentColor: "var(--brand)" }} value={form.reviewsPerDay} onChange={(e) => set("reviewsPerDay", Number(e.target.value))} />
          </Field>
          <Toggle label="Show Persian translations" value={form.showPersian} onChange={(v) => set("showPersian", v)} />
          <Field label="Notification time">
            <input type="time" className="input" value={form.reminderTime} onChange={(e) => set("reminderTime", e.target.value)} />
          </Field>
        </div>
      </Card>

      <Card title="Appearance" icon="🎨">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Theme">
            <div className="flex gap-2">
              {["light", "dark"].map((t) => (
                <button key={t} className={`btn flex-1 py-1.5 text-xs ${form.theme === t ? "btn-primary" : "btn-ghost"}`} onClick={() => set("theme", t)}>
                  {t === "dark" ? "🌙 Dark" : "☀️ Light"}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Font size">
            <div className="flex gap-2">
              {["small", "medium", "large"].map((t) => (
                <button key={t} className={`btn flex-1 py-1.5 text-xs ${form.fontSize === t ? "btn-primary" : "btn-ghost"}`} onClick={() => set("fontSize", t)}>
                  {t}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Colour scheme">
            <div className="flex gap-2">
              {[
                { k: "indigo", c: "#4F46E5" },
                { k: "green", c: "#10B981" },
                { k: "purple", c: "#8B5CF6" },
                { k: "amber", c: "#F59E0B" },
              ].map((a) => (
                <button
                  key={a.k}
                  className="h-9 flex-1 rounded-xl border transition"
                  style={{ background: a.c, borderColor: form.accent === a.k ? "var(--text)" : "transparent", transform: form.accent === a.k ? "scale(1.05)" : undefined }}
                  onClick={() => set("accent", a.k)}
                  aria-label={a.k}
                />
              ))}
            </div>
          </Field>
          <Field label="Accent preference">
            <div className="flex gap-2">
              {["US", "UK"].map((v) => (
                <button key={v} className={`btn flex-1 py-1.5 text-xs ${form.voice === v ? "btn-primary" : "btn-ghost"}`} onClick={() => set("voice", v)}>
                  🔊 {v}
                </button>
              ))}
            </div>
          </Field>
          <Toggle label="Auto-play pronunciation" value={form.autoPlayAudio} onChange={(v) => set("autoPlayAudio", v)} />
          <Toggle label="Sound effects" value={form.soundEffects} onChange={(v) => set("soundEffects", v)} />
        </div>
      </Card>

      <Card title="Data" icon="🗄️">
        <div className="grid gap-2 sm:grid-cols-2">
          <a className="btn btn-ghost" href="/api/export?format=json" download>
            ⬇️ Export progress (JSON)
          </a>
          <a className="btn btn-ghost" href="/api/export?format=csv" download>
            ⬇️ Export words (CSV)
          </a>
          <button className="btn btn-ghost" onClick={() => window.print()}>
            🖨️ Print study report
          </button>
          <button className="btn" style={{ color: "#EF4444", borderColor: "color-mix(in srgb,#EF4444 40%,transparent)" }} onClick={reset} disabled={resetting}>
            {resetting ? "Resetting…" : "⚠️ Reset progress"}
          </button>
        </div>
        <p className="mt-3 text-[11px] muted">
          Resetting clears study stats, SRS scheduling, lesson progress and achievements. Your word bank and content stay intact.
        </p>
      </Card>

      <div className="lg:col-span-2 flex items-center gap-3">
        <button className="btn btn-primary px-6" onClick={save}>
          💾 Save settings
        </button>
        {saved ? <span className="text-sm font-bold" style={{ color: "#10B981" }}>{saved}</span> : null}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold uppercase tracking-wider muted">{label}</span>
      {children}
    </label>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-xl border px-3 py-2.5" style={{ borderColor: "var(--border)" }}>
      <span className="text-xs font-semibold">{label}</span>
      <span
        className="relative h-5 w-9 rounded-full transition"
        style={{ background: value ? "var(--brand)" : "color-mix(in srgb,var(--text) 18%,transparent)" }}
        onClick={() => onChange(!value)}
      >
        <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: value ? 18 : 2 }} />
      </span>
    </label>
  );
}
