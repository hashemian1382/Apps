export default function Loading() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 animate-pulse rounded-2xl" style={{ background: "color-mix(in srgb, var(--text) 10%, transparent)" }} />
        <div className="space-y-2">
          <div className="h-6 w-56 animate-pulse rounded-lg" style={{ background: "color-mix(in srgb, var(--text) 10%, transparent)" }} />
          <div className="h-3 w-80 animate-pulse rounded-lg" style={{ background: "color-mix(in srgb, var(--text) 7%, transparent)" }} />
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="card h-28 animate-pulse" />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card h-72 animate-pulse lg:col-span-2" />
        <div className="card h-72 animate-pulse" />
      </div>
    </div>
  );
}
