"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { saveWriting } from "@/lib/actions";
import { Card, Chip } from "@/components/ui";

export type PromptRow = {
  id: number; taskType: string; title: string; prompt: string; minutes: number; minWords: number;
  template: string[]; usefulPhrases: string[]; modelAnswer: string | null; module: string;
};

const CHECKLIST = [
  "Every paragraph has one clear idea",
  "Thesis answers the prompt directly",
  "At least three different transition types",
  "Specific examples, not generic claims",
  "Subject–verb agreement checked",
  "No sentence starts with And / But / So",
];

export function WritingStudio({ prompts }: { prompts: PromptRow[] }) {
  const [activeId, setActiveId] = useState(prompts[0]?.id ?? 0);
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [running, setRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState<string | null>(null);
  const [showModel, setShowModel] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const active = prompts.find((p) => p.id === activeId) ?? prompts[0];

  useEffect(() => {
    if (running) timer.current = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [running]);

  const words = useMemo(() => content.trim().split(/\s+/).filter(Boolean).length, [content]);
  const sentences = content.split(/[.!?]+/).filter((s) => s.trim().length > 3).length;
  const avgSentence = sentences ? Math.round(words / sentences) : 0;
  const selfScore = Object.values(checks).filter(Boolean).length;
  const limit = active?.minutes ? active.minutes * 60 : 1800;
  const remaining = Math.max(0, limit - seconds);

  async function save() {
    const res = await saveWriting({
      promptId: active?.id ?? null,
      title: title || active?.title || "Untitled draft",
      content,
      taskType: active?.taskType ?? "free",
      seconds,
      selfScore,
    });
    setSaved(`Saved to portfolio · ${res.wordCount} words · +150 XP`);
    setRunning(false);
    window.setTimeout(() => setSaved(null), 4000);
  }

  if (!active) return null;

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <Card title="Choose a task" icon="🧭">
          <div className="flex flex-wrap gap-2">
            {prompts.map((p) => (
              <button
                key={p.id}
                onClick={() => { setActiveId(p.id); setShowModel(false); }}
                className={`btn px-3 py-1.5 text-xs ${p.id === activeId ? "btn-primary" : "btn-ghost"}`}
              >
                {p.taskType}
              </button>
            ))}
          </div>
          <div className="card-flat mt-3 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <Chip color="#F59E0B">{active.taskType}</Chip>
              <Chip>⏱ {active.minutes} min</Chip>
              <Chip>≥ {active.minWords} words</Chip>
            </div>
            <h3 className="mt-2 text-sm font-bold">{active.title}</h3>
            <p className="mt-1 text-sm leading-relaxed muted">{active.prompt}</p>
          </div>
        </Card>

        <Card
          title="Editor"
          icon="✍️"
          action={
            <div className="flex items-center gap-2">
              <span className="chip" style={{ color: remaining < 120 ? "#EF4444" : undefined }}>
                ⏱ {String(Math.floor(remaining / 60)).padStart(2, "0")}:{String(remaining % 60).padStart(2, "0")}
              </span>
              <button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => setRunning((r) => !r)}>
                {running ? "⏸ Pause" : "▶️ Start"}
              </button>
            </div>
          }
        >
          <input className="input mb-2" placeholder="Draft title…" value={title} onChange={(e) => setTitle(e.target.value)} />
          <textarea
            className="input min-h-[380px] leading-relaxed"
            placeholder="Start writing your response…"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
            <Chip color={words >= active.minWords ? "#10B981" : "#F59E0B"}>{words} words</Chip>
            <Chip>{sentences} sentences</Chip>
            <Chip>avg {avgSentence} words/sentence</Chip>
            <Chip color="#8B5CF6">self-score {selfScore}/{CHECKLIST.length}</Chip>
            <button className="btn btn-primary ml-auto px-4 py-1.5 text-xs" onClick={save} disabled={words < 20}>
              💾 Save to portfolio
            </button>
          </div>
          {saved ? <p className="mt-2 text-sm font-bold" style={{ color: "#10B981" }}>{saved}</p> : null}
        </Card>

        {active.modelAnswer ? (
          <Card title="Model answer" icon="🏅" action={<button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => setShowModel((v) => !v)}>{showModel ? "Hide" : "Reveal"}</button>}>
            <p className="text-sm leading-relaxed" style={{ filter: showModel ? "none" : "blur(5px)" }}>
              {active.modelAnswer}
            </p>
          </Card>
        ) : null}
      </div>

      <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
        <Card title="Template" icon="🧱">
          <ol className="space-y-2">
            {active.template.map((t, i) => (
              <li key={t} className="flex gap-2 rounded-lg px-2 py-1.5 text-[11px]" style={{ background: "color-mix(in srgb,var(--brand) 8%,transparent)" }}>
                <span className="font-bold brand-text">{i + 1}</span>
                <span>{t}</span>
              </li>
            ))}
          </ol>
        </Card>

        <Card title="Useful phrases" icon="💬">
          <div className="space-y-1.5">
            {active.usefulPhrases.map((p) => (
              <button
                key={p}
                className="w-full rounded-lg px-2 py-1.5 text-left text-[11px] transition hover:bg-[color-mix(in_srgb,var(--text)_7%,transparent)]"
                onClick={() => setContent((c) => `${c}${c && !c.endsWith(" ") ? " " : ""}${p} `)}
              >
                ＋ {p}
              </button>
            ))}
          </div>
        </Card>

        <Card title="Self-editing checklist" icon="✅">
          <ul className="space-y-1.5">
            {CHECKLIST.map((c) => (
              <li key={c}>
                <label className="flex cursor-pointer items-start gap-2 text-[11px]">
                  <input type="checkbox" checked={!!checks[c]} onChange={() => setChecks((x) => ({ ...x, [c]: !x[c] }))} className="mt-0.5" />
                  <span>{c}</span>
                </label>
              </li>
            ))}
          </ul>
        </Card>
      </aside>
    </div>
  );
}
