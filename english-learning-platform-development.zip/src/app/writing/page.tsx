import Link from "next/link";
import { getUser, listPrompts, listWritings } from "@/lib/data";
import { Card, Chip, PageHeader } from "@/components/ui";
import { WritingStudio, type PromptRow } from "./WritingStudio";

export const dynamic = "force-dynamic";

const MODULES = [
  { key: "", label: "All tasks" },
  { key: "general", label: "General" },
  { key: "tech", label: "Technical" },
  { key: "toefl", label: "TOEFL" },
];

export default async function WritingPage({ searchParams }: { searchParams: Promise<{ module?: string }> }) {
  const sp = await searchParams;
  const user = await getUser();
  const [prompts, portfolio] = await Promise.all([listPrompts("writing", sp.module), listWritings(user.id)]);
  const totalWords = portfolio.reduce((a, b) => a + b.wordCount, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        icon="✍️"
        title="Writing Studio"
        subtitle="From sentence craft to full TOEFL essays — with timers, templates, phrase banks and a personal portfolio."
        meta={
          <>
            <Chip>{prompts.length} prompts</Chip>
            <Chip color="#10B981">{portfolio.length} drafts saved</Chip>
            <Chip color="#8B5CF6">{totalWords.toLocaleString()} words written</Chip>
          </>
        }
      />

      <div className="flex flex-wrap gap-2">
        {MODULES.map((m) => (
          <Link key={m.key} href={m.key ? `/writing?module=${m.key}` : "/writing"} className={`btn px-3 py-1.5 text-xs ${(sp.module ?? "") === m.key ? "btn-primary" : "btn-ghost"}`}>
            {m.label}
          </Link>
        ))}
      </div>

      <WritingStudio prompts={prompts as unknown as PromptRow[]} />

      <Card title="My Portfolio" icon="📓">
        {portfolio.length === 0 ? (
          <p className="text-xs muted">Nothing saved yet — your drafts will appear here with word count and self-score.</p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {portfolio.map((w) => (
              <details key={w.id} className="card-flat p-4">
                <summary className="cursor-pointer text-sm font-bold">{w.title}</summary>
                <p className="mt-1 text-[11px] muted">
                  {w.taskType} · {w.wordCount} words · self-score {w.selfScore}/6 · {new Date(w.createdAt).toLocaleDateString()}
                </p>
                <p className="mt-2 max-h-40 overflow-y-auto scroll-thin whitespace-pre-wrap text-xs">{w.content}</p>
              </details>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
