import Link from "next/link";
import { getUser, listLessons, getReviewSummary, getDeckCounts } from "@/lib/data";
import { Card, Chip, PageHeader, Progress, Tile, SECTION_COLORS } from "@/components/ui";

export const dynamic = "force-dynamic";

const SKILLS = [
  { href: "/grammar", icon: "📝", title: "Grammar", subtitle: "A1 → C2 lessons, diagrams, practice and quick-reference cards", color: "#4F46E5" },
  { href: "/reading", icon: "📖", title: "Reading", subtitle: "Graded readers with click-to-define glossary and comprehension sets", color: "#06B6D4" },
  { href: "/listening", icon: "🎧", title: "Listening", subtitle: "Podcasts, lectures and dictation with speed control & transcripts", color: "#10B981" },
  { href: "/speaking", icon: "🗣️", title: "Speaking", subtitle: "Recorder, model answers, fluency drills and pronunciation clinic", color: "#F59E0B" },
  { href: "/writing", icon: "✍️", title: "Writing", subtitle: "Sentence → paragraph → essay with templates and a portfolio", color: "#8B5CF6" },
  { href: "/vocabulary", icon: "🔤", title: "Vocabulary", subtitle: "Word bank, topic lists, AWL and your personal deck", color: "#EF4444" },
  { href: "/library?cat=Pronunciation", icon: "🔉", title: "Phonetics & Pronunciation", subtitle: "IPA chart, minimal pairs and Persian-speaker problem sounds", color: "#0EA5E9" },
  { href: "/vocabulary?deck=idiom", icon: "💬", title: "Idioms & Phrases", subtitle: "Natural expressions with register notes and examples", color: "#EC4899" },
];

export default async function GeneralPage() {
  const user = await getUser();
  const [lessons, summary, decks] = await Promise.all([listLessons("general"), getReviewSummary(user.id), getDeckCounts(user.id)]);
  const levels = ["Beginner (A1-A2)", "Intermediate (B1-B2)", "Advanced (C1-C2)"];
  const generalDeck = decks.find((d) => d.deck === "general");

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📚"
        title="General English"
        subtitle="Build the four skills systematically. Every module pairs English explanations with Persian hints so nothing stays ambiguous."
        meta={
          <>
            <Chip color={SECTION_COLORS.general}>Level: {user.englishLevel}</Chip>
            <Chip>{lessons.length} grammar lessons</Chip>
            <Chip>{summary.total} words tracked</Chip>
            <Chip color="#10B981">{generalDeck?.mature ?? 0} mastered in general deck</Chip>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {SKILLS.map((s) => (
          <Tile key={s.href} {...s} />
        ))}
      </div>

      <Card title="Grammar Syllabus" icon="🗂️" action={<Link href="/grammar" className="btn btn-ghost px-3 py-1 text-xs">Open all →</Link>}>
        <div className="grid gap-4 md:grid-cols-3">
          {levels.map((lvl) => {
            const items = lessons.filter((l) => l.level === lvl);
            return (
              <div key={lvl} className="card-flat p-4">
                <h3 className="mb-3 text-sm font-bold">{lvl}</h3>
                <ul className="space-y-1.5">
                  {items.map((l) => (
                    <li key={l.id}>
                      <Link href={`/grammar/${l.slug}`} className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition hover:bg-[color-mix(in_srgb,var(--text)_7%,transparent)]">
                        <span className="muted">{"⭐".repeat(Math.min(3, l.difficulty))}</span>
                        <span className="flex-1 truncate">{l.title}</span>
                        <span className="muted">{l.minutes}m</span>
                      </Link>
                    </li>
                  ))}
                  {items.length === 0 ? <li className="text-xs muted">Coming soon</li> : null}
                </ul>
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Vocabulary by Level" icon="📈">
          {[
            { name: "Essential 500 (A1-A2)", v: 72 },
            { name: "Intermediate 1000 (B1-B2)", v: 46 },
            { name: "Advanced 1500 (C1)", v: 18 },
            { name: "Academic Word List (570)", v: 31 },
          ].map((row) => (
            <div key={row.name} className="mb-3">
              <div className="mb-1 flex justify-between text-xs">
                <span>{row.name}</span>
                <span className="font-bold muted">{row.v}%</span>
              </div>
              <Progress value={row.v} height={6} />
            </div>
          ))}
        </Card>

        <Card title="Vocabulary by Topic" icon="🏷️">
          <div className="flex flex-wrap gap-2">
            {["Daily Life", "Work & Business", "Science", "Technology", "Environment", "Health & Medicine", "Economics", "Education", "Academic"].map((t) => (
              <Link key={t} href={`/vocabulary?topic=${encodeURIComponent(t)}`} className="chip transition hover:ring-brand">
                {t}
              </Link>
            ))}
          </div>
          <Link href="/vocabulary" className="btn btn-primary mt-4 w-full">
            🔤 Open the word bank
          </Link>
        </Card>

        <Card title="Reading & Listening Skills" icon="🎯">
          <ul className="space-y-2 text-xs">
            {[
              ["Skimming & scanning drills", "/reading"],
              ["Inference & main idea questions", "/reading"],
              ["Vocabulary in context", "/reading"],
              ["Note-taking practice", "/listening"],
              ["Detail catching & dictation", "/listening"],
              ["Speaker attitude and tone", "/listening"],
            ].map(([label, href]) => (
              <li key={label}>
                <Link href={href} className="flex items-center gap-2 rounded-lg px-2 py-1.5 transition hover:bg-[color-mix(in_srgb,var(--text)_7%,transparent)]">
                  <span>▸</span>
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
