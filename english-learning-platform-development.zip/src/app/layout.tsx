import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { getUser } from "@/lib/data";
import { AppShell } from "@/components/AppShell";
import { levelFromXp } from "@/lib/srs";
import { getReviewSummary } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "EngMaster — English, Tech English & TOEFL Studio",
  description:
    "A complete personal platform for General English, Technical English for CS and TOEFL preparation with spaced repetition, analytics and gamification.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const user = await getUser();
  const summary = await getReviewSummary(user.id);
  const level = levelFromXp(user.totalXp);

  return (
    <html lang="en" data-theme={user.theme} data-accent={user.accent} data-fontsize={user.fontSize}>
      <body className="antialiased">
        <AppShell
          user={{ name: user.name, streak: user.streak, xp: user.totalXp, level: level.level, rank: level.rank, icon: level.icon, theme: user.theme }}
          dueCount={summary.due ?? 0}
        >
          {children}
        </AppShell>
      </body>
    </html>
  );
}
