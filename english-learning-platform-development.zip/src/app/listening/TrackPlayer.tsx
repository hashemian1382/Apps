"use client";

import { useEffect, useRef, useState } from "react";
import { saveListeningResult } from "@/lib/actions";
import { Card, Chip } from "@/components/ui";
import { speakText } from "@/components/Speak";

type Line = { speaker: string; text: string };
type Question = { qType: string; prompt: string; options: string[]; answer: string; explain?: string };

export function TrackPlayer({
  track,
}: {
  track: { id: number; title: string; kind: string; transcript: Line[]; questions: Question[]; notesHint: string | null };
}) {
  const [rate, setRate] = useState(1);
  const [playingIndex, setPlayingIndex] = useState<number | null>(null);
  const [showTranscript, setShowTranscript] = useState(false);
  const [notes, setNotes] = useState("");
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [dictation, setDictation] = useState("");
  const [seconds, setSeconds] = useState(0);
  const started = useRef(Date.now());

  useEffect(() => {
    const t = setInterval(() => setSeconds(Math.round((Date.now() - started.current) / 1000)), 1000);
    return () => {
      clearInterval(t);
      if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    };
  }, []);

  function playAll() {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    track.transcript.forEach((line, i) => {
      const u = new SpeechSynthesisUtterance(line.text);
      u.lang = "en-US";
      u.rate = rate;
      u.onstart = () => setPlayingIndex(i);
      u.onend = () => {
        if (i === track.transcript.length - 1) setPlayingIndex(null);
      };
      window.speechSynthesis.speak(u);
    });
  }

  function stop() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    setPlayingIndex(null);
  }

  const score = track.questions.filter((q, i) => answers[i] === q.answer).length;
  const dictationTarget = track.transcript.map((l) => l.text).join(" ");
  const dictationAccuracy = (() => {
    if (!dictation.trim()) return 0;
    const a = dictation.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean);
    const b = dictationTarget.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean);
    let hits = 0;
    a.forEach((w, i) => {
      if (b[i] === w) hits += 1;
    });
    return Math.round((hits / Math.max(1, b.length)) * 100);
  })();

  async function submit() {
    setSubmitted(true);
    await saveListeningResult(score, track.questions.length, seconds);
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <Card title="Player" icon="🎧">
          <div className="flex flex-wrap items-center gap-2">
            <button className="btn btn-primary" onClick={playAll}>▶️ Play audio</button>
            <button className="btn btn-ghost" onClick={stop}>⏹ Stop</button>
            <div className="flex items-center gap-1.5">
              {[0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => (
                <button key={r} className={`btn px-2 py-1 text-[11px] ${rate === r ? "btn-primary" : "btn-ghost"}`} onClick={() => setRate(r)}>
                  {r}×
                </button>
              ))}
            </div>
            <button className={`btn ml-auto px-3 py-1.5 text-xs ${showTranscript ? "btn-primary" : "btn-ghost"}`} onClick={() => setShowTranscript((v) => !v)}>
              📄 {showTranscript ? "Hide" : "Show"} transcript
            </button>
          </div>
          <p className="mt-3 text-[11px] muted">
            Audio is generated on-device with the Web Speech API — adjust the rate, replay any single line, and only reveal the transcript after
            your first attempt.
          </p>

          <div className="mt-4 space-y-2">
            {track.transcript.map((line, i) => (
              <div
                key={i}
                className="flex items-start gap-2 rounded-xl border px-3 py-2 transition"
                style={{
                  borderColor: playingIndex === i ? "var(--brand)" : "var(--border)",
                  background: playingIndex === i ? "color-mix(in srgb, var(--brand) 10%, transparent)" : "transparent",
                }}
              >
                <button className="btn btn-ghost px-2 py-1 text-[11px]" onClick={() => { stop(); speakText(line.text, "US", rate); setPlayingIndex(i); }}>
                  🔊
                </button>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider muted">{line.speaker}</p>
                  <p className="text-sm" style={{ filter: showTranscript ? "none" : "blur(5px)", userSelect: showTranscript ? "auto" : "none" }}>
                    {line.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card title={`Questions (${track.questions.length})`} icon="📝">
          <div className="space-y-4">
            {track.questions.map((q, i) => {
              const chosen = answers[i];
              return (
                <div key={q.prompt} className="card-flat p-4">
                  <span className="chip">{q.qType}</span>
                  <p className="mt-2 mb-3 text-sm font-semibold">{i + 1}. {q.prompt}</p>
                  <div className="grid gap-2">
                    {q.options.map((opt, oi) => {
                      const isRight = submitted && opt === q.answer;
                      const isWrong = submitted && chosen === opt && opt !== q.answer;
                      return (
                        <button
                          key={opt}
                          disabled={submitted}
                          onClick={() => setAnswers((a) => ({ ...a, [i]: opt }))}
                          className="rounded-xl border px-3 py-2 text-left text-xs transition"
                          style={{
                            borderColor: isRight ? "#10B981" : isWrong ? "#EF4444" : chosen === opt ? "var(--brand)" : "var(--border)",
                            background: isRight
                              ? "color-mix(in srgb,#10B981 14%,transparent)"
                              : isWrong
                              ? "color-mix(in srgb,#EF4444 14%,transparent)"
                              : chosen === opt
                              ? "color-mix(in srgb,var(--brand) 12%,transparent)"
                              : "transparent",
                          }}
                        >
                          <span className="mr-2 font-bold muted">{String.fromCharCode(65 + oi)})</span>
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {submitted && q.explain ? <p className="mt-2 text-xs muted">💡 {q.explain}</p> : null}
                </div>
              );
            })}
          </div>
          {!submitted ? (
            <button className="btn btn-primary mt-4 w-full" disabled={Object.keys(answers).length < track.questions.length} onClick={submit}>
              ✅ Check answers (+90 XP)
            </button>
          ) : (
            <p className="mt-4 text-center text-lg font-extrabold brand-text">
              Score: {score}/{track.questions.length}
            </p>
          )}
        </Card>
      </div>

      <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
        <Card title="Note-taking" icon="🗒️">
          {track.notesHint ? <p className="mb-2 text-[11px] muted">💡 {track.notesHint}</p> : null}
          <textarea
            className="input min-h-[190px] font-mono text-xs"
            placeholder={"main idea →\n  ex1:\n  ex2:\ncontrast ≠\nconclusion ⇒"}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
          <p className="mt-1 text-[10px] muted">{notes.split(/\s+/).filter(Boolean).length} words noted</p>
        </Card>

        <Card title="Dictation Drill" icon="⌨️">
          <p className="mb-2 text-[11px] muted">Type what you hear, then compare with the transcript.</p>
          <textarea className="input min-h-[110px] text-xs" value={dictation} onChange={(e) => setDictation(e.target.value)} placeholder="Type here…" />
          <div className="mt-2 flex items-center gap-2">
            <Chip color={dictationAccuracy > 70 ? "#10B981" : "#F59E0B"}>{dictationAccuracy}% word match</Chip>
            <span className="text-[10px] muted">⏱ {Math.floor(seconds / 60)}m {seconds % 60}s</span>
          </div>
        </Card>
      </aside>
    </div>
  );
}
