import Link from "next/link";
import { notFound } from "next/navigation";
import { getTrack } from "@/lib/data";
import { Chip, PageHeader } from "@/components/ui";
import { TrackPlayer } from "../TrackPlayer";

export const dynamic = "force-dynamic";

export default async function TrackPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const track = await getTrack(slug);
  if (!track) notFound();

  return (
    <div className="space-y-4">
      <Link href={`/listening${track.module !== "general" ? `?module=${track.module}` : ""}`} className="btn btn-ghost px-3 py-1 text-xs">
        ← Back to listening library
      </Link>
      <PageHeader
        icon="🎧"
        title={track.title}
        meta={
          <>
            <Chip>{track.kind}</Chip>
            <Chip color="#06B6D4">{track.level}</Chip>
            <Chip>⏱ ~{track.minutes} min</Chip>
          </>
        }
      />
      <TrackPlayer
        track={{
          id: track.id,
          title: track.title,
          kind: track.kind,
          transcript: track.transcript,
          questions: track.questions,
          notesHint: track.notesHint,
        }}
      />
    </div>
  );
}
