import { getUser, listWords, getDeckCounts } from "@/lib/data";
import { Chip, PageHeader, Stat } from "@/components/ui";
import { VocabExplorer, type WordRow } from "./VocabExplorer";

export const dynamic = "force-dynamic";

export default async function VocabularyPage({
  searchParams,
}: {
  searchParams: Promise<{ deck?: string; topic?: string; q?: string }>;
}) {
  const sp = await searchParams;
  const user = await getUser();
  const [rows, decks] = await Promise.all([listWords({ userId: user.id, deck: sp.deck, topic: sp.topic, q: sp.q }), getDeckCounts(user.id)]);
  const topics = Array.from(new Set(rows.map((r) => r.word.topic))).sort();
  const totals = decks.reduce(
    (acc, d) => ({ total: acc.total + d.total, due: acc.due + (d.due ?? 0), mature: acc.mature + (d.mature ?? 0) }),
    { total: 0, due: 0, mature: 0 },
  );

  return (
    <div className="space-y-6">
      <PageHeader
        icon="🔤"
        title="Vocabulary Bank"
        subtitle="Rich word cards with pronunciation, collocations, memory tricks, code examples and SRS scheduling."
        meta={
          <>
            <Chip>{totals.total} words tracked</Chip>
            <Chip color="#8B5CF6">{totals.due} due today</Chip>
            <Chip color="#10B981">{totals.mature} mature</Chip>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {decks.map((d) => (
          <Stat key={d.deck} label={d.deck} value={d.total} sub={`${d.due ?? 0} due · ${d.mature ?? 0} mature`} icon={d.deck === "tech" ? "💻" : d.deck === "toefl" ? "🎯" : d.deck === "idiom" ? "💬" : d.deck === "academic" ? "🎓" : "📚"} />
        ))}
      </div>

      <VocabExplorer rows={rows as unknown as WordRow[]} topics={topics} showPersian={user.showPersian} />
    </div>
  );
}
