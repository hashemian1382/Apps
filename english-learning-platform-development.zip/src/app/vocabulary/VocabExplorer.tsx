"use client";

import { useMemo, useState } from "react";
import { addWord, gradeCard, toggleFavorite } from "@/lib/actions";
import { SpeakButton } from "@/components/Speak";
import { Card, Chip } from "@/components/ui";
import type { Grade } from "@/lib/srs";

export type WordRow = {
  word: {
    id: number; word: string; pos: string; ipaUs: string | null; ipaUk: string | null;
    definitionEn: string; definitionFa: string; examples: string[]; synonyms: string[]; antonyms: string[];
    wordFamily: string[]; collocations: string[]; memoryTrick: string | null; toeflUsage: string | null;
    codeExample: string | null; deck: string; topic: string; level: string; difficulty: number;
  };
  progress: { id: number; status: string; intervalDays: number; favorite: boolean; timesCorrect: number; timesWrong: number; dueAt: string | Date };
};

const DECKS = [
  { key: "all", label: "All decks", icon: "🗂️" },
  { key: "general", label: "General", icon: "📚" },
  { key: "academic", label: "Academic (AWL)", icon: "🎓" },
  { key: "toefl", label: "TOEFL", icon: "🎯" },
  { key: "tech", label: "Technical", icon: "💻" },
  { key: "idiom", label: "Idioms", icon: "💬" },
];

const STATUS_COLOR: Record<string, string> = {
  new: "#06B6D4", learning: "#F59E0B", young: "#10B981", mature: "#8B5CF6", suspended: "#94A3B8",
};

export function VocabExplorer({ rows, topics, showPersian }: { rows: WordRow[]; topics: string[]; showPersian: boolean }) {
  const [deck, setDeck] = useState("all");
  const [topic, setTopic] = useState("all");
  const [q, setQ] = useState("");
  const [onlyFav, setOnlyFav] = useState(false);
  const [selected, setSelected] = useState<WordRow | null>(null);
  const [adding, setAdding] = useState(false);
  const [favs, setFavs] = useState<Record<number, boolean>>(() => Object.fromEntries(rows.map((r) => [r.progress.id, r.progress.favorite])));
  const [toast, setToast] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (deck !== "all" && r.word.deck !== deck) return false;
      if (topic !== "all" && r.word.topic !== topic) return false;
      if (onlyFav && !favs[r.progress.id]) return false;
      if (!query) return true;
      return (
        r.word.word.toLowerCase().includes(query) ||
        r.word.definitionEn.toLowerCase().includes(query) ||
        r.word.definitionFa.includes(query)
      );
    });
  }, [rows, deck, topic, q, onlyFav, favs]);

  async function onGrade(row: WordRow, grade: Grade) {
    const res = await gradeCard(row.progress.id, grade);
    setToast(res.ok ? `Scheduled in ${res.intervalDays} day(s) · status: ${res.status}` : "Could not save");
    window.setTimeout(() => setToast(null), 2500);
  }

  return (
    <div className="space-y-4">
      <div className="card flex flex-wrap items-center gap-2 p-4">
        <div className="relative min-w-[200px] flex-1">
          <input className="input pl-8" placeholder="Search words, meanings, Persian…" value={q} onChange={(e) => setQ(e.target.value)} />
          <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-xs muted">🔍</span>
        </div>
        <select className="input max-w-[170px]" value={deck} onChange={(e) => setDeck(e.target.value)}>
          {DECKS.map((d) => (
            <option key={d.key} value={d.key}>{d.icon} {d.label}</option>
          ))}
        </select>
        <select className="input max-w-[170px]" value={topic} onChange={(e) => setTopic(e.target.value)}>
          <option value="all">🏷️ All topics</option>
          {topics.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <button className={`btn px-3 py-2 text-xs ${onlyFav ? "btn-primary" : "btn-ghost"}`} onClick={() => setOnlyFav((v) => !v)}>
          ⭐ Favourites
        </button>
        <button className="btn btn-primary px-3 py-2 text-xs" onClick={() => setAdding((v) => !v)}>
          ➕ Add word
        </button>
      </div>

      {adding ? <AddWordForm onDone={() => setAdding(false)} /> : null}

      <p className="text-xs muted">{filtered.length} words</p>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filtered.map((r) => (
          <button
            key={r.word.id}
            onClick={() => setSelected(r)}
            className="card group p-4 text-left transition hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="truncate text-base font-extrabold">{r.word.word}</h3>
                <p className="truncate font-mono text-[10px] muted">{r.word.ipaUs ?? r.word.pos}</p>
              </div>
              <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: STATUS_COLOR[r.progress.status] }} title={r.progress.status} />
            </div>
            <p className="mt-2 line-clamp-2 text-xs">{r.word.definitionEn}</p>
            {showPersian ? <p className="fa mt-1 line-clamp-1 text-xs muted">{r.word.definitionFa}</p> : null}
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <span className="chip text-[10px]">{r.word.topic}</span>
              <span className="chip text-[10px]">{r.word.level}</span>
              {favs[r.progress.id] ? <span className="text-xs">⭐</span> : null}
            </div>
          </button>
        ))}
      </div>

      {selected ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => setSelected(null)}>
          <div className="card max-h-[88vh] w-full max-w-2xl overflow-y-auto scroll-thin p-6 animate-pop" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-2xl font-extrabold brand-text">{selected.word.word}</h2>
                <p className="text-xs muted">({selected.word.pos})</p>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  className="btn btn-ghost px-2.5 py-1 text-xs"
                  onClick={async () => {
                    const res = await toggleFavorite(selected.progress.id);
                    setFavs((f) => ({ ...f, [selected.progress.id]: !!res.favorite }));
                  }}
                >
                  {favs[selected.progress.id] ? "⭐" : "☆"}
                </button>
                <button className="btn btn-ghost px-2.5 py-1 text-xs" onClick={() => setSelected(null)}>✕</button>
              </div>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-2">
              {selected.word.ipaUs ? <span className="font-mono text-xs muted">{selected.word.ipaUs}</span> : null}
              <SpeakButton text={selected.word.word} accent="US" />
              <SpeakButton text={selected.word.word} accent="UK" />
              <Chip color={STATUS_COLOR[selected.progress.status]}>{selected.progress.status}</Chip>
            </div>

            <Section title="📖 Meanings">
              <p className="text-sm">{selected.word.definitionEn}</p>
              <p className="fa mt-1 text-sm muted">{selected.word.definitionFa}</p>
            </Section>

            {selected.word.examples.length > 0 ? (
              <Section title="📝 Examples">
                <ul className="space-y-1.5">
                  {selected.word.examples.map((ex) => (
                    <li key={ex} className="flex items-start gap-2 text-sm">
                      <span className="muted">•</span>
                      <span className="flex-1">{ex}</span>
                      <SpeakButton text={ex} label="" />
                    </li>
                  ))}
                </ul>
              </Section>
            ) : null}

            {selected.word.codeExample ? (
              <Section title="💻 Code Example">
                <pre className="card-flat overflow-x-auto scroll-thin p-3 font-mono text-[11px] leading-relaxed">{selected.word.codeExample}</pre>
              </Section>
            ) : null}

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {selected.word.wordFamily.length > 0 ? (
                <MiniBlock title="🔗 Word Family" items={selected.word.wordFamily} />
              ) : null}
              {selected.word.collocations.length > 0 ? <MiniBlock title="📊 Collocations" items={selected.word.collocations} /> : null}
              {selected.word.synonyms.length > 0 ? <MiniBlock title="🧩 Synonyms" items={selected.word.synonyms} /> : null}
              {selected.word.antonyms.length > 0 ? <MiniBlock title="🔄 Antonyms" items={selected.word.antonyms} /> : null}
            </div>

            {selected.word.memoryTrick ? (
              <Section title="💡 Memory Trick">
                <p className="text-sm">{selected.word.memoryTrick}</p>
              </Section>
            ) : null}

            {selected.word.toeflUsage ? (
              <Section title="🔥 TOEFL Usage">
                <p className="text-sm italic">{selected.word.toeflUsage}</p>
              </Section>
            ) : null}

            <div className="mt-5 card-flat p-3">
              <div className="mb-2 flex items-center justify-between text-xs">
                <span className="muted">
                  Mastery · {selected.progress.timesCorrect} correct / {selected.progress.timesWrong} wrong
                </span>
                <span className="font-bold">next in {Math.round(selected.progress.intervalDays)}d</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {([
                  { g: "again", label: "😫 Again", c: "#EF4444" },
                  { g: "hard", label: "😟 Hard", c: "#F59E0B" },
                  { g: "good", label: "😊 Good", c: "#10B981" },
                  { g: "easy", label: "🎯 Easy", c: "#8B5CF6" },
                ] as const).map((b) => (
                  <button
                    key={b.g}
                    className="btn py-1.5 text-[11px]"
                    style={{ borderColor: `color-mix(in srgb, ${b.c} 45%, transparent)`, color: b.c, background: `color-mix(in srgb, ${b.c} 10%, transparent)` }}
                    onClick={() => onGrade(selected, b.g)}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {toast ? (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-xl px-4 py-2 text-sm font-semibold text-white shadow-xl brand-bg animate-pop">
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-4">
      <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider muted">{title}</p>
      {children}
    </div>
  );
}

function MiniBlock({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="card-flat p-3">
      <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider muted">{title}</p>
      <div className="flex flex-wrap gap-1.5">
        {items.map((i) => (
          <span key={i} className="chip text-[10px]">{i}</span>
        ))}
      </div>
    </div>
  );
}

function AddWordForm({ onDone }: { onDone: () => void }) {
  const [form, setForm] = useState({ word: "", pos: "noun", definitionEn: "", definitionFa: "", example: "", deck: "general", topic: "My Words" });
  const [saving, setSaving] = useState(false);

  return (
    <Card title="Add a word to your bank" icon="➕">
      <div className="grid gap-3 sm:grid-cols-2">
        <input className="input" placeholder="Word *" value={form.word} onChange={(e) => setForm({ ...form, word: e.target.value })} />
        <input className="input" placeholder="Part of speech" value={form.pos} onChange={(e) => setForm({ ...form, pos: e.target.value })} />
        <input className="input" placeholder="English definition *" value={form.definitionEn} onChange={(e) => setForm({ ...form, definitionEn: e.target.value })} />
        <input className="input fa" placeholder="معنی فارسی" value={form.definitionFa} onChange={(e) => setForm({ ...form, definitionFa: e.target.value })} />
        <input className="input sm:col-span-2" placeholder="Example sentence" value={form.example} onChange={(e) => setForm({ ...form, example: e.target.value })} />
        <select className="input" value={form.deck} onChange={(e) => setForm({ ...form, deck: e.target.value })}>
          {["general", "academic", "toefl", "tech", "idiom"].map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
        <input className="input" placeholder="Topic" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} />
      </div>
      <div className="mt-3 flex gap-2">
        <button
          className="btn btn-primary"
          disabled={saving || !form.word || !form.definitionEn}
          onClick={async () => {
            setSaving(true);
            await addWord(form);
            setSaving(false);
            onDone();
          }}
        >
          {saving ? "Saving…" : "💾 Save word (+15 XP)"}
        </button>
        <button className="btn btn-ghost" onClick={onDone}>Cancel</button>
      </div>
    </Card>
  );
}
