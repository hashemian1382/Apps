"use client";

import { useMemo, useState } from "react";
import { Card, Chip } from "@/components/ui";
import { SpeakButton } from "@/components/Speak";

export type Resource = {
  id: number; slug: string; category: string; title: string; description: string; icon: string;
  columns: string[]; rows: { a: string; b: string; c?: string }[];
};

export function LibraryBrowser({ resources, initialCat }: { resources: Resource[]; initialCat?: string }) {
  const categories = useMemo(() => Array.from(new Set(resources.map((r) => r.category))), [resources]);
  const [cat, setCat] = useState(initialCat && categories.includes(initialCat) ? initialCat : "All");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<number | null>(resources[0]?.id ?? null);

  const filtered = resources.filter((r) => {
    if (cat !== "All" && r.category !== cat) return false;
    if (!q.trim()) return true;
    const query = q.toLowerCase();
    return (
      r.title.toLowerCase().includes(query) ||
      r.description.toLowerCase().includes(query) ||
      r.rows.some((row) => `${row.a} ${row.b} ${row.c ?? ""}`.toLowerCase().includes(query))
    );
  });

  const active = filtered.find((r) => r.id === open) ?? filtered[0];

  return (
    <div className="space-y-4">
      <div className="card flex flex-wrap items-center gap-2 p-4">
        <div className="relative min-w-[220px] flex-1">
          <input className="input pl-8" placeholder="Search every resource, row and phrase…" value={q} onChange={(e) => setQ(e.target.value)} />
          <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-xs muted">🔍</span>
        </div>
        {["All", ...categories].map((c) => (
          <button key={c} className={`btn px-3 py-1.5 text-xs ${cat === c ? "btn-primary" : "btn-ghost"}`} onClick={() => setCat(c)}>
            {c}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[300px_1fr]">
        <div className="space-y-2">
          {filtered.map((r) => (
            <button
              key={r.id}
              onClick={() => setOpen(r.id)}
              className="card flex w-full items-start gap-3 p-3 text-left transition hover:-translate-y-0.5"
              style={{ borderColor: active?.id === r.id ? "var(--brand)" : "var(--border)" }}
            >
              <span className="text-lg">{r.icon}</span>
              <div className="min-w-0">
                <p className="truncate text-sm font-bold">{r.title}</p>
                <p className="line-clamp-2 text-[11px] muted">{r.description}</p>
              </div>
            </button>
          ))}
          {filtered.length === 0 ? <p className="text-xs muted">No resources match your search.</p> : null}
        </div>

        {active ? (
          <Card
            title={active.title}
            icon={active.icon}
            action={
              <div className="flex gap-2">
                <Chip>{active.rows.length} entries</Chip>
                <button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => window.print()}>🖨️ Print</button>
              </div>
            }
          >
            <p className="mb-3 text-xs muted">{active.description}</p>
            <div className="overflow-x-auto scroll-thin">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="muted">
                    {active.columns.map((c) => (
                      <th key={c} className="py-2 pr-4 font-semibold">{c}</th>
                    ))}
                    <th className="py-2 font-semibold">🔊</th>
                  </tr>
                </thead>
                <tbody>
                  {active.rows
                    .filter((row) => !q.trim() || `${row.a} ${row.b} ${row.c ?? ""}`.toLowerCase().includes(q.toLowerCase()))
                    .map((row, i) => (
                      <tr key={row.a + i} className="border-t align-top" style={{ borderColor: "var(--border)" }}>
                        <td className="py-2 pr-4 font-semibold">{row.a}</td>
                        <td className="py-2 pr-4">{row.b}</td>
                        {active.columns.length > 2 ? <td className={`py-2 pr-4 ${/[\u0600-\u06FF]/.test(row.c ?? "") ? "fa" : ""}`}>{row.c}</td> : null}
                        <td className="py-2">
                          <SpeakButton text={`${row.a}. ${row.b}`} label="" />
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </Card>
        ) : null}
      </div>
    </div>
  );
}
