import { listResources } from "@/lib/data";
import { Chip, PageHeader } from "@/components/ui";
import { LibraryBrowser, type Resource } from "./LibraryBrowser";

export const dynamic = "force-dynamic";

export default async function LibraryPage({ searchParams }: { searchParams: Promise<{ cat?: string }> }) {
  const sp = await searchParams;
  const resources = await listResources();
  const categories = Array.from(new Set(resources.map((r) => r.category)));

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📕"
        title="Resource Library"
        subtitle="Searchable references: grammar charts, phrase banks, TOEFL templates, rubrics, IPA guides and planners."
        meta={
          <>
            <Chip>{resources.length} resources</Chip>
            <Chip color="#06B6D4">{categories.length} categories</Chip>
            <Chip color="#10B981">printable &amp; audio-enabled</Chip>
          </>
        }
      />
      <LibraryBrowser resources={resources as unknown as Resource[]} initialCat={sp.cat} />
    </div>
  );
}
