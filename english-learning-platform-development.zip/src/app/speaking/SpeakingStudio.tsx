"use client";

import { useEffect, useRef, useState } from "react";
import { saveSpeaking } from "@/lib/actions";
import { Card, Chip } from "@/components/ui";
import { SpeakButton } from "@/components/Speak";

export type SpeakPrompt = {
  id: number; taskType: string; title: string; prompt: string; prepSeconds: number; speakSeconds: number;
  template: string[]; usefulPhrases: string[]; modelAnswer: string | null; module: string;
};

const RUBRIC = ["Delivery: clear and paced", "Language use: varied structures", "Topic development: fully developed", "No long pauses", "Answered the question directly"];

type Phase = "idle" | "prep" | "speak" | "done";

export function SpeakingStudio({ prompts, initialId }: { prompts: SpeakPrompt[]; initialId?: number }) {
  const [activeId, setActiveId] = useState(initialId ?? prompts[0]?.id ?? 0);
  const [phase, setPhase] = useState<Phase>("idle");
  const [remaining, setRemaining] = useState(0);
  const [recording, setRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const [notes, setNotes] = useState("");
  const [saved, setSaved] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showModel, setShowModel] = useState(false);
  const recorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const tick = useRef<ReturnType<typeof setInterval> | null>(null);

  const active = prompts.find((p) => p.id === activeId) ?? prompts[0];

  useEffect(() => {
    if (phase === "prep" || phase === "speak") {
      tick.current = setInterval(() => {
        setRemaining((r) => {
          if (r <= 1) {
            if (phase === "prep") {
              setPhase("speak");
              setRemaining(active?.speakSeconds ?? 45);
              void startRecording();
              return active?.speakSeconds ?? 45;
            }
            stopRecording();
            setPhase("done");
            return 0;
          }
          return r - 1;
        });
      }, 1000);
    }
    return () => {
      if (tick.current) clearInterval(tick.current);
    };
  }, [phase, active]);

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunks.current = [];
      mr.ondataavailable = (e) => chunks.current.push(e.data);
      mr.onstop = () => {
        const blob = new Blob(chunks.current, { type: "audio/webm" });
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((t) => t.stop());
      };
      mr.start();
      recorder.current = mr;
      setRecording(true);
      setError(null);
    } catch {
      setError("Microphone permission denied — you can still practise with the timer and self-rubric.");
    }
  }

  function stopRecording() {
    if (recorder.current && recorder.current.state !== "inactive") recorder.current.stop();
    setRecording(false);
  }

  function begin() {
    setAudioUrl(null);
    setPhase("prep");
    setRemaining(active?.prepSeconds ?? 15);
  }

  async function save() {
    const score = Object.values(checks).filter(Boolean).length;
    await saveSpeaking(active?.id ?? null, active?.speakSeconds ?? 45, score, notes);
    setSaved(`Attempt logged · rubric ${score}/${RUBRIC.length} · +80 XP`);
    window.setTimeout(() => setSaved(null), 4000);
  }

  if (!active) return null;

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <Card title="Choose a task" icon="🧭">
          <div className="flex flex-wrap gap-2">
            {prompts.map((p) => (
              <button key={p.id} onClick={() => { setActiveId(p.id); setPhase("idle"); setAudioUrl(null); }} className={`btn px-3 py-1.5 text-xs ${p.id === activeId ? "btn-primary" : "btn-ghost"}`}>
                {p.taskType}
              </button>
            ))}
          </div>
          <div className="card-flat mt-3 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <Chip color="#10B981">{active.taskType}</Chip>
              <Chip>prep {active.prepSeconds}s</Chip>
              <Chip>speak {active.speakSeconds}s</Chip>
              <SpeakButton text={active.prompt} label="Hear prompt" />
            </div>
            <h3 className="mt-2 text-sm font-bold">{active.title}</h3>
            <p className="mt-1 text-sm leading-relaxed muted">{active.prompt}</p>
          </div>
        </Card>

        <Card title="Recorder" icon="🎙️">
          <div className="grid place-items-center gap-3 py-4">
            <div
              className="grid h-32 w-32 place-items-center rounded-full text-center transition"
              style={{
                background: phase === "speak" ? "color-mix(in srgb,#EF4444 20%,transparent)" : phase === "prep" ? "color-mix(in srgb,#F59E0B 18%,transparent)" : "color-mix(in srgb,var(--text) 6%,transparent)",
                boxShadow: recording ? "0 0 0 10px color-mix(in srgb,#EF4444 12%,transparent)" : "none",
              }}
            >
              <div>
                <p className="font-mono text-3xl font-extrabold">{String(remaining).padStart(2, "0")}</p>
                <p className="text-[10px] uppercase tracking-wider muted">
                  {phase === "prep" ? "preparing" : phase === "speak" ? "speaking" : phase === "done" ? "finished" : "ready"}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-2">
              <button className="btn btn-primary" onClick={begin} disabled={phase === "prep" || phase === "speak"}>
                🎬 Start task
              </button>
              <button className="btn btn-ghost" onClick={() => { stopRecording(); setPhase("done"); setRemaining(0); }} disabled={phase !== "speak"}>
                ⏹ Stop early
              </button>
              <button className="btn btn-ghost" onClick={() => { setPhase("idle"); setRemaining(0); setAudioUrl(null); }}>
                ↺ Reset
              </button>
            </div>

            {error ? <p className="text-center text-xs" style={{ color: "#F59E0B" }}>{error}</p> : null}
            {audioUrl ? (
              <div className="w-full">
                <p className="mb-1 text-xs font-bold">Your recording</p>
                <audio controls src={audioUrl} className="w-full" />
                <a href={audioUrl} download="speaking-attempt.webm" className="btn btn-ghost mt-2 w-full py-1.5 text-xs">⬇️ Download</a>
              </div>
            ) : null}
          </div>
        </Card>

        {active.modelAnswer ? (
          <Card title="Model answer" icon="🏅" action={<button className="btn btn-ghost px-3 py-1 text-xs" onClick={() => setShowModel((v) => !v)}>{showModel ? "Hide" : "Reveal"}</button>}>
            <p className="text-sm leading-relaxed" style={{ filter: showModel ? "none" : "blur(5px)" }}>{active.modelAnswer}</p>
            {showModel ? <SpeakButton text={active.modelAnswer} label="Listen to model" className="mt-2" /> : null}
          </Card>
        ) : null}
      </div>

      <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
        <Card title="Framework" icon="🧱">
          <ol className="space-y-2">
            {active.template.map((t, i) => (
              <li key={t} className="flex gap-2 rounded-lg px-2 py-1.5 text-[11px]" style={{ background: "color-mix(in srgb,#10B981 9%,transparent)" }}>
                <span className="font-bold" style={{ color: "#10B981" }}>{i + 1}</span>
                <span>{t}</span>
              </li>
            ))}
          </ol>
        </Card>

        <Card title="Useful phrases" icon="💬">
          <ul className="space-y-1.5 text-[11px]">
            {active.usefulPhrases.map((p) => (
              <li key={p} className="flex items-start justify-between gap-2">
                <span>▸ {p}</span>
                <SpeakButton text={p} label="" />
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Self-evaluation" icon="📊">
          <ul className="space-y-1.5">
            {RUBRIC.map((r) => (
              <li key={r}>
                <label className="flex cursor-pointer items-start gap-2 text-[11px]">
                  <input type="checkbox" checked={!!checks[r]} onChange={() => setChecks((c) => ({ ...c, [r]: !c[r] }))} className="mt-0.5" />
                  <span>{r}</span>
                </label>
              </li>
            ))}
          </ul>
          <textarea className="input mt-2 min-h-[70px] text-xs" placeholder="Notes for next attempt…" value={notes} onChange={(e) => setNotes(e.target.value)} />
          <button className="btn btn-primary mt-2 w-full py-1.5 text-xs" onClick={save}>💾 Log attempt (+80 XP)</button>
          {saved ? <p className="mt-2 text-center text-[11px]" style={{ color: "#10B981" }}>{saved}</p> : null}
        </Card>
      </aside>
    </div>
  );
}
