import Link from "next/link";
import { listPrompts } from "@/lib/data";
import { Card, Chip, PageHeader } from "@/components/ui";
import { SpeakingStudio, type SpeakPrompt } from "./SpeakingStudio";

export const dynamic = "force-dynamic";

const MODULES = [
  { key: "", label: "All tasks" },
  { key: "general", label: "Pronunciation" },
  { key: "tech", label: "Interview" },
  { key: "toefl", label: "TOEFL" },
];

const PROBLEM_SOUNDS = [
  { pair: "/θ/ vs /s/", ex: "think vs sink", tip: "Tongue between teeth for /θ/." },
  { pair: "/w/ vs /v/", ex: "west vs vest", tip: "No teeth–lip contact for /w/." },
  { pair: "/ɪ/ vs /iː/", ex: "sit vs seat", tip: "/iː/ is longer and tenser." },
  { pair: "/æ/ vs /e/", ex: "bad vs bed", tip: "Open the jaw wider for /æ/." },
  { pair: "Word stress", ex: "PHOtograph / phoTOgraphy", tip: "Stress shifts with suffixes." },
];

export default async function SpeakingPage({ searchParams }: { searchParams: Promise<{ module?: string; prompt?: string }> }) {
  const sp = await searchParams;
  const prompts = await listPrompts("speaking", sp.module);

  return (
    <div className="space-y-6">
      <PageHeader
        icon="🗣️"
        title="Speaking Studio"
        subtitle="Official TOEFL timing, in-browser recording, model answers and a pronunciation clinic built for Persian speakers."
        meta={
          <>
            <Chip>{prompts.length} tasks</Chip>
            <Chip color="#10B981">prep + response timers</Chip>
            <Chip color="#8B5CF6">record &amp; play back</Chip>
          </>
        }
      />

      <div className="flex flex-wrap gap-2">
        {MODULES.map((m) => (
          <Link key={m.key} href={m.key ? `/speaking?module=${m.key}` : "/speaking"} className={`btn px-3 py-1.5 text-xs ${(sp.module ?? "") === m.key ? "btn-primary" : "btn-ghost"}`}>
            {m.label}
          </Link>
        ))}
      </div>

      <SpeakingStudio prompts={prompts as unknown as SpeakPrompt[]} initialId={sp.prompt ? Number(sp.prompt) : undefined} />

      <Card title="Pronunciation Clinic — problem sounds for Persian speakers" icon="🔉">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PROBLEM_SOUNDS.map((p) => (
            <div key={p.pair} className="card-flat p-4">
              <p className="font-mono text-sm font-bold brand-text">{p.pair}</p>
              <p className="mt-1 text-xs">{p.ex}</p>
              <p className="mt-1 text-[11px] muted">{p.tip}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
