import { getProgressPage, getUser, listAchievements } from "@/lib/data";
import { levelFromXp } from "@/lib/srs";
import { Card, Chip, PageHeader, Progress, Stat } from "@/components/ui";
import { BarRow, Heatmap, LineChart } from "@/components/charts";

export const dynamic = "force-dynamic";

export default async function ProgressPage() {
  const user = await getUser();
  const [data, achievements] = await Promise.all([getProgressPage(user.id), listAchievements(user.id)]);
  const { stats, mocks, summary, decks, totals } = data;

  const weekly: { label: string; value: number }[] = [];
  for (let i = 11; i >= 0; i--) {
    const end = new Date();
    end.setDate(end.getDate() - i * 7);
    const start = new Date(end);
    start.setDate(start.getDate() - 6);
    const minutes = stats
      .filter((s) => {
        const d = new Date(s.day);
        return d >= start && d <= end;
      })
      .reduce((a, b) => a + b.minutes, 0);
    weekly.push({ label: `W${12 - i}`, value: minutes });
  }

  const latest = mocks[mocks.length - 1];
  const sections = [
    { k: "Reading", v: latest?.reading ?? 0, c: "#4F46E5" },
    { k: "Listening", v: latest?.listening ?? 0, c: "#06B6D4" },
    { k: "Speaking", v: latest?.speaking ?? 0, c: "#10B981" },
    { k: "Writing", v: latest?.writing ?? 0, c: "#F59E0B" },
  ];

  const todayKey = new Date().toISOString().slice(0, 10);
  const todayMin = stats.find((s) => s.day === todayKey)?.minutes ?? 0;
  const weekMin = stats.slice(-7).reduce((a, b) => a + b.minutes, 0);
  const monthMin = stats.slice(-30).reduce((a, b) => a + b.minutes, 0);
  const activeDays = stats.filter((s) => s.minutes > 0).length;
  const avgDay = activeDays ? Math.round(totals.minutes / activeDays) : 0;
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const byWeekday = new Array(7).fill(0);
  stats.forEach((s) => {
    byWeekday[new Date(s.day).getDay()] += s.minutes;
  });
  const mostActive = dayNames[byWeekday.indexOf(Math.max(...byWeekday))];
  const retention = summary.correct + summary.wrong > 0 ? ((summary.correct / (summary.correct + summary.wrong)) * 100).toFixed(1) : "0.0";
  const level = levelFromXp(user.totalXp);

  function fmt(min: number) {
    const h = Math.floor(min / 60);
    return h > 0 ? `${h}h ${min % 60}min` : `${min} min`;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon="📊"
        title="Progress Dashboard"
        subtitle="Every session is measured: study time, retention, section scores and consistency."
        meta={
          <>
            <Chip color="#F59E0B">🔥 {user.streak}-day streak (best {user.longestStreak})</Chip>
            <Chip color="#10B981">Level {level.level} · {level.rank}</Chip>
            <Chip>{fmt(totals.minutes)} total</Chip>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Today" value={fmt(todayMin)} sub={`goal ${user.dailyGoalMinutes} min`} icon="⏱️" />
        <Stat label="This week" value={fmt(weekMin)} sub={`${Math.round(weekMin / 7)} min/day avg`} icon="📅" />
        <Stat label="This month" value={fmt(monthMin)} sub={`${activeDays} active days`} icon="🗓️" accent="#06B6D4" />
        <Stat label="Most active day" value={mostActive} sub={`${fmt(Math.max(...byWeekday))} total`} icon="🚀" accent="#8B5CF6" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Overall Progress — weekly study minutes" icon="📈" className="lg:col-span-2">
          <LineChart points={weekly} suffix="minutes / week" />
        </Card>

        <Card title="Section Scores" icon="📋">
          {sections.map((s) => (
            <div key={s.k} className="mb-3">
              <div className="mb-1 flex justify-between text-xs">
                <span>{s.k}</span>
                <span className="font-bold" style={{ color: s.c }}>{s.v}/30</span>
              </div>
              <Progress value={(s.v / 30) * 100} color={s.c} height={7} />
            </div>
          ))}
          <div className="card-flat mt-4 p-3 text-center">
            <p className="text-2xl font-extrabold brand-text">{latest?.total ?? 0}<span className="text-sm muted">/120</span></p>
            <p className="text-[11px] muted">Target: {user.targetScore}/120</p>
          </div>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Vocabulary Stats" icon="📚">
          <ul className="space-y-1.5 text-xs">
            {[
              ["Total words studied", summary.total],
              ["Words mastered (mature)", summary.mature],
              ["Words in progress", (summary.learning ?? 0) + (summary.young ?? 0)],
              ["Struggling (never seen)", summary.fresh],
              ["Correct answers", summary.correct],
              ["Retention rate", `${retention}%`],
            ].map(([k, v]) => (
              <li key={String(k)} className="flex justify-between rounded-lg px-2 py-1.5" style={{ background: "color-mix(in srgb,var(--text) 4%,transparent)" }}>
                <span>{k}</span>
                <span className="font-bold">{v}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Deck Breakdown" icon="🗂️">
          {decks.map((d) => (
            <div key={d.deck} className="mb-3">
              <BarRow label={d.deck.slice(0, 6)} value={d.mature ?? 0} max={d.total} suffix={`/${d.total}`} />
            </div>
          ))}
        </Card>

        <Card title="TOEFL Score History" icon="🎯">
          <LineChart points={mocks.map((m) => ({ label: new Date(m.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" }), value: m.total }))} height={150} suffix="/120" />
          <p className="mt-2 text-[11px] muted">
            {mocks.length >= 2 ? `+${(mocks[mocks.length - 1].total - mocks[0].total)} points since your first attempt.` : "Take a mock test to start the trend."}
          </p>
        </Card>
      </div>

      <Card title="Activity Heatmap" icon="📅">
        <Heatmap days={stats.map((s) => ({ day: s.day, minutes: s.minutes }))} />
      </Card>

      <Card title="Achievements" icon="🏆">
        <div className="flex flex-wrap gap-2">
          {achievements.map((a) => (
            <span
              key={a.id}
              className="chip"
              style={{
                opacity: a.unlocked ? 1 : 0.45,
                borderColor: a.unlocked ? "color-mix(in srgb,#F59E0B 45%,transparent)" : "var(--border)",
              }}
              title={a.description}
            >
              {a.unlocked ? a.icon : "🔒"} {a.hidden && !a.unlocked ? "???" : a.name}
            </span>
          ))}
        </div>
      </Card>
    </div>
  );
}
