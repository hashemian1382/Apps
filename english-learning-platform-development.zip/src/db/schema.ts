import {
  boolean,
  date,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/* ------------------------------ Users ------------------------------ */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull().default("Learner"),
  englishLevel: varchar("english_level", { length: 16 }).notNull().default("B1"),
  techLevel: varchar("tech_level", { length: 16 }).notNull().default("Mid"),
  targetScore: integer("target_score").notNull().default(100),
  examDate: date("exam_date"),
  dailyGoalMinutes: integer("daily_goal_minutes").notNull().default(45),
  streak: integer("streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lastStudyDate: date("last_study_date"),
  freezeCards: integer("freeze_cards").notNull().default(2),
  totalXp: integer("total_xp").notNull().default(0),
  newWordsPerDay: integer("new_words_per_day").notNull().default(15),
  reviewsPerDay: integer("reviews_per_day").notNull().default(50),
  showPersian: boolean("show_persian").notNull().default(true),
  theme: varchar("theme", { length: 12 }).notNull().default("dark"),
  accent: varchar("accent", { length: 12 }).notNull().default("indigo"),
  voice: varchar("voice", { length: 12 }).notNull().default("US"),
  fontSize: varchar("font_size", { length: 12 }).notNull().default("medium"),
  autoPlayAudio: boolean("auto_play_audio").notNull().default(false),
  soundEffects: boolean("sound_effects").notNull().default(true),
  reminderTime: varchar("reminder_time", { length: 8 }).notNull().default("08:00"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------ Words ------------------------------ */
export const words = pgTable("words", {
  id: serial("id").primaryKey(),
  word: varchar("word", { length: 120 }).notNull(),
  pos: varchar("pos", { length: 60 }).notNull().default("noun"),
  ipaUs: varchar("ipa_us", { length: 120 }),
  ipaUk: varchar("ipa_uk", { length: 120 }),
  definitionEn: text("definition_en").notNull(),
  definitionFa: text("definition_fa").notNull(),
  examples: jsonb("examples").$type<string[]>().notNull().default([]),
  synonyms: jsonb("synonyms").$type<string[]>().notNull().default([]),
  antonyms: jsonb("antonyms").$type<string[]>().notNull().default([]),
  wordFamily: jsonb("word_family").$type<string[]>().notNull().default([]),
  collocations: jsonb("collocations").$type<string[]>().notNull().default([]),
  memoryTrick: text("memory_trick"),
  toeflUsage: text("toefl_usage"),
  codeExample: text("code_example"),
  deck: varchar("deck", { length: 32 }).notNull().default("general"), // general | tech | toefl | idiom | academic
  topic: varchar("topic", { length: 64 }).notNull().default("General"),
  level: varchar("level", { length: 16 }).notNull().default("B1"),
  difficulty: integer("difficulty").notNull().default(2),
});

export const userWords = pgTable("user_words", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  wordId: integer("word_id").notNull(),
  ease: real("ease").notNull().default(2.5),
  intervalDays: real("interval_days").notNull().default(0),
  repetitions: integer("repetitions").notNull().default(0),
  lapses: integer("lapses").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("new"), // new|learning|young|mature|suspended
  dueAt: timestamp("due_at").notNull().defaultNow(),
  lastReviewedAt: timestamp("last_reviewed_at"),
  timesCorrect: integer("times_correct").notNull().default(0),
  timesWrong: integer("times_wrong").notNull().default(0),
  favorite: boolean("favorite").notNull().default(false),
});

/* ------------------------------ Lessons ------------------------------ */
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 140 }).notNull(),
  module: varchar("module", { length: 32 }).notNull().default("general"),
  section: varchar("section", { length: 32 }).notNull().default("grammar"),
  level: varchar("level", { length: 32 }).notNull().default("Intermediate (B1-B2)"),
  title: varchar("title", { length: 200 }).notNull(),
  subtitle: text("subtitle"),
  structure: text("structure"),
  body: jsonb("body").$type<{ heading: string; text: string }[]>().notNull().default([]),
  examples: jsonb("examples").$type<{ en: string; fa: string; note?: string }[]>().notNull().default([]),
  mistakes: jsonb("mistakes").$type<{ wrong: string; right: string; why: string }[]>().notNull().default([]),
  persianHint: text("persian_hint"),
  quickCard: jsonb("quick_card").$type<string[]>().notNull().default([]),
  questions: jsonb("questions")
    .$type<{ type: string; prompt: string; options?: string[]; answer: string; explain?: string }[]>()
    .notNull()
    .default([]),
  difficulty: integer("difficulty").notNull().default(2),
  minutes: integer("minutes").notNull().default(15),
  orderIndex: integer("order_index").notNull().default(0),
});

export const userLessons = pgTable("user_lessons", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  lessonId: integer("lesson_id").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("in_progress"),
  score: integer("score").notNull().default(0),
  total: integer("total").notNull().default(0),
  progress: integer("progress").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/* ------------------------------ Reading ------------------------------ */
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull(),
  module: varchar("module", { length: 32 }).notNull().default("general"), // general|tech|toefl
  title: varchar("title", { length: 220 }).notNull(),
  topic: varchar("topic", { length: 64 }).notNull().default("Science"),
  level: integer("level").notNull().default(3),
  minutes: integer("minutes").notNull().default(8),
  wordCount: integer("word_count").notNull().default(400),
  paragraphs: jsonb("paragraphs").$type<string[]>().notNull().default([]),
  glossary: jsonb("glossary").$type<{ term: string; en: string; fa: string }[]>().notNull().default([]),
  questions: jsonb("questions")
    .$type<{ qType: string; prompt: string; options: string[]; answer: string; explain?: string }[]>()
    .notNull()
    .default([]),
});

export const readingLogs = pgTable("reading_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  articleId: integer("article_id").notNull(),
  score: integer("score").notNull().default(0),
  total: integer("total").notNull().default(0),
  wpm: integer("wpm").notNull().default(0),
  seconds: integer("seconds").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------ Listening ------------------------------ */
export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull(),
  module: varchar("module", { length: 32 }).notNull().default("general"),
  title: varchar("title", { length: 220 }).notNull(),
  kind: varchar("kind", { length: 40 }).notNull().default("Lecture"),
  level: varchar("level", { length: 32 }).notNull().default("Intermediate"),
  minutes: integer("minutes").notNull().default(5),
  transcript: jsonb("transcript").$type<{ speaker: string; text: string }[]>().notNull().default([]),
  notesHint: text("notes_hint"),
  questions: jsonb("questions")
    .$type<{ qType: string; prompt: string; options: string[]; answer: string; explain?: string }[]>()
    .notNull()
    .default([]),
});

/* ------------------------------ Writing / Speaking ------------------------------ */
export const prompts = pgTable("prompts", {
  id: serial("id").primaryKey(),
  kind: varchar("kind", { length: 20 }).notNull().default("writing"), // writing | speaking
  taskType: varchar("task_type", { length: 60 }).notNull(),
  module: varchar("module", { length: 32 }).notNull().default("general"),
  title: varchar("title", { length: 240 }).notNull(),
  prompt: text("prompt").notNull(),
  prepSeconds: integer("prep_seconds").notNull().default(15),
  speakSeconds: integer("speak_seconds").notNull().default(45),
  minutes: integer("minutes").notNull().default(20),
  minWords: integer("min_words").notNull().default(150),
  template: jsonb("template").$type<string[]>().notNull().default([]),
  usefulPhrases: jsonb("useful_phrases").$type<string[]>().notNull().default([]),
  modelAnswer: text("model_answer"),
});

export const writings = pgTable("writings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  promptId: integer("prompt_id"),
  title: varchar("title", { length: 240 }).notNull().default("Untitled draft"),
  content: text("content").notNull().default(""),
  wordCount: integer("word_count").notNull().default(0),
  taskType: varchar("task_type", { length: 60 }).notNull().default("free"),
  selfScore: integer("self_score").notNull().default(0),
  seconds: integer("seconds").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const speakingAttempts = pgTable("speaking_attempts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  promptId: integer("prompt_id"),
  seconds: integer("seconds").notNull().default(0),
  selfScore: integer("self_score").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------ TOEFL ------------------------------ */
export const mockTests = pgTable("mock_tests", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  kind: varchar("kind", { length: 20 }).notNull().default("full"), // full|section|mini
  minutes: integer("minutes").notNull().default(35),
  blurb: text("blurb"),
  sections: jsonb("sections").$type<string[]>().notNull().default([]),
});

export const mockResults = pgTable("mock_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  testId: integer("test_id"),
  reading: integer("reading").notNull().default(0),
  listening: integer("listening").notNull().default(0),
  speaking: integer("speaking").notNull().default(0),
  writing: integer("writing").notNull().default(0),
  total: integer("total").notNull().default(0),
  minutes: integer("minutes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------ Progress / Gamification ------------------------------ */
export const dailyStats = pgTable("daily_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  day: date("day").notNull(),
  minutes: integer("minutes").notNull().default(0),
  wordsLearned: integer("words_learned").notNull().default(0),
  wordsReviewed: integer("words_reviewed").notNull().default(0),
  lessonsCompleted: integer("lessons_completed").notNull().default(0),
  quizzes: integer("quizzes").notNull().default(0),
  xp: integer("xp").notNull().default(0),
  accuracy: integer("accuracy").notNull().default(0),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  day: date("day").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  icon: varchar("icon", { length: 12 }).notNull().default("📘"),
  href: varchar("href", { length: 160 }).notNull().default("/"),
  minutes: integer("minutes").notNull().default(10),
  xp: integer("xp").notNull().default(50),
  kind: varchar("kind", { length: 20 }).notNull().default("mission"), // mission | challenge
  done: boolean("done").notNull().default(false),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 60 }).notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 12 }).notNull().default("🏅"),
  xpReward: integer("xp_reward").notNull().default(200),
  category: varchar("category", { length: 40 }).notNull().default("general"),
  metric: varchar("metric", { length: 40 }).notNull().default("xp"),
  threshold: integer("threshold").notNull().default(100),
  hidden: boolean("hidden").notNull().default(false),
});

export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
});

export const gameScores = pgTable("game_scores", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  game: varchar("game", { length: 60 }).notNull(),
  score: integer("score").notNull().default(0),
  accuracy: integer("accuracy").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------ Library / Notes ------------------------------ */
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull(),
  category: varchar("category", { length: 60 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 12 }).notNull().default("📘"),
  rows: jsonb("rows").$type<{ a: string; b: string; c?: string }[]>().notNull().default([]),
  columns: jsonb("columns").$type<string[]>().notNull().default([]),
  body: text("body"),
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  refType: varchar("ref_type", { length: 32 }).notNull().default("general"),
  refId: integer("ref_id"),
  title: varchar("title", { length: 200 }).notNull().default("Note"),
  content: text("content").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
