type Point = { label: string; value: number };

export function LineChart({ points, height = 190, suffix = "" }: { points: Point[]; height?: number; suffix?: string }) {
  if (points.length === 0) return <div className="grid h-40 place-items-center text-xs muted">No data yet</div>;
  const w = 720;
  const h = height;
  const pad = { l: 34, r: 12, t: 14, b: 26 };
  const max = Math.max(...points.map((p) => p.value), 1) * 1.15;
  const stepX = (w - pad.l - pad.r) / Math.max(1, points.length - 1);
  const y = (v: number) => h - pad.b - (v / max) * (h - pad.t - pad.b);
  const coords = points.map((p, i) => [pad.l + i * stepX, y(p.value)] as const);
  const path = coords.map(([x, yy], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${yy.toFixed(1)}`).join(" ");
  const area = `${path} L${coords[coords.length - 1][0].toFixed(1)},${h - pad.b} L${pad.l},${h - pad.b} Z`;
  const ticks = 4;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height }}>
      <defs>
        <linearGradient id="lg-area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--brand)" stopOpacity="0.35" />
          <stop offset="100%" stopColor="var(--brand)" stopOpacity="0" />
        </linearGradient>
      </defs>
      {Array.from({ length: ticks + 1 }).map((_, i) => {
        const val = (max / ticks) * i;
        return (
          <g key={i}>
            <line x1={pad.l} x2={w - pad.r} y1={y(val)} y2={y(val)} stroke="currentColor" strokeOpacity="0.09" />
            <text x={4} y={y(val) + 4} fontSize="10" fill="currentColor" opacity="0.5">
              {Math.round(val)}
            </text>
          </g>
        );
      })}
      <path d={area} fill="url(#lg-area)" />
      <path d={path} fill="none" stroke="var(--brand)" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
      {coords.map(([x, yy], i) => (
        <circle key={i} cx={x} cy={yy} r={i === coords.length - 1 ? 4.5 : 2.5} fill="var(--brand-2)" />
      ))}
      {points.map((p, i) =>
        i % Math.ceil(points.length / 9) === 0 ? (
          <text key={i} x={pad.l + i * stepX} y={h - 7} fontSize="10" textAnchor="middle" fill="currentColor" opacity="0.55">
            {p.label}
          </text>
        ) : null,
      )}
      <text x={w - pad.r} y={12} fontSize="10" textAnchor="end" fill="currentColor" opacity="0.5">
        {suffix}
      </text>
    </svg>
  );
}

export function BarRow({ label, value, max, suffix = "", color }: { label: string; value: number; max: number; suffix?: string; color?: string }) {
  const pct = Math.round((value / Math.max(1, max)) * 100);
  return (
    <div className="flex items-center gap-3 text-xs">
      <span className="w-12 shrink-0 font-semibold muted">{label}</span>
      <div className="h-2.5 flex-1 overflow-hidden rounded-full" style={{ background: "color-mix(in srgb, var(--text) 10%, transparent)" }}>
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color ?? "linear-gradient(90deg,var(--brand),var(--brand-2))" }} />
      </div>
      <span className="w-16 shrink-0 text-right font-mono text-[11px]">{value}{suffix}</span>
    </div>
  );
}

export function Heatmap({ days }: { days: { day: string; minutes: number }[] }) {
  const map = new Map(days.map((d) => [d.day, d.minutes]));
  const cells: { date: string; minutes: number }[] = [];
  const start = new Date();
  start.setHours(12, 0, 0, 0);
  for (let i = 118; i >= 0; i--) {
    const d = new Date(start);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    cells.push({ date: key, minutes: map.get(key) ?? 0 });
  }
  const weeks: { date: string; minutes: number }[][] = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));

  const shade = (m: number) => {
    if (m === 0) return "color-mix(in srgb, var(--text) 8%, transparent)";
    if (m <= 15) return "color-mix(in srgb, var(--brand) 30%, transparent)";
    if (m <= 30) return "color-mix(in srgb, var(--brand) 55%, transparent)";
    if (m <= 45) return "color-mix(in srgb, var(--brand) 78%, transparent)";
    return "var(--brand)";
  };

  return (
    <div>
      <div className="flex gap-[3px] overflow-x-auto pb-2 scroll-thin">
        {weeks.map((week, wi) => (
          <div key={wi} className="flex flex-col gap-[3px]">
            {week.map((c) => (
              <div
                key={c.date}
                title={`${c.date}: ${c.minutes} min`}
                className="h-[11px] w-[11px] rounded-[3px] transition hover:scale-125"
                style={{ background: shade(c.minutes) }}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center gap-2 text-[10px] muted">
        <span>Less</span>
        {[0, 10, 25, 40, 60].map((m) => (
          <span key={m} className="h-[10px] w-[10px] rounded-[3px]" style={{ background: shade(m) }} />
        ))}
        <span>More</span>
      </div>
    </div>
  );
}

export function Donut({ value, max, label, color = "var(--brand)" }: { value: number; max: number; label: string; color?: string }) {
  const pct = Math.max(0, Math.min(1, value / Math.max(1, max)));
  const r = 42;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center">
      <svg viewBox="0 0 110 110" className="h-28 w-28 -rotate-90">
        <circle cx="55" cy="55" r={r} fill="none" strokeWidth="10" stroke="color-mix(in srgb, var(--text) 10%, transparent)" />
        <circle
          cx="55"
          cy="55"
          r={r}
          fill="none"
          strokeWidth="10"
          stroke={color}
          strokeLinecap="round"
          strokeDasharray={`${(c * pct).toFixed(1)} ${c.toFixed(1)}`}
        />
      </svg>
      <div className="absolute text-center">
        <p className="text-xl font-extrabold">{value}</p>
        <p className="text-[10px] muted">{label}</p>
      </div>
    </div>
  );
}
