"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { toggleTask } from "@/lib/actions";

type Task = { id: number; title: string; icon: string; href: string; minutes: number; xp: number; done: boolean; kind: string };

export function TaskList({ tasks, kind }: { tasks: Task[]; kind: "mission" | "challenge" }) {
  const [items, setItems] = useState(tasks);
  const [, startTransition] = useTransition();

  const list = items.filter((t) => t.kind === kind);
  const done = list.filter((t) => t.done).length;

  function onToggle(id: number) {
    setItems((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
    startTransition(async () => {
      await toggleTask(id);
    });
  }

  return (
    <div>
      <div className="mb-3 flex items-center gap-3">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full" style={{ background: "color-mix(in srgb, var(--text) 10%, transparent)" }}>
          <div className="h-full rounded-full brand-bg transition-all duration-500" style={{ width: `${(done / Math.max(1, list.length)) * 100}%` }} />
        </div>
        <span className="text-xs font-bold muted">
          {done}/{list.length}
        </span>
      </div>
      <ul className="space-y-2">
        {list.map((t) => (
          <li
            key={t.id}
            className="group flex items-center gap-3 rounded-xl border px-3 py-2.5 transition hover:shadow-md"
            style={{
              borderColor: t.done ? "color-mix(in srgb, #10B981 40%, transparent)" : "var(--border)",
              background: t.done ? "color-mix(in srgb, #10B981 10%, transparent)" : "color-mix(in srgb, var(--text) 3%, transparent)",
            }}
          >
            <button
              onClick={() => onToggle(t.id)}
              aria-label="toggle task"
              className={`grid h-6 w-6 shrink-0 place-items-center rounded-md border text-xs font-bold transition ${t.done ? "text-white" : ""}`}
              style={{
                borderColor: t.done ? "#10B981" : "var(--border)",
                background: t.done ? "#10B981" : "transparent",
              }}
            >
              {t.done ? "✓" : ""}
            </button>
            <span className="text-base">{t.icon}</span>
            <Link href={t.href} className={`flex-1 truncate text-sm font-medium ${t.done ? "line-through opacity-60" : ""}`}>
              {t.title}
            </Link>
            <span className="chip hidden shrink-0 sm:inline-flex">⏱ {t.minutes}m</span>
            <span className="chip shrink-0" style={{ color: "#F59E0B", borderColor: "color-mix(in srgb,#F59E0B 35%,transparent)" }}>
              +{t.xp} XP
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
