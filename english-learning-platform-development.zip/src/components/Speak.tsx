"use client";

import { useCallback, useState } from "react";

export function speakText(text: string, accent: "US" | "UK" = "US", rate = 1) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = accent === "UK" ? "en-GB" : "en-US";
  utter.rate = rate;
  const voices = window.speechSynthesis.getVoices();
  const match = voices.find((v) => v.lang === utter.lang) ?? voices.find((v) => v.lang.startsWith("en"));
  if (match) utter.voice = match;
  window.speechSynthesis.speak(utter);
  return true;
}

export function SpeakButton({
  text,
  accent = "US",
  label,
  className = "",
  rate = 1,
}: {
  text: string;
  accent?: "US" | "UK";
  label?: string;
  className?: string;
  rate?: number;
}) {
  const [active, setActive] = useState(false);
  const onClick = useCallback(() => {
    const ok = speakText(text, accent, rate);
    if (ok) {
      setActive(true);
      window.setTimeout(() => setActive(false), Math.min(6000, 900 + text.length * 55));
    }
  }, [text, accent, rate]);

  return (
    <button
      type="button"
      onClick={onClick}
      className={`btn btn-ghost px-2.5 py-1 text-xs ${active ? "ring-brand" : ""} ${className}`}
      title={`Play (${accent} accent)`}
    >
      🔊 {label ?? accent}
    </button>
  );
}
