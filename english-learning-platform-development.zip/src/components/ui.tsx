import Link from "next/link";
import type { ReactNode } from "react";

export function PageHeader({
  icon,
  title,
  subtitle,
  meta,
  action,
}: {
  icon: string;
  title: string;
  subtitle?: string;
  meta?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4 animate-slide-up">
      <div className="flex items-start gap-3">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl brand-bg text-2xl shadow-lg">{icon}</span>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{title}</h1>
          {subtitle ? <p className="mt-1 max-w-2xl text-sm muted">{subtitle}</p> : null}
          {meta ? <div className="mt-2 flex flex-wrap gap-2">{meta}</div> : null}
        </div>
      </div>
      {action}
    </div>
  );
}

export function Progress({ value, color, height = 8 }: { value: number; color?: string; height?: number }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className="w-full overflow-hidden rounded-full" style={{ height, background: "color-mix(in srgb, var(--text) 10%, transparent)" }}>
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${v}%`, background: color ?? "linear-gradient(90deg, var(--brand), var(--brand-2))" }}
      />
    </div>
  );
}

export function Stat({ label, value, sub, icon, accent }: { label: string; value: ReactNode; sub?: string; icon?: string; accent?: string }) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between">
        <p className="text-[11px] font-semibold uppercase tracking-wider muted">{label}</p>
        {icon ? <span className="text-lg">{icon}</span> : null}
      </div>
      <p className="mt-1.5 text-2xl font-extrabold" style={accent ? { color: accent } : undefined}>
        {value}
      </p>
      {sub ? <p className="mt-0.5 text-xs muted">{sub}</p> : null}
    </div>
  );
}

export function Tile({
  href,
  icon,
  title,
  subtitle,
  color,
  footer,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle?: string;
  color: string;
  footer?: ReactNode;
}) {
  return (
    <Link
      href={href}
      className="card group relative overflow-hidden p-5 transition hover:-translate-y-1 hover:shadow-2xl"
      style={{ borderColor: `color-mix(in srgb, ${color} 28%, var(--border))` }}
    >
      <div
        className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full opacity-25 blur-2xl transition group-hover:opacity-45"
        style={{ background: color }}
      />
      <span className="grid h-11 w-11 place-items-center rounded-xl text-xl" style={{ background: `color-mix(in srgb, ${color} 20%, transparent)` }}>
        {icon}
      </span>
      <h3 className="mt-3 text-base font-bold">{title}</h3>
      {subtitle ? <p className="mt-1 text-xs leading-relaxed muted">{subtitle}</p> : null}
      {footer ? <div className="mt-3">{footer}</div> : null}
    </Link>
  );
}

export function Card({ children, className = "", title, icon, action }: { children: ReactNode; className?: string; title?: string; icon?: string; action?: ReactNode }) {
  return (
    <section className={`card p-5 ${className}`}>
      {title ? (
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider">
            {icon ? <span className="text-base">{icon}</span> : null}
            {title}
          </h2>
          {action}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function Chip({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <span className="chip" style={color ? { color, borderColor: `color-mix(in srgb, ${color} 40%, transparent)`, background: `color-mix(in srgb, ${color} 12%, transparent)` } : undefined}>
      {children}
    </span>
  );
}

export function Empty({ icon = "🗂️", title, hint }: { icon?: string; title: string; hint?: string }) {
  return (
    <div className="card grid place-items-center gap-2 p-10 text-center">
      <span className="text-3xl">{icon}</span>
      <p className="font-semibold">{title}</p>
      {hint ? <p className="text-xs muted">{hint}</p> : null}
    </div>
  );
}

export const SECTION_COLORS = {
  general: "#4F46E5",
  tech: "#06B6D4",
  toefl: "#F59E0B",
  review: "#8B5CF6",
  games: "#10B981",
  danger: "#EF4444",
};
