import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements,
  articles,
  dailyStats,
  gameScores,
  lessons,
  mockResults,
  mockTests,
  prompts,
  resources,
  tracks,
  userWords,
  users,
  words,
} from "@/db/schema";
import { SEED_WORDS } from "./content/words";
import { SEED_LESSONS } from "./content/lessons";
import { SEED_ARTICLES } from "./content/reading";
import { SEED_TRACKS, SEED_PROMPTS, SEED_MOCKS } from "./content/media";
import { SEED_RESOURCES, SEED_ACHIEVEMENTS } from "./content/library";

let bootstrapPromise: Promise<void> | null = null;

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

function isoDay(offsetDays: number) {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() - offsetDays);
  return d.toISOString().slice(0, 10);
}

async function seed() {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length > 0) return;

  const [user] = await db
    .insert(users)
    .values({
      name: "Sina",
      englishLevel: "B1",
      techLevel: "Mid",
      targetScore: 100,
      examDate: isoDay(-60),
      dailyGoalMinutes: 45,
      streak: 15,
      longestStreak: 21,
      lastStudyDate: isoDay(0),
      totalXp: 2450,
      freezeCards: 2,
    })
    .returning();

  const insertedWords = await db.insert(words).values(SEED_WORDS).returning({ id: words.id });
  await db.insert(lessons).values(SEED_LESSONS);
  await db.insert(articles).values(
    SEED_ARTICLES.map((a) => ({
      ...a,
      wordCount: a.paragraphs.join(" ").split(/\s+/).filter(Boolean).length,
    })),
  );
  await db.insert(tracks).values(SEED_TRACKS);
  await db.insert(prompts).values(SEED_PROMPTS);
  await db.insert(mockTests).values(SEED_MOCKS);
  await db.insert(resources).values(SEED_RESOURCES);
  await db.insert(achievements).values(SEED_ACHIEVEMENTS);

  // Give the learner an SRS history so the dashboard is alive from the first load.
  const rand = rng(20260219);
  const now = Date.now();
  const rows = insertedWords.map((w, i) => {
    const r = rand();
    let status = "new";
    let intervalDays = 0;
    let repetitions = 0;
    let dueOffsetHours = 0;

    if (i % 7 === 0) {
      status = "new";
      dueOffsetHours = -1;
    } else if (r < 0.42) {
      status = "learning";
      intervalDays = 1 + Math.floor(r * 5);
      repetitions = 1 + Math.floor(r * 3);
      dueOffsetHours = r < 0.25 ? -18 : Math.floor(r * 60);
    } else if (r < 0.72) {
      status = "young";
      intervalDays = 8 + Math.floor(r * 18);
      repetitions = 4 + Math.floor(r * 3);
      dueOffsetHours = r < 0.55 ? -40 : Math.floor(r * 200);
    } else {
      status = "mature";
      intervalDays = 32 + Math.floor(r * 60);
      repetitions = 7 + Math.floor(r * 5);
      dueOffsetHours = Math.floor(r * 700);
    }

    return {
      userId: user.id,
      wordId: w.id,
      ease: 2.2 + r * 0.8,
      intervalDays,
      repetitions,
      lapses: Math.floor(r * 3),
      status,
      dueAt: new Date(now + dueOffsetHours * 3600 * 1000),
      lastReviewedAt: repetitions > 0 ? new Date(now - intervalDays * 86400000) : null,
      timesCorrect: repetitions * 2,
      timesWrong: Math.floor(r * 4),
      favorite: i % 11 === 0,
    };
  });
  await db.insert(userWords).values(rows);

  // 120 days of activity for the heatmap + charts.
  const stats: (typeof dailyStats.$inferInsert)[] = [];
  for (let i = 119; i >= 0; i--) {
    const r = rand();
    const weekday = new Date(Date.now() - i * 86400000).getDay();
    const weekendPenalty = weekday === 5 || weekday === 6 ? 0.45 : 1;
    const ramp = 0.45 + ((120 - i) / 120) * 0.75;
    const active = r > 0.14;
    const minutes = active ? Math.round(12 + r * 55 * weekendPenalty * ramp) : 0;
    stats.push({
      userId: user.id,
      day: isoDay(i),
      minutes,
      wordsLearned: active ? Math.round(minutes / 4) : 0,
      wordsReviewed: active ? Math.round(minutes * 1.4) : 0,
      lessonsCompleted: active && r > 0.6 ? 1 : 0,
      quizzes: active && r > 0.5 ? 1 : 0,
      xp: active ? Math.round(minutes * 3.2) : 0,
      accuracy: active ? Math.round(68 + r * 28) : 0,
    });
  }
  await db.insert(dailyStats).values(stats);

  await db.insert(mockResults).values([
    { userId: user.id, reading: 17, listening: 15, speaking: 14, writing: 15, total: 61, minutes: 118, createdAt: new Date(now - 62 * 86400000) },
    { userId: user.id, reading: 19, listening: 17, speaking: 16, writing: 16, total: 68, minutes: 116, createdAt: new Date(now - 41 * 86400000) },
    { userId: user.id, reading: 21, listening: 18, speaking: 17, writing: 17, total: 73, minutes: 121, createdAt: new Date(now - 22 * 86400000) },
    { userId: user.id, reading: 22, listening: 20, speaking: 18, writing: 18, total: 78, minutes: 119, createdAt: new Date(now - 6 * 86400000) },
  ]);

  await db.insert(gameScores).values([
    { userId: user.id, game: "word-match", score: 420, accuracy: 88 },
    { userId: user.id, game: "speed-quiz", score: 17, accuracy: 81 },
    { userId: user.id, game: "grammar-arena", score: 12, accuracy: 75 },
  ]);
}

/** Idempotent: safe to call on every request. */
export async function ensureSeeded(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = seed().catch((error) => {
      bootstrapPromise = null;
      throw error;
    });
  }
  return bootstrapPromise;
}

export async function resetProgress(userId: number) {
  await db.execute(sql`DELETE FROM daily_stats WHERE user_id = ${userId}`);
  await db.execute(sql`DELETE FROM user_lessons WHERE user_id = ${userId}`);
  await db.execute(sql`DELETE FROM reading_logs WHERE user_id = ${userId}`);
  await db.execute(sql`DELETE FROM game_scores WHERE user_id = ${userId}`);
  await db.execute(sql`DELETE FROM user_achievements WHERE user_id = ${userId}`);
  await db.execute(
    sql`UPDATE user_words SET ease = 2.5, interval_days = 0, repetitions = 0, lapses = 0, status = 'new', due_at = NOW(), last_reviewed_at = NULL, times_correct = 0, times_wrong = 0 WHERE user_id = ${userId}`,
  );
  await db.execute(sql`UPDATE users SET total_xp = 0, streak = 0 WHERE id = ${userId}`);
}
