"use server";

import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  dailyStats,
  gameScores,
  mockResults,
  readingLogs,
  speakingAttempts,
  tasks,
  userLessons,
  userWords,
  users,
  words,
  writings,
} from "@/db/schema";
import { getUser, today } from "./data";
import { schedule, type Grade } from "./srs";

async function bumpStats(
  userId: number,
  patch: Partial<{ minutes: number; wordsLearned: number; wordsReviewed: number; lessonsCompleted: number; quizzes: number; xp: number; accuracy: number }>,
) {
  const day = today();
  const [existing] = await db.select().from(dailyStats).where(and(eq(dailyStats.userId, userId), eq(dailyStats.day, day))).limit(1);
  if (!existing) {
    await db.insert(dailyStats).values({ userId, day, ...patch });
  } else {
    await db
      .update(dailyStats)
      .set({
        minutes: existing.minutes + (patch.minutes ?? 0),
        wordsLearned: existing.wordsLearned + (patch.wordsLearned ?? 0),
        wordsReviewed: existing.wordsReviewed + (patch.wordsReviewed ?? 0),
        lessonsCompleted: existing.lessonsCompleted + (patch.lessonsCompleted ?? 0),
        quizzes: existing.quizzes + (patch.quizzes ?? 0),
        xp: existing.xp + (patch.xp ?? 0),
        accuracy: patch.accuracy ?? existing.accuracy,
      })
      .where(eq(dailyStats.id, existing.id));
  }
  if (patch.xp) {
    await db.update(users).set({ totalXp: sql`${users.totalXp} + ${patch.xp}` }).where(eq(users.id, userId));
  }
  // keep the streak honest: any activity today counts
  const [u] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (u && u.lastStudyDate !== day) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const y = yesterday.toISOString().slice(0, 10);
    const nextStreak = u.lastStudyDate === y ? u.streak + 1 : 1;
    await db
      .update(users)
      .set({ streak: nextStreak, longestStreak: Math.max(u.longestStreak, nextStreak), lastStudyDate: day })
      .where(eq(users.id, userId));
  }
}

export async function gradeCard(userWordId: number, grade: Grade) {
  const user = await getUser();
  const [row] = await db.select().from(userWords).where(eq(userWords.id, userWordId)).limit(1);
  if (!row) return { ok: false };
  const next = schedule(
    { ease: row.ease, intervalDays: row.intervalDays, repetitions: row.repetitions, lapses: row.lapses, status: row.status },
    grade,
  );
  await db
    .update(userWords)
    .set({
      ease: next.ease,
      intervalDays: next.intervalDays,
      repetitions: next.repetitions,
      lapses: next.lapses,
      status: next.status,
      dueAt: next.dueAt,
      lastReviewedAt: new Date(),
      timesCorrect: grade === "again" ? row.timesCorrect : row.timesCorrect + 1,
      timesWrong: grade === "again" ? row.timesWrong + 1 : row.timesWrong,
    })
    .where(eq(userWords.id, userWordId));
  await bumpStats(user.id, { wordsReviewed: 1, xp: 5, minutes: 0 });
  return { ok: true, intervalDays: next.intervalDays, status: next.status };
}

export async function finishReviewSession(cards: number, correct: number, seconds: number) {
  const user = await getUser();
  const accuracy = cards > 0 ? Math.round((correct / cards) * 100) : 0;
  await bumpStats(user.id, { minutes: Math.max(1, Math.round(seconds / 60)), accuracy, xp: 20 });
  revalidatePath("/");
  revalidatePath("/review");
  return { ok: true, accuracy };
}

export async function toggleTask(taskId: number) {
  const user = await getUser();
  const [row] = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
  if (!row) return { ok: false };
  const done = !row.done;
  await db.update(tasks).set({ done }).where(eq(tasks.id, taskId));
  await bumpStats(user.id, { xp: done ? row.xp : -row.xp, minutes: done ? row.minutes : 0 });
  revalidatePath("/");
  revalidatePath("/games");
  return { ok: true, done };
}

export async function saveLessonResult(lessonId: number, score: number, total: number, progress: number) {
  const user = await getUser();
  const [existing] = await db
    .select()
    .from(userLessons)
    .where(and(eq(userLessons.userId, user.id), eq(userLessons.lessonId, lessonId)))
    .limit(1);
  const status = progress >= 100 ? "completed" : "in_progress";
  if (existing) {
    await db
      .update(userLessons)
      .set({ score, total, progress, status, updatedAt: new Date() })
      .where(eq(userLessons.id, existing.id));
  } else {
    await db.insert(userLessons).values({ userId: user.id, lessonId, score, total, progress, status });
  }
  const perfect = total > 0 && score === total;
  await bumpStats(user.id, {
    quizzes: 1,
    lessonsCompleted: status === "completed" ? 1 : 0,
    xp: perfect ? 100 : 50,
    minutes: 8,
    accuracy: total > 0 ? Math.round((score / total) * 100) : 0,
  });
  revalidatePath("/grammar");
  revalidatePath("/");
  return { ok: true, xp: perfect ? 100 : 50 };
}

export async function saveReadingLog(articleId: number, score: number, total: number, wpm: number, seconds: number) {
  const user = await getUser();
  await db.insert(readingLogs).values({ userId: user.id, articleId, score, total, wpm, seconds });
  await bumpStats(user.id, {
    minutes: Math.max(1, Math.round(seconds / 60)),
    xp: 100,
    quizzes: 1,
    accuracy: total > 0 ? Math.round((score / total) * 100) : 0,
  });
  revalidatePath("/reading");
  revalidatePath("/");
  return { ok: true };
}

export async function saveListeningResult(score: number, total: number, seconds: number) {
  const user = await getUser();
  await bumpStats(user.id, {
    minutes: Math.max(1, Math.round(seconds / 60)),
    xp: 90,
    quizzes: 1,
    accuracy: total > 0 ? Math.round((score / total) * 100) : 0,
  });
  revalidatePath("/listening");
  return { ok: true };
}

export async function saveWriting(input: { promptId?: number | null; title: string; content: string; taskType: string; seconds: number; selfScore: number }) {
  const user = await getUser();
  const wordCount = input.content.trim().split(/\s+/).filter(Boolean).length;
  await db.insert(writings).values({
    userId: user.id,
    promptId: input.promptId ?? null,
    title: input.title || "Untitled draft",
    content: input.content,
    taskType: input.taskType,
    wordCount,
    selfScore: input.selfScore,
    seconds: input.seconds,
  });
  await bumpStats(user.id, { minutes: Math.max(1, Math.round(input.seconds / 60)), xp: 150 });
  revalidatePath("/writing");
  return { ok: true, wordCount };
}

export async function saveSpeaking(promptId: number | null, seconds: number, selfScore: number, notes: string) {
  const user = await getUser();
  await db.insert(speakingAttempts).values({ userId: user.id, promptId, seconds, selfScore, notes });
  await bumpStats(user.id, { minutes: Math.max(1, Math.round(seconds / 60)), xp: 80 });
  revalidatePath("/speaking");
  return { ok: true };
}

export async function saveGameScore(game: string, score: number, accuracy: number) {
  const user = await getUser();
  await db.insert(gameScores).values({ userId: user.id, game, score, accuracy });
  await bumpStats(user.id, { xp: Math.max(10, Math.round(score / 2)), minutes: 3, accuracy });
  revalidatePath("/games");
  return { ok: true };
}

export async function saveMockResult(input: { reading: number; listening: number; speaking: number; writing: number; minutes: number }) {
  const user = await getUser();
  const total = input.reading + input.listening + input.speaking + input.writing;
  await db.insert(mockResults).values({ userId: user.id, ...input, total });
  await bumpStats(user.id, { minutes: input.minutes, xp: 300 });
  revalidatePath("/toefl");
  revalidatePath("/progress");
  return { ok: true, total };
}

export async function toggleFavorite(userWordId: number) {
  const [row] = await db.select().from(userWords).where(eq(userWords.id, userWordId)).limit(1);
  if (!row) return { ok: false };
  await db.update(userWords).set({ favorite: !row.favorite }).where(eq(userWords.id, userWordId));
  revalidatePath("/vocabulary");
  return { ok: true, favorite: !row.favorite };
}

export async function suspendCard(userWordId: number, suspend: boolean) {
  await db.update(userWords).set({ status: suspend ? "suspended" : "learning" }).where(eq(userWords.id, userWordId));
  revalidatePath("/vocabulary");
  return { ok: true };
}

export async function addWord(input: {
  word: string;
  pos: string;
  definitionEn: string;
  definitionFa: string;
  example: string;
  deck: string;
  topic: string;
}) {
  const user = await getUser();
  const [created] = await db
    .insert(words)
    .values({
      word: input.word.trim(),
      pos: input.pos || "noun",
      definitionEn: input.definitionEn,
      definitionFa: input.definitionFa,
      examples: input.example ? [input.example] : [],
      deck: input.deck || "general",
      topic: input.topic || "My Words",
      level: "B1",
      difficulty: 2,
    })
    .returning();
  await db.insert(userWords).values({ userId: user.id, wordId: created.id, dueAt: new Date() });
  await bumpStats(user.id, { wordsLearned: 1, xp: 15 });
  revalidatePath("/vocabulary");
  return { ok: true, id: created.id };
}

export async function updateSettings(input: Partial<typeof users.$inferInsert>) {
  const user = await getUser();
  await db.update(users).set(input).where(eq(users.id, user.id));
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function logStudyMinutes(minutes: number, xp = 0) {
  const user = await getUser();
  await bumpStats(user.id, { minutes, xp });
  revalidatePath("/");
  return { ok: true };
}
