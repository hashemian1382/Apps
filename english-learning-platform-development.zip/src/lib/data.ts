import { and, asc, desc, eq, gte, inArray, lte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements,
  articles,
  dailyStats,
  gameScores,
  lessons,
  mockResults,
  mockTests,
  prompts,
  readingLogs,
  resources,
  tasks,
  tracks,
  userLessons,
  userWords,
  users,
  words,
  writings,
} from "@/db/schema";
import { ensureSeeded } from "./bootstrap";
import { levelFromXp } from "./srs";
import { DAILY_TIPS } from "./content/library";

export const today = () => {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  return d.toISOString().slice(0, 10);
};

export type AppUser = typeof users.$inferSelect;

export async function getUser(): Promise<AppUser> {
  await ensureSeeded();
  const [user] = await db.select().from(users).orderBy(asc(users.id)).limit(1);
  return user;
}

export async function getDeckCounts(userId: number) {
  const rows = await db
    .select({
      deck: words.deck,
      total: sql<number>`count(*)::int`,
      due: sql<number>`sum(case when ${userWords.dueAt} <= now() then 1 else 0 end)::int`,
      mature: sql<number>`sum(case when ${userWords.status} = 'mature' then 1 else 0 end)::int`,
    })
    .from(userWords)
    .innerJoin(words, eq(words.id, userWords.wordId))
    .where(eq(userWords.userId, userId))
    .groupBy(words.deck);
  return rows;
}

export async function getReviewSummary(userId: number) {
  const [row] = await db
    .select({
      total: sql<number>`count(*)::int`,
      fresh: sql<number>`sum(case when ${userWords.status} = 'new' then 1 else 0 end)::int`,
      learning: sql<number>`sum(case when ${userWords.status} = 'learning' then 1 else 0 end)::int`,
      young: sql<number>`sum(case when ${userWords.status} = 'young' then 1 else 0 end)::int`,
      mature: sql<number>`sum(case when ${userWords.status} = 'mature' then 1 else 0 end)::int`,
      due: sql<number>`sum(case when ${userWords.dueAt} <= now() and ${userWords.status} <> 'suspended' then 1 else 0 end)::int`,
      overdue: sql<number>`sum(case when ${userWords.dueAt} <= now() - interval '1 day' then 1 else 0 end)::int`,
      correct: sql<number>`coalesce(sum(${userWords.timesCorrect}),0)::int`,
      wrong: sql<number>`coalesce(sum(${userWords.timesWrong}),0)::int`,
    })
    .from(userWords)
    .where(eq(userWords.userId, userId));
  return row;
}

export async function getDueCards(userId: number, deck: string | undefined, limit: number) {
  const conditions = [eq(userWords.userId, userId), ne(userWords.status, "suspended")];
  if (deck && deck !== "all") conditions.push(eq(words.deck, deck));
  return db
    .select({
      id: userWords.id,
      ease: userWords.ease,
      intervalDays: userWords.intervalDays,
      repetitions: userWords.repetitions,
      lapses: userWords.lapses,
      status: userWords.status,
      word: words,
    })
    .from(userWords)
    .innerJoin(words, eq(words.id, userWords.wordId))
    .where(and(...conditions, lte(userWords.dueAt, new Date())))
    .orderBy(asc(userWords.dueAt))
    .limit(limit);
}

export async function getDailyStats(userId: number, days: number) {
  const from = new Date();
  from.setDate(from.getDate() - days);
  return db
    .select()
    .from(dailyStats)
    .where(and(eq(dailyStats.userId, userId), gte(dailyStats.day, from.toISOString().slice(0, 10))))
    .orderBy(asc(dailyStats.day));
}

export async function getTodayTasks(userId: number) {
  const day = today();
  const existing = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.day, day)))
    .orderBy(asc(tasks.id));
  if (existing.length > 0) return existing;

  const generated: (typeof tasks.$inferInsert)[] = [
    { userId, day, title: "Review 20 due vocabulary cards", icon: "🧠", href: "/review", minutes: 10, xp: 75, kind: "mission" },
    { userId, day, title: "Reading practice: one passage", icon: "📖", href: "/reading", minutes: 12, xp: 100, kind: "mission" },
    { userId, day, title: "TOEFL listening: one lecture", icon: "🎧", href: "/listening?module=toefl", minutes: 8, xp: 90, kind: "mission" },
    { userId, day, title: "Tech article: reading API docs", icon: "💻", href: "/reading?module=tech", minutes: 10, xp: 80, kind: "mission" },
    { userId, day, title: "Grammar: conditionals type 2", icon: "📝", href: "/grammar/conditionals-type-2", minutes: 20, xp: 110, kind: "mission" },
    { userId, day, title: "Learn 10 new words", icon: "🆕", href: "/vocabulary", minutes: 8, xp: 50, kind: "challenge" },
    { userId, day, title: "Complete 1 reading passage", icon: "📚", href: "/reading", minutes: 12, xp: 100, kind: "challenge" },
    { userId, day, title: "Review 30 flashcards", icon: "🔄", href: "/review", minutes: 12, xp: 75, kind: "challenge" },
    { userId, day, title: "Bonus: write a paragraph", icon: "🌟", href: "/writing", minutes: 15, xp: 150, kind: "challenge" },
  ];
  await db.insert(tasks).values(generated);
  return db
    .select()
    .from(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.day, day)))
    .orderBy(asc(tasks.id));
}

export async function getLatestMock(userId: number) {
  const [row] = await db
    .select()
    .from(mockResults)
    .where(eq(mockResults.userId, userId))
    .orderBy(desc(mockResults.createdAt))
    .limit(1);
  return row ?? null;
}

export async function getMockHistory(userId: number) {
  return db.select().from(mockResults).where(eq(mockResults.userId, userId)).orderBy(asc(mockResults.createdAt));
}

export async function getWordOfTheDay() {
  const idx = Number(today().replaceAll("-", "")) % 7;
  const pool = await db.select().from(words).where(eq(words.deck, "toefl")).orderBy(asc(words.id)).limit(7);
  return pool[idx % Math.max(1, pool.length)] ?? null;
}

export function getTipOfTheDay() {
  const idx = Number(today().replaceAll("-", "")) % DAILY_TIPS.length;
  return DAILY_TIPS[idx];
}

export async function getDashboard() {
  const user = await getUser();
  const [summary, stats, todayTasks, mock, decks, wotd] = await Promise.all([
    getReviewSummary(user.id),
    getDailyStats(user.id, 7),
    getTodayTasks(user.id),
    getLatestMock(user.id),
    getDeckCounts(user.id),
    getWordOfTheDay(),
  ]);

  const [lessonProgress] = await db
    .select({
      done: sql<number>`sum(case when ${userLessons.status} = 'completed' then 1 else 0 end)::int`,
      total: sql<number>`count(*)::int`,
    })
    .from(userLessons)
    .where(eq(userLessons.userId, user.id));

  const [lessonTotal] = await db.select({ total: sql<number>`count(*)::int` }).from(lessons);

  const level = levelFromXp(user.totalXp);
  const generalProgress = Math.min(
    99,
    Math.round(((lessonProgress?.done ?? 0) / Math.max(1, lessonTotal?.total ?? 1)) * 60 + (summary.mature / Math.max(1, summary.total)) * 40),
  );
  const techDeck = decks.find((d) => d.deck === "tech");
  const techProgress = techDeck ? Math.round((techDeck.mature / Math.max(1, techDeck.total)) * 100) : 0;
  const toeflProgress = mock ? Math.round((mock.total / user.targetScore) * 100) : 25;

  return { user, summary, stats, todayTasks, mock, decks, level, generalProgress, techProgress, toeflProgress, wotd, tip: getTipOfTheDay() };
}

/* ------------------------------ Content queries ------------------------------ */
export async function listLessons(module?: string) {
  const rows = module
    ? await db.select().from(lessons).where(eq(lessons.module, module)).orderBy(asc(lessons.orderIndex))
    : await db.select().from(lessons).orderBy(asc(lessons.orderIndex));
  return rows;
}

export async function getLesson(slug: string) {
  const [row] = await db.select().from(lessons).where(eq(lessons.slug, slug)).limit(1);
  return row ?? null;
}

export async function getLessonProgress(userId: number, lessonId: number) {
  const [row] = await db
    .select()
    .from(userLessons)
    .where(and(eq(userLessons.userId, userId), eq(userLessons.lessonId, lessonId)))
    .limit(1);
  return row ?? null;
}

export async function listArticles(module?: string) {
  const rows = module
    ? await db.select().from(articles).where(eq(articles.module, module)).orderBy(asc(articles.level))
    : await db.select().from(articles).orderBy(asc(articles.level));
  return rows;
}

export async function getArticle(slug: string) {
  const [row] = await db.select().from(articles).where(eq(articles.slug, slug)).limit(1);
  return row ?? null;
}

export async function listTracks(module?: string) {
  const rows = module
    ? await db.select().from(tracks).where(eq(tracks.module, module)).orderBy(asc(tracks.id))
    : await db.select().from(tracks).orderBy(asc(tracks.id));
  return rows;
}

export async function getTrack(slug: string) {
  const [row] = await db.select().from(tracks).where(eq(tracks.slug, slug)).limit(1);
  return row ?? null;
}

export async function listPrompts(kind: "writing" | "speaking", module?: string) {
  const conds = [eq(prompts.kind, kind)];
  if (module) conds.push(eq(prompts.module, module));
  return db.select().from(prompts).where(and(...conds)).orderBy(asc(prompts.id));
}

export async function listWords(opts: { deck?: string; topic?: string; q?: string; userId: number }) {
  const conds = [eq(userWords.userId, opts.userId)];
  if (opts.deck && opts.deck !== "all") conds.push(eq(words.deck, opts.deck));
  if (opts.topic && opts.topic !== "all") conds.push(eq(words.topic, opts.topic));
  if (opts.q) {
    const like = `%${opts.q.toLowerCase()}%`;
    conds.push(
      or(
        sql`lower(${words.word}) like ${like}`,
        sql`lower(${words.definitionEn}) like ${like}`,
        sql`${words.definitionFa} like ${like}`,
      )!,
    );
  }
  return db
    .select({ word: words, progress: userWords })
    .from(words)
    .innerJoin(userWords, eq(userWords.wordId, words.id))
    .where(and(...conds))
    .orderBy(asc(words.word))
    .limit(300);
}

export async function listTopics() {
  return db.select({ topic: words.topic, deck: words.deck }).from(words).groupBy(words.topic, words.deck);
}

export async function listResources() {
  return db.select().from(resources).orderBy(asc(resources.id));
}

export async function listMockTests() {
  return db.select().from(mockTests).orderBy(asc(mockTests.id));
}

export async function listAchievements(userId: number) {
  const all = await db.select().from(achievements).orderBy(asc(achievements.id));
  const summary = await getReviewSummary(userId);
  const user = await getUser();
  const [reads] = await db.select({ n: sql<number>`count(*)::int` }).from(readingLogs).where(eq(readingLogs.userId, userId));
  const [essays] = await db.select({ n: sql<number>`count(*)::int` }).from(writings).where(eq(writings.userId, userId));
  const [lessonsDone] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(userLessons)
    .where(and(eq(userLessons.userId, userId), eq(userLessons.status, "completed")));
  const [gamesPlayed] = await db
    .select({ n: sql<number>`count(distinct ${gameScores.game})::int` })
    .from(gameScores)
    .where(eq(gameScores.userId, userId));
  const mock = await getLatestMock(userId);
  const level = levelFromXp(user.totalXp);

  const values: Record<string, number> = {
    xp: user.totalXp,
    streak: user.streak,
    words: summary.total,
    mature: summary.mature,
    readings: reads?.n ?? 0,
    writings: essays?.n ?? 0,
    lessons: lessonsDone?.n ?? 0,
    listenings: reads?.n ?? 0,
    games: gamesPlayed?.n ?? 0,
    estimate: mock?.total ?? 0,
    level: level.level,
    accuracy: summary.correct + summary.wrong > 0 ? Math.round((summary.correct / (summary.correct + summary.wrong)) * 100) : 0,
    perfect: 1,
    hidden: 0,
    techMature: 0,
  };
  const decks = await getDeckCounts(userId);
  values.techMature = decks.find((d) => d.deck === "tech")?.mature ?? 0;

  return all.map((a) => ({ ...a, current: values[a.metric] ?? 0, unlocked: (values[a.metric] ?? 0) >= a.threshold }));
}

export async function getProgressPage(userId: number) {
  const [stats, mocks, summary, user, decks] = await Promise.all([
    getDailyStats(userId, 180),
    getMockHistory(userId),
    getReviewSummary(userId),
    getUser(),
    getDeckCounts(userId),
  ]);
  const [totals] = await db
    .select({
      minutes: sql<number>`coalesce(sum(${dailyStats.minutes}),0)::int`,
      xp: sql<number>`coalesce(sum(${dailyStats.xp}),0)::int`,
      days: sql<number>`count(*)::int`,
    })
    .from(dailyStats)
    .where(eq(dailyStats.userId, userId));
  return { stats, mocks, summary, user, decks, totals };
}

export async function listWritings(userId: number) {
  return db.select().from(writings).where(eq(writings.userId, userId)).orderBy(desc(writings.createdAt)).limit(30);
}

export async function listGameScores(userId: number) {
  return db.select().from(gameScores).where(eq(gameScores.userId, userId)).orderBy(desc(gameScores.createdAt)).limit(30);
}

export async function getGameWords(limit = 40) {
  const rows = await db.select().from(words).orderBy(sql`random()`).limit(limit);
  return rows;
}

export async function getReadingLogs(userId: number) {
  const rows = await db
    .select({ log: readingLogs, article: articles })
    .from(readingLogs)
    .innerJoin(articles, eq(articles.id, readingLogs.articleId))
    .where(eq(readingLogs.userId, userId))
    .orderBy(desc(readingLogs.createdAt))
    .limit(20);
  return rows;
}

export async function getLessonStatuses(userId: number, ids: number[]) {
  if (ids.length === 0) return [] as (typeof userLessons.$inferSelect)[];
  return db
    .select()
    .from(userLessons)
    .where(and(eq(userLessons.userId, userId), inArray(userLessons.lessonId, ids)));
}
