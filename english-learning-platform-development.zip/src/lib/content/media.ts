export type SeedTrack = {
  slug: string;
  module: "general" | "tech" | "toefl";
  title: string;
  kind: string;
  level: string;
  minutes: number;
  notesHint: string;
  transcript: { speaker: string; text: string }[];
  questions: { qType: string; prompt: string; options: string[]; answer: string; explain?: string }[];
};

export const SEED_TRACKS: SeedTrack[] = [
  {
    slug: "office-hours-registration", module: "toefl", title: "Conversation: Course Registration Problem",
    kind: "Conversation (Student–Administrator)", level: "TOEFL-level", minutes: 4,
    notesHint: "Note the student's problem, the two options offered, and the final decision.",
    transcript: [
      { speaker: "Student", text: "Hi, I'm trying to register for Advanced Algorithms, but the system keeps telling me I don't meet the prerequisites." },
      { speaker: "Administrator", text: "Let me check. It says here you haven't completed Discrete Mathematics. That's the required prerequisite for the course." },
      { speaker: "Student", text: "Right, but I took an equivalent course last summer at another university. I transferred the credit in September." },
      { speaker: "Administrator", text: "Ah, that explains it. Transfer credits sometimes don't map automatically to our prerequisite checker. You have two options. First, you can submit a prerequisite waiver form, which the department reviews within about a week. Or second, if you need to register today because the class is filling up, I can add you provisionally and the professor confirms later." },
      { speaker: "Student", text: "How risky is the provisional option? I mean, could I be dropped after classes begin?" },
      { speaker: "Administrator", text: "Theoretically yes, but in practice the professor almost always approves transfer credits from accredited institutions. Still, if you prefer certainty, the waiver is the safer route." },
      { speaker: "Student", text: "The class only has four seats left, so I think I'll take the provisional registration and submit the waiver at the same time." },
      { speaker: "Administrator", text: "That's the sensible combination. I'll register you now. Bring your transcript to the department office by Friday." },
    ],
    questions: [
      { qType: "Gist", prompt: "Why does the student visit the administrator?", options: ["To change her major", "Because the system blocks her registration", "To pay tuition", "To complain about a professor"], answer: "Because the system blocks her registration" },
      { qType: "Detail", prompt: "What caused the problem?", options: ["She failed a course", "Her transfer credit wasn't recognised by the checker", "She registered too late", "The class was cancelled"], answer: "Her transfer credit wasn't recognised by the checker" },
      { qType: "Function", prompt: "Why does the student ask 'How risky is the provisional option?'", options: ["To express doubt and gather information before deciding", "To criticise the policy", "To change the subject", "To request a refund"], answer: "To express doubt and gather information before deciding" },
      { qType: "Detail", prompt: "What does the student finally decide?", options: ["Only the waiver", "Only provisional registration", "Both provisional registration and the waiver", "To take a different course"], answer: "Both provisional registration and the waiver" },
      { qType: "Attitude", prompt: "The administrator's attitude can best be described as", options: ["impatient", "helpful and practical", "indifferent", "confused"], answer: "helpful and practical" },
    ],
  },
  {
    slug: "lecture-memory-consolidation", module: "toefl", title: "Lecture: Memory Consolidation (Psychology)",
    kind: "Academic Lecture", level: "TOEFL-level", minutes: 6,
    notesHint: "Use a two-column layout: main claims on the left, examples and numbers on the right.",
    transcript: [
      { speaker: "Professor", text: "Today I want to talk about consolidation — the process by which a fragile new memory becomes a stable long-term one. And I want to challenge an assumption many of you probably hold: that repetition alone is what makes memory durable." },
      { speaker: "Professor", text: "In a classic study, two groups learned the same fifty word pairs. Group A reread the list four times. Group B read it once and then tested themselves three times. A week later, group B remembered roughly eighty per cent of the pairs; group A remembered about thirty-five." },
      { speaker: "Professor", text: "This is the testing effect. Retrieval is not merely a measurement of learning; it is an event that modifies memory. Each successful retrieval strengthens the pathway more than a passive re-exposure does." },
      { speaker: "Professor", text: "Now, spacing interacts with this. If you test yourself immediately, the item is still in working memory and the retrieval is too easy to be useful. Difficulty — what Bjork calls desirable difficulty — is precisely what produces the benefit. So spacing your self-tests across days produces far more durable learning than massing them in a single evening." },
      { speaker: "Professor", text: "One caveat before you redesign your study habits. The testing effect is strongest when you receive feedback. Retrieving an incorrect answer and never correcting it can actually consolidate the error, which is why flashcard systems always reveal the answer afterwards." },
    ],
    questions: [
      { qType: "Gist", prompt: "What is the main point of the lecture?", options: ["Repetition is the key to memory", "Retrieval practice, spaced over time, strengthens memory", "Sleep is more important than study", "Working memory is limited"], answer: "Retrieval practice, spaced over time, strengthens memory" },
      { qType: "Detail", prompt: "In the study, how much did the self-testing group remember after a week?", options: ["about 35%", "about 50%", "about 80%", "about 100%"], answer: "about 80%" },
      { qType: "Function", prompt: "Why does the professor mention 'desirable difficulty'?", options: ["To explain why spacing improves retrieval", "To criticise Bjork", "To describe exam anxiety", "To define working memory"], answer: "To explain why spacing improves retrieval" },
      { qType: "Connecting Content", prompt: "According to the lecture, feedback is important because", options: ["it makes tests easier", "without it, errors can be consolidated", "it shortens study time", "it replaces retrieval"], answer: "without it, errors can be consolidated" },
      { qType: "Attitude", prompt: "The professor's attitude toward pure rereading is", options: ["enthusiastic", "sceptical", "neutral", "confused"], answer: "sceptical" },
    ],
  },
  {
    slug: "standup-meeting", module: "tech", title: "Daily Stand-up: Blocked on a Flaky Test",
    kind: "Workplace Conversation", level: "Intermediate", minutes: 3,
    notesHint: "Listen for the three stand-up moves: what I did, what I'll do, what blocks me.",
    transcript: [
      { speaker: "Maya", text: "Yesterday I finished the pagination endpoint and opened the pull request. Today I'm picking up the caching ticket. No blockers." },
      { speaker: "Omid", text: "I spent most of yesterday chasing a flaky integration test. It passes locally but fails in CI maybe one run in five. I suspect a race condition in the fixture setup." },
      { speaker: "Lead", text: "Is it blocking the release?" },
      { speaker: "Omid", text: "It's blocking the merge queue, yes. I'd like to pair with someone who knows the test harness. Otherwise I'll keep bisecting." },
      { speaker: "Maya", text: "I can pair after lunch. I wrote part of that harness last quarter." },
      { speaker: "Lead", text: "Perfect. Time-box it to two hours. If it's still flaky, quarantine the test, open a ticket and unblock the queue." },
    ],
    questions: [
      { qType: "Gist", prompt: "What is Omid's problem?", options: ["He missed a deadline", "A test fails intermittently in CI", "He cannot access the repository", "The release was cancelled"], answer: "A test fails intermittently in CI" },
      { qType: "Detail", prompt: "What does the lead suggest if the problem is not solved?", options: ["Revert the feature", "Quarantine the test and open a ticket", "Ignore CI", "Delay the release a week"], answer: "Quarantine the test and open a ticket" },
      { qType: "Vocabulary", prompt: "'Time-box it to two hours' means", options: ["work on it for at most two hours", "finish it in two minutes", "schedule a meeting", "measure the test runtime"], answer: "work on it for at most two hours" },
      { qType: "Function", prompt: "Why does Maya offer to pair?", options: ["She wrote part of the test harness", "She has no work", "She wants to lead the team", "She dislikes the ticket"], answer: "She wrote part of the test harness" },
    ],
  },
  {
    slug: "podcast-remote-work", module: "general", title: "Podcast Segment: Does Remote Work Actually Work?",
    kind: "Podcast", level: "Intermediate", minutes: 5,
    notesHint: "Track the two speakers' opinions and the evidence each one gives.",
    transcript: [
      { speaker: "Host", text: "So the headline claim is that remote workers are more productive. Is that actually supported by data?" },
      { speaker: "Guest", text: "Partly. Large studies of call-centre staff found a thirteen per cent increase in output, but call-centre work is highly measurable. For creative or collaborative work the picture is much murkier." },
      { speaker: "Host", text: "What about junior employees? That's the objection I hear most." },
      { speaker: "Guest", text: "And it's the strongest one. Learning by overhearing — what researchers call informal knowledge transfer — is very hard to replicate over video calls. Companies that do hybrid well tend to schedule deliberate mentoring rather than hoping it happens." },
      { speaker: "Host", text: "So your verdict is that remote work suits experienced specialists better than newcomers?" },
      { speaker: "Guest", text: "Roughly, yes. And it suits organisations that write things down. If your culture depends on hallway conversations, distributing it will expose that weakness immediately." },
    ],
    questions: [
      { qType: "Gist", prompt: "What is the guest's overall position?", options: ["Remote work always increases productivity", "It depends on the type of work and the organisation", "Remote work should be banned", "Only juniors benefit"], answer: "It depends on the type of work and the organisation" },
      { qType: "Detail", prompt: "What productivity increase was found among call-centre staff?", options: ["3%", "13%", "30%", "50%"], answer: "13%" },
      { qType: "Detail", prompt: "What is 'informal knowledge transfer'?", options: ["Official training courses", "Learning by overhearing colleagues", "Reading documentation", "Attending conferences"], answer: "Learning by overhearing colleagues" },
      { qType: "Inference", prompt: "The guest implies that written culture", options: ["is unnecessary for remote teams", "makes distributed work more viable", "slows teams down", "replaces mentoring"], answer: "makes distributed work more viable" },
    ],
  },
  {
    slug: "dictation-tech-news", module: "general", title: "Dictation Drill: Short News Items",
    kind: "Dictation", level: "Beginner", minutes: 3,
    notesHint: "Play at 0.75× and type exactly what you hear, including punctuation.",
    transcript: [
      { speaker: "Narrator", text: "Researchers have developed a battery that charges in under ten minutes." },
      { speaker: "Narrator", text: "The city council approved a plan to plant twenty thousand trees by next spring." },
      { speaker: "Narrator", text: "A small team released an open source tool that translates documents offline." },
      { speaker: "Narrator", text: "Scientists say the new telescope will observe galaxies formed shortly after the Big Bang." },
    ],
    questions: [
      { qType: "Detail", prompt: "How long does the new battery take to charge?", options: ["under ten minutes", "about an hour", "two hours", "thirty seconds"], answer: "under ten minutes" },
      { qType: "Detail", prompt: "How many trees will be planted?", options: ["2,000", "20,000", "200,000", "twelve"], answer: "20,000" },
      { qType: "Detail", prompt: "What does the open-source tool do?", options: ["Edits photos", "Translates documents offline", "Compresses video", "Blocks ads"], answer: "Translates documents offline" },
    ],
  },
  {
    slug: "lecture-volcanoes", module: "toefl", title: "Lecture: Why Some Volcanoes Explode (Geology)",
    kind: "Academic Lecture", level: "TOEFL-level", minutes: 5,
    notesHint: "Note the contrast: basaltic vs rhyolitic magma — viscosity, gas, eruption style.",
    transcript: [
      { speaker: "Professor", text: "Not all volcanoes behave the same way, and the difference comes down mostly to one property: viscosity — how resistant the magma is to flowing." },
      { speaker: "Professor", text: "Basaltic magma is low in silica, so it is runny. Gas escapes easily, which is why Hawaiian eruptions produce those spectacular but relatively gentle fountains and rivers of lava." },
      { speaker: "Professor", text: "Rhyolitic magma, by contrast, is rich in silica and extremely viscous. Gas bubbles cannot escape; pressure accumulates until the rock above fails catastrophically. That's your Mount St Helens scenario." },
      { speaker: "Professor", text: "Now here's the part that surprises students. Water content matters as much as chemistry. Subduction zones drag wet oceanic crust downward, and that water lowers the melting point, generating gas-rich magma. That's why the Pacific Ring of Fire is dominated by explosive volcanoes rather than gentle ones." },
    ],
    questions: [
      { qType: "Gist", prompt: "What determines whether a volcano erupts explosively?", options: ["Its height", "Magma viscosity and gas content", "The season", "Its distance from the ocean"], answer: "Magma viscosity and gas content" },
      { qType: "Detail", prompt: "Basaltic magma is described as", options: ["silica-rich and viscous", "low in silica and runny", "cold and solid", "gas-free"], answer: "low in silica and runny" },
      { qType: "Connecting Content", prompt: "Why are subduction-zone volcanoes typically explosive?", options: ["Water lowers the melting point and creates gas-rich magma", "They are taller", "They erupt more often", "They contain no silica"], answer: "Water lowers the melting point and creates gas-rich magma" },
      { qType: "Function", prompt: "Why does the professor mention Mount St Helens?", options: ["As an example of an explosive rhyolitic eruption", "To describe Hawaiian volcanoes", "To explain plate tectonics", "To discuss climate"], answer: "As an example of an explosive rhyolitic eruption" },
    ],
  },
];

export type SeedPrompt = {
  kind: "writing" | "speaking";
  taskType: string;
  module: "general" | "tech" | "toefl";
  title: string;
  prompt: string;
  prepSeconds?: number;
  speakSeconds?: number;
  minutes?: number;
  minWords?: number;
  template: string[];
  usefulPhrases: string[];
  modelAnswer?: string;
};

export const SEED_PROMPTS: SeedPrompt[] = [
  {
    kind: "writing", taskType: "TOEFL Independent", module: "toefl",
    title: "Technology and human connection",
    prompt: "Do you agree or disagree with the following statement? Technology has made people less able to communicate face to face. Use specific reasons and examples to support your answer.",
    minutes: 30, minWords: 300,
    template: [
      "Intro: hook + paraphrase the prompt + clear thesis with two reasons.",
      "Body 1: topic sentence → explanation → concrete personal or research example → mini-conclusion.",
      "Body 2: second reason with a different kind of support (statistic, hypothetical, contrast).",
      "Optional concession: 'Admittedly, … . Nevertheless, …'",
      "Conclusion: restate thesis in new words + one forward-looking sentence.",
    ],
    usefulPhrases: ["While it is true that…, I would argue that…", "A compelling illustration of this is…", "This is not merely a matter of convenience; it reshapes…", "Ultimately, the evidence suggests that…"],
    modelAnswer: "Few technologies have altered daily interaction as profoundly as the smartphone. While critics contend that constant connectivity has eroded our capacity for face-to-face conversation, I would argue that the tool itself is neutral; what matters is the intention behind its use...",
  },
  {
    kind: "writing", taskType: "TOEFL Integrated", module: "toefl",
    title: "Reading + Lecture: the decline of the honeybee",
    prompt: "Summarise the points made in the lecture, explaining how they cast doubt on the specific claims made in the reading passage. (Reading claim: pesticides alone explain colony collapse. Lecture: the professor identifies parasites, habitat loss and monoculture as alternative causes.)",
    minutes: 20, minWords: 180,
    template: [
      "Sentence 1: The lecturer challenges the reading's claim that …",
      "Point 1: First, the professor argues that … whereas the passage states that …",
      "Point 2: Second, she points out that …, which contradicts the reading's assertion that …",
      "Point 3: Finally, the lecture notes that …, casting doubt on …",
    ],
    usefulPhrases: ["The lecturer refutes the idea that…", "In contrast to the passage, the professor maintains that…", "This directly undermines the claim that…", "The reading fails to account for…"],
  },
  {
    kind: "writing", taskType: "Academic Discussion", module: "toefl",
    title: "Online learning vs classroom learning",
    prompt: "Your professor is teaching a class on education policy. Write a post responding to the professor's question and to one classmate, adding your own contribution (at least 100 words). Professor: 'Should universities keep large lecture courses online permanently?'",
    minutes: 10, minWords: 100,
    template: [
      "Greeting/stance: 'I see Kamran's point about …, but I lean towards …'",
      "Reason with a specific example (2–3 sentences).",
      "Extension: a nuance or a condition that the others did not mention.",
    ],
    usefulPhrases: ["I'd like to build on what X said about…", "That said, there is a trade-off worth naming:", "From my own experience as a …", "A reasonable compromise might be…"],
  },
  {
    kind: "writing", taskType: "Technical Writing", module: "tech",
    title: "Write a clear bug report",
    prompt: "Write a bug report for the following situation: after the latest deployment, users on Safari cannot upload files larger than 5 MB; the request fails silently with no error shown. Include: summary, environment, steps to reproduce, expected vs actual behaviour, and severity.",
    minutes: 15, minWords: 150,
    template: [
      "**Summary:** one sentence, specific and searchable.",
      "**Environment:** browser/OS/app version/commit.",
      "**Steps to reproduce:** numbered, deterministic.",
      "**Expected:** what should happen. **Actual:** what happens.",
      "**Severity / impact:** who is affected and how badly.",
    ],
    usefulPhrases: ["Steps to reproduce (100% reproducible):", "Expected behaviour: the upload completes and a success toast appears.", "Actual behaviour: the request fails silently; no error is surfaced.", "Impact: blocks all Safari users on the paid plan."],
  },
  {
    kind: "writing", taskType: "Paragraph (PEEL)", module: "general",
    title: "PEEL paragraph: the value of daily reading",
    prompt: "Write one well-structured paragraph (Point, Evidence, Explanation, Link) arguing that reading in English for fifteen minutes a day is more effective than one long weekly session.",
    minutes: 12, minWords: 120,
    template: ["Point: a clear topic sentence.", "Evidence: a fact, study or example.", "Explanation: why the evidence supports the point.", "Link: connect back to the topic or forward to the next idea."],
    usefulPhrases: ["The principal advantage of … is that…", "Research into spaced practice indicates that…", "This matters because…", "Consequently, …"],
  },
  {
    kind: "speaking", taskType: "Task 1 — Independent", module: "toefl",
    title: "A skill you would like to learn",
    prompt: "Describe a skill you would like to learn and explain why it interests you. Include specific details in your explanation.",
    prepSeconds: 15, speakSeconds: 45,
    template: [
      "(5s) Direct answer: 'The skill I'd most like to learn is …'",
      "(20s) Reason 1 + a concrete detail.",
      "(15s) Reason 2 or a short personal story.",
      "(5s) Wrap-up: 'That's why … would really matter to me.'",
    ],
    usefulPhrases: ["If I had to choose one, I'd say…", "The main reason is that…", "For instance, last year I…", "So all in all, …"],
    modelAnswer: "If I had to choose one skill, I'd say public speaking. The main reason is that my ideas often get lost in meetings — I know the material, but I rush. For instance, last semester I presented a project and finished five minutes early because I was nervous. Learning to pace myself would make my work visible. So all in all, it's a practical skill, not just a personal goal.",
  },
  {
    kind: "speaking", taskType: "Task 2 — Campus Announcement", module: "toefl",
    title: "Library hours change",
    prompt: "The university announces it will close the main library at 10 p.m. instead of midnight to reduce costs. The man disagrees, arguing that most students study late and that the savings are small. Summarise the announcement and the man's opinion with his reasons.",
    prepSeconds: 30, speakSeconds: 60,
    template: [
      "(10s) The announcement: 'The university has decided to … in order to …'",
      "(35s) The speaker's opinion + reason 1 + reason 2 with details.",
      "(10s) Close: 'For these reasons, he opposes the change.'",
    ],
    usefulPhrases: ["According to the announcement,…", "The man disagrees with this policy for two reasons.", "First of all, he points out that…", "On top of that, he mentions that…"],
  },
  {
    kind: "speaking", taskType: "Tech Interview", module: "tech",
    title: "Tell me about a challenging bug you fixed",
    prompt: "Answer using the STAR method: Situation, Task, Action, Result. Speak for 90 seconds about a difficult technical problem you solved.",
    prepSeconds: 30, speakSeconds: 90,
    template: [
      "Situation (15s): context, system, why it mattered.",
      "Task (10s): your specific responsibility.",
      "Action (45s): what you did, step by step, with the reasoning.",
      "Result (20s): measurable outcome + what you learned.",
    ],
    usefulPhrases: ["At the time, we were running…", "My responsibility was to…", "The first thing I did was reproduce the issue with…", "As a result, error rates dropped from … to …", "The main takeaway for me was…"],
    modelAnswer: "At the time we were running a payment service that intermittently timed out during peak hours. My responsibility was to find the root cause before the next sale event. The first thing I did was reproduce the issue under load, which showed connection-pool exhaustion rather than slow queries. I added pool metrics, found a code path that never released connections on error, and fixed it with a try/finally. As a result, p99 latency dropped from 4 seconds to 300 milliseconds. The main takeaway was that observability beats guessing.",
  },
  {
    kind: "speaking", taskType: "Self Introduction", module: "tech",
    title: "Introduce yourself to an interviewer",
    prompt: "Give a 60-second professional introduction: who you are, what you work on, one achievement, and what you are looking for next.",
    prepSeconds: 20, speakSeconds: 60,
    template: ["Present: current role and focus.", "Past: relevant experience, one measurable achievement.", "Future: what you want next and why this role."],
    usefulPhrases: ["I'm a backend engineer focused on…", "Over the past two years I've…", "One project I'm particularly proud of is…", "What draws me to this role is…"],
  },
  {
    kind: "speaking", taskType: "Pronunciation Clinic", module: "general",
    title: "Minimal pairs for Persian speakers",
    prompt: "Record yourself reading these pairs clearly: think/sink, west/vest, sit/seat, ship/sheep, very/berry, three/tree. Then compare with the model pronunciation.",
    prepSeconds: 10, speakSeconds: 60,
    template: ["Read slowly, exaggerating the target sound.", "Record again at normal speed.", "Listen back and mark the pairs you could not distinguish."],
    usefulPhrases: ["/θ/ — tongue between the teeth, no voice: think, three, both", "/w/ — round the lips, no teeth contact: west, water", "/iː/ is long and tense: seat, sheep", "/ɪ/ is short and relaxed: sit, ship"],
  },
];

export type SeedMock = { title: string; kind: "full" | "section" | "mini"; minutes: number; blurb: string; sections: string[] };

export const SEED_MOCKS: SeedMock[] = [
  { title: "Full Mock Test 1", kind: "full", minutes: 120, blurb: "Complete four-section simulation with official timing and scoring.", sections: ["Reading", "Listening", "Speaking", "Writing"] },
  { title: "Full Mock Test 2", kind: "full", minutes: 120, blurb: "Second full-length simulation with new academic topics.", sections: ["Reading", "Listening", "Speaking", "Writing"] },
  { title: "Reading Section Test", kind: "section", minutes: 35, blurb: "Two academic passages, 20 questions, official pacing.", sections: ["Reading"] },
  { title: "Listening Section Test", kind: "section", minutes: 36, blurb: "Two conversations and three lectures with note-taking.", sections: ["Listening"] },
  { title: "Speaking Section Test", kind: "section", minutes: 16, blurb: "Four tasks with preparation and response timers.", sections: ["Speaking"] },
  { title: "Writing Section Test", kind: "section", minutes: 50, blurb: "Integrated task plus academic discussion post.", sections: ["Writing"] },
  { title: "Quick Mixed Mini Test", kind: "mini", minutes: 30, blurb: "One passage, one lecture, one speaking task.", sections: ["Reading", "Listening", "Speaking"] },
  { title: "Daily 15-minute Drill", kind: "mini", minutes: 15, blurb: "Short warm-up to keep exam reflexes sharp.", sections: ["Reading", "Listening"] },
];
