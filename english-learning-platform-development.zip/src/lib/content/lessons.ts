export type SeedLesson = {
  slug: string;
  module: "general" | "tech" | "toefl";
  section: string;
  level: string;
  title: string;
  subtitle: string;
  structure?: string;
  body: { heading: string; text: string }[];
  examples: { en: string; fa: string; note?: string }[];
  mistakes: { wrong: string; right: string; why: string }[];
  persianHint: string;
  quickCard: string[];
  questions: { type: string; prompt: string; options?: string[]; answer: string; explain?: string }[];
  difficulty: number;
  minutes: number;
  orderIndex: number;
};

export const SEED_LESSONS: SeedLesson[] = [
  {
    slug: "parts-of-speech", module: "general", section: "grammar", level: "Beginner (A1-A2)",
    title: "Parts of Speech", subtitle: "The eight building blocks of every English sentence",
    structure: "Noun + Verb (+ Object) — everything else describes or connects these.",
    body: [
      { heading: "What are parts of speech?", text: "Every English word belongs to a category that tells you what job it does in a sentence: noun, verb, adjective, adverb, pronoun, preposition, conjunction and interjection." },
      { heading: "The core four", text: "Nouns name things (engineer, algorithm). Verbs express actions or states (write, is). Adjectives describe nouns (fast, elegant). Adverbs describe verbs, adjectives or whole sentences (quickly, surprisingly)." },
      { heading: "The connectors", text: "Prepositions (in, on, at, of, by) show relationships. Conjunctions (and, but, because, although) join ideas. Pronouns (it, they, which) replace nouns so you avoid repetition." },
    ],
    examples: [
      { en: "The **diligent** engineer **quickly** refactored the **module**.", fa: "مهندسِ کوشا به‌سرعت ماژول را بازآرایی کرد.", note: "adjective → adverb → noun" },
      { en: "She works **at** a startup **because** she loves autonomy.", fa: "او در یک استارتاپ کار می‌کند چون استقلال را دوست دارد.", note: "preposition + conjunction" },
    ],
    mistakes: [
      { wrong: "He speaks English good.", right: "He speaks English well.", why: "'Good' is an adjective; you need the adverb 'well' to describe the verb 'speaks'." },
      { wrong: "She is very interesting in AI.", right: "She is very interested in AI.", why: "-ed adjectives describe feelings, -ing adjectives describe the thing causing them." },
    ],
    persianHint: "هر کلمه در جمله یک «نقش» دارد: اسم (چیز)، فعل (کار)، صفت (توصیف اسم)، قید (توصیف فعل).",
    quickCard: ["Noun = thing", "Verb = action/state", "Adjective → describes noun", "Adverb → describes verb/adj", "Preposition = relation", "Conjunction = joins clauses"],
    questions: [
      { type: "mcq", prompt: "In 'The algorithm runs efficiently', the word 'efficiently' is a…", options: ["adjective", "adverb", "noun", "preposition"], answer: "adverb", explain: "It modifies the verb 'runs'." },
      { type: "mcq", prompt: "Which word is a conjunction?", options: ["under", "although", "quickly", "laptop"], answer: "although" },
      { type: "fill", prompt: "She solved the problem ___ (easy → adverb).", answer: "easily" },
      { type: "mcq", prompt: "'Happiness' is a…", options: ["verb", "adjective", "noun", "adverb"], answer: "noun" },
      { type: "fill", prompt: "They were ___ (bore → feeling adjective) during the lecture.", answer: "bored" },
    ],
    difficulty: 1, minutes: 15, orderIndex: 1,
  },
  {
    slug: "present-simple-vs-continuous", module: "general", section: "grammar", level: "Beginner (A1-A2)",
    title: "Present Simple vs Present Continuous", subtitle: "Routines and facts vs actions happening now",
    structure: "S + V(s/es)  |  S + am/is/are + V-ing",
    body: [
      { heading: "Present Simple", text: "Use it for habits, routines, general truths, and permanent situations: I study every evening. Water boils at 100 °C. He works at Google." },
      { heading: "Present Continuous", text: "Use it for actions happening right now, temporary situations and future arrangements: I am studying for TOEFL this month. We are meeting the client at 5." },
      { heading: "State verbs", text: "Verbs of thinking, feeling, senses and possession (know, believe, want, like, own, seem) are usually NOT used in the continuous form." },
    ],
    examples: [
      { en: "I **study** English every day.", fa: "هر روز انگلیسی می‌خوانم.", note: "habit → simple" },
      { en: "I **am studying** for the TOEFL right now.", fa: "همین حالا دارم برای تافل می‌خوانم.", note: "now → continuous" },
      { en: "Water **boils** at 100 degrees.", fa: "آب در ۱۰۰ درجه می‌جوشد.", note: "general truth" },
    ],
    mistakes: [
      { wrong: "I am knowing the answer.", right: "I know the answer.", why: "'Know' is a state verb — no continuous form." },
      { wrong: "He work in Tehran.", right: "He works in Tehran.", why: "Third person singular needs -s." },
    ],
    persianHint: "حال ساده = عادت/حقیقت. حال استمراری = کاری که همین الان در جریان است («دارم ... می‌کنم»).",
    quickCard: ["Habit/fact → Present Simple", "Now/temporary → Present Continuous", "State verbs never take -ing", "3rd person singular: +s/es"],
    questions: [
      { type: "mcq", prompt: "Choose: 'Listen! The neighbours ___ again.'", options: ["argue", "are arguing", "argues", "argued"], answer: "are arguing" },
      { type: "fill", prompt: "My brother ___ (work) for a bank.", answer: "works" },
      { type: "mcq", prompt: "Which sentence is correct?", options: ["I am wanting a coffee.", "I want a coffee.", "I am want a coffee.", "I wants a coffee."], answer: "I want a coffee." },
      { type: "fill", prompt: "Right now she ___ (write) her TOEFL essay.", answer: "is writing" },
      { type: "mcq", prompt: "'The sun ___ in the east.'", options: ["is rising", "rises", "rise", "risen"], answer: "rises" },
    ],
    difficulty: 1, minutes: 18, orderIndex: 2,
  },
  {
    slug: "articles-a-an-the", module: "general", section: "grammar", level: "Beginner (A1-A2)",
    title: "Articles: a, an, the", subtitle: "The small words that native speakers notice immediately",
    structure: "a/an = one of many (first mention) | the = specific (shared knowledge) | ∅ = general plural/uncountable",
    body: [
      { heading: "Indefinite: a / an", text: "Use 'a/an' with singular countable nouns when the listener does not yet know which one. 'An' comes before vowel SOUNDS: an hour, a university." },
      { heading: "Definite: the", text: "Use 'the' when both speaker and listener know exactly which one — second mention, unique things (the sun), superlatives (the best), and ordinals (the first)." },
      { heading: "Zero article", text: "No article with plural or uncountable nouns used in a general sense: Computers changed society. Information is valuable." },
    ],
    examples: [
      { en: "I read **a** paper yesterday. **The** paper was about transformers.", fa: "دیروز یک مقاله خواندم. آن مقاله درباره ترنسفورمرها بود.", note: "first mention → second mention" },
      { en: "She is **the** best engineer on the team.", fa: "او بهترین مهندس تیم است.", note: "superlative" },
    ],
    mistakes: [
      { wrong: "I am student of the computer science.", right: "I am a student of computer science.", why: "Fields of study take no article; a singular job/role takes 'a'." },
      { wrong: "The life is hard.", right: "Life is hard.", why: "Abstract nouns in a general sense take no article." },
    ],
    persianHint: "در فارسی «یک» و «ـه/این» نقش a/the را بازی می‌کنند. اگر شنونده می‌داند کدام، از the استفاده کن.",
    quickCard: ["a/an → first mention, singular countable", "the → specific / already known", "∅ → general plural & uncountable", "an + vowel sound (an hour)"],
    questions: [
      { type: "mcq", prompt: "___ Internet has changed everything.", options: ["A", "An", "The", "—"], answer: "The" },
      { type: "fill", prompt: "It took me ___ hour to finish the passage.", answer: "an" },
      { type: "mcq", prompt: "___ honesty is important in research.", options: ["The", "A", "An", "—"], answer: "—" },
      { type: "fill", prompt: "She works as ___ software engineer.", answer: "a" },
      { type: "mcq", prompt: "We visited ___ university in Toronto.", options: ["a", "an", "the best of", "—"], answer: "a" },
    ],
    difficulty: 1, minutes: 15, orderIndex: 3,
  },
  {
    slug: "present-perfect-vs-past-simple", module: "general", section: "grammar", level: "Intermediate (B1-B2)",
    title: "Present Perfect vs Past Simple", subtitle: "Finished time vs time that still matters",
    structure: "S + have/has + V3   |   S + V2 (+ finished time expression)",
    body: [
      { heading: "Past Simple", text: "Use it when the time is finished and usually stated: yesterday, in 2019, last week, two hours ago." },
      { heading: "Present Perfect", text: "Use it for experiences (ever/never), unfinished time (today, this week), recent news with present relevance (just, already, yet), and duration with for/since." },
      { heading: "Signal words", text: "Past simple: ago, yesterday, last…, in 2020. Present perfect: since, for, ever, never, just, yet, already, so far, recently." },
    ],
    examples: [
      { en: "I **have studied** English for six years.", fa: "شش سال است انگلیسی می‌خوانم (و هنوز ادامه دارد).", note: "duration → perfect" },
      { en: "I **studied** English in high school.", fa: "در دبیرستان انگلیسی خواندم (تمام شده).", note: "finished period" },
      { en: "She **has just submitted** her essay.", fa: "او همین الان مقاله‌اش را ارسال کرده است." },
    ],
    mistakes: [
      { wrong: "I have seen him yesterday.", right: "I saw him yesterday.", why: "'Yesterday' is finished time — use past simple." },
      { wrong: "I am here since Monday.", right: "I have been here since Monday.", why: "Duration up to now needs present perfect." },
    ],
    persianHint: "اگر زمانِ کار تمام شده و مشخص است → گذشته ساده. اگر اثرش تا الان ادامه دارد → حال کامل.",
    quickCard: ["ago/yesterday/last → Past Simple", "for/since/just/yet/ever → Present Perfect", "Unfinished time (today) → Perfect", "Finished time → Simple"],
    questions: [
      { type: "mcq", prompt: "I ___ my keys. I can't open the door!", options: ["lost", "have lost", "was losing", "had lost"], answer: "have lost", explain: "Present result matters now." },
      { type: "fill", prompt: "We ___ (live) in Shiraz since 2018.", answer: "have lived" },
      { type: "mcq", prompt: "___ you ___ the new TOEFL format yet?", options: ["Did / try", "Have / tried", "Do / try", "Are / trying"], answer: "Have / tried" },
      { type: "fill", prompt: "He ___ (finish) the report two hours ago.", answer: "finished" },
      { type: "mcq", prompt: "Which is correct?", options: ["I have been to Paris in 2019.", "I went to Paris in 2019.", "I have go to Paris in 2019.", "I was gone to Paris in 2019."], answer: "I went to Paris in 2019." },
    ],
    difficulty: 3, minutes: 20, orderIndex: 4,
  },
  {
    slug: "conditionals-type-2", module: "general", section: "grammar", level: "Intermediate (B1-B2)",
    title: "Conditionals (Type 2) — Unreal Present", subtitle: "Imagining situations that are not true now",
    structure: "If + Subject + Past Simple, Subject + would + base verb",
    body: [
      { heading: "When to use it", text: "Second conditional describes imaginary, unlikely or impossible situations in the present or future, and gives advice ('If I were you…')." },
      { heading: "The form", text: "The 'if' clause uses past simple (but the meaning is present!). The main clause uses would / could / might + base verb." },
      { heading: "Were for all persons", text: "In formal English use 'were' for every subject: If I were you, if he were here. 'Was' is common in speech but avoid it in TOEFL writing." },
    ],
    examples: [
      { en: "If I **had** more time, I **would learn** Rust.", fa: "اگر وقت بیشتری داشتم، Rust یاد می‌گرفتم.", note: "past simple → would + base verb" },
      { en: "If she **knew** the answer, she **would tell** us.", fa: "اگر جواب را می‌دانست، به ما می‌گفت." },
      { en: "If I **were** you, I **would take** a mock test weekly.", fa: "اگر جای تو بودم، هفته‌ای یک آزمون آزمایشی می‌دادم.", note: "advice" },
    ],
    mistakes: [
      { wrong: "If I would have more time, I would travel.", right: "If I had more time, I would travel.", why: "Never use 'would' inside the if-clause of a second conditional." },
      { wrong: "If he was rich, he will buy a house.", right: "If he were rich, he would buy a house.", why: "Unreal present → were + would." },
    ],
    persianHint: "«اگر زمان بیشتری داشتم، پایتون یاد می‌گرفتم» — برای شرایط غیرواقعی در زمان حال.",
    quickCard: ["If + past simple, would + V1", "Unreal / imaginary present", "Advice: If I were you, I would…", "Never 'would' after 'if'"],
    questions: [
      { type: "fill", prompt: "If she ___ (know) the answer, she ___ (tell) us.", answer: "knew / would tell" },
      { type: "mcq", prompt: "If I ___ you, I would apply immediately.", options: ["am", "was being", "were", "would be"], answer: "were" },
      { type: "mcq", prompt: "Which sentence is second conditional?", options: ["If it rains, we stay home.", "If it rained, we would stay home.", "If it had rained, we would have stayed.", "If it will rain, we stay."], answer: "If it rained, we would stay home." },
      { type: "fill", prompt: "We ___ (hire) more engineers if we had the budget.", answer: "would hire" },
      { type: "mcq", prompt: "Choose the incorrect sentence.", options: ["If I had a car, I would drive.", "If I would have a car, I would drive.", "If he were here, he could help.", "If they studied, they might pass."], answer: "If I would have a car, I would drive." },
    ],
    difficulty: 3, minutes: 20, orderIndex: 5,
  },
  {
    slug: "passive-voice", module: "general", section: "grammar", level: "Intermediate (B1-B2)",
    title: "Passive Voice", subtitle: "When the action matters more than the actor",
    structure: "Object + be (conjugated) + past participle (+ by agent)",
    body: [
      { heading: "Why passive?", text: "Academic and technical English uses the passive when the agent is unknown, obvious, or unimportant: 'The data were collected in 2023.'" },
      { heading: "Forming it", text: "Keep the tense in the verb 'be': is written / was written / has been written / will be written / is being written." },
      { heading: "Keep it purposeful", text: "Overusing passive makes writing vague. In TOEFL writing, mix active and passive — active for your own arguments, passive for described processes." },
    ],
    examples: [
      { en: "The bug **was fixed** in the latest release.", fa: "باگ در آخرین نسخه برطرف شد." },
      { en: "Thousands of samples **have been analysed** so far.", fa: "تاکنون هزاران نمونه تحلیل شده است." },
    ],
    mistakes: [
      { wrong: "The report was wrote by the team.", right: "The report was written by the team.", why: "Passive needs the past participle (V3), not past simple." },
      { wrong: "The accident was happened yesterday.", right: "The accident happened yesterday.", why: "Intransitive verbs (happen, occur, arrive) have no passive." },
    ],
    persianHint: "مجهول: وقتی فاعل مهم نیست یا معلوم نیست — «گزارش نوشته شد».",
    quickCard: ["be + V3", "Agent optional: by …", "No passive for intransitive verbs", "Common in academic/technical writing"],
    questions: [
      { type: "fill", prompt: "Make passive: 'Engineers deploy the service weekly.' → The service ___ weekly.", answer: "is deployed" },
      { type: "mcq", prompt: "Which is correct?", options: ["The results was published.", "The results were published.", "The results were publish.", "The results have publish."], answer: "The results were published." },
      { type: "mcq", prompt: "Which verb cannot be passive?", options: ["build", "occur", "design", "analyse"], answer: "occur" },
      { type: "fill", prompt: "The prototype ___ (test) right now.", answer: "is being tested" },
      { type: "fill", prompt: "The paper ___ (accept) by the conference last week.", answer: "was accepted" },
    ],
    difficulty: 3, minutes: 18, orderIndex: 6,
  },
  {
    slug: "relative-clauses", module: "general", section: "grammar", level: "Intermediate (B1-B2)",
    title: "Relative Clauses", subtitle: "Add information without starting a new sentence",
    structure: "Noun + who/which/that/whose/where + clause",
    body: [
      { heading: "Defining clauses", text: "They identify which person or thing you mean and take NO commas: The engineer who wrote the parser is on leave." },
      { heading: "Non-defining clauses", text: "They add extra information and always take commas; 'that' is not allowed: Python, which was released in 1991, is widely used." },
      { heading: "Reduced clauses", text: "You can drop 'which is / who are': The library (which was) written in Rust is fast. This is very common in academic writing." },
    ],
    examples: [
      { en: "The article **that** I read yesterday was fascinating.", fa: "مقاله‌ای که دیروز خواندم جذاب بود." },
      { en: "TOEFL, **which** lasts about two hours, tests four skills.", fa: "تافل که حدود دو ساعت طول می‌کشد، چهار مهارت را می‌سنجد." },
    ],
    mistakes: [
      { wrong: "My laptop, that I bought in 2020, is slow.", right: "My laptop, which I bought in 2020, is slow.", why: "'That' cannot introduce a non-defining clause." },
      { wrong: "The man which called you is waiting.", right: "The man who called you is waiting.", why: "Use 'who' for people." },
    ],
    persianHint: "«که» در فارسی معادل who/which/that است؛ اگر اطلاعات اضافی می‌دهی، ویرگول بگذار.",
    quickCard: ["who → people", "which → things", "that → defining only", "whose → possession", "where → place", "Commas = extra info"],
    questions: [
      { type: "mcq", prompt: "The scientist ___ discovered the effect won a prize.", options: ["which", "who", "whom", "whose"], answer: "who" },
      { type: "fill", prompt: "Redis, ___ is an in-memory store, is very fast.", answer: "which" },
      { type: "mcq", prompt: "Which sentence needs commas?", options: ["The book that I lent you is mine.", "Students who cheat fail.", "My brother who lives in Rasht is a doctor — I have one brother.", "The file that crashed is corrupted."], answer: "My brother who lives in Rasht is a doctor — I have one brother." },
      { type: "fill", prompt: "That's the startup ___ founder studied at MIT.", answer: "whose" },
      { type: "fill", prompt: "This is the lab ___ the experiment took place.", answer: "where" },
    ],
    difficulty: 3, minutes: 18, orderIndex: 7,
  },
  {
    slug: "inversion", module: "general", section: "grammar", level: "Advanced (C1-C2)",
    title: "Inversion for Emphasis", subtitle: "Formal structures that impress TOEFL raters",
    structure: "Negative adverbial + auxiliary + subject + main verb",
    body: [
      { heading: "What is inversion?", text: "When a sentence begins with a negative or restrictive adverbial, the subject and auxiliary swap places, exactly as in a question." },
      { heading: "Common triggers", text: "Never, rarely, seldom, hardly … when, no sooner … than, not only … but also, under no circumstances, only after / only when / only by." },
      { heading: "Use sparingly", text: "One or two inverted sentences in a TOEFL essay show range; more than that sounds unnatural." },
    ],
    examples: [
      { en: "**Never have I seen** such a clean codebase.", fa: "هرگز چنین کد تمیزی ندیده بودم." },
      { en: "**Not only did the model improve accuracy**, but it also reduced latency.", fa: "مدل نه‌تنها دقت را بهبود داد، بلکه تأخیر را هم کم کرد." },
      { en: "**Only by practising daily** can you master pronunciation.", fa: "تنها با تمرین روزانه می‌توانی تلفظ را تسلط پیدا کنی." },
    ],
    mistakes: [
      { wrong: "Never I have seen such a thing.", right: "Never have I seen such a thing.", why: "The auxiliary must come before the subject." },
      { wrong: "Not only he studied, but also he worked.", right: "Not only did he study, but he also worked.", why: "Add the auxiliary 'did' and invert." },
    ],
    persianHint: "برای تأکید، ساختار جمله را سؤالی می‌کنیم: «هرگز ندیده بودم…».",
    quickCard: ["Never/Rarely/Seldom + aux + S + V", "No sooner … than", "Not only … but also", "Only by/after/when + aux + S"],
    questions: [
      { type: "mcq", prompt: "Rarely ___ such a well-structured essay.", options: ["I have read", "have I read", "I read have", "did I have read"], answer: "have I read" },
      { type: "fill", prompt: "No sooner had we deployed ___ the server crashed.", answer: "than" },
      { type: "fill", prompt: "Invert: 'He not only writes code but also teaches.' → Not only ___ he write code, but he also teaches.", answer: "does" },
      { type: "mcq", prompt: "Under no circumstances ___ share your password.", options: ["you should", "should you", "you will", "do you should"], answer: "should you" },
      { type: "fill", prompt: "Only after the review ___ (be) the feature merged.", answer: "was" },
    ],
    difficulty: 5, minutes: 22, orderIndex: 8,
  },
  {
    slug: "toefl-error-identification", module: "toefl", section: "grammar", level: "Grammar for TOEFL",
    title: "TOEFL Error Identification Patterns", subtitle: "The eight mistakes test writers love to hide",
    structure: "Scan for: agreement → tense → parallelism → article → preposition → word form → pronoun → comparison",
    body: [
      { heading: "Subject-verb agreement", text: "Watch for long noun phrases: 'The number of students IS rising' but 'A number of students ARE rising'." },
      { heading: "Parallel structure", text: "Items in a list must share the same grammatical form: reading, writing and listening (all -ing)." },
      { heading: "Word form", text: "TOEFL frequently swaps an adjective for a noun: 'economic growth' (adj + noun), not 'economy growth'." },
      { heading: "Comparisons", text: "'More easier' is wrong; use 'easier'. Compare like with like: 'The population of Iran is larger than THAT OF Iraq'." },
    ],
    examples: [
      { en: "The data **were** collected over three years.", fa: "داده‌ها طی سه سال جمع‌آوری شدند.", note: "'data' is plural in academic English" },
      { en: "She enjoys reading, writing **and swimming**.", fa: "او از خواندن، نوشتن و شنا لذت می‌برد.", note: "parallel -ing forms" },
    ],
    mistakes: [
      { wrong: "Each of the students have a laptop.", right: "Each of the students has a laptop.", why: "'Each' is singular." },
      { wrong: "The climate of Iran is different than Iraq.", right: "The climate of Iran is different from that of Iraq.", why: "Compare the same categories." },
    ],
    persianHint: "در سؤالات خطایابی، اول مطابقت فاعل و فعل، بعد زمان و موازی‌سازی را چک کن.",
    quickCard: ["Each/Every/One of → singular verb", "Keep lists parallel", "adj + noun (economic growth)", "than that of / than those of", "Neither … nor → verb agrees with 2nd subject"],
    questions: [
      { type: "mcq", prompt: "Find the error: 'The number of applicants have increased sharply.'", options: ["The number", "of applicants", "have increased", "sharply"], answer: "have increased", explain: "'The number' is singular → has increased." },
      { type: "mcq", prompt: "Find the error: 'She is more taller than her sister.'", options: ["She is", "more taller", "than", "her sister"], answer: "more taller" },
      { type: "fill", prompt: "Correct it: 'Neither the manager nor the engineers was informed.' → ___", answer: "were" },
      { type: "mcq", prompt: "Choose the parallel version.", options: ["He likes to run, swimming and bike.", "He likes running, swimming and biking.", "He likes run, swim and biking.", "He likes to run, swim and biking."], answer: "He likes running, swimming and biking." },
      { type: "fill", prompt: "Fix the word form: 'This is an ___ (economy) decision.'", answer: "economic" },
    ],
    difficulty: 4, minutes: 20, orderIndex: 9,
  },
  {
    slug: "reported-speech", module: "general", section: "grammar", level: "Intermediate (B1-B2)",
    title: "Reported Speech", subtitle: "Telling people what someone else said",
    structure: "said (that) + subject + backshifted verb",
    body: [
      { heading: "Backshift", text: "Present → past, past → past perfect, will → would, can → could, must → had to." },
      { heading: "Time & place words", text: "now → then, today → that day, tomorrow → the next day, here → there, this → that." },
      { heading: "Questions & commands", text: "Reported questions use statement word order: 'He asked where I lived.' Commands use 'told me to + verb'." },
    ],
    examples: [
      { en: "\"I am tired.\" → She said she **was** tired.", fa: "گفت خسته است." },
      { en: "\"Will you join?\" → He asked whether I **would** join.", fa: "پرسید آیا ملحق می‌شوم." },
    ],
    mistakes: [
      { wrong: "He asked me where do I live.", right: "He asked me where I lived.", why: "Reported questions use statement order and no auxiliary 'do'." },
      { wrong: "She said me that she is busy.", right: "She told me that she was busy.", why: "'Say' has no indirect object; use 'tell someone'." },
    ],
    persianHint: "نقل قول غیرمستقیم: فعل یک زمان به عقب می‌رود و قیدهای زمان تغییر می‌کنند.",
    quickCard: ["say (that) / tell someone (that)", "Backshift one tense", "Questions → statement order", "Commands → told me to + V1"],
    questions: [
      { type: "fill", prompt: "\"I will call you.\" → He said he ___ call me.", answer: "would" },
      { type: "mcq", prompt: "\"Where are you going?\" → She asked me…", options: ["where was I going", "where I was going", "where am I going", "where I am going"], answer: "where I was going" },
      { type: "fill", prompt: "\"Don't touch it.\" → He told me ___ touch it.", answer: "not to" },
      { type: "fill", prompt: "\"I have finished.\" → She said she ___ finished.", answer: "had" },
      { type: "mcq", prompt: "Choose the correct reporting verb: 'He ___ me that the build failed.'", options: ["said", "told", "spoke", "asked"], answer: "told" },
    ],
    difficulty: 3, minutes: 18, orderIndex: 10,
  },
];
