export type SeedArticle = {
  slug: string;
  module: "general" | "tech" | "toefl";
  title: string;
  topic: string;
  level: number;
  minutes: number;
  paragraphs: string[];
  glossary: { term: string; en: string; fa: string }[];
  questions: { qType: string; prompt: string; options: string[]; answer: string; explain?: string }[];
};

export const SEED_ARTICLES: SeedArticle[] = [
  {
    slug: "evolution-of-artificial-intelligence", module: "toefl", title: "The Evolution of Artificial Intelligence",
    topic: "Technology", level: 4, minutes: 12,
    paragraphs: [
      "Artificial intelligence has undergone remarkable changes since its inception in the 1950s. Early AI systems were rudimentary compared with today's models: they relied on hand-written rules, and every piece of knowledge had to be encoded explicitly by a human expert. These systems performed impressively in narrow domains such as chess openings or medical diagnosis checklists, yet they collapsed the moment they met a situation their designers had not anticipated.",
      "The paradigm shift came with machine learning, which reversed the direction of knowledge transfer. Instead of programmers telling machines what to conclude, engineers began supplying large collections of labelled examples and letting statistical algorithms infer the rules themselves. This approach proved far more resilient, because a model trained on thousands of photographs of handwriting does not need an explicit definition of the letter 'a'; it discovers the regularities on its own.",
      "Progress nevertheless remained constrained by two practical bottlenecks: data and computation. Both obstacles eased dramatically in the 2010s. The spread of the internet produced an abundant supply of text and images, while graphics processing units, originally designed for video games, turned out to be ideally suited to the matrix arithmetic at the heart of neural networks. Deep learning, a technique proposed decades earlier, suddenly became practical.",
      "Critics argue that contemporary systems, however fluent, do not understand language in any meaningful sense; they predict plausible continuations of text. Supporters counter that the distinction may matter less than the results. What is not in dispute is that the technology has become ubiquitous: it recommends films, filters spam, translates documents and increasingly writes software. The central question for the coming decade is therefore not whether artificial intelligence will spread further, but how societies will mitigate its risks while distributing its benefits.",
    ],
    glossary: [
      { term: "remarkable", en: "unusual or surprising in a good way", fa: "قابل توجه، چشمگیر" },
      { term: "inception", en: "the beginning of something", fa: "آغاز، شروع" },
      { term: "rudimentary", en: "basic, not developed", fa: "ابتدایی" },
      { term: "paradigm", en: "a model or typical pattern", fa: "الگو، پارادایم" },
      { term: "constrained", en: "limited or restricted", fa: "محدودشده" },
      { term: "abundant", en: "more than enough", fa: "فراوان" },
      { term: "ubiquitous", en: "existing everywhere", fa: "فراگیر" },
      { term: "mitigate", en: "to make less harmful", fa: "کاهش دادن" },
    ],
    questions: [
      { qType: "Main Idea", prompt: "What is the main idea of paragraph 2?", options: ["AI was invented in the 1950s", "Machine learning changed AI fundamentally", "Early computers were slow", "Programming languages evolved"], answer: "Machine learning changed AI fundamentally", explain: "The paragraph contrasts rule-writing with learning from examples." },
      { qType: "Factual Information", prompt: "According to paragraph 3, GPUs were useful for AI because they", options: ["were cheap to manufacture", "suited the matrix arithmetic of neural networks", "were designed for scientific computing", "stored large amounts of data"], answer: "suited the matrix arithmetic of neural networks" },
      { qType: "Vocabulary in Context", prompt: "The word 'constrained' in paragraph 3 is closest in meaning to", options: ["limited", "encouraged", "measured", "replaced"], answer: "limited" },
      { qType: "Negative Factual", prompt: "All of the following are mentioned as applications of AI EXCEPT", options: ["recommending films", "filtering spam", "diagnosing rare genetic disease", "translating documents"], answer: "diagnosing rare genetic disease" },
      { qType: "Inference", prompt: "What can be inferred about early rule-based systems?", options: ["They were never commercially used", "They generalised poorly to unexpected situations", "They required no human expertise", "They ran only on GPUs"], answer: "They generalised poorly to unexpected situations", explain: "'They collapsed the moment they met a situation their designers had not anticipated.'" },
    ],
  },
  {
    slug: "why-coral-reefs-matter", module: "toefl", title: "Why Coral Reefs Matter",
    topic: "Environment", level: 4, minutes: 10,
    paragraphs: [
      "Coral reefs occupy less than one per cent of the ocean floor, yet they shelter roughly a quarter of all marine species. This disproportionate importance stems from their structure: the calcium carbonate skeletons secreted by coral polyps create a three-dimensional labyrinth of caves, ledges and crevices in which fish can hide, feed and reproduce.",
      "The reef's productivity depends on an unusual partnership. Microscopic algae called zooxanthellae live inside coral tissue, converting sunlight into sugars that supply up to ninety per cent of the coral's energy. In return the coral supplies shelter and nutrients. When water temperatures rise even a degree or two above the normal maximum, this partnership breaks down; the coral expels its algae and turns white, a process known as bleaching.",
      "Bleached coral is not necessarily dead, and reefs can recover if conditions improve within a few weeks. Repeated bleaching events, however, deplete the coral's reserves and leave it vulnerable to disease. Ocean acidification compounds the problem: as seawater absorbs carbon dioxide, its chemistry shifts, making it harder for polyps to build skeletons in the first place.",
      "Conservation strategies therefore operate on two timescales. Locally, marine protected areas limit overfishing and pollution, allowing reefs to remain resilient. Globally, only a substantial reduction in greenhouse gas emissions can mitigate warming and acidification. Researchers are also experimenting with heat-tolerant coral strains, though critics warn that such interventions treat the symptom rather than the cause.",
    ],
    glossary: [
      { term: "disproportionate", en: "too large in comparison with something else", fa: "نامتناسب، بیش از حد انتظار" },
      { term: "secrete", en: "to produce and release a substance", fa: "ترشح کردن" },
      { term: "deplete", en: "to reduce greatly in amount", fa: "تهی کردن، کاهش دادن" },
      { term: "compound", en: "to make a problem worse", fa: "تشدید کردن" },
      { term: "resilient", en: "able to recover quickly", fa: "تاب‌آور" },
    ],
    questions: [
      { qType: "Factual Information", prompt: "What percentage of the coral's energy comes from zooxanthellae?", options: ["about 25%", "about 50%", "up to 90%", "less than 1%"], answer: "up to 90%" },
      { qType: "Rhetorical Purpose", prompt: "Why does the author mention marine protected areas?", options: ["To illustrate a local conservation strategy", "To criticise governments", "To explain how coral reproduces", "To describe tourism"], answer: "To illustrate a local conservation strategy" },
      { qType: "Vocabulary in Context", prompt: "'Compounds' in paragraph 3 most nearly means", options: ["solves", "worsens", "measures", "delays"], answer: "worsens" },
      { qType: "Inference", prompt: "It can be inferred that a single bleaching event", options: ["always kills the reef", "may be survivable if conditions improve", "increases algae population", "raises water temperature"], answer: "may be survivable if conditions improve" },
      { qType: "Prose Summary", prompt: "Which sentence best summarises the passage?", options: ["Coral reefs are biologically vital but threatened by warming and acidification, requiring both local and global action.", "Coral polyps secrete calcium carbonate skeletons.", "Zooxanthellae are microscopic algae.", "Tourism damages coral reefs more than fishing."], answer: "Coral reefs are biologically vital but threatened by warming and acidification, requiring both local and global action." },
    ],
  },
  {
    slug: "how-to-read-api-documentation", module: "tech", title: "How to Read API Documentation Efficiently",
    topic: "Documentation", level: 3, minutes: 8,
    paragraphs: [
      "Good API documentation follows a predictable shape, and recognising that shape saves hours. Start with the overview: it states what the service does and which authentication scheme it expects. Skim it, then jump straight to the 'Quickstart' or 'Getting started' section, which almost always contains a copy-pasteable request you can run immediately.",
      "Next comes the endpoint reference. Each entry usually lists the HTTP method, the path, path and query parameters, the request body schema, and the response schema with status codes. Pay close attention to which parameters are marked required and to the data types: a field described as 'ISO-8601 timestamp' will reject a Unix epoch integer.",
      "Error handling sections are frequently skipped by learners, yet they are the most valuable part when something breaks. Note whether the API returns a machine-readable error code alongside the human message, and whether the endpoint is idempotent — that is, whether retrying the same request is safe.",
      "Finally, check the rate limits and the versioning policy. A deprecated endpoint may still work today but disappear next quarter, and documentation usually flags this with a warning banner. When you meet an unknown term, do not stop reading: note it, finish the section, and look it up afterwards. Context often makes the meaning clear by itself.",
    ],
    glossary: [
      { term: "authentication", en: "the process of proving who you are", fa: "احراز هویت" },
      { term: "endpoint", en: "a specific URL that an API exposes", fa: "نقطه پایانی API" },
      { term: "schema", en: "the defined structure of data", fa: "ساختار داده" },
      { term: "idempotent", en: "safe to repeat with the same result", fa: "خودتوان، تکرارپذیر بی‌خطر" },
      { term: "deprecated", en: "outdated and scheduled for removal", fa: "منسوخ‌شده" },
      { term: "rate limit", en: "a cap on how many requests you may send", fa: "محدودیت نرخ درخواست" },
    ],
    questions: [
      { qType: "Main Idea", prompt: "The passage mainly explains", options: ["how to design an API", "how to read API docs efficiently", "why REST is better than GraphQL", "how to write error messages"], answer: "how to read API docs efficiently" },
      { qType: "Factual Information", prompt: "According to the passage, which section should you read after the overview?", options: ["Error handling", "Quickstart", "Changelog", "Pricing"], answer: "Quickstart" },
      { qType: "Vocabulary in Context", prompt: "'Idempotent' means that a request", options: ["cannot be repeated", "gives the same result when repeated", "requires authentication", "is deprecated"], answer: "gives the same result when repeated" },
      { qType: "Inference", prompt: "The author's advice about unknown terms suggests that", options: ["you should memorise all terms first", "context usually clarifies meaning", "documentation is unreliable", "you should avoid English docs"], answer: "context usually clarifies meaning" },
      { qType: "Detail", prompt: "A field described as 'ISO-8601 timestamp' would reject", options: ["2024-05-01T10:00:00Z", "a Unix epoch integer", "a date string with timezone", "an RFC-3339 value"], answer: "a Unix epoch integer" },
    ],
  },
  {
    slug: "anatomy-of-a-code-review", module: "tech", title: "The Anatomy of a Good Code Review",
    topic: "Software Engineering", level: 3, minutes: 9,
    paragraphs: [
      "A pull request is a conversation, not a verdict. The most effective reviewers begin by reading the description to understand intent, then look at the tests before the implementation. Tests reveal what the author believes the change should guarantee, which makes gaps in the logic much easier to spot.",
      "Language matters more than most engineers expect. Compare 'You broke the cache' with 'This change seems to bypass the cache — was that intentional?'. The second version is hedged: it describes the code rather than the person and invites explanation. Hedging language such as 'seems', 'might', 'consider' and 'what do you think about' lowers defensiveness without weakening the technical point.",
      "Reviewers should distinguish between blocking comments and suggestions. Many teams use prefixes: 'nit:' for trivial style preferences, 'question:' for clarification, and 'blocking:' for issues that must be resolved before merging. This convention prevents an author from spending an afternoon on a comment that was never meant to hold up the release.",
      "Finally, praise specific decisions. A short note such as 'nice use of a guard clause here — much easier to follow' costs nothing and reinforces good practice. Reviews that contain only criticism gradually train authors to submit smaller, safer, less interesting changes.",
    ],
    glossary: [
      { term: "pull request", en: "a proposed code change submitted for review", fa: "درخواست ادغام کد" },
      { term: "hedging", en: "softening language to sound less absolute", fa: "زبان محتاطانه" },
      { term: "blocking", en: "preventing something from continuing", fa: "بازدارنده، مانع ادغام" },
      { term: "guard clause", en: "an early return that handles an edge case", fa: "شرط محافظ، بازگشت زودهنگام" },
      { term: "nit", en: "a very minor, non-essential comment", fa: "نکته جزئی" },
    ],
    questions: [
      { qType: "Main Idea", prompt: "The passage is mainly about", options: ["how to write tests", "how to review code effectively and politely", "why pull requests are slow", "git branching strategies"], answer: "how to review code effectively and politely" },
      { qType: "Detail", prompt: "Why do effective reviewers read tests first?", options: ["Tests are shorter", "Tests reveal the intended guarantees", "Tests never contain bugs", "Tests are required by CI"], answer: "Tests reveal the intended guarantees" },
      { qType: "Vocabulary in Context", prompt: "'Hedged' in paragraph 2 means", options: ["expressed with caution", "written in code", "highly critical", "removed"], answer: "expressed with caution" },
      { qType: "Rhetorical Purpose", prompt: "Why does the author mention prefixes like 'nit:' and 'blocking:'?", options: ["To show a convention that clarifies comment severity", "To criticise style guides", "To explain git syntax", "To describe CI pipelines"], answer: "To show a convention that clarifies comment severity" },
      { qType: "Inference", prompt: "The last paragraph implies that purely critical reviews", options: ["speed up delivery", "discourage ambitious changes", "improve test coverage", "reduce merge conflicts"], answer: "discourage ambitious changes" },
    ],
  },
  {
    slug: "the-science-of-sleep", module: "general", title: "The Science of Sleep and Memory",
    topic: "Psychology", level: 3, minutes: 7,
    paragraphs: [
      "For a long time sleep was considered a passive state, a simple pause in the day's activity. Modern neuroscience tells a different story. During the night the brain replays the electrical patterns produced while learning, strengthening the connections that matter and pruning those that do not.",
      "Two stages appear to be especially important. Slow-wave sleep, which dominates the first half of the night, supports the consolidation of facts and vocabulary. REM sleep, more common towards morning, seems to help with skills, emotional regulation and creative problem solving.",
      "The practical consequence for language learners is significant. Reviewing new vocabulary shortly before sleeping, and then again the following morning, produces noticeably better retention than a single long session. Cutting sleep to make room for extra study is therefore usually counterproductive: the material is encoded, but never properly filed.",
    ],
    glossary: [
      { term: "consolidation", en: "the process of making memories stable", fa: "تثبیت حافظه" },
      { term: "prune", en: "to cut away what is unnecessary", fa: "هرس کردن" },
      { term: "retention", en: "the ability to keep something in memory", fa: "ماندگاری، حفظ" },
      { term: "counterproductive", en: "having the opposite of the desired effect", fa: "نتیجه‌معکوس" },
    ],
    questions: [
      { qType: "Main Idea", prompt: "The passage mainly argues that sleep", options: ["is a passive state", "actively strengthens memory", "is optional for students", "causes forgetting"], answer: "actively strengthens memory" },
      { qType: "Detail", prompt: "Which stage supports vocabulary consolidation?", options: ["REM sleep", "Slow-wave sleep", "Light napping", "Wakefulness"], answer: "Slow-wave sleep" },
      { qType: "Vocabulary in Context", prompt: "'Counterproductive' means", options: ["extremely useful", "producing the opposite result", "difficult to measure", "very fast"], answer: "producing the opposite result" },
      { qType: "Inference", prompt: "A learner following this advice would probably", options: ["study all night before a test", "review vocabulary before bed and after waking", "avoid reviewing at night", "sleep less during exam week"], answer: "review vocabulary before bed and after waking" },
      { qType: "Detail", prompt: "REM sleep is said to help with all EXCEPT", options: ["skills", "emotional regulation", "creative problem solving", "muscle growth"], answer: "muscle growth" },
    ],
  },
  {
    slug: "a-short-history-of-coffee", module: "general", title: "A Short History of Coffee",
    topic: "History", level: 2, minutes: 5,
    paragraphs: [
      "Coffee probably began in Ethiopia, where the plant still grows wild. Traders carried the beans across the Red Sea to Yemen, and by the fifteenth century coffee was being cultivated there on a large scale.",
      "The drink spread quickly through the Ottoman Empire, and coffee houses became centres of conversation, news and business. In Europe they were sometimes called 'penny universities', because for the price of a cup you could listen to lawyers, merchants and scientists arguing.",
      "Today coffee is the second most traded commodity in the world by value. For millions of workers, however, the price paid for raw beans remains low, which is why fair-trade schemes have attracted attention.",
    ],
    glossary: [
      { term: "cultivate", en: "to grow plants for food or profit", fa: "کشت کردن" },
      { term: "commodity", en: "a raw material that is bought and sold", fa: "کالای اساسی" },
      { term: "merchant", en: "a person who buys and sells goods", fa: "بازرگان" },
    ],
    questions: [
      { qType: "Detail", prompt: "Where did coffee probably originate?", options: ["Yemen", "Ethiopia", "Turkey", "Brazil"], answer: "Ethiopia" },
      { qType: "Vocabulary in Context", prompt: "'Cultivated' means", options: ["exported", "grown", "banned", "roasted"], answer: "grown" },
      { qType: "Detail", prompt: "Why were European coffee houses called 'penny universities'?", options: ["They charged a penny for lectures", "You could hear educated discussion cheaply", "They were owned by universities", "Students worked there"], answer: "You could hear educated discussion cheaply" },
      { qType: "Main Idea", prompt: "The passage is mainly a", options: ["scientific analysis", "brief historical overview", "business proposal", "personal story"], answer: "brief historical overview" },
    ],
  },
  {
    slug: "urban-heat-islands", module: "toefl", title: "Urban Heat Islands",
    topic: "Environment", level: 5, minutes: 11,
    paragraphs: [
      "Cities are consistently warmer than the countryside surrounding them, a phenomenon known as the urban heat island effect. The temperature difference, typically between one and three degrees Celsius but occasionally as much as twelve at night, arises from a combination of surface properties, geometry and human activity.",
      "Dark asphalt and roofing materials absorb far more solar radiation than vegetation, and because they are impermeable, little water is available to evaporate and cool the surface. The vertical geometry of streets compounds this: tall buildings trap radiation in a series of reflections, a configuration researchers call an urban canyon.",
      "The consequences are not evenly distributed. Neighbourhoods with the least tree cover are frequently those with the lowest incomes, and their residents are more likely to lack air conditioning. During heatwaves, mortality in such districts can be several times higher than in leafier areas of the same city.",
      "Mitigation is comparatively straightforward in engineering terms. Reflective 'cool roofs' can lower surface temperatures substantially, street trees provide shade and evaporative cooling, and permeable pavements allow moisture to return to the air. The obstacle is rarely technical; it is the cost of retrofitting a city that was never designed with thermal comfort in mind.",
    ],
    glossary: [
      { term: "impermeable", en: "not allowing liquid to pass through", fa: "نفوذناپذیر" },
      { term: "evaporate", en: "to change from liquid into gas", fa: "تبخیر شدن" },
      { term: "mortality", en: "the number of deaths in a population", fa: "مرگ‌ومیر" },
      { term: "retrofit", en: "to add new features to an existing structure", fa: "مقاوم‌سازی/به‌روزرسانی ساختار موجود" },
      { term: "mitigation", en: "action to reduce severity", fa: "کاهش اثر" },
    ],
    questions: [
      { qType: "Factual Information", prompt: "The urban heat island effect is typically how large?", options: ["1–3 °C", "5–8 °C", "always 12 °C", "less than 0.5 °C"], answer: "1–3 °C" },
      { qType: "Rhetorical Purpose", prompt: "The author mentions 'urban canyon' in order to", options: ["describe how street geometry traps heat", "criticise architects", "define a geological term", "explain wind patterns"], answer: "describe how street geometry traps heat" },
      { qType: "Inference", prompt: "Paragraph 3 suggests that heat risk is", options: ["equally shared across a city", "linked to income and tree cover", "highest in rural areas", "unrelated to air conditioning"], answer: "linked to income and tree cover" },
      { qType: "Negative Factual", prompt: "All of the following are mitigation measures EXCEPT", options: ["cool roofs", "street trees", "permeable pavements", "darker asphalt"], answer: "darker asphalt" },
      { qType: "Sentence Simplification", prompt: "Which best simplifies the last sentence?", options: ["Cities cannot be cooled.", "The main barrier is cost, not technology.", "Engineers disagree about solutions.", "Thermal comfort is unimportant."], answer: "The main barrier is cost, not technology." },
    ],
  },
  {
    slug: "reading-error-messages", module: "tech", title: "Reading Error Messages Like a Senior Engineer",
    topic: "Debugging", level: 2, minutes: 6,
    paragraphs: [
      "Beginners often panic at a wall of red text; experienced engineers read it backwards. The last line usually names the exception type and a short message, and the lines above it form the stack trace — the chain of calls that led to the failure, most recent first.",
      "Three phrases carry most of the meaning. 'Undefined' or 'null' indicates that something you expected to exist was never created. 'Timeout' points to a dependency that did not respond in time. 'Permission denied' is almost always about credentials or file ownership rather than your logic.",
      "Once you have located the first line of the trace that belongs to your own code rather than to a library, you have found the place to start. Reproduce the failure with the smallest possible input, add one log statement, and read the message again. Most bugs are solved by reading, not by guessing.",
    ],
    glossary: [
      { term: "stack trace", en: "the list of function calls leading to an error", fa: "ردیابی پشته فراخوانی‌ها" },
      { term: "exception", en: "an error event that interrupts normal flow", fa: "استثنا، خطا" },
      { term: "dependency", en: "an external service or library you rely on", fa: "وابستگی" },
      { term: "reproduce", en: "to make a bug happen again deliberately", fa: "بازتولید کردن خطا" },
    ],
    questions: [
      { qType: "Detail", prompt: "Which line usually contains the exception type?", options: ["The first line", "The last line", "A random line", "The log file header"], answer: "The last line" },
      { qType: "Detail", prompt: "'Permission denied' usually relates to", options: ["your algorithm", "credentials or ownership", "network latency", "syntax errors"], answer: "credentials or ownership" },
      { qType: "Main Idea", prompt: "The author's main advice is to", options: ["guess quickly", "read carefully and reproduce minimally", "restart the computer", "rewrite the module"], answer: "read carefully and reproduce minimally" },
      { qType: "Vocabulary in Context", prompt: "'Reproduce' here means", options: ["print again", "make the bug occur again", "copy the code", "publish"], answer: "make the bug occur again" },
    ],
  },
];
