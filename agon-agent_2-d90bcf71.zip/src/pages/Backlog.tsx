import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Archive, CalendarClock, ClipboardList, Filter, MoveRight, Plus, Search, Trash2 } from 'lucide-react';
import type { BacklogItem, Priority } from '../lib/types';
import { PRIORITY_META, catById, uid, useApp } from '../lib/store';
import { addDays, faNum, formatShamsiShort, isOverdue, todayKey } from '../lib/dates';
import { Card, CardHead, Field, Modal, inputCls } from '../lib/ui';
import TaskRow from '../components/TaskRow';

const ORDER: Record<Priority, number> = { urgent: 0, high: 1, medium: 2, low: 3 };

export default function Backlog({ goDaily, notify }: { goDaily: (k: string) => void; notify: (m: string) => void }) {
  const { data, setData } = useApp();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [fp, setFp] = useState<Priority | 'all'>('all');
  const [fc, setFc] = useState('all');
  const [sort, setSort] = useState<'new' | 'priority' | 'deadline'>('priority');
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [p, setP] = useState<Priority>('medium');
  const [c, setC] = useState(data.categories[0]?.id ?? '');
  const [dl, setDl] = useState('');
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const items = useMemo(() => {
    let list = [...data.backlog];
    if (q.trim()) list = list.filter((b) => (b.title + ' ' + b.desc).includes(q.trim()));
    if (fp !== 'all') list = list.filter((b) => b.priority === fp);
    if (fc !== 'all') list = list.filter((b) => b.categoryId === fc);
    list.sort((a, b) => {
      if (sort === 'priority') return ORDER[a.priority] - ORDER[b.priority] || b.createdAt.localeCompare(a.createdAt);
      if (sort === 'deadline') return (a.deadline || '9999').localeCompare(b.deadline || '9999');
      return b.createdAt.localeCompare(a.createdAt);
    });
    return list;
  }, [data.backlog, q, fp, fc, sort]);

  const save = () => {
    if (!title.trim()) return;
    const b: BacklogItem = { id: uid(), title: title.trim(), desc: desc.trim(), priority: p, categoryId: c || data.categories[0]?.id || '', createdAt: todayKey(), deadline: dl };
    setData((d) => ({ ...d, backlog: [b, ...d.backlog] }));
    setTitle(''); setDesc(''); setDl(''); setOpen(false);
    notify('به بک‌لاگ اضافه شد 📥');
  };

  const sendToToday = (b: BacklogItem) => {
    const tk = todayKey();
    setData((d) => ({
      ...d,
      backlog: d.backlog.filter((x) => x.id !== b.id),
      days: {
        ...d.days,
        [tk]: {
          ...(d.days[tk] ?? { dateKey: tk, wakeTime: '', sleepTime: '', mood: null as number | null, sport: 'none', wentOut: null as boolean | null, dayScore: null as number | null, note: '', tasks: [], tomorrowNote: '', habits: {}, positives: ['', '', ''], lesson: '' }),
          tasks: [...((d.days[tk]?.tasks) ?? []), { id: uid(), title: b.title, done: false, priority: b.priority, categoryId: b.categoryId, plannedStart: '', plannedEnd: '', actualMinutes: null, note: b.desc, createdAt: new Date().toISOString() }],
        },
      },
    }));
    notify('به تسک‌های امروز منتقل شد ✅');
    goDaily(tk);
  };

  const sendToTomorrow = (b: BacklogItem) => {
    const tk = addDays(todayKey(), 1);
    setData((d) => ({
      ...d,
      backlog: d.backlog.filter((x) => x.id !== b.id),
      days: {
        ...d.days,
        [tk]: {
          ...(d.days[tk] ?? { dateKey: tk, wakeTime: '', sleepTime: '', mood: null as number | null, sport: 'none', wentOut: null as boolean | null, dayScore: null as number | null, note: '', tasks: [], tomorrowNote: '', habits: {}, positives: ['', '', ''], lesson: '' }),
          tasks: [...((d.days[tk]?.tasks) ?? []), { id: uid(), title: b.title, done: false, priority: b.priority, categoryId: b.categoryId, plannedStart: '', plannedEnd: '', actualMinutes: null, note: b.desc, createdAt: new Date().toISOString() }],
        },
      },
    }));
    notify('به برنامه فردا منتقل شد 📝');
  };

  return (
    <div className="space-y-4">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card>
          <CardHead icon={<Archive size={18} />} title="بک‌لاگ" sub={`${faNum(data.backlog.length)} آیتم در صف`} action={
            <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-emerald-500 to-teal-600 px-3.5 py-2 text-xs font-extrabold text-white shadow transition hover:opacity-90 active:scale-95"><Plus size={15} /> آیتم جدید</button>
          } />
          <div className="flex flex-col gap-2 p-4 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جست‌وجو در بک‌لاگ…" className={`${inputCls} pr-9`} />
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <Filter size={15} className="text-zinc-400" />
              <select value={fp} onChange={(e) => setFp(e.target.value as Priority | 'all')} className="rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs font-bold dark:border-white/10 dark:bg-zinc-950">
                <option value="all">همه اولویت‌ها</option>
                {(Object.keys(PRIORITY_META) as Priority[]).map((k) => <option key={k} value={k}>{PRIORITY_META[k].label}</option>)}
              </select>
              <select value={fc} onChange={(e) => setFc(e.target.value)} className="rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs font-bold dark:border-white/10 dark:bg-zinc-950">
                <option value="all">همه دسته‌ها</option>
                {data.categories.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
              </select>
              <select value={sort} onChange={(e) => setSort(e.target.value as 'new' | 'priority' | 'deadline')} className="rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs font-bold dark:border-white/10 dark:bg-zinc-950">
                <option value="priority">مرتب: اولویت</option>
                <option value="deadline">مرتب: ددلاین</option>
                <option value="new">مرتب: جدیدترین</option>
              </select>
            </div>
          </div>
        </Card>
      </motion.div>

      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-black/15 py-14 text-center dark:border-white/15">
          <p className="text-4xl">📦</p>
          <p className="mt-3 text-sm font-extrabold">بک‌لاگ خالیه — ذهنت را خالی کن!</p>
          <p className="mx-auto mt-1 max-w-sm text-xs leading-6 text-zinc-500">هر ایده، کار آینده یا چیزی که نمی‌خوای یادت بره را اینجا بنداز؛ بعداً با یک کلیک به امروز یا فردا منتقلش کن.</p>
          <button onClick={() => setOpen(true)} className="mt-4 rounded-xl bg-zinc-900 px-5 py-2.5 text-xs font-extrabold text-white active:scale-95 dark:bg-white dark:text-zinc-900">اولین آیتم را بساز</button>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {items.map((b, i) => {
            const cat = catById(data, b.categoryId);
            const pm = PRIORITY_META[b.priority];
            const over = isOverdue(b.deadline);
            return (
              <motion.div key={b.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.04, 0.3) }} className="rounded-2xl border border-black/[0.06] bg-white p-4 shadow-sm transition hover:shadow-md dark:border-white/[0.08] dark:bg-zinc-900">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="flex-1 text-sm font-extrabold leading-6">{b.title}</h3>
                  {confirmId === b.id ? (
                    <span className="flex shrink-0 items-center gap-1 rounded-lg bg-rose-500/10 p-1 text-[11px] font-bold text-rose-600">
                      حذف؟
                      <button onClick={() => { setData((d) => ({ ...d, backlog: d.backlog.filter((x) => x.id !== b.id) })); setConfirmId(null); notify('از بک‌لاگ حذف شد'); }} className="rounded-md bg-rose-500 px-2 py-0.5 text-white">بله</button>
                      <button onClick={() => setConfirmId(null)} className="rounded-md px-1.5 py-0.5 hover:bg-rose-500/10">خیر</button>
                    </span>
                  ) : (
                    <button onClick={() => setConfirmId(b.id)} title="حذف با تأیید" className="grid size-7 shrink-0 place-items-center rounded-lg text-zinc-300 hover:bg-rose-500/10 hover:text-rose-500"><Trash2 size={15} /></button>
                  )}
                </div>
                {b.desc && <p className="mt-1.5 text-xs leading-6 text-zinc-500 dark:text-zinc-400">{b.desc}</p>}
                <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                  <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-bold ${pm.bg} ${pm.color}`}><span className={`size-1.5 rounded-full ${pm.dot}`} />{pm.label}</span>
                  {cat && <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2 py-0.5 text-[10.5px] font-bold text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300"><span className="size-1.5 rounded-full" style={{ background: cat.color }} />{cat.name}</span>}
                  <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2 py-0.5 text-[10.5px] font-bold text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400"><ClipboardList size={11} /> ثبت: {formatShamsiShort(b.createdAt)}</span>
                  {b.deadline ? (
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-bold ${over ? 'bg-rose-500/10 text-rose-600' : 'bg-amber-500/10 text-amber-600'}`}><CalendarClock size={11} /> ددلاین: {formatShamsiShort(b.deadline)}{over ? ' (گذشته!)' : ''}</span>
                  ) : <span className="text-[10.5px] text-zinc-400">بدون ددلاین</span>}
                </div>
                <div className="mt-3 flex gap-2 border-t border-black/[0.06] pt-3 dark:border-white/[0.07]">
                  <button onClick={() => sendToToday(b)} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-500/10 py-2 text-xs font-extrabold text-emerald-700 transition hover:bg-emerald-500 hover:text-white active:scale-95 dark:text-emerald-300"><MoveRight size={14} /> به امروز</button>
                  <button onClick={() => sendToTomorrow(b)} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-sky-500/10 py-2 text-xs font-extrabold text-sky-700 transition hover:bg-sky-500 hover:text-white active:scale-95 dark:text-sky-300"><MoveRight size={14} /> به فردا</button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="آیتم جدید بک‌لاگ">
        <div className="space-y-3">
          <Field label="عنوان *">
            <input value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') save(); }} placeholder="مثلاً: یادگیری طراحی سایت" className={inputCls} />
          </Field>
          <Field label="توضیحات">
            <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={2} placeholder="جزئیات، قدم بعدی…" className={inputCls} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="اولویت">
              <select value={p} onChange={(e) => setP(e.target.value as Priority)} className={inputCls}>
                {(Object.keys(PRIORITY_META) as Priority[]).map((k) => <option key={k} value={k}>{PRIORITY_META[k].label}</option>)}
              </select>
            </Field>
            <Field label="دسته‌بندی">
              <select value={c} onChange={(e) => setC(e.target.value)} className={inputCls}>
                {data.categories.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
              </select>
            </Field>
          </div>
          <Field label="ددلاین (اختیاری)">
            <input type="date" value={dl} onChange={(e) => setDl(e.target.value)} className={inputCls} dir="ltr" />
          </Field>
          <button onClick={save} disabled={!title.trim()} className="w-full rounded-xl bg-gradient-to-l from-emerald-500 to-teal-600 py-2.5 text-sm font-extrabold text-white shadow transition hover:opacity-90 active:scale-[0.98] disabled:opacity-40">ثبت در بک‌لاگ (Enter)</button>
        </div>
      </Modal>

      {/* راهنمای کوچک TaskRow برای نمایش ساختار تسک کامل */}
      <div className="hidden"><TaskRow task={{ id: 'x', title: '', done: false, priority: 'low', categoryId: '', plannedStart: '', plannedEnd: '', actualMinutes: null, note: '', createdAt: '' }} categories={[]} onPatch={() => {}} onDelete={() => {}} /></div>
    </div>
  );
}
