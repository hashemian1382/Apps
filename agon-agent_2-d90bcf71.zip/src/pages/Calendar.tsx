import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { CalendarDays, ChevronLeft, ChevronRight, LayoutGrid, Map as MapIcon } from 'lucide-react';
import { useApp } from '../lib/store';
import { J_MONTHS, WEEKDAYS_SAT, addDays, diffDays, faNum, formatShamsi, gMonthLen, jMonthLen, jToKey, keyFromDate, pad2, parseKey, toJ, todayKey } from '../lib/dates';
import { G_MONTHS_FA } from '../lib/dates';
import { Card, CardHead } from '../lib/ui';

type Mode = 'month' | 'year';

function satIndex(key: string): number {
  return (parseKey(key).getDay() + 1) % 7; // شنبه=۰
}

function intensity(key: string, days: Record<string, { tasks: { done: boolean }[]; dayScore: number | null }>): number {
  const d = days[key];
  if (!d) return 0;
  if (!d.tasks.length && d.dayScore == null) return 0;
  const rate = d.tasks.length ? d.tasks.filter((t) => t.done).length / d.tasks.length : 0;
  const score = d.dayScore != null ? d.dayScore / 10 : 0;
  const v = d.tasks.length ? rate * 0.7 + score * 0.3 : score;
  if (v <= 0) return d.tasks.length ? 1 : score > 0 ? 1 : 0;
  if (v < 0.25) return 1;
  if (v < 0.5) return 2;
  if (v < 0.8) return 3;
  return 4;
}

const HEAT = ['bg-zinc-100 dark:bg-zinc-800', 'bg-emerald-200 dark:bg-emerald-900', 'bg-emerald-300 dark:bg-emerald-700', 'bg-emerald-500 dark:bg-emerald-500', 'bg-emerald-700 dark:bg-emerald-300'];

export default function CalendarView({ goDaily }: { goDaily: (k: string) => void }) {
  const { data } = useApp();
  const useShamsiDefault = data.settings.defaultCalendar === 'shamsi';
  const [cal, setCal] = useState<'shamsi' | 'miladi'>(useShamsiDefault ? 'shamsi' : 'miladi');
  const [mode, setMode] = useState<Mode>('month');
  const t = todayKey();
  const tj = toJ(t);
  const nowG = parseKey(t);
  const [jy, setJy] = useState(tj.jy);
  const [jm, setJm] = useState(tj.jm);
  const [gy, setGy] = useState(nowG.getFullYear());
  const [gm, setGm] = useState(nowG.getMonth() + 1);

  const cells = useMemo(() => {
    if (cal === 'shamsi') {
      const len = jMonthLen(jy, jm);
      const firstKey = jToKey(jy, jm, 1);
      const lead = satIndex(firstKey);
      const arr: (string | null)[] = Array(lead).fill(null);
      for (let d = 1; d <= len; d++) arr.push(jToKey(jy, jm, d));
      while (arr.length % 7) arr.push(null);
      return arr;
    }
    const len = gMonthLen(gy, gm);
    const firstKey = `${gy}-${pad2(gm)}-01`;
    const lead = satIndex(firstKey);
    const arr: (string | null)[] = Array(lead).fill(null);
    for (let d = 1; d <= len; d++) arr.push(`${gy}-${pad2(gm)}-${pad2(d)}`);
    while (arr.length % 7) arr.push(null);
    return arr;
  }, [cal, jy, jm, gy, gm]);

  const title = cal === 'shamsi' ? `${J_MONTHS[jm - 1]} ${faNum(jy)}` : `${G_MONTHS_FA[gm - 1]} ${faNum(gy)}`;

  const step = (n: number) => {
    if (cal === 'shamsi') {
      let y = jy, m = jm + n;
      while (m < 1) { m += 12; y--; }
      while (m > 12) { m -= 12; y++; }
      setJy(y); setJm(m);
    } else {
      let y = gy, m = gm + n;
      while (m < 1) { m += 12; y--; }
      while (m > 12) { m -= 12; y++; }
      setGy(y); setGm(m);
    }
  };

  const goToday = () => {
    if (cal === 'shamsi') { setJy(tj.jy); setJm(tj.jm); }
    else { setGy(nowG.getFullYear()); setGm(nowG.getMonth() + 1); }
    goDaily(t);
  };

  const monthStats = useMemo(() => {
    const keys = cells.filter((c): c is string => !!c);
    let done = 0, total = 0;
    const scores: number[] = [];
    for (const k of keys) {
      const d = data.days[k];
      if (!d) continue;
      total += d.tasks.length;
      done += d.tasks.filter((x) => x.done).length;
      if (d.dayScore != null) scores.push(d.dayScore);
    }
    return { done, total, rate: total ? Math.round((done / total) * 100) : 0, avg: scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : null, days: keys.filter((k) => data.days[k]).length };
  }, [cells, data.days]);

  // نقشه سال: ۱۸۲ روز اخیر (۲۶ هفته)
  const yearCells = useMemo(() => {
    const arr: string[] = [];
    const start = addDays(t, -181);
    for (let i = 0; i < 182; i++) arr.push(addDays(start, i));
    // مرتب‌سازی ستونی: هفته‌ها ستون‌اند — برای سادگی ردیفی نگه می‌داریم
    return arr;
  }, [t]);

  const weeks: string[][] = useMemo(() => {
    const w: string[][] = [];
    // هفته‌بندی از شنبه
    let cur: string[] = [];
    const firstLead = satIndex(yearCells[0]);
    for (let i = 0; i < firstLead; i++) cur.push('');
    for (const k of yearCells) {
      cur.push(k);
      if (cur.length === 7) { w.push(cur); cur = []; }
    }
    if (cur.length) { while (cur.length < 7) cur.push(''); w.push(cur); }
    return w;
  }, [yearCells]);

  return (
    <div className="space-y-4">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card>
          <CardHead icon={<CalendarDays size={18} />} title="تقویم" sub="نمای ماهانه + نقشه فعالیت سال" action={
            <div className="flex flex-wrap gap-1.5">
              <div className="flex rounded-xl bg-zinc-100 p-1 dark:bg-zinc-800">
                <button onClick={() => setMode('month')} className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${mode === 'month' ? 'bg-white shadow dark:bg-zinc-900 dark:text-white' : 'text-zinc-500'}`}><LayoutGrid size={13} /> ماهانه</button>
                <button onClick={() => setMode('year')} className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${mode === 'year' ? 'bg-white shadow dark:bg-zinc-900 dark:text-white' : 'text-zinc-500'}`}><MapIcon size={13} /> نقشه سال</button>
              </div>
              <div className="flex rounded-xl bg-zinc-100 p-1 dark:bg-zinc-800">
                <button onClick={() => setCal('shamsi')} className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${cal === 'shamsi' ? 'bg-white shadow dark:bg-zinc-900 dark:text-white' : 'text-zinc-500'}`}>شمسی</button>
                <button onClick={() => setCal('miladi')} className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${cal === 'miladi' ? 'bg-white shadow dark:bg-zinc-900 dark:text-white' : 'text-zinc-500'}`}>میلادی</button>
              </div>
            </div>
          } />

          {mode === 'month' ? (
            <div className="p-4 sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <button onClick={() => step(-1)} className="grid size-9 place-items-center rounded-xl border border-black/10 hover:border-emerald-500/40 hover:text-emerald-600 active:scale-95 dark:border-white/10"><ChevronRight size={18} /></button>
                <div className="text-center">
                  <h2 className="text-lg font-black">{title}</h2>
                  <p className="mt-0.5 text-[11px] text-zinc-500">
                    {faNum(monthStats.done)}/{faNum(monthStats.total)} تسک • {faNum(monthStats.rate)}٪ • {faNum(monthStats.days)} روز دارای داده
                    {monthStats.avg != null && <> • میانگین امتیاز {faNum(monthStats.avg.toFixed(1))}</>}
                  </p>
                </div>
                <button onClick={() => step(1)} className="grid size-9 place-items-center rounded-xl border border-black/10 hover:border-emerald-500/40 hover:text-emerald-600 active:scale-95 dark:border-white/10"><ChevronLeft size={18} /></button>
              </div>

              <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
                {WEEKDAYS_SAT.map((w) => (
                  <div key={w} className={`pb-1 text-center text-[11px] font-black ${w === 'جمعه' ? 'text-rose-500' : 'text-zinc-400'}`}>{w}</div>
                ))}
                {cells.map((k, i) => {
                  if (!k) return <div key={i} />;
                  const d = data.days[k];
                  const lvl = intensity(k, data.days as never);
                  const isT = k === t;
                  const j = toJ(k);
                  const num = cal === 'shamsi' ? j.jd : parseKey(k).getDate();
                  const tot = d?.tasks.length ?? 0;
                  const dn = d?.tasks.filter((x) => x.done).length ?? 0;
                  const hasScore = d?.dayScore != null;
                  return (
                    <button key={k} onClick={() => goDaily(k)} title={`${formatShamsi(k)} — ${faNum(dn)}/${faNum(tot)} تسک`}
                      className={`group relative flex min-h-14 flex-col items-center justify-center gap-0.5 rounded-xl border p-1 text-center transition active:scale-95 sm:min-h-16 ${isT ? 'border-emerald-500 ring-2 ring-emerald-500/25' : 'border-black/[0.06] hover:border-emerald-500/40 hover:shadow-sm dark:border-white/[0.07]'} ${HEAT[lvl]}`}>
                      <span className={`text-sm font-black tabular-nums ${lvl >= 3 ? 'text-white dark:text-zinc-900' : ''}`}>{faNum(num)}</span>
                      {tot > 0 && <span className={`text-[9px] font-bold tabular-nums ${lvl >= 3 ? 'text-white/90 dark:text-zinc-800' : 'text-zinc-500'}`}>{faNum(dn)}/{faNum(tot)}</span>}
                      <span className="flex items-center gap-0.5">
                        {hasScore && <span className="text-[8px]">⭐</span>}
                        {(d?.mood != null) && <span className="size-1.5 rounded-full bg-sky-500" />}
                        {dn > 0 && dn === tot && tot > 0 && <span className="size-1.5 rounded-full bg-white" />}
                      </span>
                      {isT && <span className="absolute -top-1.5 rounded-full bg-emerald-500 px-1.5 text-[8px] font-black text-white">امروز</span>}
                    </button>
                  );
                })}
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-black/[0.06] pt-3 text-[11px] text-zinc-500 dark:border-white/[0.07]">
                <span className="flex items-center gap-1.5" dir="ltr">
                  کمتر
                  {HEAT.map((h, i) => <span key={i} className={`size-3 rounded ${h} border border-black/10`} />)}
                  بیشتر
                </span>
                <button onClick={goToday} className="rounded-lg bg-zinc-900 px-3 py-1.5 text-[11px] font-extrabold text-white active:scale-95 dark:bg-white dark:text-zinc-900">رفتن به امروز</button>
              </div>
            </div>
          ) : (
            <div className="p-4 sm:p-5">
              <h2 className="text-sm font-black">نقشه فعالیت {faNum(182)} روز اخیر <span className="font-medium text-zinc-400">(به سبک Contribution Graph)</span></h2>
              <p className="mt-1 text-[11px] text-zinc-500">هر مربع یک روز است؛ پررنگی = نرخ تکمیل + امتیاز روز. کلیک کن تا وارد آن روز شوی.</p>
              <div className="mt-4 overflow-x-auto pb-2" dir="ltr">
                <div className="flex min-w-max gap-1.5">
                  {weeks.map((w, wi) => (
                    <div key={wi} className="flex flex-col gap-1.5">
                      {w.map((k, di) => k ? (
                        <button key={di} onClick={() => goDaily(k)} title={`${formatShamsi(k)}`}
                          className={`size-4 rounded-[5px] border border-black/[0.06] transition hover:scale-125 hover:ring-2 hover:ring-emerald-500/50 sm:size-[18px] dark:border-white/[0.06] ${HEAT[intensity(k, data.days as never)]} ${k === t ? '!border-emerald-600 ring-2 ring-emerald-500/40' : ''}`} />
                      ) : <span key={di} className="size-4 sm:size-[18px]" />)}
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between text-[11px] text-zinc-500">
                <span>{faNum(182)} روز گذشته ← امروز</span>
                <span className="flex items-center gap-1" dir="ltr">Less {HEAT.map((h, i) => <span key={i} className={`size-3 rounded-sm ${h}`} />)} More</span>
              </div>
              {/* آمار سال */}
              <YearStats keys={yearCells} />
            </div>
          )}
        </Card>
      </motion.div>

      <p className="text-center text-[11px] text-zinc-400">راهنما: ⭐ = امتیاز ثبت‌شده • 🔵 = حال ثبت‌شده • ⚪ = همه تسک‌ها انجام‌شده</p>
    </div>
  );
}

function YearStats({ keys }: { keys: string[] }) {
  const { data } = useApp();
  const s = useMemo(() => {
    let done = 0, total = 0, active = 0;
    for (const k of keys) {
      const d = data.days[k];
      if (!d) continue;
      if (d.tasks.length || d.dayScore != null) active++;
      total += d.tasks.length;
      done += d.tasks.filter((x) => x.done).length;
    }
    return { done, total, active, rate: total ? Math.round((done / total) * 100) : 0 };
  }, [keys, data.days]);
  return (
    <div className="mt-4 grid grid-cols-3 gap-2 text-center">
      <div className="rounded-xl bg-zinc-50 p-3 dark:bg-zinc-800/60"><p className="text-base font-black">{faNum(s.active)}</p><p className="text-[11px] text-zinc-500">روز فعال</p></div>
      <div className="rounded-xl bg-zinc-50 p-3 dark:bg-zinc-800/60"><p className="text-base font-black">{faNum(s.done)}</p><p className="text-[11px] text-zinc-500">تسک انجام‌شده</p></div>
      <div className="rounded-xl bg-zinc-50 p-3 dark:bg-zinc-800/60"><p className="text-base font-black">{faNum(s.rate)}٪</p><p className="text-[11px] text-zinc-500">نرخ تکمیل</p></div>
    </div>
  );
}

export { keyFromDate, diffDays };
