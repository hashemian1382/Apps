import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Award, BarChart3, CalendarRange, CheckCircle2, Flame, Star, Target, TrendingUp } from 'lucide-react';
import { useApp } from '../lib/store';
import { J_MONTHS, addDays, diffDays, faNum, formatMinutes, parseKey, toJ } from '../lib/dates';
import { Card, CardHead, Progress } from '../lib/ui';

interface DayStat {
  key: string;
  total: number;
  done: number;
  rate: number;
  score: number | null;
  minutes: number;
}

function statFor(key: string, days: Record<string, { tasks: { done: boolean; actualMinutes: number | null }[]; dayScore: number | null }>): DayStat {
  const d = days[key];
  if (!d) return { key, total: 0, done: 0, rate: 0, score: null, minutes: 0 };
  const total = d.tasks.length;
  const done = d.tasks.filter((t) => t.done).length;
  return {
    key,
    total,
    done,
    rate: total ? Math.round((done / total) * 100) : 0,
    score: d.dayScore,
    minutes: d.tasks.reduce((s, t) => s + (t.actualMinutes ?? 0), 0),
  };
}

export default function Reports() {
  const { data } = useApp();
  const [mode, setMode] = useState<'week' | 'month'>('week');

  const tk = (() => { const n = new Date(); return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`; })();

  const range = useMemo(() => {
    const n = mode === 'week' ? 7 : 30;
    const arr: string[] = [];
    for (let i = n - 1; i >= 0; i--) arr.push(addDays(tk, -i));
    return arr;
  }, [mode, tk]);

  const stats: DayStat[] = useMemo(() => range.map((k) => statFor(k, data.days as never)), [range, data.days]);

  const totals = useMemo(() => {
    const t = stats.reduce((s, x) => s + x.total, 0);
    const d = stats.reduce((s, x) => s + x.done, 0);
    const scores = stats.map((x) => x.score).filter((x): x is number => x != null);
    const avg = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : null;
    const mins = stats.reduce((s, x) => s + x.minutes, 0);
    const activeDays = stats.filter((x) => x.total > 0).length;
    return { t, d, rate: t ? Math.round((d / t) * 100) : 0, avg, mins, activeDays };
  }, [stats]);

  const streak = useMemo(() => {
    let s = 0;
    for (let i = range.length - 1; i >= 0; i--) {
      const st = stats[i];
      if (st.total > 0 && st.done > 0) s++;
      else if (i === range.length - 1 && st.total === 0) continue;
      else break;
    }
    return s;
  }, [range, stats]);

  const best = useMemo(() => {
    const withTasks = stats.filter((x) => x.total > 0);
    if (!withTasks.length) return null;
    return withTasks.reduce((a, b) => (b.rate > a.rate || (b.rate === a.rate && b.done > a.done) ? b : a));
  }, [stats]);

  const maxDone = Math.max(1, ...stats.map((x) => x.done));
  const maxScore = 10;

  const scoreTrend = useMemo(() => {
    const pts = stats.map((x) => x.score);
    return pts;
  }, [stats]);

  const shortLabel = (key: string) => {
    const j = toJ(key);
    const wd = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'][(parseKey(key).getDay() + 1) % 7];
    return { top: `${faNum(j.jd)} ${J_MONTHS[j.jm - 1]}`, bottom: wd };
  };

  return (
    <div className="space-y-4">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card>
          <CardHead icon={<BarChart3 size={18} />} title="گزارش‌ها و عملکرد" sub="تحلیل روند بهره‌وری تو" action={
            <div className="flex rounded-xl bg-zinc-100 p-1 dark:bg-zinc-800">
              {([['week', 'هفتگی (۷ روز)'], ['month', 'ماهانه (۳۰ روز)']] as const).map(([v, l]) => (
                <button key={v} onClick={() => setMode(v)} className={`rounded-lg px-3.5 py-1.5 text-xs font-extrabold transition ${mode === v ? 'bg-white text-zinc-900 shadow dark:bg-zinc-900 dark:text-white' : 'text-zinc-500'}`}>{l}</button>
              ))}
            </div>
          } />
          {/* KPI ها */}
          <div className="grid grid-cols-2 gap-3 p-4 sm:p-5 lg:grid-cols-4">
            <Kpi icon={<Target size={18} />} tone="from-emerald-500 to-teal-600" label="نرخ تکمیل" value={`${faNum(totals.rate)}٪`} sub={`${faNum(totals.d)} از ${faNum(totals.t)} تسک`} />
            <Kpi icon={<Star size={18} />} tone="from-amber-500 to-orange-500" label="میانگین امتیاز روز" value={totals.avg != null ? faNum(totals.avg.toFixed(1)) : '—'} sub={`از ${faNum(10)}`} />
            <Kpi icon={<Flame size={18} />} tone="from-rose-500 to-pink-600" label="رشته فعالیت" value={`${faNum(streak)} روز`} sub="روزهای متوالی با تسک انجام‌شده" />
            <Kpi icon={<CheckCircle2 size={18} />} tone="from-sky-500 to-indigo-600" label="زمان واقعی ثبت‌شده" value={formatMinutes(totals.mins)} sub={`${faNum(totals.activeDays)} روز فعال`} />
          </div>
        </Card>
      </motion.div>

      {/* نمودار میله‌ای تسک‌های تکمیل‌شده */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
        <Card>
          <CardHead icon={<TrendingUp size={18} />} title={`تسک‌های تکمیل‌شده — ${mode === 'week' ? '۷ روز اخیر' : '۳۰ روز اخیر'}`} sub="ارتفاع میله = تعداد انجام‌شده" />
          <div className="p-4 sm:p-5">
            <div className="flex h-44 items-end gap-1.5 sm:gap-2.5" dir="ltr">
              {stats.map((s, i) => {
                const h = s.done ? Math.max(8, (s.done / maxDone) * 100) : 4;
                const lbl = shortLabel(s.key);
                const isBest = best?.key === s.key;
                return (
                  <div key={s.key} className="group relative flex h-full flex-1 flex-col items-center justify-end gap-1.5" title={`${lbl.top} — ${faNum(s.done)} انجام‌شده از ${faNum(s.total)}`}>
                    {s.done > 0 && <span className="text-[10px] font-black tabular-nums text-emerald-600 dark:text-emerald-400">{faNum(s.done)}</span>}
                    <div className="flex w-full flex-1 items-end justify-center">
                      <div
                        className={`w-full max-w-9 origin-bottom rounded-t-lg transition-all group-hover:opacity-80 ${isBest ? 'bg-gradient-to-t from-amber-500 to-amber-300 shadow-lg shadow-amber-500/30' : s.done ? 'bg-gradient-to-t from-emerald-600 to-teal-400' : 'bg-zinc-200 dark:bg-zinc-800'}`}
                        style={{ height: `${h}%`, animation: `growBar 0.5s ${i * 0.03}s ease-out both` }}
                      />
                    </div>
                    <span className={`text-[9px] font-bold leading-tight sm:text-[10px] ${i % (mode === 'month' ? 3 : 1) === 0 || mode === 'week' ? '' : 'invisible'} ${isBest ? 'text-amber-600' : 'text-zinc-400'}`}>{lbl.top.split(' ')[0]}</span>
                    {/* تولتیپ */}
                    <div className="pointer-events-none absolute -top-2 z-10 hidden -translate-y-full whitespace-nowrap rounded-xl bg-zinc-900 px-3 py-2 text-center text-[11px] font-bold text-white shadow-xl group-hover:block dark:bg-white dark:text-zinc-900" dir="rtl">
                      {lbl.top} ({lbl.bottom})<br />✅ {faNum(s.done)} از {faNum(s.total)} • {faNum(s.rate)}٪
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-3 flex items-center justify-between border-t border-black/[0.06] pt-3 text-[11px] font-bold text-zinc-500 dark:border-white/[0.07]">
              <span>کمترین: {faNum(Math.min(...stats.map((x) => x.done)))}</span>
              {best && <span className="flex items-center gap-1 text-amber-600"><Award size={13} /> بهترین روز: {faNum(toJ(best.key).jd)} {J_MONTHS[toJ(best.key).jm - 1]}</span>}
              <span>بیشترین: {faNum(maxDone)}</span>
            </div>
          </div>
        </Card>
      </motion.div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* نرخ تکمیل روزانه */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <CardHead icon={<Target size={18} />} title="نرخ تکمیل روزانه" sub="درصد انجام تسک‌های هر روز" />
            <div className="space-y-2.5 p-4 sm:p-5">
              {(mode === 'week' ? stats : stats.slice(-14)).map((s) => {
                const lbl = shortLabel(s.key);
                return (
                  <div key={s.key}>
                    <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
                      <span className="text-zinc-600 dark:text-zinc-300">{lbl.bottom} {lbl.top}</span>
                      <span className="tabular-nums text-zinc-400">{s.total ? `${faNum(s.rate)}٪ (${faNum(s.done)}/${faNum(s.total)})` : 'بدون تسک'}</span>
                    </div>
                    <Progress value={s.rate} tone={s.rate >= 80 ? 'from-emerald-500 to-teal-500' : s.rate >= 50 ? 'from-amber-500 to-orange-500' : s.rate > 0 ? 'from-rose-400 to-pink-500' : 'from-zinc-300 to-zinc-300'} />
                  </div>
                );
              })}
              {mode === 'month' && <p className="pt-1 text-center text-[11px] text-zinc-400">۱۴ روز اخیر نمایش داده شده</p>}
            </div>
          </Card>
        </motion.div>

        {/* روند امتیاز روزانه */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <Card>
            <CardHead icon={<Star size={18} />} title="روند امتیاز روزانه" sub="امتیازی که هر شب به روزت دادی" />
            <div className="p-4 sm:p-5">
              <ScoreSpark stats={stats} maxScore={maxScore} />
              <div className="mt-4 space-y-2">
                {scoreTrend.filter((x) => x != null).length === 0 ? (
                  <p className="rounded-xl bg-zinc-50 py-4 text-center text-xs text-zinc-400 dark:bg-zinc-800/50">هنوز امتیازی ثبت نشده — هر شب از صفحه روز جاری به روزت از ۱۰ نمره بده ⭐</p>
                ) : (
                  <div className="grid grid-cols-2 gap-2 text-center">
                    <div className="rounded-xl bg-amber-500/[0.08] p-3">
                      <p className="text-lg font-black text-amber-600">{faNum(Math.max(...(scoreTrend.filter((x) => x != null) as number[])))}</p>
                      <p className="text-[11px] text-zinc-500">بهترین امتیاز</p>
                    </div>
                    <div className="rounded-xl bg-violet-500/[0.08] p-3">
                      <p className="text-lg font-black text-violet-600">{totals.avg != null ? faNum(totals.avg.toFixed(1)) : '—'}</p>
                      <p className="text-[11px] text-zinc-500">میانگین دوره</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* توزیع دسته‌ها */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <CategoryBreakdown keys={range} />
      </motion.div>

      <div className="flex items-center gap-2 rounded-2xl border border-black/[0.06] bg-white p-4 text-[12px] leading-6 text-zinc-500 dark:border-white/[0.08] dark:bg-zinc-900 dark:text-zinc-400">
        <CalendarRange size={18} className="shrink-0 text-emerald-500" />
        نکته: روزهای بدون تسک در محاسبه نرخ تکمیل لحاظ نمی‌شوند. برای تحلیل دقیق‌تر، هر روز حداقل یک تسک ثبت کن — حتی یک کار کوچک.
      </div>
    </div>
  );
}

function Kpi({ icon, tone, label, value, sub }: { icon: React.ReactNode; tone: string; label: string; value: string; sub: string }) {
  return (
    <div className="rounded-2xl border border-black/[0.06] bg-zinc-50/70 p-3.5 dark:border-white/[0.07] dark:bg-zinc-800/50">
      <span className={`grid size-9 place-items-center rounded-xl bg-gradient-to-br text-white ${tone}`}>{icon}</span>
      <p className="mt-2.5 text-lg font-black tabular-nums">{value}</p>
      <p className="text-[11px] font-extrabold text-zinc-600 dark:text-zinc-300">{label}</p>
      <p className="mt-0.5 text-[10.5px] text-zinc-400">{sub}</p>
    </div>
  );
}

function ScoreSpark({ stats, maxScore }: { stats: DayStat[]; maxScore: number }) {
  const W = 560, H = 150, P = 26;
  const pts = stats.map((s, i) => ({
    x: P + (i * (W - P * 2)) / Math.max(1, stats.length - 1),
    y: s.score == null ? null : H - P - (s.score / maxScore) * (H - P * 2),
    v: s.score,
    key: s.key,
  }));
  const valid = pts.filter((p) => p.y != null) as { x: number; y: number; v: number; key: string }[];
  const path = valid.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${(p.y as number).toFixed(1)}`).join(' ');
  const area = valid.length ? `${path} L${valid[valid.length - 1].x.toFixed(1)},${H - P} L${valid[0].x.toFixed(1)},${H - P} Z` : '';
  return (
    <div className="rounded-xl border border-black/[0.06] bg-gradient-to-b from-amber-500/[0.06] to-transparent p-2 dark:border-white/[0.07]" dir="ltr">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        <defs>
          <linearGradient id="sg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#f59e0b" stopOpacity="0.45" />
            <stop offset="1" stopColor="#f59e0b" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {[0, 5, 10].map((g) => {
          const y = H - P - (g / maxScore) * (H - P * 2);
          return (
            <g key={g}>
              <line x1={P} x2={W - P} y1={y} y2={y} stroke="currentColor" strokeOpacity="0.1" strokeDasharray="4 4" />
              <text x={6} y={y + 3} fontSize="9" fill="currentColor" opacity="0.4">{g}</text>
            </g>
          );
        })}
        {area && <path d={area} fill="url(#sg)" />}
        {path && <path d={path} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
        {valid.map((p) => (
          <g key={p.key}>
            <circle cx={p.x} cy={p.y} r="4.5" fill="#f59e0b" stroke="white" strokeWidth="2" />
            <text x={p.x} y={(p.y as number) - 9} fontSize="10" fontWeight="800" textAnchor="middle" fill="currentColor" opacity="0.7">{p.v}</text>
          </g>
        ))}
      </svg>
      <div className="flex justify-between px-4 text-[9px] font-bold text-zinc-400" dir="rtl">
        <span>{stats.length ? `${faNum(toJ(stats[0].key).jd)} ${J_MONTHS[toJ(stats[0].key).jm - 1]}` : ''}</span>
        <span>{stats.length ? `${faNum(toJ(stats[stats.length - 1].key).jd)} ${J_MONTHS[toJ(stats[stats.length - 1].key).jm - 1]}` : ''}</span>
      </div>
    </div>
  );
}

function CategoryBreakdown({ keys }: { keys: string[] }) {
  const { data } = useApp();
  const rows = useMemo(() => {
    const map = new Map<string, { done: number; total: number }>();
    for (const k of keys) {
      const d = data.days[k];
      if (!d) continue;
      for (const t of d.tasks) {
        const e = map.get(t.categoryId) ?? { done: 0, total: 0 };
        e.total++;
        if (t.done) e.done++;
        map.set(t.categoryId, e);
      }
    }
    return [...map.entries()]
      .map(([id, v]) => ({ id, ...v }))
      .sort((a, b) => b.total - a.total);
  }, [keys, data.days]);
  const max = Math.max(1, ...rows.map((r) => r.total));
  if (!rows.length) return null;
  return (
    <Card>
      <CardHead icon={<CalendarRange size={18} />} title="عملکرد بر اساس دسته‌بندی" sub="کدام حوزه فعال‌تر بوده؟" />
      <div className="grid gap-2.5 p-4 sm:grid-cols-2 sm:p-5">
        {rows.map((r) => {
          const c = data.categories.find((x) => x.id === r.id);
          const name = c?.name ?? 'بدون دسته';
          const color = c?.color ?? '#94a3b8';
          return (
            <div key={r.id} className="rounded-xl border border-black/[0.06] p-3 dark:border-white/[0.07]">
              <div className="mb-1.5 flex items-center justify-between text-xs font-extrabold">
                <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full" style={{ background: color }} />{name}</span>
                <span className="tabular-nums text-zinc-500">{faNum(r.done)}/{faNum(r.total)}</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800" dir="ltr">
                <div className="h-full rounded-full transition-all" style={{ width: `${(r.total / max) * 100}%`, background: color }} />
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

export { diffDays };
