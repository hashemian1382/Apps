import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Bell, Check, Download, FolderCog, Moon, Palette, Pencil, Plus, Sun, Tags, Trash2, Upload, Sprout } from 'lucide-react';
import { CATEGORY_COLORS, QUOTA, catById, downloadJson, uid, useApp } from '../lib/store';
import { faNum } from '../lib/dates';
import { Card, CardHead, Field, Modal, inputCls } from '../lib/ui';
import type { AppData } from '../lib/types';

export default function Settings({ notify }: { notify: (m: string) => void }) {
  const { data, setData, replaceAll, reset, storageBytes } = useApp();
  const [catName, setCatName] = useState('');
  const [catColor, setCatColor] = useState(CATEGORY_COLORS[0]);
  const [editCat, setEditCat] = useState<string | null>(null);
  const [habitName, setHabitName] = useState('');
  const [habitColor, setHabitColor] = useState(CATEGORY_COLORS[2]);
  const [wipeStep, setWipeStep] = useState(0);
  const [importErr, setImportErr] = useState<string | null>(null);
  const [backupOpen, setBackupOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const pct = Math.min(100, (storageBytes / QUOTA) * 100);
  const kb = storageBytes / 1024;
  const sizeLabel = kb > 1024 ? `${faNum((kb / 1024).toFixed(2))} مگابایت` : `${faNum(kb.toFixed(1))} کیلوبایت`;

  const usedInTasks = (id: string) => Object.values(data.days).some((d) => d.tasks.some((t) => t.categoryId === id));
  const usedInBacklog = (id: string) => data.backlog.some((b) => b.categoryId === id);

  const addCat = () => {
    const n = catName.trim();
    if (!n) return;
    setData((d) => ({ ...d, categories: [...d.categories, { id: uid(), name: n, color: catColor }] }));
    setCatName('');
    notify('دسته جدید ساخته شد 🏷️');
  };

  const saveCatEdit = (id: string, name: string, color: string) => {
    if (!name.trim()) return;
    setData((d) => ({ ...d, categories: d.categories.map((c) => (c.id === id ? { ...c, name: name.trim(), color } : c)) }));
    setEditCat(null);
    notify('دسته ویرایش شد ✏️');
  };

  const delCat = (id: string) => {
    if (data.categories.length <= 1) { notify('حداقل یک دسته باید بماند ⚠️'); return; }
    const fallback = data.categories.find((c) => c.id !== id)!;
    setData((d) => ({
      ...d,
      categories: d.categories.filter((c) => c.id !== id),
      backlog: d.backlog.map((b) => (b.categoryId === id ? { ...b, categoryId: fallback.id } : b)),
      days: Object.fromEntries(Object.entries(d.days).map(([k, v]) => [k, { ...v, tasks: v.tasks.map((t) => (t.categoryId === id ? { ...t, categoryId: fallback.id } : t)) }])),
    }));
    notify(`دسته حذف شد؛ آیتم‌ها به «${fallback.name}» منتقل شدند`);
  };

  const addHabit = () => {
    const n = habitName.trim();
    if (!n) return;
    setData((d) => ({ ...d, habits: [...d.habits, { id: uid(), name: n, color: habitColor, active: true }] }));
    setHabitName('');
    notify('عادت جدید ساخته شد 🌱');
  };

  const onImport = (f: File | undefined) => {
    if (!f) return;
    setImportErr(null);
    const r = new FileReader();
    r.onload = () => {
      try {
        const parsed = JSON.parse(String(r.result)) as AppData;
        if (!parsed || typeof parsed !== 'object' || !Array.isArray((parsed as { categories?: unknown }).categories)) {
          throw new Error('ساختار فایل معتبر نیست');
        }
        replaceAll(parsed);
        notify('بازیابی از فایل انجام شد ✅');
      } catch (e) {
        setImportErr(e instanceof Error ? e.message : 'فایل خراب است');
      }
    };
    r.readAsText(f);
  };

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      {/* شخصی‌سازی ظاهری */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card>
          <CardHead icon={<Palette size={18} />} title="شخصی‌سازی ظاهری" sub="تم و تقویم پیش‌فرض" />
          <div className="space-y-4 p-4 sm:p-5">
            <Field label="نام برنامه">
              <input value={data.settings.appName} onChange={(e) => setData((d) => ({ ...d, settings: { ...d.settings, appName: e.target.value || 'روزنگاه' } }))} className={inputCls} placeholder="مثلاً برنامه روزانه من" />
            </Field>
            <div>
              <p className="mb-1.5 text-xs font-bold text-zinc-500">تم</p>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setData((d) => ({ ...d, settings: { ...d.settings, theme: 'light' } }))}
                  className={`flex items-center justify-center gap-2 rounded-xl border-2 p-3 text-sm font-extrabold transition active:scale-[0.98] ${data.settings.theme === 'light' ? 'border-emerald-500 bg-emerald-500/[0.07]' : 'border-black/10 hover:border-black/25 dark:border-white/10'}`}>
                  <Sun size={17} className="text-amber-500" /> روشن ☀️
                  {data.settings.theme === 'light' && <Check size={15} className="text-emerald-600" />}
                </button>
                <button onClick={() => setData((d) => ({ ...d, settings: { ...d.settings, theme: 'dark' } }))}
                  className={`flex items-center justify-center gap-2 rounded-xl border-2 p-3 text-sm font-extrabold transition active:scale-[0.98] ${data.settings.theme === 'dark' ? 'border-emerald-500 bg-emerald-500/[0.07]' : 'border-black/10 hover:border-black/25 dark:border-white/10'}`}>
                  <Moon size={17} className="text-indigo-400" /> تیره 🌙
                  {data.settings.theme === 'dark' && <Check size={15} className="text-emerald-500" />}
                </button>
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-bold text-zinc-500">تقویم پیش‌فرض</p>
              <div className="grid grid-cols-2 gap-2">
                {([['shamsi', 'شمسی (جلالی) 🌞'], ['miladi', 'میلادی 🌍']] as const).map(([v, l]) => (
                  <button key={v} onClick={() => setData((d) => ({ ...d, settings: { ...d.settings, defaultCalendar: v } }))}
                    className={`rounded-xl border-2 p-3 text-sm font-extrabold transition active:scale-[0.98] ${data.settings.defaultCalendar === v ? 'border-emerald-500 bg-emerald-500/[0.07]' : 'border-black/10 hover:border-black/25 dark:border-white/10'}`}>
                    {l}
                  </button>
                ))}
              </div>
              <p className="mt-1.5 text-[11px] text-zinc-400">این انتخاب، حالت پیش‌فرض صفحه تقویم را تعیین می‌کند.</p>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* دسته‌بندی‌ها */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
        <Card>
          <CardHead icon={<Tags size={18} />} title="دسته‌بندی‌ها" sub={`${faNum(data.categories.length)} دسته فعال`} />
          <div className="space-y-2.5 p-4 sm:p-5">
            <div className="flex flex-col gap-2 rounded-xl border-2 border-dashed border-emerald-500/30 bg-emerald-500/[0.04] p-3 sm:flex-row sm:items-center">
              <input value={catName} onChange={(e) => setCatName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addCat(); }} placeholder="نام دسته جدید… + Enter" className="flex-1 rounded-lg border border-black/10 bg-white px-3 py-2 text-sm font-bold outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950" />
              <div className="flex items-center gap-1.5">
                {CATEGORY_COLORS.map((col) => (
                  <button key={col} onClick={() => setCatColor(col)} className={`size-6 rounded-full transition active:scale-90 ${catColor === col ? 'ring-2 ring-zinc-900 ring-offset-2 dark:ring-white dark:ring-offset-zinc-900' : 'hover:scale-110'}`} style={{ background: col }} title={col} />
                ))}
              </div>
              <button onClick={addCat} disabled={!catName.trim()} className="flex items-center justify-center gap-1 rounded-lg bg-gradient-to-l from-emerald-500 to-teal-600 px-4 py-2 text-xs font-extrabold text-white active:scale-95 disabled:opacity-40"><Plus size={15} /> افزودن</button>
            </div>
            {data.categories.map((c) => {
              const editing = editCat === c.id;
              const usage = Object.values(data.days).reduce((s, d) => s + d.tasks.filter((t) => t.categoryId === c.id).length, 0) + data.backlog.filter((b) => b.categoryId === c.id).length;
              return (
                <div key={c.id} className="flex items-center gap-2.5 rounded-xl border border-black/[0.07] p-2.5 dark:border-white/[0.08]">
                  <span className="size-8 shrink-0 rounded-lg shadow-inner" style={{ background: `linear-gradient(135deg, ${c.color}, ${c.color}99)` }} />
                  {editing ? (
                    <CatEditor cat={{ id: c.id, name: c.name, color: c.color }} onSave={saveCatEdit} onCancel={() => setEditCat(null)} />
                  ) : (
                    <>
                      <span className="flex-1">
                        <span className="block text-sm font-extrabold">{c.name}</span>
                        <span className="block text-[11px] text-zinc-400">{faNum(usage)} استفاده • {catById(data, c.id) ? 'فعال' : ''}</span>
                      </span>
                      <button onClick={() => setEditCat(c.id)} className="grid size-8 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800" title="ویرایش"><Pencil size={15} /></button>
                      <button onClick={() => delCat(c.id)} className="grid size-8 place-items-center rounded-lg text-zinc-300 hover:bg-rose-500/10 hover:text-rose-500" title={`حذف${usedInTasks(c.id) || usedInBacklog(c.id) ? ' (آیتم‌ها منتقل می‌شوند)' : ''}`}><Trash2 size={15} /></button>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      </motion.div>

      {/* عادت‌ها */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card>
          <CardHead icon={<Sprout size={18} />} title="عادت‌ها" sub="برای ردیاب روزانه صفحه اصلی" />
          <div className="space-y-2.5 p-4 sm:p-5">
            <div className="flex flex-col gap-2 rounded-xl border-2 border-dashed border-violet-500/30 bg-violet-500/[0.04] p-3 sm:flex-row sm:items-center">
              <input value={habitName} onChange={(e) => setHabitName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addHabit(); }} placeholder="نام عادت جدید… مثلاً پیاده‌روی + Enter" className="flex-1 rounded-lg border border-black/10 bg-white px-3 py-2 text-sm font-bold outline-none focus:border-violet-500 dark:border-white/10 dark:bg-zinc-950" />
              <div className="flex items-center gap-1.5">
                {CATEGORY_COLORS.slice(0, 6).map((col) => (
                  <button key={col} onClick={() => setHabitColor(col)} className={`size-6 rounded-full transition ${habitColor === col ? 'ring-2 ring-zinc-900 ring-offset-2 dark:ring-white dark:ring-offset-zinc-900' : 'hover:scale-110'}`} style={{ background: col }} />
                ))}
              </div>
              <button onClick={addHabit} disabled={!habitName.trim()} className="flex items-center justify-center gap-1 rounded-lg bg-gradient-to-l from-violet-500 to-fuchsia-600 px-4 py-2 text-xs font-extrabold text-white active:scale-95 disabled:opacity-40"><Plus size={15} /> افزودن</button>
            </div>
            {data.habits.length === 0 && <p className="py-3 text-center text-xs text-zinc-400">هنوز عادتی نساختی</p>}
            {data.habits.map((h) => (
              <div key={h.id} className={`flex items-center gap-2.5 rounded-xl border p-2.5 ${h.active ? 'border-black/[0.07] dark:border-white/[0.08]' : 'border-dashed opacity-60'}`}>
                <span className="size-3 shrink-0 rounded-full" style={{ background: h.color }} />
                <span className="flex-1 text-sm font-extrabold">{h.name}</span>
                <button onClick={() => setData((d) => ({ ...d, habits: d.habits.map((x) => (x.id === h.id ? { ...x, active: !x.active } : x)) }))}
                  className={`rounded-full px-3 py-1 text-[11px] font-extrabold transition active:scale-95 ${h.active ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'bg-zinc-100 text-zinc-400 dark:bg-zinc-800'}`}>
                  {h.active ? 'فعال' : 'غیرفعال'}
                </button>
                <button onClick={() => setData((d) => ({ ...d, habits: d.habits.filter((x) => x.id !== h.id) }))} className="grid size-8 place-items-center rounded-lg text-zinc-300 hover:bg-rose-500/10 hover:text-rose-500"><Trash2 size={15} /></button>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>

      {/* پشتیبان‌گیری */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
        <Card>
          <CardHead icon={<FolderCog size={18} />} title="پشتیبان‌گیری و داده‌ها" sub="خروجی / ورودی JSON + مدیریت حافظه" />
          <div className="space-y-4 p-4 sm:p-5">
            {/* وضعیت حافظه */}
            <div className={`rounded-xl border p-3.5 ${pct > 80 ? 'border-amber-500/40 bg-amber-500/[0.07]' : 'border-black/[0.07] bg-zinc-50/70 dark:border-white/[0.08] dark:bg-zinc-800/50'}`}>
              <div className="mb-2 flex items-center justify-between text-xs font-extrabold">
                <span className="flex items-center gap-1.5"><Bell size={14} className={pct > 80 ? 'text-amber-500' : 'text-zinc-400'} /> حافظه مرورگر (LocalStorage)</span>
                <span className="tabular-nums">{sizeLabel} • {faNum(Math.round(pct))}٪</span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-700" dir="ltr">
                <div className={`h-full rounded-full transition-all ${pct > 80 ? 'bg-gradient-to-r from-amber-500 to-rose-500' : 'bg-gradient-to-r from-emerald-500 to-teal-500'}`} style={{ width: `${Math.max(2, pct)}%` }} />
              </div>
              <p className="mt-2 text-[11px] leading-5 text-zinc-500">
                {pct > 80
                  ? '⚠️ حافظه رو به اتمام است! همین حالا خروجی بگیرید، سپس روز‌های خیلی قدیمی را پاک کنید تا برنامه کند نشود.'
                  : 'وضعیت حافظه سالم است. ذخیره‌سازی خودکار هر تغییری را بلافاصله نگه می‌دارد.'}
              </p>
            </div>

            <div className="grid gap-2 sm:grid-cols-2">
              <button onClick={() => { downloadJson(data, data.settings.appName); notify('فایل پشتیبان دانلود شد 💾'); }} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-emerald-500 to-teal-600 py-3 text-sm font-extrabold text-white shadow transition hover:opacity-90 active:scale-[0.98]"><Download size={17} /> خروجی (Export JSON)</button>
              <button onClick={() => fileRef.current?.click()} className="flex items-center justify-center gap-2 rounded-xl border-2 border-dashed border-black/15 py-3 text-sm font-extrabold text-zinc-600 transition hover:border-emerald-500/50 hover:text-emerald-700 active:scale-[0.98] dark:border-white/15 dark:text-zinc-300"><Upload size={17} /> ورودی (Import JSON)</button>
              <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { onImport(e.target.files?.[0]); e.target.value = ''; }} />
            </div>
            {importErr && <p className="rounded-xl bg-rose-500/10 p-3 text-xs font-bold text-rose-600">❌ خطا در فایل: {importErr}</p>}

            {/* پاک‌سازی */}
            <div className="rounded-xl border border-rose-500/25 bg-rose-500/[0.04] p-3.5">
              <p className="text-xs font-black text-rose-600">🗑️ پاک‌سازی کامل داده‌ها</p>
              <p className="mt-1 text-[11px] leading-5 text-zinc-500">همه روزها، تسک‌ها، بک‌لاگ، عادت‌ها و تنظیمات برای همیشه پاک می‌شود. این عمل با تأیید دو مرحله‌ای انجام می‌شود.</p>
              {wipeStep === 0 && (
                <button onClick={() => setWipeStep(1)} className="mt-2.5 rounded-xl border border-rose-500/40 px-4 py-2 text-xs font-extrabold text-rose-600 transition hover:bg-rose-500 hover:text-white active:scale-95">شروع پاک‌سازی…</button>
              )}
              {wipeStep === 1 && (
                <div className="mt-2.5 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-extrabold">مطمئنی؟ اول خروجی گرفتی؟</span>
                  <button onClick={() => { downloadJson(data, data.settings.appName); setWipeStep(2); }} className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-extrabold text-white active:scale-95">اول خروجی بگیر، بعد ادامه</button>
                  <button onClick={() => setWipeStep(2)} className="rounded-xl bg-rose-500 px-4 py-2 text-xs font-extrabold text-white active:scale-95">بله، ادامه بده</button>
                  <button onClick={() => setWipeStep(0)} className="rounded-xl border px-4 py-2 text-xs font-bold text-zinc-500">انصراف</button>
                </div>
              )}
              {wipeStep === 2 && (
                <div className="mt-2.5 flex flex-wrap items-center gap-2 rounded-xl bg-rose-500/10 p-3">
                  <span className="text-xs font-black text-rose-700 dark:text-rose-300">⚠️ تأیید نهایی: همه‌چیز برای همیشه حذف شود؟</span>
                  <button onClick={() => { reset(); setWipeStep(0); notify('همه داده‌ها پاک شد 🗑️'); }} className="rounded-xl bg-rose-600 px-5 py-2 text-xs font-extrabold text-white shadow active:scale-95">بله، همه را پاک کن</button>
                  <button onClick={() => setWipeStep(0)} className="rounded-xl border bg-white px-4 py-2 text-xs font-bold text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300">انصراف</button>
                </div>
              )}
            </div>

            <button onClick={() => setBackupOpen(true)} className="w-full rounded-xl bg-zinc-100 py-2.5 text-xs font-extrabold text-zinc-600 transition hover:bg-zinc-200 active:scale-[0.99] dark:bg-zinc-800 dark:text-zinc-300">
              مشاهده راهنمای پشتیبان‌گیری ❓
            </button>
          </div>
        </Card>
      </motion.div>

      <p className="pb-6 text-center text-[11px] leading-5 text-zinc-400">
        {data.settings.appName} • نسخه ۱ • کاملاً آفلاین و خصوصی — داده‌ها فقط در مرورگر شماست 🔒
      </p>

      <Modal open={backupOpen} onClose={() => setBackupOpen(false)} title="راهنمای پشتیبان‌گیری" wide>
        <div className="space-y-2.5 text-[13px] leading-7 text-zinc-600 dark:text-zinc-300">
          <p>۱. هر هفته یک‌بار دکمه <b>خروجی (Export)</b> را بزنید؛ یک فایل JSON دانلود می‌شود.</p>
          <p>۲. آن فایل را در جای امن (گوگل درایو، فلش و…) نگه دارید.</p>
          <p>۳. برای بازگردانی، دکمه <b>ورودی (Import)</b> را بزنید و همان فایل را انتخاب کنید.</p>
          <p>۴. اگر مرورگر را ریست کردید یا دستگاه عوض شد، همین فایل همه‌چیز را برمی‌گرداند.</p>
        </div>
      </Modal>
    </div>
  );
}

function CatEditor({ cat, onSave, onCancel }: { cat: { id: string; name: string; color: string }; onSave: (id: string, name: string, color: string) => void; onCancel: () => void }) {
  const [n, setN] = useState(cat.name);
  const [col, setCol] = useState(cat.color);
  return (
    <span className="flex flex-1 flex-wrap items-center gap-2">
      <input value={n} onChange={(e) => setN(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') onSave(cat.id, n, col); if (e.key === 'Escape') onCancel(); }} className="min-w-24 flex-1 rounded-lg border border-emerald-500/50 px-2 py-1.5 text-sm font-bold outline-none dark:bg-zinc-950" />
      <span className="flex items-center gap-1">
        {CATEGORY_COLORS.map((c) => (
          <button key={c} onClick={() => setCol(c)} className={`size-5 rounded-full ${col === c ? 'ring-2 ring-zinc-900 ring-offset-1 dark:ring-white' : ''}`} style={{ background: c }} />
        ))}
      </span>
      <button onClick={() => onSave(cat.id, n, col)} className="grid size-7 place-items-center rounded-lg bg-emerald-500 text-white"><Check size={14} /></button>
    </span>
  );
}
