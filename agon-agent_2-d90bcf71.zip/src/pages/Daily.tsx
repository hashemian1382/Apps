import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import {
  BedDouble, CalendarPlus, CheckCircle2, ChevronLeft, ChevronRight, ClipboardCopy, ListChecks,
  MoonStar, NotebookPen, Plus, Smile, Sparkles, Sprout, Sun, TrendingUp,
} from 'lucide-react';
import type { Priority, Task } from '../lib/types';
import { MOODS, PRIORITY_META, SPORT_OPTS, catById, uid, useApp } from '../lib/store';
import { addDays, diffDays, faNum, formatMiladi, formatMinutes, formatShamsi, timeToMin, todayKey } from '../lib/dates';
import { Card, CardHead, EditableText, Progress, Toast, inputCls } from '../lib/ui';
import TaskRow from '../components/TaskRow';

const anim = { initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 } };

export default function Daily({ dateKey, setDateKey, notify }: { dateKey: string; setDateKey: (k: string) => void; notify: (m: string) => void }) {
  const { data, updateDay, setData } = useApp();
  const day = data.days[dateKey] ?? {
    dateKey, wakeTime: '', sleepTime: '', mood: null, sport: 'none', wentOut: null,
    dayScore: null, note: '', tasks: [], tomorrowNote: '', habits: {}, positives: ['', '', ''], lesson: '',
  };
  const tomorrowKey = addDays(dateKey, 1);
  const tomorrow = data.days[tomorrowKey];
  const tomorrowTasks: Task[] = tomorrow?.tasks ?? [];

  const [q, setQ] = useState('');
  const [qp, setQp] = useState<Priority>('medium');
  const [qc, setQc] = useState(data.categories[0]?.id ?? '');
  const [qs, setQs] = useState('');
  const [qe, setQe] = useState('');
  const [tq, setTq] = useState('');
  const [copied, setCopied] = useState<string | null>(null);
  const quickRef = useRef<HTMLInputElement>(null);
  const isToday = dateKey === todayKey();
  const offset = diffDays(dateKey, todayKey());

  useEffect(() => { if (data.categories[0] && !qc) setQc(data.categories[0].id); }, [data.categories, qc]);

  // کلیدهای میانبر
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (e.target as HTMLElement)?.isContentEditable;
      if (e.key === 'ArrowRight' && !typing) { setDateKey(addDays(dateKey, -1)); }
      else if (e.key === 'ArrowLeft' && !typing) { setDateKey(addDays(dateKey, 1)); }
      else if ((e.key === 'n' || e.key === 'N' || e.key === 'ی') && !typing) { e.preventDefault(); quickRef.current?.focus(); quickRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
      else if ((e.key === 't' || e.key === 'T' || e.key === 'ف') && !typing) { setDateKey(todayKey()); }
    };
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [dateKey, setDateKey]);

  const done = day.tasks.filter((t) => t.done).length;
  const total = day.tasks.length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  const actualSum = day.tasks.reduce((s, t) => s + (t.actualMinutes ?? 0), 0);
  const habitsDone = data.habits.filter((h) => h.active && day.habits[h.id]).length;
  const habitsTotal = data.habits.filter((h) => h.active).length;

  const addTask = () => {
    const title = q.trim();
    if (!title) return;
    const t: Task = { id: uid(), title, done: false, priority: qp, categoryId: qc || data.categories[0]?.id || '', plannedStart: qs, plannedEnd: qe, actualMinutes: null, note: '', createdAt: new Date().toISOString() };
    updateDay(dateKey, { tasks: [...day.tasks, t] });
    setQ(''); setQs(''); setQe('');
    notify('تسک جدید اضافه شد ✨');
  };

  const patchTask = (id: string, p: Partial<Task>) =>
    updateDay(dateKey, { tasks: day.tasks.map((t) => (t.id === id ? { ...t, ...p } : t)) });
  const delTask = (id: string) => {
    updateDay(dateKey, { tasks: day.tasks.filter((t) => t.id !== id) });
    notify('تسک حذف شد');
  };

  const addTomorrow = () => {
    const title = tq.trim();
    if (!title) return;
    const t: Task = { id: uid(), title, done: false, priority: 'medium', categoryId: data.categories[0]?.id || '', plannedStart: '', plannedEnd: '', actualMinutes: null, note: '', createdAt: new Date().toISOString() };
    setData((d) => ({
      ...d,
      days: {
        ...d.days,
        [tomorrowKey]: { ...(d.days[tomorrowKey] ?? { dateKey: tomorrowKey, wakeTime: '', sleepTime: '', mood: null as number | null, sport: 'none', wentOut: null as boolean | null, dayScore: null as number | null, note: '', tasks: [], tomorrowNote: '', habits: {}, positives: ['', '', ''], lesson: '' }), tasks: [...((d.days[tomorrowKey]?.tasks) ?? []), t] },
      },
    }));
    setTq('');
    notify('به برنامه فردا اضافه شد 📝');
  };

  const timed = useMemo(() =>
    day.tasks
      .map((t) => ({ t, s: timeToMin(t.plannedStart), e: timeToMin(t.plannedEnd) }))
      .filter((x) => x.s != null)
      .sort((a, b) => (a.s ?? 0) - (b.s ?? 0)),
  [day.tasks]);

  const copySummary = async () => {
    const lines: string[] = [];
    lines.push(`📅 خلاصه روز ${formatShamsi(dateKey)} (${formatMiladi(dateKey)})`);
    lines.push(`⏰ بیداری: ${day.wakeTime ? faNum(day.wakeTime) : '—'} | خواب: ${day.sleepTime ? faNum(day.sleepTime) : '—'}`);
    const mood = MOODS.find((m) => m.v === day.mood);
    const sport = SPORT_OPTS.find((s) => s.id === day.sport);
    lines.push(`🙂 حال: ${mood ? `${mood.icon} ${mood.label}` : '—'} | 🏃 ورزش: ${sport ? `${sport.icon} ${sport.label}` : '—'} | 🚶 بیرون: ${day.wentOut == null ? '—' : day.wentOut ? 'بله' : 'خیر'} | ⭐ امتیاز: ${day.dayScore != null ? faNum(day.dayScore) : '—'} از ${faNum(10)}`);
    lines.push(`✅ تسک‌ها: ${faNum(done)} از ${faNum(total)} (${faNum(pct)}٪)`);
    day.tasks.forEach((t) => {
      const c = catById(data, t.categoryId);
      lines.push(`${t.done ? '✓' : '○'} ${t.title} [${PRIORITY_META[t.priority].label}${c ? ` | ${c.name}` : ''}${t.plannedStart ? ` | ${t.plannedStart}${t.plannedEnd ? ` تا ${t.plannedEnd}` : ''}` : ''}${t.actualMinutes ? ` | واقعی: ${t.actualMinutes} دقیقه` : ''}]${t.note ? ` — ${t.note}` : ''}`);
    });
    if (actualSum) lines.push(`⏱️ مجموع زمان واقعی: ${formatMinutes(actualSum)}`);
    const hp = day.positives.filter((p) => p.trim());
    if (hp.length) { lines.push('🌟 سه نکته مثبت:'); hp.forEach((p, i) => lines.push(`${faNum(i + 1)}. ${p}`)); }
    if (day.lesson.trim()) lines.push(`📚 درس آموخته: ${day.lesson}`);
    if (day.note.trim()) lines.push(`📝 یادداشت روز: ${day.note}`);
    if (day.tomorrowNote.trim()) lines.push(`🔜 برنامه فردا: ${day.tomorrowNote}`);
    if (tomorrowTasks.length) { lines.push(`📌 تسک‌های فردا (${faNum(tomorrowTasks.length)}):`); tomorrowTasks.forEach((t) => lines.push(`○ ${t.title}`)); }
    const text = lines.join('\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopied('خلاصه روز کپی شد! 📋');
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      setCopied('خلاصه روز کپی شد! 📋');
    }
    setTimeout(() => setCopied(null), 2500);
  };

  const relLabel = offset === 0 ? 'امروز' : offset === 1 ? 'فردا' : offset === -1 ? 'دیروز' : offset > 1 ? `${faNum(offset)} روز بعد` : `${faNum(Math.abs(offset))} روز قبل`;

  return (
    <div className="space-y-4 pb-4">
      <Toast msg={copied} />
      {/* ناوبری روزانه */}
      <motion.div {...anim} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-black/[0.06] bg-white p-3 shadow-sm sm:p-4 dark:border-white/[0.08] dark:bg-zinc-900">
        <div className="flex items-center gap-2">
          <button onClick={() => setDateKey(addDays(dateKey, -1))} title="روز قبل (→)" className="grid size-10 place-items-center rounded-xl border border-black/10 text-zinc-600 transition hover:border-emerald-500/40 hover:text-emerald-600 active:scale-95 dark:border-white/10 dark:text-zinc-300"><ChevronRight size={19} /></button>
          <button onClick={() => setDateKey(addDays(dateKey, 1))} title="روز بعد (←)" className="grid size-10 place-items-center rounded-xl border border-black/10 text-zinc-600 transition hover:border-emerald-500/40 hover:text-emerald-600 active:scale-95 dark:border-white/10 dark:text-zinc-300"><ChevronLeft size={19} /></button>
          {!isToday && (
            <button onClick={() => setDateKey(todayKey())} title="بازگشت به امروز (T)" className="rounded-xl bg-zinc-900 px-3.5 py-2.5 text-xs font-extrabold text-white transition hover:bg-zinc-700 active:scale-95 dark:bg-white dark:text-zinc-900">امروز</button>
          )}
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center gap-2">
            <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-extrabold ${isToday ? 'bg-emerald-500 text-white' : 'bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-300'}`}>{relLabel}</span>
            <h2 className="text-base font-black sm:text-lg">{formatShamsi(dateKey)}</h2>
          </div>
          <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">{formatMiladi(dateKey)}</p>
        </div>
        <input type="date" value={dateKey} onChange={(e) => e.target.value && setDateKey(e.target.value)} className="rounded-xl border border-black/10 bg-zinc-50 px-3 py-2.5 text-xs font-bold outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950" dir="ltr" />
      </motion.div>

      {/* نوار پیشرفت روز */}
      <motion.div {...anim} className="flex flex-wrap items-center gap-3 rounded-2xl border border-emerald-500/20 bg-gradient-to-l from-emerald-500/[0.08] to-teal-500/[0.08] p-4">
        <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow"><TrendingUp size={20} /></span>
        <div className="min-w-40 flex-1">
          <div className="mb-1.5 flex items-center justify-between text-xs font-extrabold">
            <span>پیشرفت امروز</span>
            <span className="tabular-nums">{faNum(done)} از {faNum(total)} تسک • {faNum(pct)}٪</span>
          </div>
          <Progress value={pct} />
        </div>
        <div className="flex gap-2 text-center">
          <div className="rounded-xl bg-white/70 px-3 py-1.5 dark:bg-zinc-900/70"><p className="text-sm font-black">{faNum(habitsDone)}/{faNum(habitsTotal)}</p><p className="text-[10px] text-zinc-500">عادت‌ها</p></div>
          <div className="rounded-xl bg-white/70 px-3 py-1.5 dark:bg-zinc-900/70"><p className="text-sm font-black">{actualSum ? faNum(actualSum) : faNum(0)}<span className="text-[10px] font-bold"> د</span></p><p className="text-[10px] text-zinc-500">دقیقه واقعی</p></div>
          <div className="rounded-xl bg-white/70 px-3 py-1.5 dark:bg-zinc-900/70"><p className="text-sm font-black">{day.dayScore != null ? faNum(day.dayScore) : '—'}</p><p className="text-[10px] text-zinc-500">امتیاز روز</p></div>
        </div>
      </motion.div>

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="space-y-4 xl:col-span-2">
          {/* ۱. اطلاعات پایه روز */}
          <motion.div {...anim}>
            <Card>
              <CardHead icon={<Sun size={18} />} title="اطلاعات پایه روز" sub="ریتم روزانه‌ات را ثبت کن" />
              <div className="grid gap-4 p-5 sm:grid-cols-2">
                <div className="flex items-center gap-3">
                  <label className="flex-1">
                    <span className="mb-1.5 flex items-center gap-1 text-xs font-bold text-zinc-500"><Sun size={13} /> بیدار شدن</span>
                    <input type="time" value={day.wakeTime} onChange={(e) => updateDay(dateKey, { wakeTime: e.target.value })} className={inputCls} dir="ltr" />
                  </label>
                  <label className="flex-1">
                    <span className="mb-1.5 flex items-center gap-1 text-xs font-bold text-zinc-500"><MoonStar size={13} /> خوابیدن</span>
                    <input type="time" value={day.sleepTime} onChange={(e) => updateDay(dateKey, { sleepTime: e.target.value })} className={inputCls} dir="ltr" />
                  </label>
                </div>
                <div>
                  <span className="mb-1.5 flex items-center gap-1 text-xs font-bold text-zinc-500"><Smile size={13} /> وضعیت روحی</span>
                  <div className="flex gap-1.5">
                    {MOODS.map((m) => (
                      <button key={m.v} onClick={() => updateDay(dateKey, { mood: day.mood === m.v ? null : m.v })} title={m.label}
                        className={`grid size-11 flex-1 place-items-center rounded-xl border text-xl transition active:scale-90 ${day.mood === m.v ? 'border-emerald-500 bg-emerald-500/10 shadow-sm' : 'border-black/[0.07] hover:border-black/20 hover:bg-zinc-50 dark:border-white/[0.08] dark:hover:bg-zinc-800'}`}>
                        {m.icon}
                      </button>
                    ))}
                  </div>
                  <p className="mt-1 text-[11px] text-zinc-400">{day.mood ? MOODS.find((m) => m.v === day.mood)?.label : 'انتخاب نشده'}</p>
                </div>
                <div>
                  <span className="mb-1.5 block text-xs font-bold text-zinc-500">🏃 وضعیت ورزش</span>
                  <div className="flex flex-wrap gap-1.5">
                    {SPORT_OPTS.map((s) => (
                      <button key={s.id} onClick={() => updateDay(dateKey, { sport: s.id })}
                        className={`rounded-full border px-3 py-1.5 text-xs font-bold transition active:scale-95 ${day.sport === s.id ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-black/10 text-zinc-500 hover:text-zinc-800 dark:border-white/10 dark:text-zinc-400'}`}>
                        {s.icon} {s.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mb-1.5 block text-xs font-bold text-zinc-500">🚶 بیرون رفتن</span>
                  <div className="flex gap-1.5">
                    <button onClick={() => updateDay(dateKey, { wentOut: true })} className={`flex-1 rounded-xl border px-3 py-1.5 text-xs font-bold transition active:scale-95 ${day.wentOut === true ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-black/10 text-zinc-500 dark:border-white/10 dark:text-zinc-400'}`}>بله، رفتم</button>
                    <button onClick={() => updateDay(dateKey, { wentOut: false })} className={`flex-1 rounded-xl border px-3 py-1.5 text-xs font-bold transition active:scale-95 ${day.wentOut === false ? 'border-zinc-500 bg-zinc-500/10 text-zinc-700 dark:text-zinc-200' : 'border-black/10 text-zinc-500 dark:border-white/10 dark:text-zinc-400'}`}>خونه بودم</button>
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="text-xs font-bold text-zinc-500">⭐ امتیاز روز (از ۱۰)</span>
                    <span className={`rounded-lg px-2.5 py-0.5 text-sm font-black ${day.dayScore != null ? 'bg-amber-500/15 text-amber-600 dark:text-amber-300' : 'bg-zinc-100 text-zinc-400 dark:bg-zinc-800'}`}>{day.dayScore != null ? faNum(day.dayScore) : '—'}</span>
                  </div>
                  <input type="range" min={0} max={10} step={1} value={day.dayScore ?? 5} onChange={(e) => updateDay(dateKey, { dayScore: Number(e.target.value) })} className="w-full" dir="ltr" />
                  <div className="flex justify-between text-[10px] text-zinc-400"><span>{faNum(0)}</span><span>{faNum(5)}</span><span>{faNum(10)}</span></div>
                </div>
                <label className="block sm:col-span-2">
                  <span className="mb-1.5 flex items-center gap-1 text-xs font-bold text-zinc-500"><NotebookPen size={13} /> یادداشت آزاد روز</span>
                  <textarea value={day.note} onChange={(e) => updateDay(dateKey, { note: e.target.value })} rows={2} placeholder="هرچه در ذهنته بنویس؛ اتفاق‌ها، حس‌ها، ایده‌ها…" className={`${inputCls} leading-6`} />
                </label>
              </div>
            </Card>
          </motion.div>

          {/* ۲. تسک‌های امروز */}
          <motion.div {...anim}>
            <Card>
              <CardHead icon={<ListChecks size={18} />} title="تسک‌های امروز" sub={`${faNum(total)} تسک • ${faNum(done)} انجام‌شده`} />
              <div className="space-y-3 p-4 sm:p-5">
                <div className="rounded-xl border-2 border-dashed border-emerald-500/30 bg-emerald-500/[0.04] p-3">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <Plus size={17} className="shrink-0 text-emerald-600" />
                      <input ref={quickRef} value={q} onChange={(e) => setQ(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter') addTask(); }}
                        placeholder="تسک جدید بنویس و Enter بزن… (کلید N)" className="w-full bg-transparent text-sm font-bold outline-none placeholder:font-medium placeholder:text-zinc-400" />
                      <button onClick={addTask} disabled={!q.trim()} className="shrink-0 rounded-lg bg-gradient-to-l from-emerald-500 to-teal-600 px-4 py-1.5 text-xs font-extrabold text-white shadow transition hover:opacity-90 active:scale-95 disabled:opacity-40">افزودن</button>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5" dir="ltr">
                      <select value={qp} onChange={(e) => setQp(e.target.value as Priority)} className="rounded-lg border border-black/10 bg-white px-2 py-1 text-[11px] font-bold outline-none dark:border-white/10 dark:bg-zinc-950" dir="rtl">
                        {(Object.keys(PRIORITY_META) as Priority[]).map((p) => <option key={p} value={p}>{PRIORITY_META[p].label}</option>)}
                      </select>
                      <select value={qc} onChange={(e) => setQc(e.target.value)} className="rounded-lg border border-black/10 bg-white px-2 py-1 text-[11px] font-bold outline-none dark:border-white/10 dark:bg-zinc-950" dir="rtl">
                        {data.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                      <input type="time" value={qs} onChange={(e) => setQs(e.target.value)} className="rounded-lg border border-black/10 bg-white px-1.5 py-1 text-[11px] outline-none dark:border-white/10 dark:bg-zinc-950" title="شروع" />
                      <span className="text-zinc-400">–</span>
                      <input type="time" value={qe} onChange={(e) => setQe(e.target.value)} className="rounded-lg border border-black/10 bg-white px-1.5 py-1 text-[11px] outline-none dark:border-white/10 dark:bg-zinc-950" title="پایان" />
                    </div>
                  </div>
                </div>
                {total === 0 ? (
                  <div className="rounded-xl bg-zinc-50 py-8 text-center dark:bg-zinc-800/50">
                    <p className="text-3xl">🗒️</p>
                    <p className="mt-2 text-sm font-extrabold text-zinc-600 dark:text-zinc-300">هنوز تسکی برای این روز ثبت نشده</p>
                    <p className="mt-1 text-xs text-zinc-400">بالا بنویس و Enter بزن، یا از بک‌لاگ منتقل کن</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {day.tasks.filter((t) => !t.done).map((t) => (
                      <TaskRow key={t.id} task={t} categories={data.categories} onPatch={(p) => patchTask(t.id, p)} onDelete={() => delTask(t.id)} moveLabel={{ label: 'انتقال به فردا', onMove: () => {
                        updateDay(dateKey, { tasks: day.tasks.filter((x) => x.id !== t.id) });
                        setData((d) => ({ ...d, days: { ...d.days, [tomorrowKey]: { ...(d.days[tomorrowKey] ?? { dateKey: tomorrowKey, wakeTime: '', sleepTime: '', mood: null as number | null, sport: 'none', wentOut: null as boolean | null, dayScore: null as number | null, note: '', tasks: [], tomorrowNote: '', habits: {}, positives: ['', '', ''], lesson: '' }), tasks: [...((d.days[tomorrowKey]?.tasks) ?? []), { ...t, done: false }] } } }));
                        notify('به فردا منتقل شد ⏭️');
                      } }} />
                    ))}
                    {done > 0 && (
                      <details className="rounded-xl bg-zinc-50 dark:bg-zinc-800/50" open>
                        <summary className="cursor-pointer px-3 py-2.5 text-xs font-extrabold text-zinc-500">✅ انجام‌شده‌ها ({faNum(done)}) — کلیک برای باز/بسته</summary>
                        <div className="space-y-2 px-2 pb-2">
                          {day.tasks.filter((t) => t.done).map((t) => (
                            <TaskRow key={t.id} task={t} categories={data.categories} onPatch={(p) => patchTask(t.id, p)} onDelete={() => delTask(t.id)} />
                          ))}
                        </div>
                      </details>
                    )}
                  </div>
                )}
              </div>
            </Card>
          </motion.div>

          {/* ۵. برنامه‌ریزی فردا */}
          <motion.div {...anim}>
            <Card>
              <CardHead icon={<CalendarPlus size={18} />} title="برنامه‌ریزی فردا" sub={formatShamsi(tomorrowKey)} />
              <div className="space-y-3 p-4 sm:p-5">
                <div className="flex items-center gap-2">
                  <input value={tq} onChange={(e) => setTq(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addTomorrow(); }} placeholder="تسک فردا را از همین امشب بنویس… + Enter" className={inputCls} />
                  <button onClick={addTomorrow} disabled={!tq.trim()} className="grid size-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 text-white shadow transition hover:opacity-90 active:scale-95 disabled:opacity-40"><Plus size={18} /></button>
                </div>
                {tomorrowTasks.length > 0 ? (
                  <ul className="space-y-1.5">
                    {tomorrowTasks.map((t, i) => (
                      <li key={t.id} className="flex items-center gap-2 rounded-lg bg-sky-500/[0.06] px-3 py-2 text-[13px] font-bold text-zinc-700 dark:text-zinc-200">
                        <span className="grid size-5 shrink-0 place-items-center rounded-full bg-sky-500/15 text-[10px] font-black text-sky-700 dark:text-sky-300">{faNum(i + 1)}</span>
                        <span className="flex-1 truncate">{t.title}</span>
                        <EditableText value={t.title} onSave={(v) => { if (!v) return; setData((d) => ({ ...d, days: { ...d.days, [tomorrowKey]: { ...(d.days[tomorrowKey]!), tasks: d.days[tomorrowKey]!.tasks.map((x) => (x.id === t.id ? { ...x, title: v } : x)) } } })); }} className="hidden" />
                        <button onClick={() => setData((d) => ({ ...d, days: { ...d.days, [tomorrowKey]: { ...(d.days[tomorrowKey]!), tasks: d.days[tomorrowKey]!.tasks.filter((x) => x.id !== t.id) } } }))} className="text-[11px] text-zinc-400 hover:text-rose-500">حذف</button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="rounded-lg bg-zinc-50 py-3 text-center text-xs text-zinc-400 dark:bg-zinc-800/50">هنوز چیزی برای فردا برنامه‌ریزی نشده — امشب سه کار مهم فردا را بنویس 🌙</p>
                )}
                <label className="block">
                  <span className="mb-1.5 block text-xs font-bold text-zinc-500">یادداشت مربوط به فردا</span>
                  <textarea value={day.tomorrowNote} onChange={(e) => updateDay(dateKey, { tomorrowNote: e.target.value })} rows={2} placeholder="اولویت اصلی فردا، قرارها، نکاتی که نباید یادت بره…" className={`${inputCls} leading-6`} />
                </label>
              </div>
            </Card>
          </motion.div>

          {/* ۶. بازتاب پایان روز */}
          <motion.div {...anim}>
            <Card>
              <CardHead icon={<Sprout size={18} />} title="بازتاب پایان روز" sub="۳ نکته مثبت و ۱ درس" />
              <div className="grid gap-3 p-4 sm:p-5">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="flex items-center gap-2.5 rounded-xl border border-black/[0.06] bg-gradient-to-l from-amber-500/[0.06] to-transparent p-2.5 dark:border-white/[0.07]">
                    <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-amber-500/15 text-base">{['🥇', '🥈', '🥉'][i]}</span>
                    <input value={day.positives[i] ?? ''} onChange={(e) => { const p = [...day.positives]; p[i] = e.target.value; updateDay(dateKey, { positives: p }); }} placeholder={["امروز به چی افتخار می‌کنی؟", 'چه اتفاق خوبی افتاد؟', 'برای چی شکرگزاری؟'][i]} className="w-full bg-transparent text-[13px] font-medium outline-none placeholder:text-zinc-400" />
                    {day.positives[i]?.trim() && <CheckCircle2 size={16} className="shrink-0 text-emerald-500" />}
                  </div>
                ))}
                <div className="flex items-start gap-2.5 rounded-xl border border-black/[0.06] bg-gradient-to-l from-violet-500/[0.07] to-transparent p-2.5 dark:border-white/[0.07]">
                  <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-violet-500/15 text-base">📚</span>
                  <textarea value={day.lesson} onChange={(e) => updateDay(dateKey, { lesson: e.target.value })} rows={2} placeholder="یک درس که امروز گرفتی و فردا به کارت میاد…" className="w-full bg-transparent text-[13px] font-medium leading-6 outline-none placeholder:text-zinc-400" />
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        <div className="space-y-4">
          {/* ۳. تایم‌لاین روز */}
          <motion.div {...anim}>
            <Card>
              <CardHead icon={<BedDouble size={18} />} title="تایم‌لاین روز" sub={timed.length ? `${faNum(timed.length)} بازه زمانی` : 'بدون بازه زمانی'} />
              <div className="p-4">
                {timed.length === 0 ? (
                  <div className="py-6 text-center">
                    <p className="text-3xl">🕰️</p>
                    <p className="mt-2 text-xs font-bold text-zinc-500">برای تسک‌ها ساعت شروع/پایان بذار</p>
                    <p className="mt-1 text-[11px] leading-5 text-zinc-400">تا نقشه بصری روزت اینجا کشیده بشه</p>
                  </div>
                ) : (
                  <div className="relative pr-9" dir="rtl">
                    <div className="absolute bottom-1 right-[26px] top-1 w-1 rounded-full bg-gradient-to-b from-amber-200 via-emerald-300 to-indigo-300 dark:from-amber-500/30 dark:via-emerald-500/30 dark:to-indigo-500/30" />
                    <div className="space-y-2">
                      {timed.map(({ t, s, e }) => {
                        const c = catById(data, t.categoryId);
                        const dur = s != null && e != null && e > s ? e - s : 30;
                        return (
                          <div key={t.id} className="relative">
                            <span className={`absolute -right-9 top-2 grid size-4 place-items-center rounded-full border-2 border-white shadow ${t.done ? 'bg-emerald-500' : ''}`} style={t.done ? undefined : { background: c?.color ?? '#94a3b8' }} />
                            <div className={`mr-1 rounded-xl border p-2.5 transition ${t.done ? 'border-emerald-500/25 bg-emerald-500/[0.05]' : 'border-black/[0.07] bg-zinc-50/70 hover:shadow-sm dark:border-white/[0.08] dark:bg-zinc-800/60'}`}>
                              <p className={`text-xs font-extrabold leading-5 ${t.done ? 'text-zinc-400 line-through' : ''}`}>{t.title}</p>
                              <p className="mt-1 text-[10.5px] font-bold tabular-nums text-zinc-500">
                                {faNum(t.plannedStart)}{t.plannedEnd ? ` تا ${faNum(t.plannedEnd)}` : ''} • {formatMinutes(dur)}
                              </p>
                              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-zinc-200/70 dark:bg-zinc-700" dir="ltr">
                                <div className="h-full rounded-full" style={{ width: `${Math.min(100, (dur / 240) * 100)}%`, background: c?.color ?? '#10b981' }} />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    {(day.wakeTime || day.sleepTime) && (
                      <div className="mt-3 flex items-center justify-between rounded-xl bg-indigo-500/[0.07] px-3 py-2 text-[11px] font-bold text-indigo-700 dark:text-indigo-300">
                        <span>🌅 {day.wakeTime ? faNum(day.wakeTime) : '—'}</span>
                        <span>🌙 {day.sleepTime ? faNum(day.sleepTime) : '—'}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Card>
          </motion.div>

          {/* ۴. ردیاب عادت‌ها */}
          <motion.div {...anim}>
            <Card>
              <CardHead icon={<Sparkles size={18} />} title="ردیاب عادت‌ها" sub={habitsTotal ? `${faNum(habitsDone)} از ${faNum(habitsTotal)}` : 'عادتی فعال نیست'} />
              <div className="space-y-2 p-4">
                {habitsTotal === 0 ? (
                  <p className="py-3 text-center text-xs leading-6 text-zinc-400">در بخش تنظیمات عادت بساز تا هر روز اینجا تیک بزنی 🌱</p>
                ) : (
                  <>
                    <Progress value={habitsTotal ? (habitsDone / habitsTotal) * 100 : 0} tone="from-violet-500 to-fuchsia-500" />
                    {data.habits.filter((h) => h.active).map((h) => {
                      const on = !!day.habits[h.id];
                      return (
                        <button key={h.id} onClick={() => updateDay(dateKey, { habits: { ...day.habits, [h.id]: !on } })}
                          className={`flex w-full items-center gap-2.5 rounded-xl border p-2.5 text-right transition active:scale-[0.98] ${on ? 'border-emerald-500/30 bg-emerald-500/[0.07]' : 'border-black/[0.07] hover:border-black/[0.15] dark:border-white/[0.08]'}`}>
                          <span className={`grid size-6 shrink-0 place-items-center rounded-full border-2 transition ${on ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-zinc-300 dark:border-zinc-600'}`}>
                            {on && <svg viewBox="0 0 12 12" className="size-3" fill="none" stroke="currentColor" strokeWidth={2.5}><path d="M2 6.5 4.8 9 10 3" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                          </span>
                          <span className="size-2.5 shrink-0 rounded-full" style={{ background: h.color }} />
                          <span className={`flex-1 text-[13px] font-bold ${on ? 'text-zinc-500 line-through dark:text-zinc-400' : ''}`}>{h.name}</span>
                        </button>
                      );
                    })}
                  </>
                )}
              </div>
            </Card>
          </motion.div>

          {/* ۷. کپی خلاصه روز */}
          <motion.div {...anim}>
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-br from-zinc-900 to-zinc-700 p-5 text-white dark:from-emerald-600 dark:to-teal-700">
                <h3 className="flex items-center gap-2 text-sm font-black"><ClipboardCopy size={17} /> خروجی روزانه</h3>
                <p className="mt-1 text-[11.5px] leading-5 text-white/70">گزارش کامل امروز را یک‌جا کپی کن و هرجا خواستی نگه دار</p>
                <button onClick={copySummary} className="mt-3 w-full rounded-xl bg-white py-2.5 text-[13px] font-black text-zinc-900 shadow transition hover:bg-emerald-50 active:scale-[0.98]">📋 کپی خلاصه روز</button>
                {total > 0 && (
                  <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-lg bg-white/10 py-1.5"><p className="text-sm font-black">{faNum(pct)}٪</p><p className="text-[10px] text-white/60">تکمیل</p></div>
                    <div className="rounded-lg bg-white/10 py-1.5"><p className="text-sm font-black">{actualSum ? faNum(actualSum) : '—'}</p><p className="text-[10px] text-white/60">دقیقه</p></div>
                    <div className="rounded-lg bg-white/10 py-1.5"><p className="text-sm font-black">{day.dayScore != null ? faNum(day.dayScore) : '—'}</p><p className="text-[10px] text-white/60">امتیاز</p></div>
                  </div>
                )}
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
