import { useEffect, useState } from 'react';
import { Archive, BarChart3, CalendarDays, Database, Download, Home, Menu, Settings as SettingsIcon, SunMoon, X } from 'lucide-react';
import { useApp, QUOTA, downloadJson } from '../lib/store';
import { formatMiladi, formatShamsi, faNum, todayKey } from '../lib/dates';
import type { ViewKey } from '../lib/types';

const NAV: { id: ViewKey; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'daily', label: 'روز جاری', icon: <Home size={19} />, desc: 'نمای روزانه' },
  { id: 'backlog', label: 'بک‌لاگ', icon: <Archive size={19} />, desc: 'ایده‌ها و کارهای آینده' },
  { id: 'reports', label: 'گزارش‌ها', icon: <BarChart3 size={19} />, desc: 'عملکرد هفتگی و ماهانه' },
  { id: 'calendar', label: 'تقویم', icon: <CalendarDays size={19} />, desc: 'نمای ماهانه' },
  { id: 'settings', label: 'تنظیمات', icon: <SettingsIcon size={19} />, desc: 'دسته‌ها و ظاهر' },
];

export default function Layout({ view, setView, dateKey, children }: { view: ViewKey; setView: (v: ViewKey) => void; dateKey: string; children: React.ReactNode }) {
  const { data, setData, storageBytes, lastSaved } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [time, setTime] = useState(new Date());
  const dark = data.settings.theme === 'dark';
  const pct = Math.min(100, (storageBytes / QUOTA) * 100);
  const nearFull = pct > 80;

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    document.title = `${data.settings.appName} | برنامه‌ریزی روزانه`;
    document.documentElement.lang = 'fa';
    document.documentElement.dir = 'rtl';
  }, [data.settings.appName]);

  const go = (v: ViewKey) => {
    setView(v);
    setMobileOpen(false);
  };

  const clock = `${faNum(String(time.getHours()).padStart(2, '0'))}:${faNum(String(time.getMinutes()).padStart(2, '0'))}`;

  return (
    <div className="min-h-screen bg-[#f6f7f9] text-zinc-900 transition-colors dark:bg-zinc-950 dark:text-zinc-100">
      {/* هدر ثابت */}
      <header className="sticky top-0 z-40 border-b border-black/[0.06] bg-white/85 backdrop-blur-xl dark:border-white/[0.07] dark:bg-zinc-950/85">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(!mobileOpen)} className="grid size-10 place-items-center rounded-xl border border-black/10 text-zinc-600 hover:bg-zinc-100 lg:hidden dark:border-white/10 dark:text-zinc-300 dark:hover:bg-zinc-800" aria-label="منو">
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <button onClick={() => go('daily')} className="flex items-center gap-2.5">
              <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-xl shadow-md shadow-emerald-500/25">🌱</span>
              <span className="text-right leading-tight">
                <span className="block text-[15px] font-black">{data.settings.appName}</span>
                <span className="block text-[11px] font-medium text-zinc-500 dark:text-zinc-400">دستیار روزانه تو</span>
              </span>
            </button>
          </div>

          <div className="hidden items-center gap-2 rounded-full border border-black/[0.07] bg-zinc-50 px-4 py-1.5 text-xs font-semibold text-zinc-600 md:flex dark:border-white/[0.08] dark:bg-zinc-900 dark:text-zinc-300">
            <span className="text-emerald-600 dark:text-emerald-400">📅 {formatShamsi(dateKey || todayKey())}</span>
            <span className="h-3 w-px bg-black/10 dark:bg-white/10" />
            <span className="text-zinc-500 dark:text-zinc-400">{formatMiladi(dateKey || todayKey())}</span>
            <span className="h-3 w-px bg-black/10 dark:bg-white/10" />
            <span className="tabular-nums">🕒 {clock}</span>
          </div>

          <div className="flex items-center gap-2">
            <span title={lastSaved ? `آخرین ذخیره خودکار: ${lastSaved.toLocaleTimeString('fa-IR')}` : 'ذخیره خودکار فعال'} className="hidden items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1.5 text-[11px] font-bold text-emerald-700 sm:flex dark:text-emerald-300">
              <span className="relative flex size-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" /><span className="relative inline-flex size-2 rounded-full bg-emerald-500" /></span>
              ذخیره خودکار
            </span>
            <button onClick={() => downloadJson(data, data.settings.appName)} title="پشتیبان‌گیری سریع (دانلود JSON)" className="grid size-10 place-items-center rounded-xl border border-black/10 text-zinc-600 transition hover:border-emerald-500/40 hover:bg-emerald-50 hover:text-emerald-700 active:scale-95 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-emerald-500/10 dark:hover:text-emerald-300">
              <Download size={18} />
            </button>
            <button onClick={() => setData((d) => ({ ...d, settings: { ...d.settings, theme: dark ? 'light' : 'dark' } }))} title={dark ? 'حالت روشن' : 'حالت تیره'} className="grid size-10 place-items-center rounded-xl border border-black/10 text-zinc-600 transition hover:border-amber-500/40 hover:bg-amber-50 hover:text-amber-600 active:scale-95 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-amber-500/10">
              <SunMoon size={18} />
            </button>
            <button onClick={() => go('settings')} title="تنظیمات" className={`grid size-10 place-items-center rounded-xl transition active:scale-95 ${view === 'settings' ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900' : 'border border-black/10 text-zinc-600 hover:bg-zinc-100 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-zinc-800'}`}>
              <Database size={17} />
            </button>
          </div>
        </div>
        {/* نوار موبایل تاریخ */}
        <div className="flex items-center justify-center gap-2 border-t border-black/[0.05] px-4 py-1.5 text-[11px] font-semibold text-zinc-600 md:hidden dark:border-white/[0.06] dark:text-zinc-300">
          <span className="text-emerald-600 dark:text-emerald-400">{formatShamsi(dateKey || todayKey())}</span>
          <span className="text-zinc-300">•</span>
          <span>{formatMiladi(dateKey || todayKey())}</span>
        </div>
        {/* هشدار حافظه */}
        {nearFull && (
          <div className="border-t border-amber-500/20 bg-amber-50 px-4 py-1.5 text-center text-[11px] font-bold text-amber-700 dark:bg-amber-500/10 dark:text-amber-300">
            ⚠️ حافظه مرورگر رو به اتمام است ({faNum(Math.round(pct))}٪) — لطفاً از بخش تنظیمات خروجی بگیرید و داده‌های قدیمی را پاک کنید.
          </div>
        )}
      </header>

      <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6 sm:px-6">
        {/* سایدبار دسکتاپ */}
        <aside className="sticky top-24 hidden h-fit w-60 shrink-0 lg:block">
          <nav className="rounded-2xl border border-black/[0.06] bg-white p-2.5 shadow-sm dark:border-white/[0.08] dark:bg-zinc-900">
            {NAV.map((n) => {
              const on = view === n.id;
              return (
                <button key={n.id} onClick={() => go(n.id)}
                  className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-right transition active:scale-[0.98] ${on ? 'bg-gradient-to-l from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/25' : 'text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800'}`}>
                  <span className={`grid size-9 shrink-0 place-items-center rounded-lg ${on ? 'bg-white/20' : 'bg-zinc-100 dark:bg-zinc-800'}`}>{n.icon}</span>
                  <span>
                    <span className="block text-sm font-extrabold">{n.label}</span>
                    <span className={`block text-[11px] ${on ? 'text-white/80' : 'text-zinc-400'}`}>{n.desc}</span>
                  </span>
                </button>
              );
            })}
          </nav>
          <div className="mt-4 rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-50 to-teal-50 p-4 dark:from-emerald-500/10 dark:to-teal-500/10 dark:border-emerald-500/20">
            <p className="text-xs font-extrabold text-emerald-800 dark:text-emerald-200">💡 میانبرها</p>
            <ul className="mt-2 space-y-1.5 text-[11px] font-medium leading-5 text-emerald-900/80 dark:text-emerald-100/70">
              <li><Kbd>N</Kbd> تسک جدید</li>
              <li><Kbd>→</Kbd> <Kbd>←</Kbd> جابه‌جایی روز</li>
              <li><Kbd>T</Kbd> بازگشت به امروز</li>
              <li><Kbd>Enter</Kbd> ثبت سریع</li>
            </ul>
          </div>
        </aside>

        {/* محتوای اصلی */}
        <main className="min-w-0 flex-1">{children}</main>
      </div>

      {/* ناوبری موبایل پایین */}
      <nav className="fixed inset-x-3 bottom-3 z-40 flex items-stretch justify-between gap-1 rounded-2xl border border-black/10 bg-white/95 p-1.5 shadow-2xl backdrop-blur-xl lg:hidden dark:border-white/10 dark:bg-zinc-900/95">
        {NAV.map((n) => {
          const on = view === n.id;
          return (
            <button key={n.id} onClick={() => go(n.id)} className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl px-1 py-2 transition active:scale-95 ${on ? 'bg-gradient-to-b from-emerald-500 to-teal-600 text-white shadow' : 'text-zinc-500 dark:text-zinc-400'}`}>
              {n.icon}
              <span className="text-[10px] font-extrabold">{n.label}</span>
            </button>
          );
        })}
      </nav>

      {/* منوی همبرگری */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-zinc-950/50" onClick={() => setMobileOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-72 animate-[fadeUp_0.2s_ease-out] overflow-y-auto border-l border-black/10 bg-white p-4 dark:border-white/10 dark:bg-zinc-900">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-black">منوی برنامه</span>
              <button onClick={() => setMobileOpen(false)} className="grid size-8 place-items-center rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"><X size={18} /></button>
            </div>
            {NAV.map((n) => (
              <button key={n.id} onClick={() => go(n.id)} className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold ${view === n.id ? 'bg-emerald-500 text-white' : 'text-zinc-700 hover:bg-zinc-100 dark:text-zinc-200 dark:hover:bg-zinc-800'}`}>
                {n.icon} {n.label}
              </button>
            ))}
            <div className="mt-3 rounded-xl bg-zinc-50 p-3 text-[11px] leading-5 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400">
              داده‌ها کاملاً آفلاین در مرورگر شما ذخیره می‌شود. فراموش نکنید مرتب خروجی بگیرید.
            </div>
          </div>
        </div>
      )}
      <div className="h-20 lg:hidden" />
    </div>
  );
}

function Kbd({ children }: { children: React.ReactNode }) {
  return <kbd className="rounded-md border border-emerald-600/30 bg-white px-1.5 py-0.5 font-mono text-[10px] font-bold text-emerald-700 dark:bg-zinc-900 dark:text-emerald-300">{children}</kbd>;
}
