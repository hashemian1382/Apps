import { useState } from 'react';
import { AlarmClock, ArrowLeft, ChevronDown, Clock3, Flag, StickyNote, Trash2 } from 'lucide-react';
import type { Category, Task } from '../lib/types';
import { PRIORITY_META, catById, useApp } from '../lib/store';
import { faNum, formatMinutes } from '../lib/dates';
import { EditableText } from '../lib/ui';

export default function TaskRow({ task, categories, onPatch, onDelete, moveLabel }: {
  task: Task;
  categories: Category[];
  onPatch: (p: Partial<Task>) => void;
  onDelete: () => void;
  moveLabel?: { label: string; onMove: () => void };
}) {
  const { data } = useApp();
  const [open, setOpen] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const cat = catById(data, task.categoryId) ?? categories.find((c) => c.id === task.categoryId);
  const pm = PRIORITY_META[task.priority];
  const hasTime = !!(task.plannedStart || task.plannedEnd);
  const hasNote = !!task.note;
  const hasActual = task.actualMinutes != null && task.actualMinutes > 0;

  return (
    <div className={`group rounded-xl border transition ${task.done ? 'border-emerald-500/25 bg-emerald-50/50 dark:bg-emerald-500/[0.06]' : 'border-black/[0.07] bg-white hover:border-black/[0.14] hover:shadow-sm dark:border-white/[0.08] dark:bg-zinc-900 dark:hover:border-white/[0.16]'}`}>
      <div className="flex items-center gap-2.5 px-3 py-2.5">
        <button
          onClick={() => onPatch({ done: !task.done })}
          aria-label={task.done ? 'بازگردانی' : 'انجام شد'}
          className={`grid size-6 shrink-0 place-items-center rounded-full border-2 transition active:scale-90 ${task.done ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-zinc-300 hover:border-emerald-500 dark:border-zinc-600'}`}>
          {task.done && <svg viewBox="0 0 12 12" className="size-3.5" fill="none" stroke="currentColor" strokeWidth={2.5}><path d="M2 6.5 4.8 9 10 3" strokeLinecap="round" strokeLinejoin="round" /></svg>}
        </button>

        <div className="min-w-0 flex-1">
          <EditableText
            value={task.title}
            onSave={(v) => v && onPatch({ title: v })}
            className={`w-full text-[13.5px] font-bold ${task.done ? 'text-zinc-400 line-through dark:text-zinc-500' : 'text-zinc-800 dark:text-zinc-100'}`}
          />
          <div className="mt-1 flex flex-wrap items-center gap-1.5">
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-bold ${pm.bg} ${pm.color}`}>
              <span className={`size-1.5 rounded-full ${pm.dot}`} />{pm.label}
            </span>
            {cat && (
              <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2 py-0.5 text-[10.5px] font-bold text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
                <span className="size-1.5 rounded-full" style={{ background: cat.color }} />{cat.name}
              </span>
            )}
            {hasTime && (
              <span className="inline-flex items-center gap-1 rounded-full bg-sky-500/10 px-2 py-0.5 text-[10.5px] font-bold text-sky-700 dark:text-sky-300">
                <Clock3 size={11} />{faNum(task.plannedStart || '—')} تا {faNum(task.plannedEnd || '—')}
              </span>
            )}
            {hasActual && (
              <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10.5px] font-bold text-violet-700 dark:text-violet-300">
                <AlarmClock size={11} />{formatMinutes(task.actualMinutes!)}
              </span>
            )}
            {hasNote && !open && <span className="text-[10.5px] text-zinc-400">📝 یادداشت دارد</span>}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          {moveLabel && !task.done && (
            <button onClick={moveLabel.onMove} title={moveLabel.label} className="grid size-7 place-items-center rounded-lg text-zinc-400 transition hover:bg-sky-500/10 hover:text-sky-600">
              <ArrowLeft size={15} />
            </button>
          )}
          <button onClick={() => setOpen(!open)} title="جزئیات" className={`grid size-7 place-items-center rounded-lg transition ${open ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900' : 'text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200'}`}>
            <ChevronDown size={15} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
          </button>
          {confirmDel ? (
            <span className="flex items-center gap-1 rounded-lg bg-rose-500/10 p-1 text-[11px] font-bold text-rose-600">
              حذف شود؟
              <button onClick={onDelete} className="rounded-md bg-rose-500 px-2 py-0.5 text-white hover:bg-rose-600">بله</button>
              <button onClick={() => setConfirmDel(false)} className="rounded-md px-1.5 py-0.5 hover:bg-rose-500/10">خیر</button>
            </span>
          ) : (
            <button onClick={() => setConfirmDel(true)} title="حذف (با تأیید)" className="grid size-7 place-items-center rounded-lg text-zinc-300 transition hover:bg-rose-500/10 hover:text-rose-500">
              <Trash2 size={15} />
            </button>
          )}
        </div>
      </div>

      {open && (
        <div className="grid gap-3 border-t border-black/[0.06] px-3 py-3 sm:grid-cols-2 dark:border-white/[0.07]">
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-[11px] font-bold text-zinc-500"><Flag size={12} /> اولویت</span>
            <div className="flex flex-wrap gap-1">
              {(Object.keys(PRIORITY_META) as (keyof typeof PRIORITY_META)[]).map((p) => (
                <button key={p} onClick={() => onPatch({ priority: p })}
                  className={`rounded-full border px-2.5 py-1 text-[11px] font-bold transition active:scale-95 ${task.priority === p ? `${PRIORITY_META[p].bg} ${PRIORITY_META[p].color} border-current` : 'border-black/10 text-zinc-400 hover:text-zinc-700 dark:border-white/10'}`}>
                  {PRIORITY_META[p].label}
                </button>
              ))}
            </div>
          </label>
          <label className="block">
            <span className="mb-1 block text-[11px] font-bold text-zinc-500">دسته‌بندی</span>
            <select value={task.categoryId} onChange={(e) => onPatch({ categoryId: e.target.value })}
              className="w-full rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs font-bold outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950">
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-[11px] font-bold text-zinc-500"><Clock3 size={12} /> بازه زمانی برنامه‌ریزی‌شده</span>
            <div className="flex items-center gap-1.5" dir="ltr">
              <input type="time" value={task.plannedStart} onChange={(e) => onPatch({ plannedStart: e.target.value })}
                className="w-full rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950" />
              <span className="text-zinc-400">–</span>
              <input type="time" value={task.plannedEnd} onChange={(e) => onPatch({ plannedEnd: e.target.value })}
                className="w-full rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950" />
            </div>
          </label>
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-[11px] font-bold text-zinc-500"><AlarmClock size={12} /> زمان واقعی صرف‌شده (دقیقه)</span>
            <div className="flex items-center gap-1.5">
              <input type="number" min={0} max={1440} value={task.actualMinutes ?? ''} placeholder="مثلاً ۴۵"
                onChange={(e) => onPatch({ actualMinutes: e.target.value === '' ? null : Math.max(0, Number(e.target.value)) })}
                className="w-full rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950" />
              {[15, 30, 60].map((m) => (
                <button key={m} onClick={() => onPatch({ actualMinutes: (task.actualMinutes ?? 0) + m })} className="shrink-0 rounded-lg bg-zinc-100 px-2 py-1.5 text-[11px] font-bold text-zinc-600 hover:bg-emerald-500/15 hover:text-emerald-700 dark:bg-zinc-800 dark:text-zinc-300">+{faNum(m)}</button>
              ))}
            </div>
          </label>
          <label className="block sm:col-span-2">
            <span className="mb-1 flex items-center gap-1 text-[11px] font-bold text-zinc-500"><StickyNote size={12} /> یادداشت / نتیجه</span>
            <textarea value={task.note} onChange={(e) => onPatch({ note: e.target.value })} rows={2} placeholder="نتیجه، مانع، نکته… (Ctrl+Enter برای ثبت)"
              className="w-full rounded-lg border border-black/10 bg-zinc-50 px-2 py-1.5 text-xs leading-5 outline-none focus:border-emerald-500 dark:border-white/10 dark:bg-zinc-950" />
          </label>
        </div>
      )}
    </div>
  );
}
