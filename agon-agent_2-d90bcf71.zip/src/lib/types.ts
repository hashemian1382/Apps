export type Priority = 'low' | 'medium' | 'high' | 'urgent';

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface Habit {
  id: string;
  name: string;
  color: string;
  active: boolean;
}

export interface Task {
  id: string;
  title: string;
  done: boolean;
  priority: Priority;
  categoryId: string;
  plannedStart: string; // "HH:MM" or ""
  plannedEnd: string; // "HH:MM" or ""
  actualMinutes: number | null;
  note: string;
  createdAt: string; // ISO
}

export interface DayData {
  dateKey: string; // gregorian YYYY-MM-DD
  wakeTime: string;
  sleepTime: string;
  mood: number | null; // 1..5
  sport: string; // none | light | medium | heavy
  wentOut: boolean | null;
  dayScore: number | null; // 0..10
  note: string;
  tasks: Task[];
  tomorrowNote: string;
  habits: Record<string, boolean>;
  positives: string[]; // exactly 3
  lesson: string;
}

export interface BacklogItem {
  id: string;
  title: string;
  desc: string;
  priority: Priority;
  categoryId: string;
  createdAt: string; // dateKey
  deadline: string; // dateKey or ""
}

export interface AppSettings {
  theme: 'light' | 'dark';
  defaultCalendar: 'shamsi' | 'miladi';
  appName: string;
}

export interface AppData {
  version: number;
  categories: Category[];
  habits: Habit[];
  days: Record<string, DayData>;
  backlog: BacklogItem[];
  settings: AppSettings;
}

export type ViewKey = 'daily' | 'backlog' | 'reports' | 'calendar' | 'settings';
