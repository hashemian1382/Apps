import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { AppData, AppSettings, BacklogItem, Category, DayData, Habit, Priority, Task } from './types';
import { todayKey } from './dates';

const KEY = 'rooznegah-data-v1';
const QUOTA = 5 * 1024 * 1024; // ~5MB estimate

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export const PRIORITY_META: Record<Priority, { label: string; color: string; bg: string; dot: string }> = {
  low: { label: 'کم', color: 'text-slate-500', bg: 'bg-slate-500/10', dot: 'bg-slate-400' },
  medium: { label: 'متوسط', color: 'text-sky-600', bg: 'bg-sky-500/10', dot: 'bg-sky-500' },
  high: { label: 'زیاد', color: 'text-amber-600', bg: 'bg-amber-500/10', dot: 'bg-amber-500' },
  urgent: { label: 'فوری', color: 'text-rose-600', bg: 'bg-rose-500/10', dot: 'bg-rose-500' },
};

export const SPORT_OPTS = [
  { id: 'none', label: 'استراحت', icon: '🛋️' },
  { id: 'light', label: 'سبک', icon: '🚶' },
  { id: 'medium', label: 'متوسط', icon: '🏃' },
  { id: 'heavy', label: 'سنگین', icon: '🏋️' },
];

export const MOODS = [
  { v: 1, icon: '😞', label: 'خیلی بد' },
  { v: 2, icon: '🙁', label: 'بد' },
  { v: 3, icon: '😐', label: 'معمولی' },
  { v: 4, icon: '🙂', label: 'خوب' },
  { v: 5, icon: '🤩', label: 'عالی' },
];

export const CATEGORY_COLORS = ['#059669', '#0ea5e9', '#8b5cf6', '#f43f5e', '#f59e0b', '#14b8a6', '#ec4899', '#6366f1', '#84cc16', '#f97316'];

export function emptyDay(dateKey: string): DayData {
  return {
    dateKey,
    wakeTime: '',
    sleepTime: '',
    mood: null,
    sport: 'none',
    wentOut: null,
    dayScore: null,
    note: '',
    tasks: [],
    tomorrowNote: '',
    habits: {},
    positives: ['', '', ''],
    lesson: '',
  };
}

function defaultCategories(): Category[] {
  return [
    { id: 'work', name: 'کاری', color: '#059669' },
    { id: 'personal', name: 'شخصی', color: '#0ea5e9' },
    { id: 'learn', name: 'یادگیری', color: '#8b5cf6' },
    { id: 'health', name: 'سلامتی', color: '#f43f5e' },
    { id: 'finance', name: 'مالی', color: '#f59e0b' },
  ];
}

function defaultHabits(): Habit[] {
  return [
    { id: 'h-read', name: 'مطالعه ۲۰ دقیقه', color: '#8b5cf6', active: true },
    { id: 'h-sport', name: 'ورزش روزانه', color: '#059669', active: true },
    { id: 'h-water', name: 'نوشیدن آب کافی', color: '#0ea5e9', active: true },
    { id: 'h-medit', name: 'مدیتیشن ۱۰ دقیقه', color: '#f59e0b', active: true },
  ];
}

function defaultSettings(): AppSettings {
  return { theme: 'light', defaultCalendar: 'shamsi', appName: 'روزنگاه' };
}

function defaultData(): AppData {
  return { version: 1, categories: defaultCategories(), habits: defaultHabits(), days: {}, backlog: [], settings: defaultSettings() };
}

function normalizeDay(raw: unknown, dateKey: string): DayData {
  const base = emptyDay(dateKey);
  if (!raw || typeof raw !== 'object') return base;
  const r = raw as Record<string, unknown>;
  const pos = Array.isArray(r.positives) ? (r.positives as unknown[]).map((x) => String(x ?? '')).slice(0, 3) : [];
  while (pos.length < 3) pos.push('');
  return {
    dateKey,
    wakeTime: typeof r.wakeTime === 'string' ? r.wakeTime : '',
    sleepTime: typeof r.sleepTime === 'string' ? r.sleepTime : '',
    mood: typeof r.mood === 'number' && r.mood >= 1 && r.mood <= 5 ? r.mood : null,
    sport: typeof r.sport === 'string' ? r.sport : 'none',
    wentOut: typeof r.wentOut === 'boolean' ? r.wentOut : null,
    dayScore: typeof r.dayScore === 'number' ? r.dayScore : null,
    note: typeof r.note === 'string' ? r.note : '',
    tasks: Array.isArray(r.tasks) ? (r.tasks as Task[]) : [],
    tomorrowNote: typeof r.tomorrowNote === 'string' ? r.tomorrowNote : '',
    habits: r.habits && typeof r.habits === 'object' ? (r.habits as Record<string, boolean>) : {},
    positives: pos,
    lesson: typeof r.lesson === 'string' ? r.lesson : '',
  };
}

function load(): AppData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      const d = defaultData();
      // seed demo content for today so first run feels alive
      const tk = todayKey();
      const day = emptyDay(tk);
      day.wakeTime = '06:30';
      day.tasks = [
        { id: uid(), title: 'مرور اهداف هفته و برنامه‌ریزی روز', done: true, priority: 'high', categoryId: 'personal', plannedStart: '07:00', plannedEnd: '07:30', actualMinutes: 25, note: 'با تمرکز کامل انجام شد', createdAt: new Date().toISOString() },
        { id: uid(), title: 'جلسه تیم محصول', done: false, priority: 'urgent', categoryId: 'work', plannedStart: '10:00', plannedEnd: '11:00', actualMinutes: null, note: '', createdAt: new Date().toISOString() },
        { id: uid(), title: 'مطالعه ۲۰ صفحه کتاب', done: false, priority: 'medium', categoryId: 'learn', plannedStart: '21:00', plannedEnd: '21:40', actualMinutes: null, note: '', createdAt: new Date().toISOString() },
      ];
      d.days[tk] = day;
      d.backlog = [
        { id: uid(), title: 'راه‌اندازی وب‌سایت شخصی', desc: 'طراحی لندینگ + بخش نمونه‌کارها', priority: 'high', categoryId: 'personal', createdAt: tk, deadline: '' },
        { id: uid(), title: 'یادگیری زبان انگلیسی - سطح B2', desc: 'روزانه ۳۰ دقیقه تمرین', priority: 'medium', categoryId: 'learn', createdAt: tk, deadline: '' },
      ];
      return d;
    }
    const parsed = JSON.parse(raw) as AppData;
    const d = defaultData();
    const merged: AppData = {
      version: 1,
      categories: Array.isArray(parsed.categories) && parsed.categories.length ? parsed.categories : d.categories,
      habits: Array.isArray(parsed.habits) ? parsed.habits : d.habits,
      days: {},
      backlog: Array.isArray(parsed.backlog) ? parsed.backlog : [],
      settings: { ...d.settings, ...(parsed.settings ?? {}) },
    };
    if (parsed.days && typeof parsed.days === 'object') {
      for (const [k, v] of Object.entries(parsed.days)) merged.days[k] = normalizeDay(v, k);
    }
    return merged;
  } catch {
    return defaultData();
  }
}

interface Store {
  data: AppData;
  setData: (fn: (d: AppData) => AppData) => void;
  replaceAll: (d: AppData) => void;
  reset: () => void;
  getDay: (key: string) => DayData;
  updateDay: (key: string, patch: Partial<DayData>) => void;
  storageBytes: number;
  lastSaved: Date | null;
}

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setDataState] = useState<AppData>(load);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const persist = (d: AppData) => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      try {
        localStorage.setItem(KEY, JSON.stringify(d));
        setLastSaved(new Date());
      } catch {
        /* quota — surfaced via storageBytes warning */
      }
    }, 350);
  };

  useEffect(() => {
    document.documentElement.dataset.theme = data.settings.theme;
    document.documentElement.classList.toggle('dark', data.settings.theme === 'dark');
  }, [data.settings.theme]);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
      setLastSaved(new Date());
    } catch { /* ignore */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setData = (fn: (d: AppData) => AppData) => {
    setDataState((prev) => {
      const next = fn(prev);
      persist(next);
      return next;
    });
  };

  const replaceAll = (d: AppData) => {
    const norm: AppData = {
      version: 1,
      categories: d.categories ?? [],
      habits: d.habits ?? [],
      days: {},
      backlog: d.backlog ?? [],
      settings: { ...defaultSettings(), ...(d.settings ?? {}) },
    };
    for (const [k, v] of Object.entries(d.days ?? {})) norm.days[k] = normalizeDay(v, k);
    setDataState(norm);
    try {
      localStorage.setItem(KEY, JSON.stringify(norm));
      setLastSaved(new Date());
    } catch { /* ignore */ }
  };

  const reset = () => {
    const d = defaultData();
    setDataState(d);
    try {
      localStorage.setItem(KEY, JSON.stringify(d));
      setLastSaved(new Date());
    } catch { /* ignore */ }
  };

  const getDay = (key: string): DayData => data.days[key] ?? emptyDay(key);

  const updateDay = (key: string, patch: Partial<DayData>) => {
    setData((prev) => ({
      ...prev,
      days: { ...prev.days, [key]: { ...(prev.days[key] ?? emptyDay(key)), ...patch, dateKey: key } },
    }));
  };

  const storageBytes = useMemo(() => {
    try {
      return new Blob([JSON.stringify(data)]).size;
    } catch {
      return 0;
    }
  }, [data]);

  const value: Store = { data, setData, replaceAll, reset, getDay, updateDay, storageBytes, lastSaved };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): Store {
  const s = useContext(Ctx);
  if (!s) throw new Error('useApp outside provider');
  return s;
}

export function catById(data: AppData, id: string): Category | undefined {
  return data.categories.find((c) => c.id === id);
}

export function downloadJson(data: AppData, appName: string) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const d = new Date();
  a.href = url;
  a.download = `${appName}-backup-${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export { QUOTA, KEY };
