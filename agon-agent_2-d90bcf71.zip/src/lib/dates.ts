import { toJalaali, toGregorian, jalaaliMonthLength } from 'jalaali-js';

const FA_D = '۰۱۲۳۴۵۶۷۸۹';

export function faNum(v: number | string): string {
  return String(v).replace(/[0-9]/g, (d) => FA_D[Number(d)]);
}

export const pad2 = (n: number): string => String(n).padStart(2, '0');

export function keyFromDate(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export function todayKey(): string {
  return keyFromDate(new Date());
}

export function parseKey(key: string): Date {
  const parts = key.split('-').map(Number);
  return new Date(parts[0], parts[1] - 1, parts[2]);
}

export function addDays(key: string, n: number): string {
  const d = parseKey(key);
  d.setDate(d.getDate() + n);
  return keyFromDate(d);
}

export function diffDays(a: string, b: string): number {
  return Math.round((parseKey(a).getTime() - parseKey(b).getTime()) / 86400000);
}

export interface JDate {
  jy: number;
  jm: number;
  jd: number;
}

export function toJ(key: string): JDate {
  const d = parseKey(key);
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

export const J_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

export const G_MONTHS_FA = [
  'ژانویه', 'فوریه', 'مارس', 'آوریل', 'مه', 'ژوئن',
  'ژوئیه', 'اوت', 'سپتامبر', 'اکتبر', 'نوامبر', 'دسامبر',
];

export const WEEKDAYS_FA = [
  'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه',
];

/** هفته از شنبه شروع می‌شود */
export const WEEKDAYS_SAT = [
  'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه',
];

export function weekdayFa(key: string): string {
  return WEEKDAYS_FA[parseKey(key).getDay()];
}

export function formatShamsi(key: string): string {
  const j = toJ(key);
  return `${weekdayFa(key)} ${faNum(j.jd)} ${J_MONTHS[j.jm - 1]} ${faNum(j.jy)}`;
}

export function formatShamsiShort(key: string): string {
  const j = toJ(key);
  return `${faNum(j.jd)} ${J_MONTHS[j.jm - 1]}`;
}

export function formatMiladi(key: string): string {
  const d = parseKey(key);
  return `${faNum(d.getDate())} ${G_MONTHS_FA[d.getMonth()]} ${faNum(d.getFullYear())}`;
}

export function formatMiladiShort(key: string): string {
  const d = parseKey(key);
  return `${faNum(d.getFullYear())}/${faNum(d.getMonth() + 1)}/${faNum(d.getDate())}`;
}

export function jMonthLen(jy: number, jm: number): number {
  return jalaaliMonthLength(jy, jm);
}

export function gMonthLen(gy: number, gm: number): number {
  return new Date(gy, gm, 0).getDate();
}

export function jToKey(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  return `${g.gy}-${pad2(g.gm)}-${pad2(g.gd)}`;
}

export function formatMinutes(min: number): string {
  if (!min || min <= 0) return `۰ دقیقه`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (h === 0) return `${faNum(m)} دقیقه`;
  if (m === 0) return `${faNum(h)} ساعت`;
  return `${faNum(h)} ساعت و ${faNum(m)} دقیقه`;
}

export function timeToMin(t: string): number | null {
  if (!t || !/^\d{1,2}:\d{2}$/.test(t)) return null;
  const [h, m] = t.split(':').map(Number);
  if (h > 23 || m > 59) return null;
  return h * 60 + m;
}

export function isOverdue(deadline: string): boolean {
  if (!deadline) return false;
  return diffDays(deadline, todayKey()) < 0;
}
