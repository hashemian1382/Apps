import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Check, Pencil, X } from 'lucide-react';

export function Card({ children, className = '', id }: { children: ReactNode; className?: string; id?: string }) {
  return (
    <section id={id} className={`rounded-2xl border border-black/[0.06] bg-white shadow-[0_1px_2px_rgba(16,24,40,0.04),0_8px_24px_-12px_rgba(16,24,40,0.12)] dark:border-white/[0.08] dark:bg-zinc-900 dark:shadow-[0_8px_30px_-12px_rgba(0,0,0,0.6)] ${className}`}>
      {children}
    </section>
  );
}

export function CardHead({ icon, title, sub, action }: { icon: ReactNode; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-black/[0.06] px-5 py-4 dark:border-white/[0.07]">
      <div className="flex items-center gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">{icon}</span>
        <span>
          <h3 className="text-[15px] font-extrabold text-zinc-900 dark:text-zinc-50">{title}</h3>
          {sub && <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">{sub}</p>}
        </span>
      </div>
      {action}
    </div>
  );
}

export function Progress({ value, tone = 'from-emerald-500 to-teal-500' }: { value: number; tone?: string }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800" dir="ltr">
      <div className={`h-full rounded-full bg-gradient-to-r transition-all duration-500 ${tone}`} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const fn = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] grid place-items-center p-4">
      <div className="absolute inset-0 bg-zinc-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative w-full ${wide ? 'max-w-2xl' : 'max-w-md'} animate-[pop_0.18s_ease-out] rounded-2xl border border-black/10 bg-white p-5 shadow-2xl dark:border-white/10 dark:bg-zinc-900`}>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-extrabold text-zinc-900 dark:text-white">{title}</h3>
          <button onClick={onClose} className="grid size-8 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200" aria-label="بستن">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function EditableText({ value, onSave, placeholder, className = '', multiline }: { value: string; onSave: (v: string) => void; placeholder?: string; className?: string; multiline?: boolean }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const ref = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
  useEffect(() => {
    if (editing) {
      setDraft(value);
      setTimeout(() => ref.current?.focus(), 30);
    }
  }, [editing, value]);
  if (!editing) {
    return (
      <button onClick={() => setEditing(true)} title="ویرایش درجا — کلیک کنید" className={`group inline-flex max-w-full items-center gap-1.5 text-right ${className}`}>
        <span className="truncate">{value || <span className="text-zinc-400">{placeholder ?? '—'}</span>}</span>
        <Pencil size={13} className="shrink-0 opacity-0 transition group-hover:opacity-60" />
      </button>
    );
  }
  const commit = () => {
    onSave(draft.trim());
    setEditing(false);
  };
  return (
    <span className="inline-flex w-full items-center gap-1.5">
      {multiline ? (
        <textarea ref={ref as React.RefObject<HTMLTextAreaElement>} value={draft} onChange={(e) => setDraft(e.target.value)} rows={2}
          onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) commit(); if (e.key === 'Escape') setEditing(false); }}
          onBlur={commit} className="w-full rounded-lg border border-emerald-500/50 bg-white px-2 py-1 text-sm outline-none dark:bg-zinc-950" />
      ) : (
        <input ref={ref as React.RefObject<HTMLInputElement>} value={draft} onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false); }}
          onBlur={commit} placeholder={placeholder}
          className="w-full rounded-lg border border-emerald-500/50 bg-white px-2 py-1 text-sm outline-none dark:bg-zinc-950" />
      )}
      <button onMouseDown={(e) => e.preventDefault()} onClick={commit} className="grid size-7 shrink-0 place-items-center rounded-lg bg-emerald-500 text-white hover:bg-emerald-600" aria-label="تأیید">
        <Check size={15} />
      </button>
    </span>
  );
}

export function Toast({ msg }: { msg: string | null }) {
  if (!msg) return null;
  return (
    <div className="fixed bottom-6 left-1/2 z-[90] -translate-x-1/2 animate-[toast_0.25s_ease-out]">
      <div className="flex items-center gap-2 rounded-full bg-zinc-900 px-5 py-2.5 text-sm font-bold text-white shadow-2xl dark:bg-white dark:text-zinc-900">
        <span className="grid size-5 place-items-center rounded-full bg-emerald-500 text-white"><Check size={13} strokeWidth={3} /></span>
        {msg}
      </div>
    </div>
  );
}

export function Seg<T extends string>({ options, value, onChange }: { options: { id: T; label: string; hint?: string }[]; value: T | null; onChange: (v: T | null) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map((o) => {
        const on = value === o.id;
        return (
          <button key={o.id} onClick={() => onChange(on ? (null as unknown as T) : o.id)}
            title={o.hint}
            className={`rounded-full border px-3 py-1.5 text-xs font-bold transition active:scale-95 ${on ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-black/10 text-zinc-500 hover:border-black/20 hover:text-zinc-800 dark:border-white/10 dark:text-zinc-400 dark:hover:text-zinc-100'}`}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold text-zinc-500 dark:text-zinc-400">{label}</span>
      {children}
    </label>
  );
}

export const inputCls = 'w-full rounded-xl border border-black/10 bg-zinc-50/60 px-3 py-2 text-sm text-zinc-900 outline-none transition placeholder:text-zinc-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 dark:border-white/10 dark:bg-zinc-950/60 dark:text-zinc-100 dark:focus:bg-zinc-950';
