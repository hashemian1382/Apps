import { useRef, useState } from 'react';
import { StoreProvider } from './lib/store';
import { todayKey } from './lib/dates';
import type { ViewKey } from './lib/types';
import Layout from './components/Layout';
import Daily from './pages/Daily';
import Backlog from './pages/Backlog';
import Reports from './pages/Reports';
import CalendarView from './pages/Calendar';
import Settings from './pages/Settings';
import { Toast } from './lib/ui';

export default function App() {
  const [view, setView] = useState<ViewKey>('daily');
  const [dateKey, setDateKey] = useState(todayKey());
  const [toast, setToast] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const notify = (m: string) => {
    setToast(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 2200);
  };

  const goDaily = (k: string) => {
    setDateKey(k);
    setView('daily');
  };

  return (
    <StoreProvider>
      <Layout view={view} setView={setView} dateKey={dateKey}>
        {view === 'daily' && <Daily dateKey={dateKey} setDateKey={setDateKey} notify={notify} />}
        {view === 'backlog' && <Backlog goDaily={goDaily} notify={notify} />}
        {view === 'reports' && <Reports />}
        {view === 'calendar' && <CalendarView goDaily={goDaily} />}
        {view === 'settings' && <Settings notify={notify} />}
      </Layout>
      <Toast msg={toast} />
    </StoreProvider>
  );
}
