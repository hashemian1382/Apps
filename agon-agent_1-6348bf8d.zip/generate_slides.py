from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR, MSO_AUTO_SIZE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
from pptx.chart.data import CategoryChartData
from pptx.oxml.ns import qn
from PIL import Image as PILImage

CREAM = RGBColor(0xFA, 0xF6, 0xEF)
DARK = RGBColor(0x0F, 0x3D, 0x3E)
PANEL = RGBColor(0x16, 0x4C, 0x4D)
PRIMARY = RGBColor(0x0E, 0x6B, 0x66)
PRIMARY_D = RGBColor(0x0C, 0x54, 0x52)
GOLD = RGBColor(0xC9, 0xA2, 0x27)
GOLD_D = RGBColor(0x8A, 0x6E, 0x12)
GOLD_BG = RGBColor(0xF5, 0xE9, 0xC6)
TEXT = RGBColor(0x1E, 0x2F, 0x2F)
MUTED = RGBColor(0x5F, 0x7A, 0x7A)
CARD = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_TEAL = RGBColor(0xE7, 0xF0, 0xED)
BORDER = RGBColor(0xE0, 0xD8, 0xC2)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

TITLE_FONT = "Arial"
BODY_FONT = "Arial"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]
TITLE_L, TITLE_T, TITLE_W, TITLE_H = Inches(0.7), Inches(0.45), Inches(11.93), Inches(0.95)

def place_image_cover(slide, path, left, top, width, height):
    iw, ih = PILImage.open(path).size
    box_ar = float(width) / float(height)
    img_ar = iw / ih
    pic = slide.shapes.add_picture(path, left, top, width, height)
    if img_ar > box_ar:
        c = (1 - box_ar / img_ar) / 2
        pic.crop_left = c
        pic.crop_right = c
    else:
        total = 1 - img_ar / box_ar
        pic.crop_top = total * 0.2
        pic.crop_bottom = total * 0.8
    return pic

def set_bg(slide, color):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color

def add_tf(slide, left, top, width, height, anchor=MSO_ANCHOR.TOP):
    tx = slide.shapes.add_textbox(left, top, width, height)
    tf = tx.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    tf.vertical_anchor = anchor
    return tf

def set_run_font(run, font):
    run.font.name = font
    try:
        rPr = run._r.get_or_add_rPr()
        from pptx.oxml.base import OxmlElement
        for tag in ('a:ea', 'a:cs'):
            el = rPr.find(qn(tag))
            if el is None:
                el = OxmlElement(tag)
                rPr.append(el)
            el.set('typeface', font)
    except Exception:
        pass

def para(tf, text, font=BODY_FONT, size=Pt(16), bold=False, color=TEXT, first=False, space_after=Pt(4), align=PP_ALIGN.RIGHT, rtl=True):
    if first:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = text
    p.font.name = font
    p.font.size = size
    p.font.bold = bold
    p.font.color.rgb = color
    p.space_after = space_after
    p.space_before = Pt(0)
    p.line_spacing = 1.15
    p.alignment = align
    try:
        p._p.get_or_add_pPr().set('rtl', '1' if rtl else '0')
    except Exception:
        pass
    for run in p.runs:
        set_run_font(run, font)
    return p

def add_card(slide, left, top, w, h, fill=CARD, border=None, radius=0.08):
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, w, h)
    shp.fill.solid()
    shp.fill.fore_color.rgb = fill
    if border:
        shp.line.color.rgb = border
        shp.line.width = Pt(1)
    else:
        shp.line.fill.background()
    try:
        shp.adjustments[0] = radius
    except Exception:
        pass
    return shp

def add_gold_bar(slide, left, top, width):
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, Pt(4))
    bar.fill.solid()
    bar.fill.fore_color.rgb = GOLD
    bar.line.fill.background()
    return bar

def header(slide, kicker, title):
    tf = add_tf(slide, TITLE_L, TITLE_T, TITLE_W, TITLE_H)
    para(tf, kicker, font=BODY_FONT, size=Pt(12), bold=True, color=GOLD_D, first=True, space_after=Pt(1))
    para(tf, title, font=TITLE_FONT, size=Pt(27), bold=True, color=DARK, space_after=Pt(0))
    add_gold_bar(slide, Inches(13.333 - 0.7 - 1.6), Inches(1.55), Inches(1.6))

def footer(slide, num, total="12"):
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.7), Inches(7.0), Inches(11.93), Pt(1))
    line.fill.solid()
    line.fill.fore_color.rgb = BORDER
    line.line.fill.background()
    tf = add_tf(slide, Inches(0.7), Inches(7.05), Inches(7.0), Inches(0.35))
    para(tf, "ارائه پایان‌نامه کارشناسی ارشد  ·  قابل ویرایش و استفاده مجدد", font=BODY_FONT, size=Pt(9), color=MUTED, first=True, space_after=Pt(0))
    tf2 = add_tf(slide, Inches(10.6), Inches(7.05), Inches(1.93), Inches(0.35))
    para(tf2, num + " / " + total, font=BODY_FONT, size=Pt(9), color=MUTED, first=True, space_after=Pt(0))

def style_chart_text(chart, rgb):
    try:
        chart.font.color.rgb = rgb
        chart.font.size = Pt(11)
        chart.font.name = BODY_FONT
    except Exception:
        pass
    if chart.has_title:
        try:
            chart.chart_title.text_frame.paragraphs[0].font.color.rgb = rgb
        except Exception:
            pass
    # axes (skip for doughnut/pie which have none)
    try:
        axes = []
        try:
            axes.append(chart.category_axis)
        except Exception:
            pass
        try:
            axes.append(chart.value_axis)
        except Exception:
            pass
        for ax in axes:
            try:
                ax.tick_labels.font.color.rgb = rgb
                ax.tick_labels.font.size = Pt(10)
                ax.tick_labels.font.name = BODY_FONT
            except Exception:
                pass
    except Exception:
        pass
    if chart.has_legend:
        try:
            chart.legend.font.color.rgb = rgb
            chart.legend.font.size = Pt(10)
        except Exception:
            pass
    for plot in chart.plots:
        try:
            if plot.has_data_labels:
                plot.data_labels.font.color.rgb = rgb
                plot.data_labels.font.size = Pt(10)
        except Exception:
            pass

def style_table(tbl):
    for r in range(len(tbl.rows)):
        for c in range(len(tbl.columns)):
            cell = tbl.cell(r, c)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.text_frame.word_wrap = True
            cell.text_frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
            for p in cell.text_frame.paragraphs:
                p.alignment = PP_ALIGN.RIGHT
                try:
                    p._p.get_or_add_pPr().set('rtl', '1')
                except Exception:
                    pass
                for run in p.runs:
                    set_run_font(run, BODY_FONT)
            if r == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = DARK
                for p in cell.text_frame.paragraphs:
                    for run in p.runs:
                        run.font.color.rgb = WHITE
                        run.font.bold = True
                        run.font.size = Pt(12)
            else:
                cell.fill.solid()
                cell.fill.fore_color.rgb = CARD if r % 2 == 1 else LIGHT_TEAL
                for p in cell.text_frame.paragraphs:
                    for run in p.runs:
                        run.font.color.rgb = TEXT
                        run.font.size = Pt(11)
            cell.margin_right = Inches(0.08)
            cell.margin_left = Inches(0.08)
            cell.margin_top = Inches(0.03)
            cell.margin_bottom = Inches(0.03)

# ============ SLIDE 1 : Title ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, DARK)
place_image_cover(sl, "images/hero_university.png", Inches(0), Inches(0), Inches(5.9), Inches(7.5))
div = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(5.9), Inches(0), Pt(4), Inches(7.5))
div.fill.solid()
div.fill.fore_color.rgb = GOLD
div.line.fill.background()
tf = add_tf(sl, Inches(6.6), Inches(0.5), Inches(6.0), Inches(0.6))
para(tf, "نام دانشگاه  ·  دانشکده  ·  گروه آموزشی — اینجا بنویسید", font=BODY_FONT, size=Pt(12), color=GOLD, first=True, space_after=Pt(0))
tf2 = add_tf(sl, Inches(6.6), Inches(1.1), Inches(6.0), Inches(1.9))
para(tf2, "عنوان پایان‌نامه را اینجا بنویسید", font=TITLE_FONT, size=Pt(33), bold=True, color=WHITE, first=True, space_after=Pt(4))
para(tf2, "زیرعنوان یا یک جمله روشن از قلمرو و نوآوری پژوهش", font=BODY_FONT, size=Pt(13.5), color=RGBColor(0xD6, 0xE5, 0xE1))
add_gold_bar(sl, Inches(13.333 - 0.73 - 1.4), Inches(3.2), Inches(1.4))
infos = [("دانشجو", "نام و نام خانوادگی  ·  شماره دانشجویی"), ("استاد راهنما", "دکتر نام خانوادگی"), ("استاد مشاور / داور", "دکتر نام خانوادگی")]
for i, (k, v) in enumerate(infos):
    y = 3.6 + i * 0.85
    add_card(sl, Inches(6.6), Inches(y), Inches(6.0), Inches(0.72), fill=PANEL, radius=0.1)
    t = add_tf(sl, Inches(6.85), Inches(y + 0.07), Inches(5.55), Inches(0.58))
    para(t, k + ":  " + v, font=BODY_FONT, size=Pt(12), color=WHITE, first=True, space_after=Pt(0))
tfb = add_tf(sl, Inches(6.6), Inches(6.5), Inches(6.0), Inches(0.5))
para(tfb, "شهریور ۱۴۰۵  ·  جلسه دفاع کارشناسی ارشد", font=BODY_FONT, size=Pt(12), color=GOLD_BG, first=True)
sl.notes_slide.notes_text_frame.text = "این اسلاید افتتاحیه است. نام دانشگاه، عنوان کامل، نام دانشجو و اساتید را جایگزین کنید. عنوان را حداکثر در دو خط نگه دارید و از خواندن آن خودداری کنید؛ فقط سلام، معرفی و یک جمله درباره اهمیت موضوع بگویید."

# ============ SLIDE 2 : Agenda ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "نقشه راه  ·  در ۱ دقیقه بگویید چه می‌گویید", "ساختار ارائه")
steps = [("۱", "مقدمه", "بیان مسئله\nو ضرورت"), ("۲", "پیشینه", "ادبیات و\nمدل مفهومی"), ("۳", "روش", "طرح، نمونه\nو ابزار"), ("۴", "یافته‌ها", "نتایج اصلی\nبا نمودار"), ("۵", "بحث", "تفسیر\nو مقایسه"), ("۶", "جمع‌بندی", "نتیجه‌گیری\nو پیشنهاد")]
for i, (n, t, d) in enumerate(steps):
    x = 13.333 - 0.7 - 1.88 - i * 2.10
    add_card(sl, Inches(x), Inches(2.15), Inches(1.88), Inches(3.7), fill=CARD, border=BORDER, radius=0.08)
    if i == 3:
        top = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(2.15), Inches(1.88), Pt(9))
        top.fill.solid()
        top.fill.fore_color.rgb = GOLD
        top.line.fill.background()
        try:
            top.adjustments[0] = 0.25
        except Exception:
            pass
    circ = sl.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x + 0.63), Inches(2.45), Inches(0.62), Inches(0.62))
    circ.fill.solid()
    circ.fill.fore_color.rgb = PRIMARY if i == 3 else DARK
    circ.line.fill.background()
    tfn = add_tf(sl, Inches(x + 0.55), Inches(2.47), Inches(0.78), Inches(0.6))
    pp = para(tfn, n, font=TITLE_FONT, size=Pt(19), bold=True, color=WHITE, first=True)
    pp.alignment = PP_ALIGN.CENTER
    tf2 = add_tf(sl, Inches(x + 0.1), Inches(3.25), Inches(1.68), Inches(2.3))
    pp2 = para(tf2, t, font=TITLE_FONT, size=Pt(18), bold=True, color=DARK, first=True, space_after=Pt(6))
    pp2.alignment = PP_ALIGN.CENTER
    pp3 = para(tf2, d, font=BODY_FONT, size=Pt(11.5), color=MUTED, space_after=Pt(0))
    pp3.alignment = PP_ALIGN.CENTER
    if i < 5:
        arr = add_tf(sl, Inches(x - 0.28), Inches(3.6), Inches(0.3), Inches(0.5))
        ppA = para(arr, "◀", font=BODY_FONT, size=Pt(15), color=GOLD_D, first=True)
        ppA.alignment = PP_ALIGN.CENTER
tip = add_tf(sl, Inches(0.7), Inches(6.15), Inches(11.93), Inches(0.55))
para(tip, "راهنما: ترتیب اسلایدها از راست به چپ است؛ اگر بخشی ندارید کارت مربوط را حذف کنید.", font=BODY_FONT, size=Pt(11), color=MUTED, first=True)
footer(sl, "۰۲")
sl.notes_slide.notes_text_frame.text = "کل مسیر ارائه را نشان دهید تا داوران بدانند قرار است چه بشنوند. بیش از یک دقیقه روی این اسلاید نمانید."

# ============ SLIDE 3 : Problem ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "فصل اول  ·  مقدمه", "بیان مسئله و ضرورت پژوهش")
add_card(sl, Inches(6.85), Inches(1.9), Inches(5.78), Inches(4.8), fill=CARD, border=BORDER)
tf = add_tf(sl, Inches(7.15), Inches(2.1), Inches(5.2), Inches(4.4))
para(tf, "مسئله اصلی چیست؟", font=TITLE_FONT, size=Pt(16), bold=True, color=PRIMARY_D, first=True, space_after=Pt(6))
for b in ["خلاء یا چالش را در یک جمله روشن بنویسید؛ از کلی‌گویی پرهیز کنید.", "شاهد و آمار معتبر بیاورید: مثلا یک آمار رسمی از وضع موجود.", "پیامد عدم حل مسئله را بگویید: چرا این پژوهش الان مهم است."]:
    para(tf, "●  " + b, font=BODY_FONT, size=Pt(12.5), color=TEXT, space_after=Pt(6))
gaps = [("شکاف ۱", "نبود مدل بومی"), ("شکاف ۲", "داده به‌روز نیست"), ("شکاف ۳", "روش کم‌هزینه")]
for i, (t, d) in enumerate(gaps):
    x = 0.7 + i * 1.98
    add_card(sl, Inches(x), Inches(1.9), Inches(1.85), Inches(1.65), fill=DARK, radius=0.08)
    tt = add_tf(sl, Inches(x + 0.1), Inches(2.0), Inches(1.65), Inches(1.45))
    pp = para(tt, t, font=BODY_FONT, size=Pt(11), bold=True, color=GOLD, first=True, space_after=Pt(4))
    pp.alignment = PP_ALIGN.CENTER
    pp2 = para(tt, d, font=TITLE_FONT, size=Pt(13.5), bold=True, color=WHITE)
    pp2.alignment = PP_ALIGN.CENTER
add_card(sl, Inches(0.7), Inches(3.8), Inches(5.94), Inches(2.9), fill=WHITE, border=BORDER)
strip = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.7), Inches(3.8), Inches(5.94), Pt(10))
strip.fill.solid()
strip.fill.fore_color.rgb = GOLD
strip.line.fill.background()
try:
    strip.adjustments[0] = 0.2
except Exception:
    pass
tfi = add_tf(sl, Inches(1.0), Inches(4.15), Inches(5.35), Inches(2.3))
para(tfi, "چرا این پژوهش مهم است؟", font=TITLE_FONT, size=Pt(15), bold=True, color=DARK, first=True, space_after=Pt(6))
para(tfi, "دو تا سه جمله از جنبه نظری و کاربردی بنویسید: چه گرهی از ادبیات یا صنعت باز می‌کند و مخاطب اصلی آن چه کسی است.", font=BODY_FONT, size=Pt(12), color=MUTED)
footer(sl, "۰۳")
sl.notes_slide.notes_text_frame.text = "با یک داستان کوتاه یا آمار شروع کنید، سپس مسئله را دقیق بگویید. تمرکز این اسلاید بر چرایی است، نه چیستی. بیش از سه نکته نگویید."

# ============ SLIDE 4 : Objectives ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "اهداف  ·  سوالات  ·  فرضیه‌ها", "اهداف و سوالات پژوهش")
cards = [
    ("هدف اصلی", "بررسی تأثیر ... بر ... در ...", "اهداف فرعی: • شناسایی مؤلفه‌ها • ارائه مدل • اعتبارسنجی", PRIMARY),
    ("سوالات پژوهش", "۱. آیا ... بر ... اثر معنادار دارد؟", "۲. کدام مؤلفه بیشترین اثر را دارد؟\n۳. مدل پیشنهادی چقدر دقیق است؟", DARK),
    ("فرضیه‌ها", "H1: بین ... و ... رابطه معنادار وجود دارد.", "H2: مدل ... برازش قابل قبول دارد.\nنوع: کاربردی  ·  قلمرو: ...", GOLD_D),
]
for i, (t, b1, b2, accent) in enumerate(cards):
    x = 13.333 - 0.7 - 3.83 - i * 4.05
    add_card(sl, Inches(x), Inches(1.9), Inches(3.83), Inches(4.8), fill=CARD, border=BORDER)
    top = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(1.9), Inches(3.83), Pt(10))
    top.fill.solid()
    top.fill.fore_color.rgb = accent
    top.line.fill.background()
    try:
        top.adjustments[0] = 0.18
    except Exception:
        pass
    pill = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x + 2.35), Inches(2.25), Inches(1.1), Inches(0.42))
    pill.fill.solid()
    pill.fill.fore_color.rgb = LIGHT_TEAL
    pill.line.fill.background()
    try:
        pill.adjustments[0] = 0.35
    except Exception:
        pass
    ttp = add_tf(sl, Inches(x + 2.35), Inches(2.25), Inches(1.1), Inches(0.42), anchor=MSO_ANCHOR.MIDDLE)
    pp = para(ttp, t, font=BODY_FONT, size=Pt(11), bold=True, color=accent, first=True)
    pp.alignment = PP_ALIGN.CENTER
    tb = add_tf(sl, Inches(x + 0.3), Inches(2.9), Inches(3.25), Inches(3.45))
    para(tb, b1, font=BODY_FONT, size=Pt(12.5), color=TEXT, first=True, space_after=Pt(8))
    para(tb, b2, font=BODY_FONT, size=Pt(11.5), color=MUTED, space_after=Pt(0))
footer(sl, "۰۴")
sl.notes_slide.notes_text_frame.text = "هدف اصلی را در یک جمله بگویید و نشان دهید هر سوال به کدام یافته وصل می‌شود. اگر پژوهش کیفی است کارت فرضیه را به سوال کیفی تغییر دهید."

# ============ SLIDE 5 : Literature ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "فصل دوم  ·  مرور ادبیات", "پیشینه پژوهش و خلاء نظری")
add_card(sl, Inches(0.7), Inches(1.85), Inches(11.93), Inches(4.2), fill=CARD, border=BORDER)
tbl_shape = sl.shapes.add_table(4, 4, Inches(0.9), Inches(2.05), Inches(11.53), Inches(3.8))
tbl = tbl_shape.table
tbl.columns[0].width = Inches(2.6)
tbl.columns[1].width = Inches(2.7)
tbl.columns[2].width = Inches(3.4)
tbl.columns[3].width = Inches(2.83)
data = [
    ["پژوهشگر (سال)", "روش", "یافته کلیدی", "خلاء / نقد"],
    ["احمدی (۱۴۰۲)", "پیمایشی · 320 نمونه", "اثر مثبت و معنادار", "بدون مدل بومی"],
    ["اسمیت و همکاران (2023)", "آزمایشی · دو گروه", "بهبود ۱۸٪ در دقت", "نمونه محدود"],
    ["پژوهش حاضر (۱۴۰۵)", "ترکیبی · مدل جدید", "رفع خلاءهای بالا", "—"],
]
for r in range(4):
    for c in range(4):
        tbl.cell(r, c).text = data[r][c]
style_table(tbl)
tip = add_tf(sl, Inches(0.7), Inches(6.2), Inches(11.93), Inches(0.5))
para(tip, "راهنما: فقط ۳ تا ۴ پژوهش نزدیک را نگه دارید و ستون آخر را به «چرا کار من متفاوت است» وصل کنید.", font=BODY_FONT, size=Pt(11), color=MUTED, first=True)
footer(sl, "۰۵")
sl.notes_slide.notes_text_frame.text = "به‌جای خلاصه تک‌تک مقالات، جمع‌بندی کنید: چه می‌دانیم، چه نمی‌دانیم و کار شما کجا می‌ایستد. جدول را نخوانید، روایت کنید."

# ============ SLIDE 6 : Conceptual model ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "چارچوب نظری  ·  نقشه راه استدلال", "مدل مفهومی پژوهش")
boxes = [("ورودی‌ها", "متغیرهای\nمستقل", "X1 · X2", DARK), ("فرایند", "سازوکار\nواسط", "M: میانجی", PRIMARY), ("خروجی", "متغیر\nوابسته", "Y: نتیجه", GOLD_D)]
for i, (k, t, d, col) in enumerate(boxes):
    x = 13.333 - 0.7 - 2.9 - i * 4.0
    add_card(sl, Inches(x), Inches(2.25), Inches(2.9), Inches(2.75), fill=CARD, border=BORDER)
    top = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(2.25), Inches(2.9), Pt(10))
    top.fill.solid()
    top.fill.fore_color.rgb = col
    top.line.fill.background()
    try:
        top.adjustments[0] = 0.2
    except Exception:
        pass
    tfb = add_tf(sl, Inches(x + 0.25), Inches(2.6), Inches(2.4), Inches(2.15))
    pp = para(tfb, k, font=BODY_FONT, size=Pt(12), bold=True, color=col, first=True, space_after=Pt(2))
    pp.alignment = PP_ALIGN.CENTER
    pp2 = para(tfb, t, font=TITLE_FONT, size=Pt(21), bold=True, color=DARK, space_after=Pt(4))
    pp2.alignment = PP_ALIGN.CENTER
    pp3 = para(tfb, d, font=BODY_FONT, size=Pt(12), color=MUTED)
    pp3.alignment = PP_ALIGN.CENTER
    if i < 2:
        arr = add_tf(sl, Inches(x - 0.85), Inches(3.3), Inches(0.6), Inches(0.6))
        ppA = para(arr, "◀", font=BODY_FONT, size=Pt(26), bold=True, color=GOLD, first=True)
        ppA.alignment = PP_ALIGN.CENTER
add_card(sl, Inches(0.7), Inches(5.3), Inches(11.93), Inches(1.0), fill=DARK, radius=0.1)
tfl = add_tf(sl, Inches(1.0), Inches(5.4), Inches(11.33), Inches(0.8), anchor=MSO_ANCHOR.MIDDLE)
para(tfl, "منطق مدل:  اگر X افزایش یابد، از طریق M ، Y بهبود می‌یابد  —  این جمله را با متغیرهای خودتان جایگزین کنید.", font=BODY_FONT, size=Pt(13), color=WHITE, first=True)
footer(sl, "۰۶")
sl.notes_slide.notes_text_frame.text = "مدل را از راست به چپ بخوانید: ورودی‌ها، فرایند و خروجی. بگویید چرا این ترتیب منطقی است و فرضیه‌ها چطور از آن می‌آیند."

# ============ SLIDE 7 : Method ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "فصل سوم  ·  روش‌شناسی", "روش‌شناسی پژوهش")
add_card(sl, Inches(9.1), Inches(1.9), Inches(3.53), Inches(4.8), fill=CARD, border=BORDER)
place_image_cover(sl, "images/method_flatlay.png", Inches(9.25), Inches(2.05), Inches(3.23), Inches(2.6))
timg = add_tf(sl, Inches(9.35), Inches(4.8), Inches(3.03), Inches(1.75))
para(timg, "مشخصات طرح", font=TITLE_FONT, size=Pt(13), bold=True, color=DARK, first=True, space_after=Pt(4))
para(timg, "● نوع: کاربردی  ·  طرح: توصیفی – پیمایشی", font=BODY_FONT, size=Pt(11), color=TEXT, space_after=Pt(3))
para(timg, "● نمونه: ۳۸۴ نفر  ·  نمونه‌گیری تصادفی", font=BODY_FONT, size=Pt(11), color=TEXT)
steps_m = [("۱", "جامعه و نمونه", "جامعه ...، حجم نمونه با فرمول کوکران"), ("۲", "ابزار گردآوری", "پرسش‌نامه ... · مصاحبه ..."), ("۳", "روایی و پایایی", "روایی محتوا  ·  آلفای کرونباخ ۰/۸۷"), ("۴", "تحلیل داده‌ها", "نرم‌افزار ... · آزمون ...")]
for i, (n, t, d) in enumerate(steps_m):
    y = 1.9 + i * 1.24
    add_card(sl, Inches(0.7), Inches(y), Inches(8.15), Inches(1.09), fill=CARD, border=BORDER)
    nb = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(7.7), Inches(y + 0.18), Inches(0.72), Inches(0.72))
    nb.fill.solid()
    nb.fill.fore_color.rgb = PRIMARY if i == 3 else DARK
    nb.line.fill.background()
    try:
        nb.adjustments[0] = 0.2
    except Exception:
        pass
    tfn = add_tf(sl, Inches(7.7), Inches(y + 0.2), Inches(0.72), Inches(0.7), anchor=MSO_ANCHOR.MIDDLE)
    ppn = para(tfn, n, font=TITLE_FONT, size=Pt(17), bold=True, color=WHITE, first=True)
    ppn.alignment = PP_ALIGN.CENTER
    ttt = add_tf(sl, Inches(0.95), Inches(y + 0.1), Inches(6.55), Inches(0.9))
    para(ttt, t, font=TITLE_FONT, size=Pt(13), bold=True, color=DARK, first=True, space_after=Pt(1))
    para(ttt, d, font=BODY_FONT, size=Pt(11.5), color=MUTED)
footer(sl, "۰۷")
sl.notes_slide.notes_text_frame.text = "روش را دفاع کنید: چرا این طرح و این نمونه برای سوال شما مناسب است. روایی و پایایی را با عدد بگویید چون داوران حتما می‌پرسند. اعداد نمونه‌ای است؛ جایگزین کنید."

# ============ SLIDE 8 : Tools ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "ابزار و تحلیل  ·  چطور اطمینان دادیم؟", "ابزار گردآوری و تحلیل")
add_card(sl, Inches(0.7), Inches(1.9), Inches(5.85), Inches(4.8), fill=CARD, border=BORDER)
add_card(sl, Inches(6.78), Inches(1.9), Inches(5.85), Inches(4.8), fill=CARD, border=BORDER)
tr = add_tf(sl, Inches(7.08), Inches(2.1), Inches(5.25), Inches(3.1))
para(tr, "گردآوری داده‌ها", font=TITLE_FONT, size=Pt(16), bold=True, color=DARK, first=True, space_after=Pt(6))
for b in ["پرسش‌نامه استاندارد ... (۲۴ گویه، طیف لیکرت ۵تایی)", "مصاحبه نیمه‌ساختاریافته با ۱۲ خبره", "داده‌های ثانویه: اسناد و آمار رسمی"]:
    para(tr, "●  " + b, font=BODY_FONT, size=Pt(12), color=TEXT, space_after=Pt(5))
vb = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(7.08), Inches(5.4), Inches(5.25), Inches(1.0))
vb.fill.solid()
vb.fill.fore_color.rgb = LIGHT_TEAL
vb.line.fill.background()
try:
    vb.adjustments[0] = 0.12
except Exception:
    pass
tvb = add_tf(sl, Inches(7.2), Inches(5.5), Inches(5.0), Inches(0.8), anchor=MSO_ANCHOR.MIDDLE)
para(tvb, "روایی محتوا تأیید شد (۱۰ خبره)  ·  پایایی: آلفا = ۰/۸۷", font=BODY_FONT, size=Pt(11.5), bold=True, color=PRIMARY_D, first=True)
tl = add_tf(sl, Inches(1.0), Inches(2.1), Inches(5.25), Inches(3.1))
para(tl, "تحلیل داده‌ها", font=TITLE_FONT, size=Pt(16), bold=True, color=DARK, first=True, space_after=Pt(6))
for b in ["توصیفی: میانگین، انحراف معیار، جدول فراوانی", "استنباطی: تی مستقل، رگرسیون، مدل‌یابی معادلات", "نرم‌افزار: SPSS · SmartPLS · MAXQDA"]:
    para(tl, "●  " + b, font=BODY_FONT, size=Pt(12), color=TEXT, space_after=Pt(5))
ab = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.0), Inches(5.4), Inches(5.25), Inches(1.0))
ab.fill.solid()
ab.fill.fore_color.rgb = DARK
ab.line.fill.background()
try:
    ab.adjustments[0] = 0.12
except Exception:
    pass
tab = add_tf(sl, Inches(1.1), Inches(5.5), Inches(5.05), Inches(0.8), anchor=MSO_ANCHOR.MIDDLE)
para(tab, "سطح معناداری ۰/۰۵  ·  توان آزمون ۰/۸۰", font=BODY_FONT, size=Pt(12), bold=True, color=WHITE, first=True)
footer(sl, "۰۸")
sl.notes_slide.notes_text_frame.text = "توضیح دهید چرا این ابزار و این آزمون‌ها برای سوال شما مناسب است. اعداد روایی و پایایی را آماده داشته باشید چون داوران حتما می‌پرسند."

# ============ SLIDE 9 : Findings ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "فصل چهارم  ·  نتایج", "یافته‌های اصلی پژوهش")
kpis = [("۳۲٪+", "بهبود شاخص اصلی"), ("p < ۰/۰۱", "معناداری آزمون"), ("۰/۷۴", "توان تبیین (R2)")]
for i, (v, l) in enumerate(kpis):
    x = 13.333 - 0.7 - 2.2 - i * 2.45
    c = add_card(sl, Inches(x), Inches(1.8), Inches(2.2), Inches(1.05), fill=PRIMARY if i == 0 else CARD, border=None if i == 0 else BORDER, radius=0.1)
    tv = add_tf(sl, Inches(x + 0.15), Inches(1.87), Inches(1.9), Inches(0.9), anchor=MSO_ANCHOR.MIDDLE)
    ppv = para(tv, v, font=TITLE_FONT, size=Pt(19), bold=True, color=WHITE if i == 0 else DARK, first=True, space_after=Pt(1))
    ppv.alignment = PP_ALIGN.CENTER
    ppl = para(tv, l, font=BODY_FONT, size=Pt(10.5), color=GOLD_BG if i == 0 else MUTED)
    ppl.alignment = PP_ALIGN.CENTER
add_card(sl, Inches(0.7), Inches(3.05), Inches(7.7), Inches(3.65), fill=CARD, border=BORDER)
ct = add_tf(sl, Inches(0.95), Inches(3.15), Inches(7.2), Inches(0.5))
para(ct, "مقایسه میانگین قبل و بعد — نمودار نمونه است، با داده‌های خودتان جایگزین کنید", font=BODY_FONT, size=Pt(11), bold=True, color=MUTED, first=True)
cdata = CategoryChartData()
cdata.categories = ["گروه گواه", "گروه کنترل"]
cdata.add_series("پیش‌آزمون", (3.1, 3.0))
cdata.add_series("پس‌آزمون", (4.2, 3.2))
gf = sl.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.95), Inches(3.65), Inches(7.2), Inches(2.8), cdata)
chart = gf.chart
chart.has_title = False
chart.has_legend = True
chart.legend.position = XL_LEGEND_POSITION.BOTTOM
chart.legend.include_in_layout = False
chart.plots[0].has_data_labels = True
try:
    chart.value_axis.minimum_scale = 0
    chart.value_axis.maximum_scale = 5
    chart.value_axis.has_major_gridlines = True
    chart.value_axis.major_gridlines.format.line.color.rgb = BORDER
    chart.value_axis.major_gridlines.format.line.width = Pt(0.75)
except Exception:
    pass
try:
    chart.series[0].format.fill.solid()
    chart.series[0].format.fill.fore_color.rgb = RGBColor(0xB9, 0xC9, 0xC5)
    chart.series[0].format.line.fill.background()
    chart.series[1].format.fill.solid()
    chart.series[1].format.fill.fore_color.rgb = PRIMARY
    chart.series[1].format.line.fill.background()
except Exception:
    pass
style_chart_text(chart, TEXT)
add_card(sl, Inches(8.63), Inches(3.05), Inches(4.0), Inches(3.65), fill=DARK, radius=0.1)
ts = add_tf(sl, Inches(8.93), Inches(3.25), Inches(3.4), Inches(3.25))
para(ts, "چه بخوانیم؟", font=TITLE_FONT, size=Pt(15), bold=True, color=GOLD, first=True, space_after=Pt(8))
for b in ["گروه گواه ۱/۱ واحد رشد کرد؛ گروه کنترل تغییر نکرد.", "اثر بزرگ است (d=۰/۸۱) و از نظر آماری معنادار.", "این عددها را با پژوهش‌های پیشین مقایسه کنید."]:
    para(ts, "●  " + b, font=BODY_FONT, size=Pt(11.5), color=WHITE, space_after=Pt(6))
footer(sl, "۰۹")
sl.notes_slide.notes_text_frame.text = "فقط دو تا سه یافته کلیدی را نشان دهید. نمودار را بخوانید و بلافاصله بگویید چه معنایی دارد. جزییات آماری را به پیوست منتقل کنید."

# ============ SLIDE 10 : Discussion ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "تفسیر  ·  مقایسه با ادبیات", "بحث و تفسیر نتایج")
add_card(sl, Inches(0.7), Inches(1.9), Inches(4.6), Inches(4.8), fill=CARD, border=BORDER)
dt = add_tf(sl, Inches(0.95), Inches(2.05), Inches(4.1), Inches(0.55))
para(dt, "سهم مؤلفه‌ها در تبیین نتیجه", font=BODY_FONT, size=Pt(12), bold=True, color=MUTED, first=True)
ddata = CategoryChartData()
ddata.categories = ["مؤلفه A", "مؤلفه B", "سایر"]
ddata.add_series("سهم", (48, 32, 20))
gf2 = sl.shapes.add_chart(XL_CHART_TYPE.DOUGHNUT, Inches(0.95), Inches(2.6), Inches(4.1), Inches(2.7), ddata)
ch2 = gf2.chart
ch2.has_title = False
ch2.has_legend = True
ch2.legend.position = XL_LEGEND_POSITION.BOTTOM
ch2.legend.include_in_layout = False
ch2.plots[0].has_data_labels = True
try:
    dl = ch2.plots[0].data_labels
    dl.show_percentage = True
    dl.show_category_name = False
    dl.show_value = False
    dl.position = XL_LABEL_POSITION.OUTSIDE_END
    ch2.plots[0].doughnut_hole_size = 52
except Exception:
    pass
try:
    cols = [PRIMARY, GOLD, RGBColor(0xB9, 0xC9, 0xC5)]
    for idx, pt in enumerate(ch2.series[0].points):
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = cols[idx % 3]
        pt.format.line.fill.background()
except Exception:
    pass
style_chart_text(ch2, TEXT)
tcenter = add_tf(sl, Inches(1.95), Inches(3.5), Inches(2.1), Inches(0.9), anchor=MSO_ANCHOR.MIDDLE)
ppc = para(tcenter, "تبیین", font=BODY_FONT, size=Pt(11), color=MUTED, first=True, space_after=Pt(0))
ppc.alignment = PP_ALIGN.CENTER
ppc2 = para(tcenter, "۸۰٪", font=TITLE_FONT, size=Pt(26), bold=True, color=DARK)
ppc2.alignment = PP_ALIGN.CENTER
interp = [
    ("هم‌سو با پیشینه", "نتیجه ... با احمدی (۱۴۰۲) هم‌خوان است؛ اما اثر قوی‌تر است زیرا ...", PRIMARY),
    ("تفاوت کلیدی", "برخلاف اسمیت (2023)، مؤلفه B در بافت بومی کم‌رنگ‌تر بود؛ دلیل ...", GOLD),
    ("دلیل احتمالی", "تفاوت نمونه، ابزار یا بافت فرهنگی می‌تواند توضیح‌دهنده باشد.", DARK),
]
for i, (t, d, col) in enumerate(interp):
    y = 1.9 + i * 1.65
    add_card(sl, Inches(5.53), Inches(y), Inches(7.1), Inches(1.5), fill=CARD, border=BORDER)
    bar = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(12.35), Inches(y + 0.19), Pt(7), Inches(1.12))
    bar.fill.solid()
    bar.fill.fore_color.rgb = col
    bar.line.fill.background()
    try:
        bar.adjustments[0] = 0.4
    except Exception:
        pass
    tt = add_tf(sl, Inches(5.83), Inches(y + 0.15), Inches(6.3), Inches(1.2))
    para(tt, t, font=BODY_FONT, size=Pt(12), bold=True, color=DARK, first=True, space_after=Pt(3))
    para(tt, d, font=BODY_FONT, size=Pt(11.5), color=MUTED)
footer(sl, "۱۰")
sl.notes_slide.notes_text_frame.text = "اینجا فرصت دفاع از تحلیل است: چرا نتیجه این‌طور شد و چرا با برخی پژوهش‌ها فرق دارد. صادقانه محدودیت‌ها را هم بگویید."

# ============ SLIDE 11 : Conclusion ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, CREAM)
header(sl, "جمع‌بندی  ·  پاسخ به سوال اصلی", "نتیجه‌گیری و پیشنهادها")
add_card(sl, Inches(6.78), Inches(1.9), Inches(5.85), Inches(4.8), fill=DARK, radius=0.1)
tc = add_tf(sl, Inches(7.08), Inches(2.1), Inches(5.25), Inches(4.4))
para(tc, "✓  نتیجه‌گیری", font=TITLE_FONT, size=Pt(16), bold=True, color=GOLD, first=True, space_after=Pt(8))
for b in ["پاسخ روشن به سوال اصلی: ... تأثیر دارد.", "سه پیام کلیدی که داور باید به خاطر بسپارد.", "مشارکت نظری: توسعه مدل ... در بافت ..."]:
    para(tc, b, font=BODY_FONT, size=Pt(12), color=WHITE, space_after=Pt(6))
add_card(sl, Inches(0.7), Inches(1.9), Inches(5.85), Inches(4.8), fill=CARD, border=BORDER)
ts2 = add_tf(sl, Inches(1.0), Inches(2.1), Inches(5.25), Inches(4.4))
para(ts2, "پیشنهادها", font=TITLE_FONT, size=Pt(16), bold=True, color=DARK, first=True, space_after=Pt(8))
para(ts2, "کاربردی:", font=BODY_FONT, size=Pt(12), bold=True, color=PRIMARY_D, space_after=Pt(3))
para(ts2, "●  پیشنهاد اول برای سیاست‌گذار یا صنعت — قابل اجرا در ...", font=BODY_FONT, size=Pt(11.5), color=TEXT, space_after=Pt(3))
para(ts2, "●  پیشنهاد دوم — اولویت‌بندی بر اساس اثر", font=BODY_FONT, size=Pt(11.5), color=TEXT, space_after=Pt(6))
para(ts2, "پژوهشی:", font=BODY_FONT, size=Pt(12), bold=True, color=PRIMARY_D, space_after=Pt(3))
para(ts2, "●  تکرار با نمونه بزرگ‌تر و روش ترکیبی", font=BODY_FONT, size=Pt(11.5), color=TEXT)
footer(sl, "۱۱")
sl.notes_slide.notes_text_frame.text = "با پاسخ صریح به سوال اصلی شروع کنید، سپس دو پیشنهاد کاربردی و یک پیشنهاد پژوهشی بگویید. پیشنهادها باید از یافته‌ها بیایند، نه کلی."

# ============ SLIDE 12 : Limits + Thanks ============
sl = prs.slides.add_slide(BLANK)
set_bg(sl, DARK)
topline = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Pt(5))
topline.fill.solid()
topline.fill.fore_color.rgb = GOLD
topline.line.fill.background()
place_image_cover(sl, "images/library.png", Inches(0), Inches(0.08), Inches(5.9), Inches(7.42))
cap_bg = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.5), Inches(5.9), Inches(4.9), Inches(1.0))
cap_bg.fill.solid()
cap_bg.fill.fore_color.rgb = DARK
cap_bg.line.fill.background()
try:
    cap_bg.adjustments[0] = 0.1
except Exception:
    pass
cap = add_tf(sl, Inches(0.65), Inches(6.0), Inches(4.6), Inches(0.8), anchor=MSO_ANCHOR.MIDDLE)
para(cap, "نکته: این اسلاید پایانی است؛ صادقانه محدودیت‌ها را بگویید تا اعتماد بسازید.", font=BODY_FONT, size=Pt(11), color=WHITE, first=True)
tf = add_tf(sl, Inches(6.7), Inches(0.55), Inches(5.9), Inches(0.6))
para(tf, "محدودیت‌ها و مسیر آینده", font=BODY_FONT, size=Pt(13), bold=True, color=GOLD, first=True)
tf2 = add_tf(sl, Inches(6.7), Inches(1.05), Inches(5.9), Inches(1.1))
para(tf2, "سپاس از توجه شما", font=TITLE_FONT, size=Pt(36), bold=True, color=WHITE, first=True, space_after=Pt(2))
tf3 = add_tf(sl, Inches(6.7), Inches(2.2), Inches(5.9), Inches(0.55))
para(tf3, "آماده پاسخ‌گویی به پرسش‌های شما هستم  —  پرسش و پاسخ", font=BODY_FONT, size=Pt(13.5), color=RGBColor(0xD6, 0xE5, 0xE1), first=True)
add_card(sl, Inches(9.78), Inches(3.05), Inches(2.85), Inches(1.9), fill=PANEL, radius=0.1)
add_card(sl, Inches(6.7), Inches(3.05), Inches(2.85), Inches(1.9), fill=PANEL, radius=0.1)
t0 = add_tf(sl, Inches(9.93), Inches(3.2), Inches(2.55), Inches(1.6))
para(t0, "محدودیت‌ها", font=BODY_FONT, size=Pt(12), bold=True, color=GOLD, first=True, space_after=Pt(4))
para(t0, "• نمونه محدود به ...\n• بازه زمانی ...", font=BODY_FONT, size=Pt(11), color=WHITE)
t1 = add_tf(sl, Inches(6.85), Inches(3.2), Inches(2.55), Inches(1.6))
para(t1, "کارهای آتی", font=BODY_FONT, size=Pt(12), bold=True, color=GOLD, first=True, space_after=Pt(4))
para(t1, "• بررسی در بافت ...\n• استفاده از روش ...", font=BODY_FONT, size=Pt(11), color=WHITE)
contact = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.7), Inches(5.25), Inches(5.9), Inches(1.15))
contact.fill.solid()
contact.fill.fore_color.rgb = PANEL
contact.line.color.rgb = GOLD
contact.line.width = Pt(1)
try:
    contact.adjustments[0] = 0.12
except Exception:
    pass
tcon = add_tf(sl, Inches(6.9), Inches(5.4), Inches(5.5), Inches(0.9), anchor=MSO_ANCHOR.MIDDLE)
para(tcon, "ایمیل: name@univ.ac.ir  ·  این متن را با اطلاعات خودتان جایگزین کنید", font=BODY_FONT, size=Pt(11), color=WHITE, first=True)
sl.notes_slide.notes_text_frame.text = "با تشکر و دعوت به پرسش تمام کنید. انتظار سوال درباره روش و تعمیم‌پذیری را داشته باشید و به محدودیت‌ها صادقانه اشاره کنید."

prs.save("output.pptx")
print("saved 12 slides")
