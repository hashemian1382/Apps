# Slides Workspace

Python environment with python-pptx, Pillow, and httpx pre-installed.

Write a script (e.g. `generate_slides.py`) that creates a presentation
and saves it to `output.pptx`, then run `build_slides()`.
