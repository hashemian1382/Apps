import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlarmClock, Archive, BarChart3, CalendarDays, CheckCircle2, Copy,
  Database, Download, House, Moon, Settings as SettingsIcon, Sparkles, Sun, X,
} from "lucide-react";
import {
  buildDaySummary, currentJalali, dayStats, emptyDay, formatJalaliLong,
  formatJalaliShort, loadData, persist, todayISO, toFa, type AppData,
} from "./lib/core";
import DayView from "./components/DayView";
import BacklogView from "./components/BacklogView";
import ReportsView from "./components/ReportsView";
import CalendarView from "./components/CalendarView";
import SettingsView from "./components/SettingsView";

export type ViewKey = "today" | "backlog" | "reports" | "calendar" | "settings";

const ACCENTS: Record<string, string> = {
  emerald: "16 185 129",
  blue: "59 130 246",
  violet: "139 92 246",
  rose: "244 63 94",
  amber: "245 158 11",
  teal: "20 184 166",
};

export default function App() {
  const [data, setData] = useState<AppData>(() => loadData());
  const [view, setView] = useState<ViewKey>("today");
  const [date, setDate] = useState<string>(todayISO());
  const [toast, setToast] = useState<string | null>(null);

  const tISO = todayISO();

  useEffect(() => { persist(data); }, [data]);
  useEffect(() => {
    const s = data.settings;
    document.documentElement.classList.toggle("dark", s.theme === "dark");
    document.documentElement.style.setProperty("--accent", ACCENTS[s.accent] || ACCENTS.emerald);
    document.body.classList.toggle("font-large-mode", s.fontScale === "large");
    document.documentElement.lang = "fa";
    document.documentElement.dir = "rtl";
  }, [data.settings]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const notify = (m: string) => setToast(m);

  const day = useMemo(() => data.days[date] ?? emptyDay(date), [data.days, date]);
  const activeHabits = data.habits.filter((h) => h.active);
  const stats = dayStats(day, activeHabits.length);

  const goDay = (iso: string) => { setDate(iso); setView("today"); window.scrollTo({ top: 0, behavior: "smooth" }); };

  const copySummary = async () => {
    const text = buildDaySummary(day, data.categories, data.habits);
    try {
      await navigator.clipboard.writeText(text);
      notify("خلاصه روز در کلیپ‌بورد کپی شد ✓");
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); } catch { /* noop */ }
      ta.remove();
      notify("خلاصه روز کپی شد ✓");
    }
  };

  const exportBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const j = currentJalali();
    a.href = url;
    a.download = `roozaneh-backup-${j.jy}-${j.jm}-${j.jd}.json`;
    a.click();
    URL.revokeObjectURL(url);
    notify("فایل بکاپ دانلود شد");
  };

  const NAV: { k: ViewKey; label: string; desc: string; icon: React.ReactNode }[] = [
    { k: "today", label: "روز جاری", desc: "قلب برنامه", icon: <House size={19} /> },
    { k: "backlog", label: "بک‌لاگ", desc: `${toFa(data.backlog.filter((b) => !b.done).length)} کار باز`, icon: <Archive size={19} /> },
    { k: "reports", label: "گزارش و عملکرد", desc: "هفتگی • ماهانه", icon: <BarChart3 size={19} /> },
    { k: "calendar", label: "تقویم", desc: "نمای ماهانه", icon: <CalendarDays size={19} /> },
    { k: "settings", label: "تنظیمات", desc: "داده و ظاهر", icon: <SettingsIcon size={19} /> },
  ];

  const isToday = date === tISO;

  return (
    <div className="min-h-screen bg-[#f6f4ee] text-stone-800 transition-colors dark:bg-[#0c0c0e] dark:text-zinc-100">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 left-1/4 h-96 w-96 rounded-full bg-emerald-300/20 blur-[110px] dark:bg-emerald-500/10" />
        <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-amber-200/30 blur-[100px] dark:bg-violet-500/10" />
        <div className="absolute left-0 top-1/3 h-64 w-64 rounded-full bg-sky-200/25 blur-[100px] dark:bg-sky-500/[0.07]" />
      </div>

      <header className="fixed inset-x-0 top-0 z-40 border-b border-stone-200/70 bg-white/80 backdrop-blur-xl dark:border-white/10 dark:bg-zinc-950/80">
        <div className="mx-auto flex h-[68px] max-w-[1400px] items-center justify-between gap-2 px-3 sm:px-5">
          <button onClick={() => { setView("today"); setDate(tISO); }} className="flex items-center gap-2.5 text-right">
            <span className="bg-accent grid h-10 w-10 place-items-center rounded-2xl text-xl text-white shadow-lg">🌿</span>
            <span className="leading-tight">
              <span className="block text-[16px] font-black">روزانه</span>
              <span className="block text-[11px] font-medium text-stone-400 dark:text-zinc-500">سامانه مدیریت شخصی روزانه</span>
            </span>
          </button>

          <button
            onClick={() => { setDate(tISO); setView("today"); }}
            className="bg-accent-soft hidden items-center gap-2 rounded-2xl px-4 py-2 transition hover:brightness-[0.97] sm:flex"
            title="برو به امروز"
          >
            <CalendarDays size={16} className="text-accent" />
            <span className="text-[13px] font-extrabold">{formatJalaliLong(tISO)}</span>
            <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-black text-white">امروز</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-1.5 rounded-full border border-stone-200 bg-white px-3 py-1.5 text-[11px] font-bold text-stone-500 md:inline-flex dark:border-white/10 dark:bg-white/5 dark:text-zinc-400">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
              ذخیره خودکار محلی
            </span>
            <button
              onClick={() => setData((p) => ({ ...p, settings: { ...p.settings, theme: p.settings.theme === "dark" ? "light" : "dark" } }))}
              className="grid h-10 w-10 place-items-center rounded-2xl border border-stone-200 bg-white text-stone-500 transition hover:bg-stone-50 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-zinc-300"
              title="حالت شب / روز"
            >
              {data.settings.theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <button onClick={exportBackup} className="hidden h-10 items-center gap-2 rounded-2xl border border-stone-200 bg-white px-3.5 text-[13px] font-bold text-stone-600 transition hover:bg-stone-50 active:scale-95 sm:inline-flex dark:border-white/10 dark:bg-white/5 dark:text-zinc-300 dark:hover:bg-white/10">
              <Download size={15} /> بکاپ
            </button>
            <button onClick={() => setView("settings")} className="bg-accent grid h-10 w-10 place-items-center rounded-2xl text-white shadow-lg transition hover:brightness-110 active:scale-95" title="تنظیمات">
              <SettingsIcon size={17} />
            </button>
          </div>
        </div>
        <div className="border-t border-stone-100 px-4 py-1.5 text-center text-[12px] font-bold text-stone-500 sm:hidden dark:border-white/5 dark:text-zinc-400">
          {formatJalaliLong(tISO)}
        </div>
      </header>

      <div className="relative mx-auto flex max-w-[1400px] gap-5 px-3 pb-28 pt-[132px] sm:px-5 sm:pt-[92px] lg:pb-12">
        <aside className="sticky top-[92px] hidden h-fit w-[248px] shrink-0 flex-col gap-2 lg:flex">
          <div className="rounded-3xl border border-stone-200/80 bg-white p-3 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.12)] dark:border-white/10 dark:bg-zinc-900">
            {NAV.map((n) => {
              const active = view === n.k;
              return (
                <button
                  key={n.k}
                  onClick={() => { setView(n.k); if (n.k === "today") setDate(tISO); }}
                  className={`mb-1 flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-right transition last:mb-0 ${active ? "bg-accent text-white shadow-lg" : "text-stone-600 hover:bg-stone-100 dark:text-zinc-300 dark:hover:bg-white/5"}`}
                >
                  <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${active ? "bg-white/20" : "bg-accent-soft text-accent"}`}>{n.icon}</span>
                  <span className="leading-tight">
                    <span className="block text-[13.5px] font-extrabold">{n.label}</span>
                    <span className={`block text-[11px] ${active ? "text-white/80" : "text-stone-400 dark:text-zinc-500"}`}>{n.desc}</span>
                  </span>
                </button>
              );
            })}
          </div>

          <div className="rounded-3xl border border-stone-200/80 bg-white p-4 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.12)] dark:border-white/10 dark:bg-zinc-900">
            <div className="mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[12px] font-extrabold text-stone-600 dark:text-zinc-300"><Sparkles size={14} className="text-accent" /> پیشرفت {isToday ? "امروز" : formatJalaliShort(date)}</span>
              <span className="text-accent text-[12px] font-black">{toFa(stats.overall)}٪</span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-stone-100 dark:bg-white/10" dir="ltr">
              <div className="bg-accent h-full rounded-full transition-all" style={{ width: `${stats.overall}%`, marginLeft: "auto" }} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-center">
              <div className="rounded-2xl bg-stone-50 px-2 py-2 dark:bg-white/5">
                <p className="text-[15px] font-black">{toFa(stats.tasksDone)}/{toFa(stats.tasksTotal)}</p>
                <p className="text-[10.5px] text-stone-400 dark:text-zinc-500">تسک انجام‌شده</p>
              </div>
              <div className="rounded-2xl bg-stone-50 px-2 py-2 dark:bg-white/5">
                <p className="text-[15px] font-black">{toFa(stats.habitsDone)}/{toFa(activeHabits.length)}</p>
                <p className="text-[10.5px] text-stone-400 dark:text-zinc-500">عادت انجام‌شده</p>
              </div>
            </div>
            <button onClick={copySummary} className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-stone-300 px-3.5 py-2 text-[12px] font-bold text-stone-500 transition hover:bg-stone-50 dark:border-white/15 dark:text-zinc-300 dark:hover:bg-white/5">
              <Copy size={14} /> کپی خلاصه روز
            </button>
          </div>

          <div className="rounded-3xl border border-dashed border-stone-300 bg-white/60 p-4 text-[11.5px] leading-6 text-stone-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-zinc-400">
            <p className="mb-1 flex items-center gap-1.5 font-extrabold text-stone-600 dark:text-zinc-300"><AlarmClock size={14} className="text-accent" /> جریان روز</p>
            صبح هدف اصلی را بنویس ← طول روز تسک و عادت بزن ← شب گزارش و امتیاز بده.
          </div>
        </aside>

        <main className="min-w-0 flex-1">
          <AnimatePresence mode="wait">
            <motion.div key={view + date} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
              {view === "today" && (
                <DayView data={data} setData={setData} date={date} setDate={setDate} notify={notify} onCopy={copySummary} onOpenCalendar={(iso) => { setDate(iso); setView("calendar"); }} />
              )}
              {view === "backlog" && (
                <BacklogView data={data} setData={setData} notify={notify} goToday={(iso) => goDay(iso)} />
              )}
              {view === "reports" && <ReportsView data={data} goDay={goDay} />}
              {view === "calendar" && <CalendarView data={data} selected={date} onSelect={goDay} />}
              {view === "settings" && <SettingsView data={data} setData={setData} notify={notify} />}
            </motion.div>
          </AnimatePresence>

          <footer className="mt-8 hidden items-center justify-between rounded-3xl border border-stone-200/70 bg-white/70 px-5 py-3.5 text-[11.5px] text-stone-400 lg:flex dark:border-white/10 dark:bg-white/[0.03] dark:text-zinc-500">
            <span className="flex items-center gap-1.5"><Database size={13} /> همه داده‌ها فقط در مرورگر شما ذخیره می‌شود — بدون سرور، بدون حساب کاربری.</span>
            <span className="flex items-center gap-1.5 font-bold"><CheckCircle2 size={13} className="text-emerald-500" /> {toFa(Object.keys(data.days).length)} روز ثبت‌شده</span>
          </footer>
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-stone-200 bg-white/90 px-2 pb-[max(8px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl lg:hidden dark:border-white/10 dark:bg-zinc-950/90">
        <div className="mx-auto grid max-w-lg grid-cols-5 gap-1">
          {NAV.map((n) => {
            const active = view === n.k;
            return (
              <button key={n.k} onClick={() => { setView(n.k); if (n.k === "today") setDate(tISO); }}
                className={`flex flex-col items-center gap-1 rounded-2xl py-2 text-[10px] font-extrabold transition ${active ? "text-accent" : "text-stone-400 dark:text-zinc-500"}`}>
                <span className={`grid h-9 w-12 place-items-center rounded-2xl transition ${active ? "bg-accent-soft" : ""}`}>{n.icon}</span>
                {n.label}
              </button>
            );
          })}
        </div>
      </nav>

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 24, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12, scale: 0.97 }}
            className="fixed bottom-24 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-2xl bg-stone-900 px-4 py-3 text-[13px] font-bold text-white shadow-2xl lg:bottom-8 dark:bg-zinc-100 dark:text-zinc-900">
            <CheckCircle2 size={16} className="shrink-0 text-emerald-400 dark:text-emerald-600" /> {toast}
            <button onClick={() => setToast(null)} className="opacity-60 hover:opacity-100"><X size={14} /></button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
