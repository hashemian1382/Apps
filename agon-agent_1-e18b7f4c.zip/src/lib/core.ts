import { toJalaali, toGregorian, jalaaliMonthLength as jMonthLength } from "jalaali-js";

// ---------- Types ----------
export type Priority = "low" | "medium" | "high" | "urgent";

export interface Category { id: string; name: string; color: string }
export interface Habit { id: string; name: string; emoji: string; color: string; active: boolean }
export interface Task { id: string; title: string; done: boolean; priority: Priority; categoryId?: string; createdAt: number }
export interface ScheduleItem { id: string; title: string; start: string; end: string; categoryId?: string; done: boolean }
export interface BacklogItem { id: string; title: string; desc: string; priority: Priority; categoryId?: string; createdAt: number; done: boolean }

export interface DayData {
  date: string;
  wakeTime: string;
  sleepTime: string;
  mood: number;
  energy: number;
  water: number;
  weight: string;
  mainGoal: string;
  gratitude: string;
  tasks: Task[];
  schedule: ScheduleItem[];
  habitsDone: Record<string, boolean>;
  tomorrowTasks: string[];
  tomorrowNote: string;
  notes: string;
  endReport: string;
  score: number;
  completed: boolean;
}

export interface Settings {
  userName: string;
  theme: "light" | "dark";
  accent: string;
  fontScale: "normal" | "large";
  weekStartSaturday: boolean;
}

export interface AppData {
  days: Record<string, DayData>;
  backlog: BacklogItem[];
  habits: Habit[];
  categories: Category[];
  settings: Settings;
  createdAt: number;
}

// ---------- Small utils ----------
export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

const FA_D = ["۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"];
export const toFa = (v: string | number): string =>
  String(v).replace(/[0-9]/g, (d) => FA_D[Number(d)]);

export const toFaTime = (t: string) => (t ? toFa(t) : "—");

export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
export function parseISO(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d, 12, 0, 0);
}
export function todayISO(): string { return toISODate(new Date()); }
export function addDaysISO(iso: string, n: number): string {
  const d = parseISO(iso);
  d.setDate(d.getDate() + n);
  return toISODate(d);
}

// ---------- Jalali ----------
export const J_MONTHS = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
export const WEEKDAYS_FA = ["یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"];
export const WEEKDAYS_SHORT = ["شنبه","یک","دو","سه","چهار","پنج","جمعه"];

export function jalaliOf(iso: string) {
  const d = parseISO(iso);
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}
export function weekdayFa(iso: string): string {
  return WEEKDAYS_FA[parseISO(iso).getDay()];
}
export function formatJalaliLong(iso: string): string {
  const j = jalaliOf(iso);
  return `${weekdayFa(iso)} ${toFa(j.jd)} ${J_MONTHS[j.jm - 1]} ${toFa(j.jy)}`;
}
export function formatJalaliShort(iso: string): string {
  const j = jalaliOf(iso);
  return `${toFa(j.jd)} ${J_MONTHS[j.jm - 1]}`;
}
export function formatJalaliMonthYear(jy: number, jm: number): string {
  return `${J_MONTHS[jm - 1]} ${toFa(jy)}`;
}
export function isoFromJalali(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  return toISODate(new Date(g.gy, g.gm - 1, g.gd, 12));
}
export function jalaliMonthLength(jy: number, jm: number): number {
  return jMonthLength(jy, jm);
}
export function currentJalali(): { jy: number; jm: number; jd: number } {
  const n = new Date();
  return toJalaali(n.getFullYear(), n.getMonth() + 1, n.getDate());
}

export interface CalCell { iso: string; inMonth: boolean; jd: number }
export function jalaliMonthGrid(jy: number, jm: number): CalCell[][] {
  const firstISO = isoFromJalali(jy, jm, 1);
  const jsDay = parseISO(firstISO).getDay();
  const offset = (jsDay + 1) % 7;
  const len = jalaliMonthLength(jy, jm);
  const cells: CalCell[] = [];
  for (let i = offset - 1; i >= 0; i--) {
    const iso = addDaysISO(firstISO, -(i + 1));
    cells.push({ iso, inMonth: false, jd: jalaliOf(iso).jd });
  }
  for (let d = 1; d <= len; d++) cells.push({ iso: isoFromJalali(jy, jm, d), inMonth: true, jd: d });
  while (cells.length % 7 !== 0) {
    const last = cells[cells.length - 1].iso;
    const nx = addDaysISO(last, 1);
    cells.push({ iso: nx, inMonth: false, jd: jalaliOf(nx).jd });
  }
  const weeks: CalCell[][] = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
  return weeks;
}

// ---------- Labels ----------
export const PRIORITY_META: Record<Priority, { label: string; color: string; bg: string; dot: string }> = {
  urgent: { label: "فوری", color: "text-rose-700 dark:text-rose-300", bg: "bg-rose-100 dark:bg-rose-500/15 border-rose-200 dark:border-rose-500/30", dot: "bg-rose-500" },
  high: { label: "مهم", color: "text-orange-700 dark:text-orange-300", bg: "bg-orange-100 dark:bg-orange-500/15 border-orange-200 dark:border-orange-500/30", dot: "bg-orange-500" },
  medium: { label: "متوسط", color: "text-sky-700 dark:text-sky-300", bg: "bg-sky-100 dark:bg-sky-500/15 border-sky-200 dark:border-sky-500/30", dot: "bg-sky-500" },
  low: { label: "کم", color: "text-slate-600 dark:text-slate-300", bg: "bg-slate-100 dark:bg-white/10 border-slate-200 dark:border-white/15", dot: "bg-slate-400" },
};
export const CATEGORY_COLORS = ["#10b981","#3b82f6","#f59e0b","#ef4444","#8b5cf6","#ec4899","#14b8a6","#84cc16"];
export const MOODS = [
  { v: 1, emoji: "😞", label: "بد" },
  { v: 2, emoji: "😐", label: "معمولی" },
  { v: 3, emoji: "🙂", label: "خوب" },
  { v: 4, emoji: "😄", label: "عالی" },
  { v: 5, emoji: "🤩", label: "فوق‌العاده" },
];

// ---------- Day factory ----------
export function emptyDay(date: string): DayData {
  return {
    date, wakeTime: "", sleepTime: "", mood: 0, energy: 0, water: 0, weight: "",
    mainGoal: "", gratitude: "", tasks: [], schedule: [], habitsDone: {},
    tomorrowTasks: [], tomorrowNote: "", notes: "", endReport: "", score: 0, completed: false,
  };
}
export function dayStats(day: DayData | undefined, habitCount: number) {
  if (!day) return { tasksTotal: 0, tasksDone: 0, tasksPct: 0, habitsDone: 0, habitsPct: 0, overall: 0 };
  const t = day.tasks.length;
  const td = day.tasks.filter((x) => x.done).length;
  const tasksPct = t ? Math.round((td / t) * 100) : 0;
  const hd = Object.values(day.habitsDone).filter(Boolean).length;
  const habitsPct = habitCount ? Math.round((hd / habitCount) * 100) : 0;
  const parts = [t ? tasksPct : -1, habitCount ? habitsPct : -1].filter((x) => x >= 0);
  const overall = parts.length ? Math.round(parts.reduce((a, b) => a + b, 0) / parts.length) : 0;
  return { tasksTotal: t, tasksDone: td, tasksPct, habitsDone: hd, habitsPct, overall };
}

// ---------- Seed ----------
function seedDays(): Record<string, DayData> {
  const days: Record<string, DayData> = {};
  const today = todayISO();
  const rnd = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));
  const sampleTasks = ["جلسه تیم محصول","مرور ایمیل‌ها","تمرین زبان","خرید هفتگی","نوشتن گزارش","پیاده‌روی عصر","تماس با خانواده","مطالعه کتاب","مرتب کردن میز کار","برنامه‌ریزی هفته"];
  const schedPairs: [string,string][] = [["09:00","10:30"],["11:00","12:30"],["14:00","15:30"],["17:00","18:00"]];
  for (let back = 21; back >= 1; back--) {
    const iso = addDaysISO(today, -back);
    const d = emptyDay(iso);
    d.wakeTime = `0${rnd(5, 7)}:${String(rnd(10,59))}`;
    d.sleepTime = `2${rnd(2, 3)}:${String(rnd(10,50))}`;
    d.mood = rnd(2, 5);
    d.energy = rnd(2, 5);
    d.water = rnd(3, 8);
    const n = rnd(2, 5);
    for (let i = 0; i < n; i++) {
      d.tasks.push({ id: uid(), title: sampleTasks[rnd(0, sampleTasks.length - 1)], done: Math.random() > 0.3, priority: (["low","medium","high","urgent"] as Priority[])[rnd(0, 3)], createdAt: Date.now() });
    }
    const sn = rnd(1, 3);
    for (let i = 0; i < sn; i++) {
      const s = schedPairs[rnd(0, schedPairs.length - 1)];
      d.schedule.push({ id: uid(), title: sampleTasks[rnd(0, sampleTasks.length - 1)], start: s[0], end: s[1], done: Math.random() > 0.4 });
    }
    d.score = rnd(4, 10);
    d.completed = Math.random() > 0.15;
    d.endReport = d.completed ? "روز پرباری بود؛ بیشتر برنامه‌ها انجام شد." : "";
    d.mainGoal = sampleTasks[rnd(0, sampleTasks.length - 1)];
    days[iso] = d;
  }
  return days;
}

export function defaultData(): AppData {
  const days = seedDays();
  const t = todayISO();
  const categories: Category[] = [
    { id: "c1", name: "کاری", color: "#3b82f6" },
    { id: "c2", name: "شخصی", color: "#8b5cf6" },
    { id: "c3", name: "سلامت", color: "#10b981" },
    { id: "c4", name: "یادگیری", color: "#f59e0b" },
    { id: "c5", name: "خانه", color: "#ec4899" },
  ];
  const habits: Habit[] = [
    { id: "h1", name: "ورزش ۳۰ دقیقه", emoji: "🏃", color: "#10b981", active: true },
    { id: "h2", name: "مطالعه ۲۰ صفحه", emoji: "📚", color: "#3b82f6", active: true },
    { id: "h3", name: "مدیتیشن", emoji: "🧘", color: "#8b5cf6", active: true },
    { id: "h4", name: "بدون قند", emoji: "🍏", color: "#f59e0b", active: true },
    { id: "h5", name: "خواب منظم", emoji: "😴", color: "#14b8a6", active: true },
  ];
  Object.values(days).forEach((d) => {
    habits.forEach((h) => { d.habitsDone[h.id] = Math.random() > 0.35; });
  });
  if (!days[t]) days[t] = emptyDay(t);
  return {
    days,
    backlog: [
      { id: uid(), title: "طراحی لندینگ محصول جدید", desc: "وایرفریم + متن فارسی + ریسپانسیو", priority: "high", categoryId: "c1", createdAt: Date.now(), done: false },
      { id: uid(), title: "خواندن کتاب عادت‌های اتمی", desc: "فصل ۴ تا ۷ — خلاصه بنویس", priority: "medium", categoryId: "c4", createdAt: Date.now(), done: false },
      { id: uid(), title: "تعویض روغن ماشین", desc: "نمایندگی سعادت‌آباد، قبل از سفر", priority: "urgent", categoryId: "c5", createdAt: Date.now(), done: false },
      { id: uid(), title: "چکاپ سالانه", desc: "آزمایش خون + دندان‌پزشکی", priority: "medium", categoryId: "c3", createdAt: Date.now(), done: false },
      { id: uid(), title: "مرتب کردن گالری عکس‌ها", desc: "پشتیبان + حذف تکراری‌ها", priority: "low", categoryId: "c2", createdAt: Date.now(), done: false },
    ],
    habits, categories,
    settings: { userName: "دوست من", theme: "light", accent: "emerald", fontScale: "normal", weekStartSaturday: true },
    createdAt: Date.now(),
  };
}

// ---------- Storage ----------
const KEY = "roozaneh-data-v1";
export function loadData(): AppData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) { const d = defaultData(); localStorage.setItem(KEY, JSON.stringify(d)); return d; }
    const parsed = JSON.parse(raw) as AppData;
    if (!parsed.days || !parsed.settings) throw new Error("bad");
    const t = todayISO();
    if (!parsed.days[t]) parsed.days[t] = emptyDay(t);
    return parsed;
  } catch {
    const d = defaultData();
    try { localStorage.setItem(KEY, JSON.stringify(d)); } catch { /* noop */ }
    return d;
  }
}
export function persist(data: AppData) {
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* noop */ }
}

// ---------- Summary ----------
export function buildDaySummary(day: DayData, _cats: Category[], habits: Habit[]): string {
  const j = jalaliOf(day.date);
  const lines: string[] = [];
  lines.push(`خلاصه روز — ${weekdayFa(day.date)} ${j.jd} ${J_MONTHS[j.jm - 1]} ${j.jy}`);
  lines.push(`━━━━━━━━━━━━━━━`);
  if (day.mainGoal) lines.push(`هدف اصلی: ${day.mainGoal}`);
  if (day.wakeTime || day.sleepTime) lines.push(`بیداری ${day.wakeTime || "—"} | خواب ${day.sleepTime || "—"}`);
  if (day.mood) lines.push(`حال: ${(MOODS.find((m) => m.v === day.mood)?.label) || day.mood} | انرژی: ${day.energy}/۵ | آب: ${day.water} لیوان`);
  lines.push("");
  lines.push(`تسک‌ها (${day.tasks.filter((t) => t.done).length} از ${day.tasks.length}):`);
  if (!day.tasks.length) lines.push("— کاری ثبت نشده");
  day.tasks.forEach((t) => lines.push(`${t.done ? "[x]" : "[ ]"} ${t.title} (${PRIORITY_META[t.priority].label})`));
  lines.push("");
  lines.push(`برنامه زمانی:`);
  if (!day.schedule.length) lines.push("— برنامه‌ای ثبت نشده");
  [...day.schedule].sort((a, b) => a.start.localeCompare(b.start)).forEach((s) => lines.push(`- ${s.start} تا ${s.end} — ${s.title}${s.done ? " ✓" : ""}`));
  lines.push("");
  lines.push(`عادت‌ها:`);
  habits.filter((h) => h.active).forEach((h) => lines.push(`${day.habitsDone[h.id] ? "[x]" : "[ ]"} ${h.emoji} ${h.name}`));
  lines.push("");
  if (day.tomorrowTasks.length) { lines.push(`فردا:`); day.tomorrowTasks.forEach((t) => lines.push(`- ${t}`)); lines.push(""); }
  if (day.gratitude) lines.push(`قدردانی: ${day.gratitude}`);
  if (day.notes) lines.push(`یادداشت: ${day.notes}`);
  if (day.endReport) lines.push(`گزارش پایان روز: ${day.endReport}`);
  if (day.score) lines.push(`امتیاز روز: ${day.score}/۱۰`);
  void _cats;
  return lines.join("\n");
}

// ---------- Streaks ----------
export function calcStreak(days: Record<string, DayData>, predicate: (d: DayData | undefined) => boolean, refISO: string): number {
  let s = 0;
  let cur = refISO;
  if (!predicate(days[cur])) cur = addDaysISO(cur, -1);
  let guard = 0;
  while (predicate(days[cur]) && guard < 3650) { s++; cur = addDaysISO(cur, -1); guard++; }
  return s;
}

export function lastNDays(refISO: string, n: number): string[] {
  const out: string[] = [];
  for (let i = n - 1; i >= 0; i--) out.push(addDaysISO(refISO, -i));
  return out;
}
