import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CalendarDays, ChevronLeft, ChevronRight, CheckCircle2, Star } from "lucide-react";
import {
  WEEKDAYS_SHORT, addDaysISO, currentJalali, dayStats, formatJalaliMonthYear,
  isoFromJalali, jalaliMonthGrid, jalaliMonthLength, jalaliOf, todayISO, toFa, type AppData,
} from "../lib/core";
import { Card, CardHead, Progress } from "./ui";

export default function CalendarView({ data, selected, onSelect }: {
  data: AppData; selected: string; onSelect: (iso: string) => void;
  jump?: { jy: number; jm: number } | null; setJump?: (v: { jy: number; jm: number } | null) => void;
}) {
  const t = todayISO();
  const cj = currentJalali();
  const [jy, setJy] = useState(cj.jy);
  const [jm, setJm] = useState(cj.jm);

  const activeHabits = data.habits.filter((h) => h.active).length;
  const weeks = useMemo(() => jalaliMonthGrid(jy, jm), [jy, jm]);
  const monthLen = jalaliMonthLength(jy, jm);

  const prev = () => { if (jm === 1) { setJy(jy - 1); setJm(12); } else setJm(jm - 1); };
  const next = () => { if (jm === 12) { setJy(jy + 1); setJm(1); } else setJm(jm + 1); };
  const goToday = () => { const c = currentJalali(); setJy(c.jy); setJm(c.jm); onSelect(t); };

  const colorFor = (iso: string) => {
    const d = data.days[iso];
    if (!d || (d.tasks.length === 0 && Object.keys(d.habitsDone).length === 0 && !d.score)) return null;
    const s = dayStats(d, activeHabits).overall;
    if (d.completed && s >= 70) return "bg-emerald-500";
    if (s >= 70) return "bg-emerald-400";
    if (s >= 40) return "bg-amber-400";
    if (s > 0) return "bg-orange-300";
    return "bg-stone-200 dark:bg-white/15";
  };

  const selDay = data.days[selected];
  const selStats = dayStats(selDay, activeHabits);

  return (
    <div className="grid items-start gap-4 xl:grid-cols-[1fr_300px]">
      <Card>
        <CardHead icon={<CalendarDays size={19} />} title={formatJalaliMonthYear(jy, jm)} sub={`${toFa(monthLen)} روز • برای مشاهده روز، روی خانه‌اش بزن`}
          action={
            <div className="flex items-center gap-1.5">
              <button onClick={prev} className="grid h-9 w-9 place-items-center rounded-xl border border-stone-200 transition hover:bg-stone-50 active:scale-95 dark:border-white/10 dark:hover:bg-white/10"><ChevronRight size={16} /></button>
              <button onClick={goToday} className="rounded-xl bg-accent-soft px-3 py-2 text-[12px] font-black text-accent transition hover:brightness-95">امروز</button>
              <button onClick={next} className="grid h-9 w-9 place-items-center rounded-xl border border-stone-200 transition hover:bg-stone-50 active:scale-95 dark:border-white/10 dark:hover:bg-white/10"><ChevronLeft size={16} /></button>
            </div>
          } />
        <div className="p-4 sm:p-5">
          <div className="mb-2 grid grid-cols-7 gap-1.5 text-center">
            {WEEKDAYS_SHORT.map((w, i) => (
              <span key={w} className={`py-1 text-[11px] font-black ${i === 6 ? "text-rose-500" : "text-stone-400 dark:text-zinc-500"}`}>{w}</span>
            ))}
          </div>
          <div className="flex flex-col gap-1.5">
            {weeks.map((week, wi) => (
              <div key={wi} className="grid grid-cols-7 gap-1.5">
                {week.map((cell) => {
                  const isSel = cell.iso === selected;
                  const isToday = cell.iso === t;
                  const dot = colorFor(cell.iso);
                  const fri = new Date(cell.iso).getDay() === 5;
                  return (
                    <motion.button
                      key={cell.iso}
                      whileTap={{ scale: 0.93 }}
                      onClick={() => onSelect(cell.iso)}
                      className={`relative flex min-h-[56px] flex-col items-center justify-center gap-1 rounded-2xl border p-1 transition sm:min-h-[68px] ${
                        isSel
                          ? "border-transparent bg-accent text-white shadow-lg"
                          : isToday
                            ? "border-emerald-400 bg-emerald-50/70 dark:bg-emerald-500/10"
                            : cell.inMonth
                              ? "border-stone-100 bg-white hover:border-stone-300 hover:shadow-sm dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/25"
                              : "border-transparent bg-stone-50/60 opacity-45 dark:bg-white/[0.02]"
                      }`}
                    >
                      <span className={`text-[15px] font-black sm:text-[17px] ${isSel ? "text-white" : fri && cell.inMonth ? "text-rose-500" : "text-stone-700 dark:text-zinc-200"}`}>
                        {toFa(cell.jd)}
                      </span>
                      {dot && !isSel && <span className={`h-1.5 w-6 rounded-full ${dot}`} />}
                      {isSel && (
                        <span className="flex items-center gap-1 text-[9.5px] font-bold text-white/90">
                          {selDay?.completed ? "✓ بسته" : `${toFa(selStats.overall)}٪`}
                        </span>
                      )}
                      {isToday && !isSel && (
                        <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-emerald-500" />
                      )}
                    </motion.button>
                  );
                })}
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 rounded-2xl bg-stone-50 px-4 py-3 text-[11px] font-bold text-stone-500 dark:bg-white/5 dark:text-zinc-400">
            <span className="font-black">راهنما:</span>
            <span className="flex items-center gap-1"><span className="h-2 w-4 rounded-full bg-emerald-500" /> عالی / بسته</span>
            <span className="flex items-center gap-1"><span className="h-2 w-4 rounded-full bg-amber-400" /> متوسط</span>
            <span className="flex items-center gap-1"><span className="h-2 w-4 rounded-full bg-orange-300" /> ضعیف</span>
            <span className="flex items-center gap-1"><span className="h-2 w-4 rounded-full bg-stone-200" /> ثبت ناقص</span>
          </div>
        </div>
      </Card>

      {/* side detail */}
      <Card>
        <CardHead icon={<Star size={18} />} title="جزئیات روز" sub={selected ? `${toFa(jalaliOf(selected).jd)} ${["", "فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"][jalaliOf(selected).jm]}` : ""} />
        <div className="flex flex-col gap-3 p-5">
          {!selDay || (selDay.tasks.length === 0 && !selDay.mainGoal && !selDay.score) ? (
            <div className="rounded-2xl border border-dashed border-stone-200 py-8 text-center dark:border-white/10">
              <p className="text-3xl">📭</p>
              <p className="mt-2 text-[13px] font-bold text-stone-500 dark:text-zinc-400">این روز خالی است</p>
              <button onClick={() => onSelect(selected)} className="bg-accent mx-auto mt-3 flex items-center gap-1.5 rounded-2xl px-4 py-2 text-[12.5px] font-bold text-white">
                <CheckCircle2 size={14} /> باز کردن روز
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between rounded-2xl bg-stone-50 px-3.5 py-2.5 dark:bg-white/5">
                <span className="text-[12px] font-bold text-stone-500 dark:text-zinc-400">پیشرفت</span>
                <span className="text-[15px] font-black text-accent">{toFa(selStats.overall)}٪</span>
              </div>
              <Progress value={selStats.overall} />
              {selDay.mainGoal && <p className="rounded-2xl bg-accent-soft px-3.5 py-2.5 text-[12.5px] font-bold leading-6">🎯 {selDay.mainGoal}</p>}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-2xl border border-stone-100 px-1 py-2.5 dark:border-white/10">
                  <p className="text-[15px] font-black">{toFa(selDay.tasks.filter((x) => x.done).length)}/{toFa(selDay.tasks.length)}</p>
                  <p className="text-[10px] text-stone-400">تسک</p>
                </div>
                <div className="rounded-2xl border border-stone-100 px-1 py-2.5 dark:border-white/10">
                  <p className="text-[15px] font-black">{toFa(Object.values(selDay.habitsDone).filter(Boolean).length)}</p>
                  <p className="text-[10px] text-stone-400">عادت</p>
                </div>
                <div className="rounded-2xl border border-stone-100 px-1 py-2.5 dark:border-white/10">
                  <p className="text-[15px] font-black">{selDay.score ? toFa(selDay.score) : "—"}</p>
                  <p className="text-[10px] text-stone-400">امتیاز</p>
                </div>
              </div>
              {selDay.tasks.slice(0, 5).map((task) => (
                <p key={task.id} className="flex items-center gap-2 truncate text-[12.5px] font-bold text-stone-500 dark:text-zinc-400">
                  <span>{task.done ? "☑" : "☐"}</span><span className="truncate">{task.title}</span>
                </p>
              ))}
              <button onClick={() => onSelect(selected)} className="bg-accent mt-1 rounded-2xl py-2.5 text-[13px] font-bold text-white transition hover:brightness-110">
                باز کردن این روز ←
              </button>
            </>
          )}
          <button onClick={() => { const c = currentJalali(); const iso = isoFromJalali(c.jy, c.jm, 1); onSelect(addDaysISO(iso, 0)); setJy(c.jy); setJm(c.jm); }} className="text-[11.5px] font-bold text-stone-400 hover:text-stone-600">
            پرش به ماه جاری
          </button>
        </div>
      </Card>
    </div>
  );
}
