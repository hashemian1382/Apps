import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { toFa } from "../lib/core";

// ---------- Card ----------
export function Card({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className={`rounded-3xl border border-stone-200/80 bg-white shadow-[0_8px_30px_-12px_rgba(0,0,0,0.12)] dark:border-white/10 dark:bg-zinc-900 dark:shadow-[0_8px_30px_-12px_rgba(0,0,0,0.6)] ${className}`}
    >
      {children}
    </motion.section>
  );
}

export function CardHead({ icon, title, sub, action }: { icon: ReactNode; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-stone-100 px-5 pb-4 pt-5 dark:border-white/10">
      <div className="flex items-center gap-3">
        <div className="bg-accent-soft text-accent grid h-10 w-10 shrink-0 place-items-center rounded-2xl">{icon}</div>
        <div>
          <h3 className="text-[15px] font-extrabold text-stone-800 dark:text-zinc-100">{title}</h3>
          {sub && <p className="mt-0.5 text-xs text-stone-500 dark:text-zinc-400">{sub}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

// ---------- Progress ----------
export function Progress({ value, tone = "bg-accent" }: { value: number; tone?: string }) {
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-stone-100 dark:bg-white/10" dir="ltr">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${Math.min(100, Math.max(0, value))}%` }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`h-full rounded-full ${tone}`}
        style={{ marginLeft: "auto" }}
      />
    </div>
  );
}

export function Ring({ value, size = 56 }: { value: number; size?: number }) {
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} strokeWidth={6} fill="none" className="stroke-stone-100 dark:stroke-white/10" />
        <circle
          cx={size / 2} cy={size / 2} r={r} strokeWidth={6} fill="none" strokeLinecap="round"
          stroke="rgb(var(--accent))" strokeDasharray={c} strokeDashoffset={c - (c * Math.min(100, value)) / 100}
          style={{ transition: "stroke-dashoffset .6s ease" }}
        />
      </svg>
      <span className="absolute text-sm font-black text-stone-800 dark:text-zinc-100">{toFa(Math.round(value))}٪</span>
    </div>
  );
}

// ---------- Inputs ----------
export const inputCls =
  "w-full rounded-2xl border border-stone-200 bg-stone-50/60 px-3.5 py-2.5 text-sm text-stone-800 placeholder:text-stone-400 outline-none transition focus:border-transparent focus:ring-2 ring-accent focus:bg-white dark:border-white/10 dark:bg-white/5 dark:text-zinc-100 dark:placeholder:text-zinc-500 dark:focus:bg-zinc-900";

export const btnAccent =
  "bg-accent inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none";

export const btnGhost =
  "inline-flex items-center justify-center gap-2 rounded-2xl border border-stone-200 bg-white px-3.5 py-2 text-[13px] font-bold text-stone-600 transition hover:bg-stone-50 active:scale-[0.98] dark:border-white/10 dark:bg-white/5 dark:text-zinc-300 dark:hover:bg-white/10";

export const iconBtn =
  "grid h-9 w-9 place-items-center rounded-xl border border-stone-200 bg-white text-stone-500 transition hover:bg-stone-50 hover:text-stone-800 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-zinc-400 dark:hover:bg-white/10 dark:hover:text-zinc-100";

export function Empty({ emoji, title, sub }: { emoji: string; title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-2xl border border-dashed border-stone-200 bg-stone-50/60 px-4 py-8 text-center dark:border-white/10 dark:bg-white/[0.03]">
      <span className="text-3xl">{emoji}</span>
      <p className="text-sm font-bold text-stone-600 dark:text-zinc-300">{title}</p>
      {sub && <p className="text-xs leading-5 text-stone-400 dark:text-zinc-500">{sub}</p>}
    </div>
  );
}

export function Chip({ children, tone = "" }: { children: ReactNode; tone?: string }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-bold ${tone || "border-stone-200 bg-stone-50 text-stone-500 dark:border-white/10 dark:bg-white/5 dark:text-zinc-400"}`}>
      {children}
    </span>
  );
}
