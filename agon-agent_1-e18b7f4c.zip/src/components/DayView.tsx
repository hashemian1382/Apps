import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  AlarmClock, ArrowLeft, ArrowRight, BedDouble, CalendarPlus, Check, CheckCircle2,
  ChevronLeft, ClipboardCopy, Droplets, Flame, Heart, Leaf, MoonStar, NotebookPen,
  Plus, Reply, Sparkles, Star, Sun, Target, Trash2, Clock3, ListChecks, PartyPopper,
} from "lucide-react";
import {
  MOODS, PRIORITY_META, addDaysISO, dayStats, emptyDay, formatJalaliLong, formatJalaliShort,
  todayISO, toFa, uid, weekdayFa, type AppData, type DayData, type Priority,
} from "../lib/core";
import { Card, CardHead, Progress, Ring, btnAccent, btnGhost, iconBtn, inputCls, Empty } from "./ui";

interface Props {
  data: AppData;
  setData: React.Dispatch<React.SetStateAction<AppData>>;
  date: string;
  setDate: (iso: string) => void;
  notify: (m: string) => void;
  onCopy: () => void;
  onOpenCalendar: (iso: string) => void;
}

const PRI_ORDER: Record<Priority, number> = { urgent: 0, high: 1, medium: 2, low: 3 };

export default function DayView({ data, setData, date, setDate, notify, onCopy }: Props) {
  const tISO = todayISO();
  const day: DayData = data.days[date] ?? emptyDay(date);
  const activeHabits = data.habits.filter((h) => h.active);
  const stats = dayStats(day, activeHabits.length);

  const [taskTitle, setTaskTitle] = useState("");
  const [taskPri, setTaskPri] = useState<Priority>("medium");
  const [taskCat, setTaskCat] = useState("");
  const [taskFilter, setTaskFilter] = useState<"all" | "open" | "done">("all");

  const [sTitle, setSTitle] = useState("");
  const [sStart, setSStart] = useState("");
  const [sEnd, setSEnd] = useState("");

  const [tomInput, setTomInput] = useState("");
  const [confirmClose, setConfirmClose] = useState(false);

  const upd = (fn: (d: DayData) => void) => {
    setData((prev) => {
      const cur: DayData = prev.days[date] ? { ...prev.days[date] } : emptyDay(date);
      fn(cur);
      return { ...prev, days: { ...prev.days, [date]: cur } };
    });
  };

  const diff = useMemo(() => {
    const a = new Date(date).getTime();
    const b = new Date(tISO).getTime();
    return Math.round((a - b) / 86400000);
  }, [date, tISO]);

  const diffLabel = diff === 0 ? "امروز" : diff === 1 ? "فردا" : diff === -1 ? "دیروز" : diff > 1 ? `${toFa(diff)} روز آینده` : `${toFa(Math.abs(diff))} روز گذشته`;

  const catName = (id?: string) => data.categories.find((c) => c.id === id)?.name;
  const catColor = (id?: string) => data.categories.find((c) => c.id === id)?.color;

  const addTask = () => {
    const t = taskTitle.trim();
    if (!t) { notify("عنوان تسک را بنویس"); return; }
    upd((d) => { d.tasks.push({ id: uid(), title: t, done: false, priority: taskPri, categoryId: taskCat || undefined, createdAt: Date.now() }); });
    setTaskTitle("");
    notify("تسک اضافه شد");
  };

  const addSchedule = () => {
    if (!sTitle.trim() || !sStart || !sEnd) { notify("عنوان و ساعت شروع/پایان لازم است"); return; }
    if (sStart >= sEnd) { notify("ساعت پایان باید بعد از شروع باشد"); return; }
    upd((d) => { d.schedule.push({ id: uid(), title: sTitle.trim(), start: sStart, end: sEnd, done: false }); });
    setSTitle(""); setSStart(""); setSEnd("");
    notify("به برنامه اضافه شد");
  };

  const addTomorrow = () => {
    const t = tomInput.trim();
    if (!t) return;
    upd((d) => { d.tomorrowTasks.push(t); });
    setTomInput("");
  };

  const pushTomorrowToDay = () => {
    if (!day.tomorrowTasks.length) { notify("برای فردا چیزی ننوشته‌ای"); return; }
    const next = addDaysISO(date, 1);
    setData((prev) => {
      const nd: DayData = prev.days[next] ? { ...prev.days[next] } : emptyDay(next);
      day.tomorrowTasks.forEach((t) =>
        nd.tasks.push({ id: uid(), title: t, done: false, priority: "medium", createdAt: Date.now() })
      );
      return { ...prev, days: { ...prev.days, [next]: nd } };
    });
    notify(`برنامه فردا ساخته شد (${toFa(day.tomorrowTasks.length)} تسک)`);
    setDate(next);
  };

  const carryUnfinished = () => {
    const prevIso = addDaysISO(date, -1);
    const prev = data.days[prevIso];
    if (!prev) { notify("روز قبل داده‌ای ندارد"); return; }
    const open = prev.tasks.filter((t) => !t.done);
    const tom = prev.tomorrowTasks;
    if (!open.length && !tom.length) { notify("کار ناتمامی از دیروز نیست 🎉"); return; }
    upd((d) => {
      open.forEach((t) => { if (!d.tasks.some((x) => x.title === t.title)) d.tasks.push({ ...t, id: uid(), done: false }); });
      tom.forEach((t) => { if (!d.tasks.some((x) => x.title === t)) d.tasks.push({ id: uid(), title: t, done: false, priority: "medium", createdAt: Date.now() }); });
    });
    notify(`${toFa(open.length + tom.length)} کار از دیروز منتقل شد`);
  };

  const visibleTasks = day.tasks
    .filter((t) => (taskFilter === "open" ? !t.done : taskFilter === "done" ? t.done : true))
    .sort((a, b) => Number(a.done) - Number(b.done) || PRI_ORDER[a.priority] - PRI_ORDER[b.priority]);

  const sortedSched = [...day.schedule].sort((a, b) => a.start.localeCompare(b.start));

  const toggleHabit = (hid: string) => upd((d) => { d.habitsDone[hid] = !d.habitsDone[hid]; });

  const scoreEmoji = day.score >= 9 ? "🏆" : day.score >= 7 ? "🌟" : day.score >= 5 ? "🙂" : day.score >= 3 ? "😐" : day.score > 0 ? "😞" : "—";

  return (
    <div className="flex flex-col gap-4">
      {/* ===== day navigator ===== */}
      <div className="overflow-hidden rounded-3xl border border-stone-200/80 bg-white shadow-[0_8px_30px_-12px_rgba(0,0,0,0.12)] dark:border-white/10 dark:bg-zinc-900">
        <div className="bg-accent relative overflow-hidden px-5 pb-5 pt-5 text-white">
          <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-white/15 blur-2xl" />
          <div className="pointer-events-none absolute -bottom-14 right-10 h-40 w-40 rounded-full bg-black/10 blur-2xl" />
          <div className="relative flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="flex items-center gap-2 text-[12px] font-bold text-white/85">
                <Sun size={14} /> {weekdayFa(date)} • {diffLabel}
                {!day.completed && diff <= 0 && <span className="rounded-full bg-white/20 px-2 py-0.5 text-[10px]">در جریان</span>}
                {day.completed && <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-black text-emerald-700">بسته شده ✓</span>}
              </p>
              <h2 className="mt-1 text-[22px] font-black leading-8 sm:text-[26px]">{formatJalaliLong(date)}</h2>
              <p className="mt-1 text-[12px] text-white/80">سلام {data.settings.userName}! امروز را بساز 🌱</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setDate(addDaysISO(date, -1))} className="grid h-10 w-10 place-items-center rounded-2xl bg-white/20 transition hover:bg-white/30 active:scale-95" title="روز قبل">
                <ArrowRight size={17} />
              </button>
              {date !== tISO && (
                <button onClick={() => setDate(tISO)} className="rounded-2xl bg-white px-4 py-2.5 text-[12.5px] font-black text-emerald-700 shadow transition hover:brightness-95 active:scale-95">
                  بازگشت به امروز
                </button>
              )}
              <button onClick={() => setDate(addDaysISO(date, 1))} className="grid h-10 w-10 place-items-center rounded-2xl bg-white/20 transition hover:bg-white/30 active:scale-95" title="روز بعد">
                <ArrowLeft size={17} />
              </button>
            </div>
          </div>
          {/* progress strip */}
          <div className="relative mt-4 flex items-center gap-3 rounded-2xl bg-black/15 p-3 backdrop-blur-sm">
            <Ring value={stats.overall} size={54} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between text-[11.5px] font-bold text-white/90">
                <span>تسک‌ها: {toFa(stats.tasksDone)} از {toFa(stats.tasksTotal)}</span>
                <span>{toFa(stats.tasksPct)}٪</span>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/25" dir="ltr">
                <div className="h-full rounded-full bg-white transition-all" style={{ width: `${stats.tasksPct}%`, marginLeft: "auto" }} />
              </div>
              <div className="mt-2 flex items-center justify-between text-[11.5px] font-bold text-white/90">
                <span>عادت‌ها: {toFa(stats.habitsDone)} از {toFa(activeHabits.length)}</span>
                <span>{toFa(stats.habitsPct)}٪</span>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/25" dir="ltr">
                <div className="h-full rounded-full bg-amber-300 transition-all" style={{ width: `${stats.habitsPct}%`, marginLeft: "auto" }} />
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 px-4 py-3">
          <button onClick={onCopy} className={`${btnAccent} !py-2 text-[13px]`}><ClipboardCopy size={15} /> کپی خلاصه روز</button>
          <button onClick={carryUnfinished} className={`${btnGhost} text-[12.5px]`}><Reply size={14} /> انتقال ناتمام‌های دیروز</button>
          <button onClick={pushTomorrowToDay} className={`${btnGhost} text-[12.5px]`}><CalendarPlus size={14} /> ساخت تسک‌های فردا</button>
          <span className="mr-auto hidden text-[11.5px] text-stone-400 sm:block dark:text-zinc-500">{formatJalaliShort(addDaysISO(date, 1))} ← برنامه فردا</span>
        </div>
      </div>

      {/* ===== cards grid ===== */}
      <div className="grid items-start gap-4 xl:grid-cols-2">
        {/* ---- col right ---- */}
        <div className="flex flex-col gap-4">
          {/* کارت ۱: اطلاعات پایه */}
          <Card>
            <CardHead icon={<Heart size={19} />} title="اطلاعات پایه روز" sub="حال، انرژی و هدف امروز" action={<Chip1 text={day.mainGoal ? "هدف ثبت شده" : "بدون هدف"} ok={!!day.mainGoal} />} />
            <div className="flex flex-col gap-4 p-5">
              <div className="grid grid-cols-2 gap-3">
                <label className="rounded-2xl border border-stone-100 bg-stone-50/70 p-3 dark:border-white/10 dark:bg-white/5">
                  <span className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-bold text-stone-500 dark:text-zinc-400"><AlarmClock size={13} className="text-accent" /> ساعت بیداری</span>
                  <input type="time" value={day.wakeTime} onChange={(e) => upd((d) => { d.wakeTime = e.target.value; })} className="w-full bg-transparent text-[15px] font-extrabold outline-none" dir="ltr" />
                </label>
                <label className="rounded-2xl border border-stone-100 bg-stone-50/70 p-3 dark:border-white/10 dark:bg-white/5">
                  <span className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-bold text-stone-500 dark:text-zinc-400"><BedDouble size={13} className="text-accent" /> ساعت خواب (دیشب)</span>
                  <input type="time" value={day.sleepTime} onChange={(e) => upd((d) => { d.sleepTime = e.target.value; })} className="w-full bg-transparent text-[15px] font-extrabold outline-none" dir="ltr" />
                </label>
              </div>
              <div>
                <p className="mb-2 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400">حالت امروز چطوره؟</p>
                <div className="grid grid-cols-5 gap-1.5">
                  {MOODS.map((m) => (
                    <button key={m.v} onClick={() => upd((d) => { d.mood = m.v; })}
                      className={`flex flex-col items-center gap-0.5 rounded-2xl border px-1 py-2 transition active:scale-95 ${day.mood === m.v ? "border-transparent bg-accent-soft ring-2 ring-accent" : "border-stone-100 bg-white hover:bg-stone-50 dark:border-white/10 dark:bg-white/5 dark:hover:bg-white/10"}`}>
                      <span className="text-[22px] leading-none">{m.emoji}</span>
                      <span className="text-[10px] font-bold text-stone-500 dark:text-zinc-400">{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-stone-100 bg-stone-50/70 p-3 dark:border-white/10 dark:bg-white/5">
                  <div className="mb-1.5 flex items-center justify-between text-[11.5px] font-bold text-stone-500 dark:text-zinc-400">
                    <span className="flex items-center gap-1"><Flame size={13} className="text-orange-500" /> انرژی</span>
                    <span className="text-accent text-[13px] font-black">{toFa(day.energy)} از ۵</span>
                  </div>
                  <div className="flex gap-1.5" dir="ltr">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <button key={i} onClick={() => upd((d) => { d.energy = i; })}
                        className={`h-2.5 flex-1 rounded-full transition ${i <= day.energy ? "bg-accent" : "bg-stone-200 hover:bg-stone-300 dark:bg-white/15"}`} />
                    ))}
                  </div>
                </div>
                <div className="rounded-2xl border border-stone-100 bg-stone-50/70 p-3 dark:border-white/10 dark:bg-white/5">
                  <div className="mb-1.5 flex items-center justify-between text-[11.5px] font-bold text-stone-500 dark:text-zinc-400">
                    <span className="flex items-center gap-1"><Droplets size={13} className="text-sky-500" /> آب</span>
                    <span className="text-[13px] font-black text-sky-600 dark:text-sky-300">{toFa(day.water)} لیوان</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => upd((d) => { d.water = Math.max(0, d.water - 1); })} className={iconBtn + " !h-7 !w-7 !rounded-lg text-base font-black"}>−</button>
                    <div className="flex flex-1 justify-center gap-0.5 text-[13px]" dir="ltr">
                      {Array.from({ length: 8 }).map((_, i) => (
                        <span key={i} className={i < Math.min(8, day.water) ? "" : "opacity-20 grayscale"}>💧</span>
                      ))}
                    </div>
                    <button onClick={() => upd((d) => { d.water = Math.min(20, d.water + 1); })} className={iconBtn + " !h-7 !w-7 !rounded-lg text-base font-black"}>+</button>
                  </div>
                </div>
              </div>
              <div>
                <label className="mb-1.5 flex items-center gap-1.5 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400"><Target size={13} className="text-accent" /> مهم‌ترین هدف امروز (فقط یکی!)</label>
                <input value={day.mainGoal} onChange={(e) => upd((d) => { d.mainGoal = e.target.value; })} placeholder="مثلاً: تمام کردن فصل ۴ کتاب…" className={inputCls + " font-bold"} />
              </div>
              <div className="grid grid-cols-[1fr_auto] items-end gap-2">
                <div>
                  <label className="mb-1.5 flex items-center gap-1.5 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400"><Sparkles size={13} className="text-accent" /> سه خط قدردانی</label>
                  <input value={day.gratitude} onChange={(e) => upd((d) => { d.gratitude = e.target.value; })} placeholder="بابت چی شکرگزاری؟" className={inputCls} />
                </div>
                <div className="flex items-center gap-2 rounded-2xl border border-stone-100 bg-stone-50/70 px-3 py-2 dark:border-white/10 dark:bg-white/5">
                  <span className="text-[11px] font-bold text-stone-400">وزن</span>
                  <input value={day.weight} onChange={(e) => upd((d) => { d.weight = e.target.value; })} placeholder="۷۰" className="w-12 bg-transparent text-center text-sm font-black outline-none" />
                </div>
              </div>
            </div>
          </Card>

          {/* کارت ۴: عادت‌ها */}
          <Card>
            <CardHead icon={<Leaf size={19} />} title="عادت‌های روزانه" sub={`${toFa(stats.habitsDone)} از ${toFa(activeHabits.length)} انجام شده`} action={<span className="text-[12px] font-black text-accent">{toFa(stats.habitsPct)}٪</span>} />
            <div className="p-5">
              <div className="mb-4"><Progress value={stats.habitsPct} /></div>
              {activeHabits.length === 0 ? (
                <Empty emoji="🌱" title="عادتی فعال نیست" sub="از بخش تنظیمات چند عادت بساز تا اینجا ردیابی بشن" />
              ) : (
                <div className="grid gap-2 sm:grid-cols-2">
                  {activeHabits.map((h) => {
                    const on = !!day.habitsDone[h.id];
                    return (
                      <button key={h.id} onClick={() => toggleHabit(h.id)}
                        className={`flex items-center gap-3 rounded-2xl border p-3 text-right transition active:scale-[0.98] ${on ? "border-transparent shadow-sm" : "border-stone-150 border-stone-200 bg-white hover:bg-stone-50 dark:border-white/10 dark:bg-white/[0.03] dark:hover:bg-white/[0.07]"}`}
                        style={on ? { background: `${h.color}18`, boxShadow: `inset 0 0 0 1.5px ${h.color}` } : undefined}>
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-[22px]" style={{ background: `${h.color}22` }}>{h.emoji}</span>
                        <span className="min-w-0 flex-1">
                          <span className={`block truncate text-[13px] font-extrabold ${on ? "" : "text-stone-600 dark:text-zinc-300"}`}>{h.name}</span>
                          <span className="text-[11px] font-bold" style={{ color: on ? h.color : undefined }}>{on ? "انجام شد ✓" : "انجام نشده"}</span>
                        </span>
                        <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 transition ${on ? "border-transparent text-white" : "border-stone-200 text-transparent dark:border-white/20"}`} style={on ? { background: h.color } : undefined}>
                          <Check size={15} strokeWidth={3.5} />
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </Card>

          {/* کارت ۵: فردا */}
          <Card>
            <CardHead icon={<MoonStar size={19} />} title="برنامه فردا" sub="امشب بنویس، صبح آماده‌ای" action={<span className="rounded-full bg-accent-soft px-2.5 py-1 text-[11px] font-black text-accent">{toFa(day.tomorrowTasks.length)} مورد</span>} />
            <div className="flex flex-col gap-3 p-5">
              <div className="flex gap-2">
                <input value={tomInput} onChange={(e) => setTomInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addTomorrow()} placeholder="فردا چه کارهایی؟ + Enter" className={inputCls} />
                <button onClick={addTomorrow} className={btnAccent + " shrink-0 !px-3.5"}><Plus size={16} /></button>
              </div>
              {day.tomorrowTasks.length === 0 ? (
                <Empty emoji="🌙" title="هنوز برای فردا چیزی ننوشته‌ای" sub="۳ کار مهم فردا را از همین امشب مشخص کن" />
              ) : (
                <ul className="flex flex-col gap-1.5">
                  {day.tomorrowTasks.map((t, i) => (
                    <motion.li key={i} layout initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }}
                      className="flex items-center gap-2.5 rounded-2xl border border-stone-100 bg-stone-50/70 px-3 py-2.5 text-[13px] font-bold text-stone-600 dark:border-white/10 dark:bg-white/5 dark:text-zinc-300">
                      <span className="bg-accent grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[11px] font-black text-white">{toFa(i + 1)}</span>
                      <span className="min-w-0 flex-1 truncate">{t}</span>
                      <button onClick={() => upd((d) => { d.tomorrowTasks.splice(i, 1); })} className="text-stone-300 transition hover:text-rose-500"><Trash2 size={15} /></button>
                    </motion.li>
                  ))}
                </ul>
              )}
              <textarea value={day.tomorrowNote} onChange={(e) => upd((d) => { d.tomorrowNote = e.target.value; })} placeholder="یادداشت برای فردا… (مثلاً: صبح زود بیدار شو، لباس ورزش آماده است)" rows={2} className={inputCls + " resize-none"} />
              <button onClick={pushTomorrowToDay} className={btnGhost + " w-full border-dashed"}><CalendarPlus size={15} /> انتقال به تسک‌های {formatJalaliShort(addDaysISO(date, 1))}</button>
            </div>
          </Card>
        </div>

        {/* ---- col left ---- */}
        <div className="flex flex-col gap-4">
          {/* کارت ۲: تسک‌ها */}
          <Card>
            <CardHead icon={<ListChecks size={19} />} title="تسک‌های روز" sub={`${toFa(stats.tasksDone)} از ${toFa(stats.tasksTotal)} انجام شده`} action={<Ring value={stats.tasksPct} size={52} />} />
            <div className="flex flex-col gap-3 p-5">
              <div className="flex gap-2">
                <input value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addTask()} placeholder="کار جدید… + Enter" className={inputCls} />
                <button onClick={addTask} className={btnAccent + " shrink-0 !px-3.5"}><Plus size={16} /></button>
              </div>
              <div className="flex flex-wrap gap-2">
                <select value={taskPri} onChange={(e) => setTaskPri(e.target.value as Priority)} className="rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 text-[12px] font-bold outline-none dark:border-white/10 dark:bg-white/5">
                  {(Object.keys(PRIORITY_META) as Priority[]).map((p) => <option key={p} value={p}>{PRIORITY_META[p].label}</option>)}
                </select>
                <select value={taskCat} onChange={(e) => setTaskCat(e.target.value)} className="rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 text-[12px] font-bold outline-none dark:border-white/10 dark:bg-white/5">
                  <option value="">بدون دسته</option>
                  {data.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <div className="mr-auto flex overflow-hidden rounded-xl border border-stone-200 text-[11.5px] font-bold dark:border-white/10">
                  {(["all", "open", "done"] as const).map((f) => (
                    <button key={f} onClick={() => setTaskFilter(f)} className={`px-3 py-1.5 transition ${taskFilter === f ? "bg-accent text-white" : "bg-white text-stone-500 dark:bg-white/5 dark:text-zinc-400"}`}>
                      {f === "all" ? "همه" : f === "open" ? "باز" : "شده"}
                    </button>
                  ))}
                </div>
              </div>
              {visibleTasks.length === 0 ? (
                <Empty emoji={day.tasks.length ? "🔍" : "📝"} title={day.tasks.length ? "موردی با این فیلتر نیست" : "هنوز تسکی نداری"} sub="یک کار کوچک بنویس و شروع کن؛ حرکت، انگیزه می‌سازد" />
              ) : (
                <ul className="flex flex-col gap-1.5">
                  {visibleTasks.map((t) => {
                    const pm = PRIORITY_META[t.priority];
                    return (
                      <motion.li key={t.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                        className={`group flex items-center gap-2.5 rounded-2xl border px-3 py-2.5 transition ${t.done ? "border-transparent bg-stone-50 opacity-70 dark:bg-white/[0.04]" : "border-stone-150 border-stone-200 bg-white hover:shadow-sm dark:border-white/10 dark:bg-white/[0.03]"}`}>
                        <button onClick={() => upd((d) => { const x = d.tasks.find((y) => y.id === t.id); if (x) x.done = !x.done; })}
                          className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 transition active:scale-90 ${t.done ? "border-transparent bg-accent text-white" : "border-stone-300 text-transparent hover:border-emerald-400 dark:border-white/25"}`}>
                          <Check size={15} strokeWidth={3.5} />
                        </button>
                        <span className="min-w-0 flex-1">
                          <span className={`block truncate text-[13.5px] font-bold ${t.done ? "text-stone-400 line-through dark:text-zinc-500" : "text-stone-700 dark:text-zinc-200"}`}>{t.title}</span>
                          <span className="mt-0.5 flex items-center gap-1.5">
                            <span className={`h-1.5 w-1.5 rounded-full ${pm.dot}`} />
                            <span className={`text-[10.5px] font-bold ${pm.color}`}>{pm.label}</span>
                            {t.categoryId && catName(t.categoryId) && (
                              <span className="flex items-center gap-1 text-[10.5px] font-bold text-stone-400">
                                <span className="h-2 w-2 rounded-full" style={{ background: catColor(t.categoryId) }} /> {catName(t.categoryId)}
                              </span>
                            )}
                          </span>
                        </span>
                        <button onClick={() => upd((d) => { d.tasks = d.tasks.filter((y) => y.id !== t.id); })} className="shrink-0 text-stone-300 opacity-0 transition hover:text-rose-500 group-hover:opacity-100"><Trash2 size={15} /></button>
                      </motion.li>
                    );
                  })}
                </ul>
              )}
            </div>
          </Card>

          {/* کارت ۳: برنامه زمانی */}
          <Card>
            <CardHead icon={<Clock3 size={19} />} title="برنامه زمانی روز" sub="بلوک‌های زمانی‌ات را بچین" action={<span className="rounded-full bg-accent-soft px-2.5 py-1 text-[11px] font-black text-accent">{toFa(day.schedule.length)} بلوک</span>} />
            <div className="flex flex-col gap-3 p-5">
              <input value={sTitle} onChange={(e) => setSTitle(e.target.value)} placeholder="عنوان برنامه… مثلاً جلسه، مطالعه" className={inputCls} />
              <div className="flex items-center gap-2" dir="ltr">
                <input type="time" value={sStart} onChange={(e) => setSStart(e.target.value)} className={inputCls + " text-center font-black"} />
                <span className="text-[12px] font-black text-stone-400">تا</span>
                <input type="time" value={sEnd} onChange={(e) => setSEnd(e.target.value)} className={inputCls + " text-center font-black"} />
                <button onClick={addSchedule} className={btnAccent + " shrink-0 !px-3.5"}><Plus size={16} /></button>
              </div>
              {sortedSched.length === 0 ? (
                <Empty emoji="🕒" title="برنامه‌ای ثبت نشده" sub="روزت را به بلوک‌های ۱–۲ ساعته تقسیم کن" />
              ) : (
                <div className="flex flex-col">
                  {sortedSched.map((s) => (
                    <div key={s.id} className="timeline-dot group relative flex gap-3 pb-2.5 pr-9 last:pb-0">
                      <span className={`absolute right-2 top-2 grid h-[30px] w-[30px] place-items-center rounded-full border-2 bg-white text-[11px] font-black dark:bg-zinc-900 ${s.done ? "border-emerald-400 text-emerald-500" : "border-stone-200 text-stone-400 dark:border-white/20"}`}>
                        {toFa(s.start.slice(0, 2))}
                      </span>
                      <div className={`flex flex-1 items-center gap-2 rounded-2xl border px-3 py-2.5 ${s.done ? "border-transparent bg-emerald-50/60 dark:bg-emerald-500/10" : "border-stone-150 border-stone-200 bg-white dark:border-white/10 dark:bg-white/[0.03]"}`}>
                        <button onClick={() => upd((d) => { const x = d.schedule.find((y) => y.id === s.id); if (x) x.done = !x.done; })}
                          className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition ${s.done ? "border-transparent bg-emerald-500 text-white" : "border-stone-300 text-transparent dark:border-white/25"}`}>
                          <Check size={13} strokeWidth={3.5} />
                        </button>
                        <div className="min-w-0 flex-1">
                          <p className={`truncate text-[13px] font-extrabold ${s.done ? "text-stone-400 line-through" : "text-stone-700 dark:text-zinc-200"}`}>{s.title}</p>
                          <p className="text-[11px] font-bold text-stone-400" dir="ltr">{toFa(s.start)} – {toFa(s.end)}</p>
                        </div>
                        <button onClick={() => upd((d) => { d.schedule = d.schedule.filter((y) => y.id !== s.id); })} className="text-stone-300 opacity-0 transition hover:text-rose-500 group-hover:opacity-100"><Trash2 size={14} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* کارت ۶: یادداشت و گزارش */}
          <Card className="overflow-hidden">
            <CardHead icon={<NotebookPen size={19} />} title="یادداشت و گزارش پایان روز" sub="شب، روزت را مرور و ببند" />
            <div className="flex flex-col gap-3 p-5">
              <textarea value={day.notes} onChange={(e) => upd((d) => { d.notes = e.target.value; })} placeholder="یادداشت‌های طول روز… ایده‌ها، اتفاق‌ها، حرف‌های نگفته" rows={3} className={inputCls + " resize-none leading-6"} />
              <textarea value={day.endReport} onChange={(e) => upd((d) => { d.endReport = e.target.value; })} placeholder="🌙 گزارش پایان روز… امروز چی شد؟ چی یاد گرفتی؟ فردا چی را بهتر می‌کنی؟" rows={3} className={inputCls + " resize-none border-emerald-200 bg-emerald-50/40 leading-6 dark:border-emerald-500/20 dark:bg-emerald-500/[0.06]"} />
              <div className="rounded-2xl border border-stone-100 bg-stone-50/70 p-4 dark:border-white/10 dark:bg-white/5">
                <div className="mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-[12.5px] font-extrabold"><Star size={14} className="text-amber-500" /> امتیاز امروز</span>
                  <span className="flex items-center gap-1.5 text-[18px] font-black">{scoreEmoji} <span className="text-accent">{toFa(day.score)}</span><span className="text-[12px] font-bold text-stone-400">از ۱۰</span></span>
                </div>
                <input type="range" min={0} max={10} value={day.score} onChange={(e) => upd((d) => { d.score = Number(e.target.value); })} className="w-full" dir="ltr" />
                <div className="mt-1 flex justify-between text-[10px] font-bold text-stone-400" dir="ltr">
                  <span>0</span><span>5</span><span>10</span>
                </div>
              </div>
              {!day.completed ? (
                !confirmClose ? (
                  <button onClick={() => setConfirmClose(true)} className={btnAccent + " w-full !py-3"}>
                    <CheckCircle2 size={17} /> بستن و پایان روز
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button onClick={() => { upd((d) => { d.completed = true; }); setConfirmClose(false); notify("روز بسته شد. فردا می‌بینمت 🌙"); }} className={btnAccent + " flex-1 !py-3"}>
                      <PartyPopper size={16} /> مطمئنم، ببندش
                    </button>
                    <button onClick={() => setConfirmClose(false)} className={btnGhost + " flex-1"}>انصراف</button>
                  </div>
                )
              ) : (
                <button onClick={() => upd((d) => { d.completed = false; })} className={btnGhost + " w-full border-dashed"}>
                  <ChevronLeft size={15} /> بازگشایی روز برای ویرایش
                </button>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Chip1({ text, ok }: { text: string; ok: boolean }) {
  return (
    <span className={`rounded-full px-2.5 py-1 text-[11px] font-black ${ok ? "bg-accent-soft text-accent" : "bg-stone-100 text-stone-400 dark:bg-white/10 dark:text-zinc-500"}`}>
      {text}
    </span>
  );
}
