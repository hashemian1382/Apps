import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Archive, ArrowLeft, Check, CornerDownLeft, Plus, Search, Trash2, Pencil } from "lucide-react";
import { PRIORITY_META, addDaysISO, todayISO, toFa, uid, type AppData, type BacklogItem, type Priority } from "../lib/core";
import { Card, CardHead, Empty, btnAccent, btnGhost, inputCls } from "./ui";

export default function BacklogView({ data, setData, notify, goToday }: {
  data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>>; notify: (m: string) => void; goToday: (iso: string) => void;
}) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [pri, setPri] = useState<Priority>("medium");
  const [cat, setCat] = useState("");
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | Priority | "done">("all");
  const [editing, setEditing] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");

  const add = () => {
    if (!title.trim()) { notify("عنوان کار را بنویس"); return; }
    const item: BacklogItem = { id: uid(), title: title.trim(), desc: desc.trim(), priority: pri, categoryId: cat || undefined, createdAt: Date.now(), done: false };
    setData((p) => ({ ...p, backlog: [item, ...p.backlog] }));
    setTitle(""); setDesc("");
    notify("به بک‌لاگ اضافه شد");
  };

  const sendToToday = (id: string) => {
    const item = data.backlog.find((b) => b.id === id);
    if (!item) return;
    const t = todayISO();
    setData((p) => {
      const days = { ...p.days };
      const dd = days[t] ?? { date: t, wakeTime: "", sleepTime: "", mood: 0, energy: 0, water: 0, weight: "", mainGoal: "", gratitude: "", tasks: [], schedule: [], habitsDone: {}, tomorrowTasks: [], tomorrowNote: "", notes: "", endReport: "", score: 0, completed: false };
      if (!dd.tasks.some((x) => x.title === item.title)) {
        dd.tasks = [...dd.tasks, { id: uid(), title: item.title, done: false, priority: item.priority, categoryId: item.categoryId, createdAt: Date.now() }];
      }
      days[t] = dd;
      return { ...p, days };
    });
    notify("به تسک‌های امروز منتقل شد");
    goToday(t);
  };

  const sendToTomorrow = (id: string) => {
    const item = data.backlog.find((b) => b.id === id);
    if (!item) return;
    const nx = addDaysISO(todayISO(), 1);
    setData((p) => {
      const days = { ...p.days };
      const dd = days[nx] ?? { date: nx, wakeTime: "", sleepTime: "", mood: 0, energy: 0, water: 0, weight: "", mainGoal: "", gratitude: "", tasks: [], schedule: [], habitsDone: {}, tomorrowTasks: [], tomorrowNote: "", notes: "", endReport: "", score: 0, completed: false };
      if (!dd.tasks.some((x) => x.title === item.title)) {
        dd.tasks = [...dd.tasks, { id: uid(), title: item.title, done: false, priority: item.priority, categoryId: item.categoryId, createdAt: Date.now() }];
      }
      days[nx] = dd;
      return { ...p, days };
    });
    notify("برای فردا برنامه‌ریزی شد");
  };

  const list = data.backlog.filter((b) => {
    if (filter === "done" && !b.done) return false;
    if (filter !== "all" && filter !== "done" && (b.done || b.priority !== filter)) return false;
    if (filter === "all" && b.done) return false;
    if (q && !(b.title + b.desc).includes(q)) return false;
    return true;
  }).sort((a, b) => Number(a.done) - Number(b.done));

  const doneCount = data.backlog.filter((b) => b.done).length;
  const openCount = data.backlog.length - doneCount;

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardHead icon={<Archive size={19} />} title="بک‌لاگ" sub="مخزن همه کارهایی که باید روزی انجام شوند"
          action={<span className="rounded-full bg-accent-soft px-3 py-1 text-[11.5px] font-black text-accent">{toFa(openCount)} کار باز</span>} />
        <div className="flex flex-col gap-3 p-5">
          <input value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="عنوان کار… مثلاً: تمدید بیمه ماشین" className={inputCls + " font-bold"} />
          <div className="flex flex-col gap-2 sm:flex-row">
            <input value={desc} onChange={(e) => setDesc(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="توضیح کوتاه (اختیاری)…" className={inputCls + " flex-1"} />
            <div className="flex gap-2">
              <select value={pri} onChange={(e) => setPri(e.target.value as Priority)} className="rounded-2xl border border-stone-200 bg-white px-3 py-2.5 text-[12.5px] font-bold outline-none dark:border-white/10 dark:bg-white/5">
                <option value="urgent">فوری</option><option value="high">مهم</option><option value="medium">متوسط</option><option value="low">کم</option>
              </select>
              <select value={cat} onChange={(e) => setCat(e.target.value)} className="rounded-2xl border border-stone-200 bg-white px-3 py-2.5 text-[12.5px] font-bold outline-none dark:border-white/10 dark:bg-white/5">
                <option value="">دسته…</option>
                {data.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <button onClick={add} className={btnAccent + " shrink-0"}><Plus size={16} /> افزودن</button>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو در بک‌لاگ…" className={inputCls + " !pr-10"} />
            </div>
            <div className="flex overflow-hidden rounded-2xl border border-stone-200 text-[11.5px] font-bold dark:border-white/10">
              {(["all", "urgent", "high", "medium", "low", "done"] as const).map((f) => (
                <button key={f} onClick={() => setFilter(f)} className={`px-2.5 py-2 transition ${filter === f ? "bg-accent text-white" : "bg-white text-stone-500 hover:bg-stone-50 dark:bg-white/5 dark:text-zinc-400"}`}>
                  {f === "all" ? "همه" : f === "done" ? `شده (${toFa(doneCount)})` : PRIORITY_META[f].label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {list.length === 0 ? (
        <Card className="p-5"><Empty emoji="🗂️" title="چیزی اینجا نیست" sub={q ? "جستجو نتیجه‌ای نداشت" : "اولین کار بک‌لاگ را بالا اضافه کن"} /></Card>
      ) : (
        <div className="grid gap-2.5 md:grid-cols-2">
          <AnimatePresence>
            {list.map((b) => {
              const pm = PRIORITY_META[b.priority];
              const c = data.categories.find((x) => x.id === b.categoryId);
              const isEd = editing === b.id;
              return (
                <motion.div key={b.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }}
                  className={`rounded-3xl border bg-white p-4 shadow-sm dark:bg-zinc-900 ${b.done ? "border-transparent opacity-60 dark:border-white/5" : "border-stone-200/80 dark:border-white/10"}`}>
                  <div className="flex items-start gap-2.5">
                    <button onClick={() => setData((p) => ({ ...p, backlog: p.backlog.map((x) => x.id === b.id ? { ...x, done: !x.done } : x) }))}
                      className={`mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition ${b.done ? "border-transparent bg-accent text-white" : "border-stone-300 text-transparent hover:border-emerald-400 dark:border-white/25"}`}>
                      <Check size={13} strokeWidth={3.5} />
                    </button>
                    <div className="min-w-0 flex-1">
                      {isEd ? (
                        <div className="flex flex-col gap-1.5">
                          <input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} className={inputCls + " !py-1.5 text-[13px]"} />
                          <input value={editDesc} onChange={(e) => setEditDesc(e.target.value)} className={inputCls + " !py-1.5 text-[12px]"} />
                          <div className="flex gap-1.5">
                            <button onClick={() => { setData((p) => ({ ...p, backlog: p.backlog.map((x) => x.id === b.id ? { ...x, title: editTitle || x.title, desc: editDesc } : x) })); setEditing(null); notify("ویرایش شد"); }} className={btnAccent + " !py-1.5 !text-[12px]"}>ذخیره</button>
                            <button onClick={() => setEditing(null)} className={btnGhost + " !py-1.5 !text-[12px]"}>انصراف</button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <p className={`text-[13.5px] font-extrabold leading-6 ${b.done ? "text-stone-400 line-through" : "text-stone-700 dark:text-zinc-200"}`}>{b.title}</p>
                          {b.desc && <p className="mt-0.5 text-[12px] leading-5 text-stone-400 dark:text-zinc-500">{b.desc}</p>}
                          <div className="mt-2 flex flex-wrap items-center gap-1.5">
                            <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-black ${pm.bg} ${pm.color}`}><span className={`h-1.5 w-1.5 rounded-full ${pm.dot}`} />{pm.label}</span>
                            {c && <span className="inline-flex items-center gap-1 rounded-full bg-stone-100 px-2 py-0.5 text-[10.5px] font-bold text-stone-500 dark:bg-white/10 dark:text-zinc-400"><span className="h-2 w-2 rounded-full" style={{ background: c.color }} />{c.name}</span>}
                          </div>
                        </>
                      )}
                    </div>
                    {!isEd && (
                      <div className="flex shrink-0 gap-1">
                        <button onClick={() => { setEditing(b.id); setEditTitle(b.title); setEditDesc(b.desc); }} className="grid h-8 w-8 place-items-center rounded-xl text-stone-300 transition hover:bg-stone-100 hover:text-stone-600 dark:hover:bg-white/10" title="ویرایش"><Pencil size={14} /></button>
                        <button onClick={() => setData((p) => ({ ...p, backlog: p.backlog.filter((x) => x.id !== b.id) }))} className="grid h-8 w-8 place-items-center rounded-xl text-stone-300 transition hover:bg-rose-50 hover:text-rose-500" title="حذف"><Trash2 size={14} /></button>
                      </div>
                    )}
                  </div>
                  {!b.done && !isEd && (
                    <div className="mt-3 flex gap-1.5 border-t border-dashed border-stone-100 pt-2.5 dark:border-white/10">
                      <button onClick={() => sendToToday(b.id)} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-accent-soft py-2 text-[12px] font-black text-accent transition hover:brightness-95 active:scale-[0.98]">
                        <CornerDownLeft size={13} /> امروز
                      </button>
                      <button onClick={() => sendToTomorrow(b.id)} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-stone-100 py-2 text-[12px] font-black text-stone-500 transition hover:bg-stone-200 active:scale-[0.98] dark:bg-white/10 dark:text-zinc-300">
                        فردا <ArrowLeft size={13} />
                      </button>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
