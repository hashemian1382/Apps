import { useRef, useState } from "react";
import {
  AlertTriangle, Bell, Check, Database, Download, FolderCog, Leaf, Moon, Palette,
  Plus, RotateCcw, Settings2, Sun, Trash2, Upload, User, Type, Info, HardDrive,
} from "lucide-react";
import { CATEGORY_COLORS, defaultData, loadData, persist, toFa, uid, type AppData } from "../lib/core";
import { Card, CardHead, Empty, btnAccent, btnGhost, inputCls } from "./ui";

const EMOJIS = ["🏃", "📚", "🧘", "🍏", "😴", "💧", "✍️", "🎨", "💪", "🧠", "🌅", "📵", "🚶", "🎵", "💰", "🧹"];
const ACCENTS = [
  { k: "emerald", c: "#10b981", label: "سبز" },
  { k: "blue", c: "#3b82f6", label: "آبی" },
  { k: "violet", c: "#8b5cf6", label: "بنفش" },
  { k: "rose", c: "#f2446e", label: "رز" },
  { k: "amber", c: "#f59e0b", label: "کهربایی" },
  { k: "teal", c: "#14b8a6", label: "فیروزه‌ای" },
];

export default function SettingsView({ data, setData, notify }: {
  data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>>; notify: (m: string) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [catName, setCatName] = useState("");
  const [catColor, setCatColor] = useState(CATEGORY_COLORS[0]);
  const [habitName, setHabitName] = useState("");
  const [habitEmoji, setHabitEmoji] = useState("🌱");
  const [habitColor, setHabitColor] = useState(CATEGORY_COLORS[0]);
  const [showReset, setShowReset] = useState(false);
  const [reminder, setReminder] = useState(() => localStorage.getItem("roozaneh-reminder") || "");

  let sizeKB = 0;
  try { sizeKB = Math.round(((localStorage.getItem("roozaneh-data-v1") || "").length * 2) / 1024); } catch { /* noop */ }

  const exportBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `roozaneh-backup.json`;
    a.click();
    URL.revokeObjectURL(url);
    notify("فایل بکاپ دانلود شد");
  };

  const importBackup = (f: File) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const parsed = JSON.parse(String(r.result));
        if (!parsed.days || !parsed.settings || !Array.isArray(parsed.backlog)) throw new Error("bad");
        setData(parsed);
        persist(parsed);
        notify("بکاپ با موفقیت بازیابی شد ✓");
      } catch { notify("فایل انتخاب‌شده معتبر نیست"); }
    };
    r.readAsText(f);
  };

  const resetAll = () => {
    const fresh = defaultData();
    // keep settings appearance
    fresh.settings = data.settings;
    setData(fresh);
    persist(fresh);
    setShowReset(false);
    notify("همه داده‌ها پاک و از نو شروع شد");
  };

  const loadDemo = () => {
    const fresh = defaultData();
    fresh.settings = data.settings;
    setData(fresh);
    persist(fresh);
    notify("داده نمایشی بارگذاری شد");
  };

  const setTheme = (theme: "light" | "dark") =>
    setData((p) => ({ ...p, settings: { ...p.settings, theme } }));

  return (
    <div className="grid items-start gap-4 xl:grid-cols-2">
      <div className="flex flex-col gap-4">
        {/* profile */}
        <Card>
          <CardHead icon={<User size={19} />} title="پروفایل" sub="برنامه با نام تو صحبت می‌کند" />
          <div className="flex items-center gap-3 p-5">
            <span className="bg-accent grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-2xl text-white shadow-lg">
              {(data.settings.userName || "ر").trim().charAt(0) || "ر"}
            </span>
            <div className="flex-1">
              <label className="mb-1 block text-[12px] font-extrabold text-stone-500 dark:text-zinc-400">نام نمایشی</label>
              <input value={data.settings.userName} onChange={(e) => setData((p) => ({ ...p, settings: { ...p.settings, userName: e.target.value } }))}
                placeholder="اسمت چیه؟" className={inputCls + " font-bold"} maxLength={30} />
            </div>
          </div>
        </Card>

        {/* appearance */}
        <Card>
          <CardHead icon={<Palette size={19} />} title="تنظیمات ظاهری" sub="تم، رنگ و اندازه فونت" />
          <div className="flex flex-col gap-4 p-5">
            <div>
              <p className="mb-2 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400">حالت نمایش</p>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setTheme("light")} className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-3 text-[13px] font-extrabold transition ${data.settings.theme === "light" ? "border-transparent bg-accent-soft text-accent ring-2 ring-accent" : "border-stone-200 text-stone-500 dark:border-white/10 dark:text-zinc-400"}`}>
                  <Sun size={16} /> روشن
                </button>
                <button onClick={() => setTheme("dark")} className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-3 text-[13px] font-extrabold transition ${data.settings.theme === "dark" ? "border-transparent bg-accent-soft text-accent ring-2 ring-accent" : "border-stone-200 text-stone-500 dark:border-white/10 dark:text-zinc-400"}`}>
                  <Moon size={16} /> تیره
                </button>
              </div>
            </div>
            <div>
              <p className="mb-2 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400">رنگ اصلی برنامه</p>
              <div className="flex flex-wrap gap-2">
                {ACCENTS.map((a) => (
                  <button key={a.k} onClick={() => setData((p) => ({ ...p, settings: { ...p.settings, accent: a.k } }))} title={a.label}
                    className={`grid h-11 w-11 place-items-center rounded-2xl transition active:scale-90 ${data.settings.accent === a.k ? "ring-2 ring-offset-2 ring-stone-400 dark:ring-offset-zinc-900" : "hover:scale-105"}`}
                    style={{ background: a.c, ["--tw-ring-color" as string]: a.c }}>
                    {data.settings.accent === a.k && <Check size={17} className="text-white" strokeWidth={3} />}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-2 flex items-center gap-1.5 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400"><Type size={13} /> اندازه فونت</p>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setData((p) => ({ ...p, settings: { ...p.settings, fontScale: "normal" } }))} className={`rounded-2xl border px-3 py-2.5 text-[13px] font-extrabold ${data.settings.fontScale === "normal" ? "border-transparent bg-accent-soft text-accent ring-2 ring-accent" : "border-stone-200 text-stone-500 dark:border-white/10 dark:text-zinc-400"}`}>معمولی</button>
                <button onClick={() => setData((p) => ({ ...p, settings: { ...p.settings, fontScale: "large" } }))} className={`rounded-2xl border px-3 py-2.5 text-[15px] font-extrabold ${data.settings.fontScale === "large" ? "border-transparent bg-accent-soft text-accent ring-2 ring-accent" : "border-stone-200 text-stone-500 dark:border-white/10 dark:text-zinc-400"}`}>درشت‌تر</button>
              </div>
            </div>
            <div>
              <p className="mb-2 flex items-center gap-1.5 text-[12px] font-extrabold text-stone-500 dark:text-zinc-400"><Bell size={13} /> یادآور روزانه (فقط نمایشی)</p>
              <div className="flex gap-2">
                <input type="time" value={reminder} onChange={(e) => { setReminder(e.target.value); localStorage.setItem("roozaneh-reminder", e.target.value); }} className={inputCls + " text-center font-black"} dir="ltr" />
                <button onClick={() => { notify(reminder ? `یادآور روی ${toFa(reminder)} تنظیم شد (در این نسخه فقط ذخیره می‌شود)` : "اول ساعت را انتخاب کن"); }} className={btnGhost}>ثبت</button>
              </div>
              <p className="mt-1.5 text-[11px] leading-5 text-stone-400">در نسخه تک‌فایل، اعلان واقعی مرورگر نیاز به باز بودن صفحه دارد؛ این ساعت فقط ذخیره می‌شود.</p>
            </div>
          </div>
        </Card>

        {/* backup */}
        <Card>
          <CardHead icon={<Database size={19} />} title="بکاپ و بازیابی" sub="داده فقط روی همین مرورگر است — مراقبش باش" />
          <div className="flex flex-col gap-3 p-5">
            <div className="flex items-center gap-2.5 rounded-2xl bg-stone-50 px-4 py-3 text-[12px] font-bold text-stone-500 dark:bg-white/5 dark:text-zinc-400">
              <HardDrive size={16} className="text-accent shrink-0" />
              حجم داده ذخیره‌شده: <span className="font-black text-stone-700 dark:text-zinc-200">{toFa(sizeKB)} کیلوبایت</span>
              <span className="mr-auto">{toFa(Object.keys(data.days).length)} روز • {toFa(data.backlog.length)} بک‌لاگ</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={exportBackup} className={btnAccent}><Download size={16} /> دانلود بکاپ</button>
              <button onClick={() => fileRef.current?.click()} className={btnGhost + " !py-2.5"}><Upload size={16} /> بازیابی از فایل</button>
            </div>
            <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importBackup(f); e.target.value = ""; }} />
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3.5 text-[12px] leading-6 text-amber-800 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200">
              ⚠️ پاک شدن حافظه مرورگر = از دست رفتن داده. پیشنهاد: هفته‌ای یک‌بار «دانلود بکاپ» را بزن و فایل را نگه دار.
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={loadDemo} className={btnGhost}><RotateCcw size={15} /> بارگذاری داده نمایشی</button>
              {!showReset ? (
                <button onClick={() => setShowReset(true)} className="inline-flex items-center justify-center gap-2 rounded-2xl border border-rose-200 bg-rose-50 px-3.5 py-2 text-[13px] font-bold text-rose-600 transition hover:bg-rose-100 dark:border-rose-500/20 dark:bg-rose-500/10 dark:text-rose-300">
                  <Trash2 size={15} /> حذف همه داده‌ها
                </button>
              ) : (
                <div className="flex gap-1.5">
                  <button onClick={resetAll} className="flex-1 rounded-2xl bg-rose-500 py-2 text-[12.5px] font-black text-white">مطمئنم، حذف کن</button>
                  <button onClick={() => setShowReset(false)} className={btnGhost + " flex-1"}>انصراف</button>
                </div>
              )}
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-4">
        {/* categories */}
        <Card>
          <CardHead icon={<FolderCog size={19} />} title="مدیریت دسته‌بندی‌ها" sub={`${toFa(data.categories.length)} دسته`} />
          <div className="flex flex-col gap-3 p-5">
            <div className="flex gap-2">
              <input value={catName} onChange={(e) => setCatName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addCat()} placeholder="نام دسته جدید…" className={inputCls} maxLength={24} />
              <button onClick={addCat} className={btnAccent + " shrink-0 !px-3.5"}><Plus size={16} /></button>
            </div>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_COLORS.map((c) => (
                <button key={c} onClick={() => setCatColor(c)} className={`h-8 w-8 rounded-xl transition ${catColor === c ? "ring-2 ring-offset-2 ring-stone-400 scale-110 dark:ring-offset-zinc-900" : "hover:scale-105"}`} style={{ background: c }} />
              ))}
            </div>
            {data.categories.length === 0 && <Empty emoji="📁" title="دسته‌ای نیست" />}
            <ul className="flex flex-col gap-1.5">
              {data.categories.map((c) => {
                const usage = data.backlog.filter((b) => b.categoryId === c.id).length + Object.values(data.days).reduce((a, d) => a + d.tasks.filter((t) => t.categoryId === c.id).length, 0);
                return (
                  <li key={c.id} className="flex items-center gap-2.5 rounded-2xl border border-stone-100 bg-stone-50/60 px-3 py-2.5 dark:border-white/10 dark:bg-white/5">
                    <span className="h-4 w-4 shrink-0 rounded-full" style={{ background: c.color }} />
                    <span className="flex-1 text-[13px] font-extrabold">{c.name}</span>
                    <span className="text-[11px] font-bold text-stone-400">{toFa(usage)} استفاده</span>
                    <button onClick={() => setData((p) => ({ ...p, categories: p.categories.filter((x) => x.id !== c.id) }))} className="text-stone-300 transition hover:text-rose-500"><Trash2 size={15} /></button>
                  </li>
                );
              })}
            </ul>
          </div>
        </Card>

        {/* habits */}
        <Card>
          <CardHead icon={<Leaf size={19} />} title="مدیریت عادت‌ها" sub={`${toFa(data.habits.filter((h) => h.active).length)} فعال`} />
          <div className="flex flex-col gap-3 p-5">
            <input value={habitName} onChange={(e) => setHabitName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addHabit()} placeholder="نام عادت جدید… مثلاً پیاده‌روی" className={inputCls} maxLength={30} />
            <div>
              <p className="mb-1.5 text-[11.5px] font-bold text-stone-400">ایموجی:</p>
              <div className="flex flex-wrap gap-1">
                {EMOJIS.map((e) => (
                  <button key={e} onClick={() => setHabitEmoji(e)} className={`grid h-9 w-9 place-items-center rounded-xl text-[18px] transition ${habitEmoji === e ? "bg-accent-soft ring-2 ring-accent" : "bg-stone-50 hover:bg-stone-100 dark:bg-white/5 dark:hover:bg-white/10"}`}>{e}</button>
                ))}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_COLORS.map((c) => (
                <button key={c} onClick={() => setHabitColor(c)} className={`h-8 w-8 rounded-xl transition ${habitColor === c ? "ring-2 ring-offset-2 ring-stone-400 scale-110 dark:ring-offset-zinc-900" : "hover:scale-105"}`} style={{ background: c }} />
              ))}
            </div>
            <button onClick={addHabit} className={btnAccent + " w-full"}><Plus size={16} /> افزودن عادت {habitEmoji}</button>
            <ul className="flex flex-col gap-1.5">
              {data.habits.map((h) => (
                <li key={h.id} className={`flex items-center gap-2.5 rounded-2xl border px-3 py-2.5 ${h.active ? "border-stone-100 bg-stone-50/60 dark:border-white/10 dark:bg-white/5" : "border-dashed border-stone-200 opacity-60 dark:border-white/10"}`}>
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[19px]" style={{ background: `${h.color}22` }}>{h.emoji}</span>
                  <span className="flex-1 text-[13px] font-extrabold">{h.name}</span>
                  <button onClick={() => setData((p) => ({ ...p, habits: p.habits.map((x) => x.id === h.id ? { ...x, active: !x.active } : x) }))}
                    className={`rounded-xl px-3 py-1.5 text-[11px] font-black transition ${h.active ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300" : "bg-stone-200 text-stone-500 dark:bg-white/10 dark:text-zinc-400"}`}>
                    {h.active ? "فعال" : "غیرفعال"}
                  </button>
                  <button onClick={() => setData((p) => ({ ...p, habits: p.habits.filter((x) => x.id !== h.id) }))} className="text-stone-300 transition hover:text-rose-500"><Trash2 size={15} /></button>
                </li>
              ))}
            </ul>
          </div>
        </Card>

        {/* about */}
        <Card>
          <CardHead icon={<Settings2 size={19} />} title="درباره روزانه" sub="نسخه ۱٫۰ • تک‌فایل • آفلاین" />
          <div className="flex flex-col gap-2 p-5 text-[12.5px] leading-7 text-stone-500 dark:text-zinc-400">
            <p className="flex gap-2"><Info size={15} className="mt-1.5 shrink-0 text-accent" /> «روزانه» یک ابزار شخصی مدیریت روز است: صبح هدف بگذار، طول روز تسک و عادت بزن، شب گزارش بنویس و روز را ببند. بدون حساب کاربری، بدون سرور؛ همه‌چیز در LocalStorage همین مرورگر.</p>
            <div className="flex items-center gap-2 rounded-2xl bg-stone-50 px-3.5 py-2.5 dark:bg-white/5">
              <AlertTriangle size={14} className="shrink-0 text-amber-500" />
              با «حذف داده مرورگر» همه‌چیز پاک می‌شود؛ بکاپ هفتگی را فراموش نکن.
            </div>
            <button onClick={() => { const d = loadData(); void d; notify("داده از حافظه محلی بازخوانی شد"); }} className={btnGhost + " w-full"}>
              <RotateCcw size={14} /> بازخوانی داده از حافظه محلی
            </button>
          </div>
        </Card>
      </div>
    </div>
  );

  function addCat() {
    if (!catName.trim()) { notify("نام دسته را بنویس"); return; }
    setData((p) => ({ ...p, categories: [...p.categories, { id: uid(), name: catName.trim(), color: catColor }] }));
    setCatName("");
    notify("دسته اضافه شد");
  }
  function addHabit() {
    if (!habitName.trim()) { notify("نام عادت را بنویس"); return; }
    setData((p) => ({ ...p, habits: [...p.habits, { id: uid(), name: habitName.trim(), emoji: habitEmoji, color: habitColor, active: true }] }));
    setHabitName("");
    notify("عادت جدید اضافه شد");
  }
}
