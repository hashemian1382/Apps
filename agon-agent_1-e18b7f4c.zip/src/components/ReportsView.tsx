import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Award, BarChart3, CalendarRange, Flame, Star, TrendingUp, Trophy } from "lucide-react";
import {
  J_MONTHS, addDaysISO, calcStreak, currentJalali, dayStats, formatJalaliShort,
  jalaliOf, lastNDays, todayISO, toFa, weekdayFa, type AppData,
} from "../lib/core";
import { Card, CardHead, Empty, Progress, inputCls } from "./ui";

function Bar({ label, value, max, color, onClick }: { label: string; value: number; max: number; color: string; onClick?: () => void }) {
  const h = max ? Math.max(6, Math.round((value / max) * 120)) : 6;
  return (
    <button onClick={onClick} className="group flex min-w-[38px] flex-1 flex-col items-center gap-1.5" title={`${label}: ${value}٪`}>
      <span className="text-[10.5px] font-black text-stone-400 dark:text-zinc-500">{toFa(value)}٪</span>
      <span className="flex h-[128px] w-full items-end justify-center rounded-2xl bg-stone-50 px-1 pb-1 dark:bg-white/[0.04]">
        <motion.span initial={{ height: 0 }} animate={{ height: h }} transition={{ duration: 0.5 }}
          className="w-full max-w-[34px] rounded-xl transition group-hover:brightness-110"
          style={{ background: value === 0 ? "rgba(140,150,160,.25)" : color }} />
      </span>
      <span className="truncate text-[10.5px] font-bold text-stone-500 dark:text-zinc-400">{label}</span>
    </button>
  );
}

export default function ReportsView({ data, goDay }: { data: AppData; goDay: (iso: string) => void }) {
  const t = todayISO();
  const [range, setRange] = useState<7 | 30>(7);
  const [customFrom, setCustomFrom] = useState(addDaysISO(t, -13));
  const [customTo, setCustomTo] = useState(t);
  const [mode, setMode] = useState<"preset" | "custom">("preset");

  const habitsActive = data.habits.filter((h) => h.active);

  const days = useMemo(() => {
    if (mode === "preset") return lastNDays(t, range);
    const out: string[] = [];
    const start = customFrom <= customTo ? customFrom : customTo;
    const end = customFrom <= customTo ? customTo : customFrom;
    let cur = start;
    let guard = 0;
    while (cur <= end && guard < 120) { out.push(cur); cur = addDaysISO(cur, 1); guard++; }
    return out;
  }, [mode, range, customFrom, customTo, t]);

  const rows = days.map((iso) => {
    const d = data.days[iso];
    const s = dayStats(d, habitsActive.length);
    return { iso, day: d, ...s, score: d?.score ?? 0, mood: d?.mood ?? 0, water: d?.water ?? 0 };
  });

  const withData = rows.filter((r) => r.day && (r.day.tasks.length > 0 || Object.keys(r.day.habitsDone).length > 0 || r.day.score > 0 || r.day.mainGoal));
  const avg = (f: (r: (typeof rows)[number]) => number) => (withData.length ? Math.round(withData.reduce((a, r) => a + f(r), 0) / withData.length) : 0);
  const avgOverall = avg((r) => r.overall);
  const avgTasks = avg((r) => r.tasksPct);
  const avgHabits = avg((r) => r.habitsPct);
  const scored = withData.filter((r) => r.score > 0);
  const avgScore = scored.length ? scored.reduce((a, r) => a + r.score, 0) / scored.length : 0;
  const totalDone = rows.reduce((a, r) => a + r.tasksDone, 0);
  const totalWater = rows.reduce((a, r) => a + r.water, 0);
  const best = [...rows].sort((a, b) => b.overall - a.overall)[0];
  const maxV = Math.max(10, ...rows.map((r) => r.overall));

  const streakAny = calcStreak(data.days, (d) => !!d && (d.tasks.length > 0 || Object.keys(d.habitsDone).length > 0), t);
  const streakTasks = calcStreak(data.days, (d) => !!d && d.tasks.length > 0 && d.tasks.every((x) => x.done), t);
  const streakHabits = calcStreak(data.days, (d) => !!d && habitsActive.length > 0 && habitsActive.every((h) => d.habitsDone[h.id]), t);
  const streakClose = calcStreak(data.days, (d) => !!d && d.completed, t);

  const cj = currentJalali();
  const monthRows = useMemo(() => {
    const out: string[] = [];
    try {
      const tj = jalaliOf(t);
      let cur = t;
      let guard = 0;
      while (jalaliOf(cur).jd !== 1 && guard < 40) { cur = addDaysISO(cur, -1); guard++; }
      const firstIso = cur;
      let n = 0;
      let c = firstIso;
      while (jalaliOf(c).jm === tj.jm && n < 32) { n++; c = addDaysISO(c, 1); }
      for (let i = 0; i < n; i++) out.push(addDaysISO(firstIso, i));
    } catch { /* noop */ }
    return out;
  }, [t]);

  const mWith = monthRows.filter((iso) => {
    const d = data.days[iso];
    return d && (d.tasks.length > 0 || d.score > 0 || d.completed);
  });
  const mAvg = mWith.length ? Math.round(mWith.reduce((a, iso) => a + dayStats(data.days[iso], habitsActive.length).overall, 0) / mWith.length) : 0;
  const mDone = monthRows.reduce((a, iso) => a + (data.days[iso]?.tasks.filter((x) => x.done).length ?? 0), 0);
  const mTotal = monthRows.reduce((a, iso) => a + (data.days[iso]?.tasks.length ?? 0), 0);
  const mScores = monthRows.map((i) => data.days[i]?.score ?? 0).filter((x) => x > 0);
  const mAvgScore = mScores.length ? (mScores.reduce((a, b) => a + b, 0) / mScores.length).toFixed(1) : "—";

  const habitRates = habitsActive.map((h) => {
    const c = days.filter((iso) => data.days[iso]?.habitsDone[h.id]).length;
    return { h, pct: days.length ? Math.round((c / days.length) * 100) : 0, count: c };
  }).sort((a, b) => b.pct - a.pct);

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {[
          { icon: <Flame size={20} />, label: "استریک روزهای فعال", v: streakAny, c: "from-orange-500 to-rose-500" },
          { icon: <Trophy size={20} />, label: "استریک تکمیل تسک‌ها", v: streakTasks, c: "from-amber-400 to-orange-500" },
          { icon: <Star size={20} />, label: "استریک همه عادت‌ها", v: streakHabits, c: "from-emerald-500 to-teal-500" },
          { icon: <Award size={20} />, label: "استریک بستن روز", v: streakClose, c: "from-violet-500 to-purple-500" },
        ].map((s, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
            className="relative overflow-hidden rounded-3xl border border-stone-200/80 bg-white p-4 dark:border-white/10 dark:bg-zinc-900">
            <div className={`absolute -left-6 -top-6 h-20 w-20 rounded-full bg-gradient-to-br ${s.c} opacity-15 blur-xl`} />
            <span className={`inline-grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br ${s.c} text-white shadow`}>{s.icon}</span>
            <p className="mt-2 text-[26px] font-black leading-none">{toFa(s.v)} <span className="text-[12px] font-bold text-stone-400">روز</span></p>
            <p className="mt-1 text-[11.5px] font-bold text-stone-500 dark:text-zinc-400">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <Card>
        <CardHead icon={<CalendarRange size={19} />} title="گزارش عملکرد" sub="روند پیشرفتت را ببین" action={
          <div className="flex overflow-hidden rounded-xl border border-stone-200 text-[11.5px] font-bold dark:border-white/10">
            <button onClick={() => setMode("preset")} className={`px-3 py-1.5 ${mode === "preset" ? "bg-accent text-white" : "text-stone-500 dark:text-zinc-400"}`}>هفتگی / ماهانه</button>
            <button onClick={() => setMode("custom")} className={`px-3 py-1.5 ${mode === "custom" ? "bg-accent text-white" : "text-stone-500 dark:text-zinc-400"}`}>سفارشی</button>
          </div>
        } />
        <div className="flex flex-col gap-4 p-5">
          {mode === "preset" ? (
            <div className="flex gap-2">
              <button onClick={() => setRange(7)} className={`flex-1 rounded-2xl border px-3 py-2.5 text-[13px] font-extrabold transition ${range === 7 ? "border-transparent bg-accent-soft text-accent ring-2 ring-accent" : "border-stone-200 text-stone-500 dark:border-white/10 dark:text-zinc-400"}`}>۷ روز گذشته</button>
              <button onClick={() => setRange(30)} className={`flex-1 rounded-2xl border px-3 py-2.5 text-[13px] font-extrabold transition ${range === 30 ? "border-transparent bg-accent-soft text-accent ring-2 ring-accent" : "border-stone-200 text-stone-500 dark:border-white/10 dark:text-zinc-400"}`}>۳۰ روز گذشته</button>
            </div>
          ) : (
            <div className="flex flex-col gap-2 sm:flex-row" dir="ltr">
              <input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} className={inputCls} />
              <input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} className={inputCls} />
            </div>
          )}

          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-6">
            {[
              { l: "میانگین پیشرفت", v: `${toFa(avgOverall)}٪` },
              { l: "میانگین تسک", v: `${toFa(avgTasks)}٪` },
              { l: "میانگین عادت", v: `${toFa(avgHabits)}٪` },
              { l: "تسک انجام‌شده", v: toFa(totalDone) },
              { l: "میانگین امتیاز", v: avgScore ? `${toFa(avgScore.toFixed(1))} از ۱۰` : "—" },
              { l: "آب (مجموع)", v: `${toFa(totalWater)} لیوان` },
            ].map((k, i) => (
              <div key={i} className="rounded-2xl border border-stone-100 bg-stone-50/70 px-2 py-3 text-center dark:border-white/10 dark:bg-white/5">
                <p className="text-[16px] font-black text-accent">{k.v}</p>
                <p className="mt-0.5 text-[10.5px] font-bold text-stone-400 dark:text-zinc-500">{k.l}</p>
              </div>
            ))}
          </div>

          <div>
            <p className="mb-2 flex items-center gap-1.5 text-[12.5px] font-extrabold text-stone-500 dark:text-zinc-400"><TrendingUp size={14} className="text-accent" /> نمودار پیشرفت روزانه (برای دیدن روز، لمس کن)</p>
            <div className="flex items-end gap-1 overflow-x-auto pb-1">
              {rows.map((r) => (
                <Bar key={r.iso} label={range === 30 && mode === "preset" ? String(toFa(jalaliOf(r.iso).jd)) : weekdayFa(r.iso).slice(0, 3)}
                  value={r.overall} max={maxV} color="rgb(var(--accent))" onClick={() => goDay(r.iso)} />
              ))}
            </div>
          </div>

          {best && best.overall > 0 ? (
            <div className="flex items-center gap-3 rounded-2xl bg-gradient-to-l from-amber-50 to-orange-50 p-4 ring-1 ring-amber-200/60 dark:from-amber-500/10 dark:to-orange-500/10 dark:ring-amber-500/20">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-xl text-white shadow">🏅</span>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-extrabold">بهترین روز این بازه: {weekdayFa(best.iso)} {formatJalaliShort(best.iso)} با {toFa(best.overall)}٪ پیشرفت</p>
                <button onClick={() => goDay(best.iso)} className="mt-0.5 text-[12px] font-bold text-orange-600 hover:underline dark:text-orange-300">مشاهده روز ←</button>
              </div>
            </div>
          ) : (
            <Empty emoji="📊" title="داده‌ای در این بازه نیست" sub="چند روز را ثبت کن تا نمودار شکل بگیرد" />
          )}

          <div className="overflow-hidden rounded-2xl border border-stone-100 dark:border-white/10">
            {rows.slice().reverse().slice(0, 10).map((r) => (
              <button key={r.iso} onClick={() => goDay(r.iso)} className="flex w-full items-center gap-3 border-b border-stone-50 px-4 py-2.5 text-right transition last:border-0 hover:bg-stone-50 dark:border-white/5 dark:hover:bg-white/5">
                <span className="min-w-[110px] text-[12px] font-extrabold">{weekdayFa(r.iso)} <span className="font-medium text-stone-400">{formatJalaliShort(r.iso)}</span></span>
                <span className="flex-1"><Progress value={r.overall} /></span>
                <span className="w-12 text-left text-[12px] font-black">{toFa(r.overall)}٪</span>
              </button>
            ))}
          </div>
        </div>
      </Card>

      <Card>
        <CardHead icon={<BarChart3 size={19} />} title={`گزارش ماه ${J_MONTHS[cj.jm - 1]} ${toFa(cj.jy)}`} sub={`${toFa(mWith.length)} روز فعال از ${toFa(monthRows.length)} روز`}
          action={<span className="rounded-full bg-accent-soft px-3 py-1 text-[11.5px] font-black text-accent">میانگین {toFa(mAvg)}٪</span>} />
        <div className="grid gap-2.5 p-5 sm:grid-cols-3">
          <div className="rounded-2xl bg-stone-50 p-4 text-center dark:bg-white/5">
            <p className="text-[22px] font-black">{toFa(mDone)}<span className="text-[13px] text-stone-400"> / {toFa(mTotal)}</span></p>
            <p className="text-[11px] font-bold text-stone-400">تسک‌های انجام‌شده ماه</p>
            <div className="mt-2"><Progress value={mTotal ? Math.round((mDone / mTotal) * 100) : 0} /></div>
          </div>
          <div className="rounded-2xl bg-stone-50 p-4 text-center dark:bg-white/5">
            <p className="text-[22px] font-black">{toFa(monthRows.filter((iso) => data.days[iso]?.completed).length)}</p>
            <p className="text-[11px] font-bold text-stone-400">روزهای بسته‌شده</p>
            <p className="mt-2 text-[11px] font-bold text-stone-400">میانگین امتیاز: <span className="text-accent text-[14px] font-black">{toFa(mAvgScore)}</span></p>
          </div>
          <div className="rounded-2xl bg-stone-50 p-4 text-center dark:bg-white/5">
            <p className="text-[22px] font-black">{toFa(mWith.length)}</p>
            <p className="text-[11px] font-bold text-stone-400">روز فعال این ماه</p>
            <p className="mt-2 text-[11px] font-bold text-stone-400">تداوم: <span className="text-accent text-[14px] font-black">{toFa(monthRows.length ? Math.round((mWith.length / monthRows.length) * 100) : 0)}٪</span></p>
          </div>
        </div>
      </Card>

      <Card>
        <CardHead icon={<Flame size={19} />} title="عملکرد عادت‌ها در بازه" sub="کدام عادت قوی‌تر است؟" />
        <div className="flex flex-col gap-2.5 p-5">
          {habitRates.length === 0 && <Empty emoji="🌱" title="عادتی فعال نیست" />}
          {habitRates.map(({ h, pct, count }) => (
            <div key={h.id} className="flex items-center gap-3 rounded-2xl border border-stone-100 bg-stone-50/50 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-[20px]" style={{ background: `${h.color}20` }}>{h.emoji}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between text-[12.5px] font-extrabold">
                  <span>{h.name}</span>
                  <span style={{ color: h.color }}>{toFa(pct)}٪ • {toFa(count)} روز</span>
                </div>
                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-stone-200/70 dark:bg-white/10" dir="ltr">
                  <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: h.color, marginLeft: "auto" }} />
                </div>
              </div>
            </div>
          ))}
          <p className="text-[11px] leading-5 text-stone-400 dark:text-zinc-500">نکته مربی: برای هفته آینده فقط روی ضعیف‌ترین عادت تمرکز کن؛ یک عادت، یک برد کوچک، هر روز.</p>
        </div>
      </Card>
    </div>
  );
}
