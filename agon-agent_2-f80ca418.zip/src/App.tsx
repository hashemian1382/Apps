import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BarChart3, CalendarDays, Database, Download, Home, Menu, Moon, Package, Settings, Sun, X } from "lucide-react";
import type { BacklogItem, DayData, Store, Task, ViewKey } from "./lib/data";
import { emptyDay, faPlain, gregStr, jalaliFull, loadStore, todayKey, uid } from "./lib/data";
import DailyView from "./components/DailyView";
import BacklogView from "./components/BacklogView";
import ReportsView from "./components/ReportsView";
import CalendarView from "./components/CalendarView";
import SettingsView from "./components/SettingsView";

const NAV: { key: ViewKey; label: string; icon: typeof Home; emoji: string }[] = [
  { key: "today", label: "روز جاری", icon: Home, emoji: "☀️" },
  { key: "backlog", label: "بک‌لاگ", icon: Package, emoji: "📦" },
  { key: "reports", label: "گزارش‌ها و عملکرد", icon: BarChart3, emoji: "📊" },
  { key: "calendar", label: "تقویم", icon: CalendarDays, emoji: "🗓" },
  { key: "settings", label: "تنظیمات و داده", icon: Settings, emoji: "⚙️" },
];

export default function App() {
  const [store, setStore] = useState<Store>(() => loadStore());
  const [view, setView] = useState<ViewKey>("today");
  const [selectedDate, setSelectedDate] = useState(todayKey());
  const [sidebar, setSidebar] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [toastTimer, setToastTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try { localStorage.setItem("rooznegar-v1", JSON.stringify(store)); } catch { /* quota */ }
  }, [store]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", store.settings.theme === "dark");
  }, [store.settings.theme]);

  const toast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimer) clearTimeout(toastTimer);
    setToastTimer(setTimeout(() => setToastMsg(null), 2600));
  }, [toastTimer]);

  // keyboard shortcuts: N new task focus, arrows day nav
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "n" || e.key === "N" || e.key === "N".toLowerCase()) {
        if (view === "today") {
          const el = document.querySelector<HTMLInputElement>('input[placeholder*="تسک جدید"]');
          el?.focus();
        }
      }
      if (view === "today") {
        if (e.key === "ArrowLeft") setSelectedDate((d) => { const [y, m, dd] = d.split("-").map(Number); const dt = new Date(y, m - 1, dd); dt.setDate(dt.getDate() + 1); return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`; });
        if (e.key === "ArrowRight") setSelectedDate((d) => { const [y, m, dd] = d.split("-").map(Number); const dt = new Date(y, m - 1, dd); dt.setDate(dt.getDate() - 1); return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`; });
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [view]);

  const day: DayData = useMemo(
    () => store.days[selectedDate] ?? emptyDay(selectedDate),
    [store.days, selectedDate]
  );

  const updateDay = useCallback((patch: Partial<DayData>) => {
    setStore((s) => {
      const cur = s.days[selectedDate] ?? emptyDay(selectedDate);
      return { ...s, days: { ...s.days, [selectedDate]: { ...cur, ...patch } } };
    });
  }, [selectedDate]);

  const moveToBacklog = useCallback((task: Task) => {
    setStore((s) => ({
      ...s,
      backlog: [{ id: uid(), title: task.title, desc: task.note, priority: task.priority, categoryId: task.categoryId, createdAt: todayKey() }, ...s.backlog],
    }));
    toast("به بک‌لاگ منتقل شد");
  }, [toast]);

  const assignToDay = useCallback((item: BacklogItem, dateKey: string) => {
    setStore((s) => {
      const cur = s.days[dateKey] ?? emptyDay(dateKey);
      return {
        ...s,
        days: { ...s.days, [dateKey]: { ...cur, tasks: [...cur.tasks, { id: uid(), title: item.title, done: false, priority: item.priority, categoryId: item.categoryId, note: item.desc }] } },
      };
    });
  }, []);

  const quickBackup = () => {
    const blob = new Blob([JSON.stringify(store, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `rooznegar-backup-${todayKey()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast("بکاپ دانلود شد");
  };

  const goDay = (k: string) => { setSelectedDate(k); setView("today"); };

  const headerDate = jalaliFull(todayKey());

  return (
    <div className="min-h-screen bg-[#f6f5f1] dark:bg-[#0e1116] text-stone-800 dark:text-stone-100 transition-colors">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-stone-200/70 dark:border-white/10 bg-white/85 dark:bg-[#14181f]/85 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-3 sm:px-5 h-16 flex items-center gap-2">
          <button onClick={() => setSidebar(true)} className="lg:hidden p-2 rounded-xl hover:bg-stone-100 dark:hover:bg-white/10"><Menu size={20} /></button>
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 grid place-items-center text-xl shadow-lg shadow-emerald-500/25">🌿</span>
            <div>
              <div className="font-black text-[17px] leading-5">روزنگار</div>
              <div className="text-[10px] text-stone-400 font-bold">سامانه مدیریت شخصی روزانه</div>
            </div>
          </div>
          <div className="hidden md:block absolute left-1/2 -translate-x-1/2 text-center">
            <div className="font-black text-[15px]">{faPlain(headerDate)}</div>
            <div className="text-[11px] text-stone-400 font-bold">{faPlain(gregStr(todayKey()))}</div>
          </div>
          <div className="mr-auto flex items-center gap-1.5">
            <button onClick={() => setStore((s) => ({ ...s, settings: { ...s.settings, theme: s.settings.theme === "dark" ? "light" : "dark" } }))} className="p-2.5 rounded-xl border border-stone-200 dark:border-white/10 hover:bg-stone-100 dark:hover:bg-white/10 transition" title="تم">
              {store.settings.theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <button onClick={quickBackup} className="p-2.5 rounded-xl border border-stone-200 dark:border-white/10 hover:bg-stone-100 dark:hover:bg-white/10 transition" title="بکاپ سریع"><Database size={17} /></button>
            <button onClick={() => setView("settings")} className="p-2.5 rounded-xl bg-stone-900 dark:bg-white dark:text-stone-900 text-white hover:opacity-90 transition" title="تنظیمات"><Settings size={17} /></button>
          </div>
        </div>
        <div className="md:hidden text-center pb-2 -mt-1">
          <span className="text-xs font-black">{faPlain(headerDate)}</span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-3 sm:px-5 py-4 sm:py-6 flex gap-5 items-start">
        {/* Sidebar desktop */}
        <aside className="hidden lg:block w-60 shrink-0 sticky top-24">
          <nav className="rounded-2xl border border-stone-200/80 dark:border-white/10 bg-white dark:bg-white/[0.04] p-2.5 space-y-1 shadow-sm">
            {NAV.map((n) => (
              <button key={n.key} onClick={() => setView(n.key)}
                className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-black transition ${view === n.key ? "bg-gradient-to-l from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/25" : "hover:bg-stone-100 dark:hover:bg-white/5 text-stone-600 dark:text-stone-300"}`}>
                <span className="text-lg">{n.emoji}</span>
                {n.label}
                {n.key === "backlog" && store.backlog.length > 0 && (
                  <span className={`mr-auto text-[10px] rounded-full px-2 py-0.5 font-black ${view === n.key ? "bg-white/25" : "bg-stone-100 dark:bg-white/10"}`}>{store.backlog.length}</span>
                )}
              </button>
            ))}
          </nav>
          <div className="mt-3 rounded-2xl border border-amber-500/25 bg-gradient-to-b from-amber-400/10 to-transparent p-4 text-xs leading-6">
            <div className="font-black mb-1">💡 جریان پیشنهادی امروز</div>
            <div className="text-stone-500 dark:text-stone-400 font-bold">۱. ساعت بیداری را ثبت کن<br />۲. تسک‌ها را مرور کن<br />۳. امشب بازتاب بنویس و فردا را بچین</div>
            <button onClick={quickBackup} className="mt-2 flex items-center gap-1.5 text-[11px] font-black text-amber-700 dark:text-amber-300 hover:underline"><Download size={12} /> بکاپ امروز</button>
          </div>
        </aside>

        {/* Mobile sidebar */}
        <AnimatePresence>
          {sidebar && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSidebar(false)} className="fixed inset-0 bg-black/40 z-40 lg:hidden" />
              <motion.aside initial={{ x: 260 }} animate={{ x: 0 }} exit={{ x: 260 }} transition={{ type: "spring", damping: 28 }}
                className="fixed top-0 bottom-0 right-0 w-72 bg-white dark:bg-[#14181f] z-50 p-4 lg:hidden shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-black">🌿 روزنگار</span>
                  <button onClick={() => setSidebar(false)} className="p-2 rounded-xl hover:bg-stone-100 dark:hover:bg-white/10"><X size={18} /></button>
                </div>
                <nav className="space-y-1">
                  {NAV.map((n) => (
                    <button key={n.key} onClick={() => { setView(n.key); setSidebar(false); }}
                      className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-black ${view === n.key ? "bg-gradient-to-l from-emerald-600 to-teal-600 text-white" : "hover:bg-stone-100 dark:hover:bg-white/5"}`}>
                      <span className="text-lg">{n.emoji}</span>{n.label}
                    </button>
                  ))}
                </nav>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main */}
        <main className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div key={view + selectedDate} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.22 }}>
              {view === "today" && (
                <DailyView day={day} update={updateDay} categories={store.categories} habits={store.habits}
                  selectedDate={selectedDate} setSelectedDate={setSelectedDate} moveToBacklog={moveToBacklog} toast={toast} />
              )}
              {view === "backlog" && (
                <BacklogView backlog={store.backlog} setBacklog={(b) => setStore((s) => ({ ...s, backlog: b }))} categories={store.categories} assignToDay={assignToDay} toast={toast} />
              )}
              {view === "reports" && <ReportsView store={store} />}
              {view === "calendar" && <CalendarView store={store} goDay={goDay} />}
              {view === "settings" && <SettingsView store={store} setStore={setStore} toast={toast} />}
            </motion.div>
          </AnimatePresence>

          <footer className="text-center text-[11px] text-stone-400 mt-8 pb-4">
            روزنگار — همه داده‌ها محلی در مرورگر تو ذخیره می‌شود · بدون سرور · بدون اینترنت
          </footer>
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t border-stone-200 dark:border-white/10 bg-white/90 dark:bg-[#14181f]/90 backdrop-blur-xl px-2 py-1.5 grid grid-cols-5 gap-1">
        {NAV.map((n) => (
          <button key={n.key} onClick={() => setView(n.key)} className={`flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[10px] font-black ${view === n.key ? "text-emerald-600 dark:text-emerald-300" : "text-stone-400"}`}>
            <n.icon size={19} />
            {n.label.split(" ")[0]}
          </button>
        ))}
      </nav>
      <div className="h-16 lg:hidden" />

      {/* Toast */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div initial={{ opacity: 0, y: 20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 rounded-2xl bg-stone-900 dark:bg-white dark:text-stone-900 text-white text-sm font-bold px-5 py-3 shadow-2xl max-w-[90vw] text-center">
            {toastMsg}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
