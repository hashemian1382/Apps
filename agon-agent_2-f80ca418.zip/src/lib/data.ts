import { jalaaliMonthLength, toGregorian, toJalaali } from "jalaali-js";

export type Priority = "q1" | "q2" | "q3" | "q4";
export type ViewKey = "today" | "backlog" | "reports" | "calendar" | "settings";

export interface Task {
  id: string;
  title: string;
  done: boolean;
  priority: Priority;
  categoryId: string;
  plannedStart?: string;
  plannedEnd?: string;
  actualMinutes?: number;
  note?: string;
}

export interface TomorrowTask { id: string; title: string; done: boolean }

export interface DayData {
  date: string;
  wakeUp?: string;
  sleep?: string;
  mood?: string;
  exercised?: boolean;
  exerciseType?: string;
  wentOut?: boolean;
  outWhere?: string;
  score?: number;
  note?: string;
  tasks: Task[];
  habits: Record<string, boolean>;
  tomorrowTasks: TomorrowTask[];
  tomorrowNote?: string;
  good1?: string; good2?: string; good3?: string;
  improve?: string;
  lesson?: string;
}

export interface BacklogItem {
  id: string;
  title: string;
  desc?: string;
  priority: Priority;
  categoryId: string;
  createdAt: string;
  deadline?: string;
}

export interface Category { id: string; name: string; color: string; icon: string }
export interface Habit { id: string; name: string; icon: string; active: boolean }
export interface AppSettings { theme: "light" | "dark"; calendarLang: "jalali" | "gregorian"; weekStart: "saturday" | "monday" }
export interface Store {
  days: Record<string, DayData>;
  backlog: BacklogItem[];
  categories: Category[];
  habits: Habit[];
  settings: AppSettings;
}

export const PRIORITIES: Record<Priority, { label: string; short: string; color: string; bg: string; dot: string; desc: string }> = {
  q1: { label: "فوری و مهم", short: "فوری·مهم", color: "text-red-700 dark:text-red-300", bg: "bg-red-100 dark:bg-red-500/15 border-red-200 dark:border-red-500/30", dot: "bg-red-500", desc: "اول انجام بده" },
  q2: { label: "مهم، غیرفوری", short: "مهم", color: "text-blue-700 dark:text-blue-300", bg: "bg-blue-100 dark:bg-blue-500/15 border-blue-200 dark:border-blue-500/30", dot: "bg-blue-500", desc: "برنامه‌ریزی کن" },
  q3: { label: "فوری، غیرمهم", short: "فوری", color: "text-amber-700 dark:text-amber-300", bg: "bg-amber-100 dark:bg-amber-500/15 border-amber-200 dark:border-amber-500/30", dot: "bg-amber-500", desc: "واگذار / سریع بزن" },
  q4: { label: "نه فوری، نه مهم", short: "کم‌اهمیت", color: "text-slate-600 dark:text-slate-300", bg: "bg-slate-100 dark:bg-slate-500/15 border-slate-200 dark:border-slate-500/30", dot: "bg-slate-400", desc: "حذف / بعدا" },
};

export const MOODS = [
  { emoji: "😩", label: "خیلی بد" },
  { emoji: "😞", label: "بد" },
  { emoji: "😐", label: "معمولی" },
  { emoji: "🙂", label: "خوب" },
  { emoji: "😄", label: "عالی" },
  { emoji: "🤩", label: "فوق‌العاده" },
];

export const JALALI_MONTHS = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
export const JALALI_WEEKDAYS = ["شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"];
export const GREG_MONTHS_FA = ["ژانویه","فوریه","مارس","آوریل","مه","ژوئن","ژوئیه","اوت","سپتامبر","اکتبر","نوامبر","دسامبر"];

export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

export const FA_DIGITS = ["۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"];
export function fa(input: string | number | null | undefined): string {
  if (input === null || input === undefined || input === "") return "—";
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}
export function faPlain(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function todayKey(): string {
  const d = new Date();
  return toKey(d);
}
export function toKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
export function parseKey(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, m - 1, d);
}
export function addDays(key: string, n: number): string {
  const d = parseKey(key);
  d.setDate(d.getDate() + n);
  return toKey(d);
}

export function jalaliOf(key: string) {
  const d = parseKey(key);
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}
export function jalaliStr(key: string): string {
  const { jy, jm, jd } = jalaliOf(key);
  return `${fa(jd)} ${JALALI_MONTHS[jm - 1]} ${fa(jy)}`;
}
export function jalaliWeekday(key: string): string {
  const d = parseKey(key);
  const map: Record<number, number> = { 6: 0, 0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6 };
  return JALALI_WEEKDAYS[map[d.getDay()]];
}
export function gregStr(key: string): string {
  const d = parseKey(key);
  return `${fa(d.getDate())} ${GREG_MONTHS_FA[d.getMonth()]} ${fa(d.getFullYear())}`;
}
export function jalaliFull(key: string): string {
  return `${jalaliWeekday(key)} ${jalaliStr(key)}`;
}
export function dateRangeKeys(from: string, to: string): string[] {
  const out: string[] = [];
  let cur = from;
  let guard = 0;
  while (cur <= to && guard < 400) { out.push(cur); if (cur === to) break; cur = addDays(cur, 1); guard++; }
  return out;
}

export function weekRange(refKey: string, weekStart: "saturday" | "monday"): { start: string; end: string } {
  const d = parseKey(refKey);
  const js = d.getDay();
  let offset: number;
  if (weekStart === "saturday") offset = (js + 1) % 7;
  else offset = (js + 6) % 7;
  return { start: addDays(refKey, -offset), end: addDays(refKey, 6 - offset) };
}

export function monthRangeJalali(refKey: string): { start: string; end: string; label: string } {
  const { jy, jm } = jalaliOf(refKey);
  const g1 = toGregorian(jy, jm, 1);
  const len = jalaaliMonthLength(jy, jm);
  const g2 = toGregorian(jy, jm, len);
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    start: `${g1.gy}-${pad(g1.gm)}-${pad(g1.gd)}`,
    end: `${g2.gy}-${pad(g2.gm)}-${pad(g2.gd)}`,
    label: `${JALALI_MONTHS[jm - 1]} ${fa(jy)}`,
  };
}
export function monthRangeGreg(refKey: string): { start: string; end: string; label: string } {
  const d = parseKey(refKey);
  const pad = (n: number) => String(n).padStart(2, "0");
  const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  return {
    start: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-01`,
    end: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(last)}`,
    label: `${GREG_MONTHS_FA[d.getMonth()]} ${fa(d.getFullYear())}`,
  };
}

export function emptyDay(date: string): DayData {
  return { date, tasks: [], habits: {}, tomorrowTasks: [] };
}

export function defaultStore(): Store {
  return {
    days: {},
    backlog: [],
    categories: [
      { id: "work", name: "کار", color: "#3b82f6", icon: "💼" },
      { id: "personal", name: "شخصی", color: "#8b5cf6", icon: "🌿" },
      { id: "health", name: "سلامت", color: "#10b981", icon: "💪" },
      { id: "learn", name: "یادگیری", color: "#f59e0b", icon: "📚" },
      { id: "home", name: "خانه", color: "#f43f5e", icon: "🏠" },
    ],
    habits: [
      { id: "h1", name: "مطالعه", icon: "📖", active: true },
      { id: "h2", name: "آب کافی", icon: "💧", active: true },
      { id: "h3", name: "مدیتیشن", icon: "🧘", active: true },
      { id: "h4", name: "کدنویسی شخصی", icon: "💻", active: true },
      { id: "h5", name: "ثبت مخارج", icon: "💰", active: true },
    ],
    settings: { theme: "light", calendarLang: "jalali", weekStart: "saturday" },
  };
}

export function seedStore(): Store {
  const s = defaultStore();
  const t = todayKey();
  const titles = [
    { title: "جلسه تیم محصول", cat: "work", pr: "q1" as Priority },
    { title: "کار روی پروژه ایکس", cat: "work", pr: "q2" as Priority },
    { title: "پاسخ ایمیل‌ها", cat: "work", pr: "q3" as Priority },
    { title: "مطالعه فصل ۳ کتاب", cat: "learn", pr: "q2" as Priority },
    { title: "دویدن ۳۰ دقیقه", cat: "health", pr: "q2" as Priority },
    { title: "خرید هفتگی", cat: "home", pr: "q3" as Priority },
    { title: "تمرین زبان", cat: "learn", pr: "q4" as Priority },
    { title: "مرتب کردن اتاق", cat: "home", pr: "q4" as Priority },
  ];
  const moods = ["🙂", "😄", "😐", "😄", "🙂", "🤩", "😐"];
  const scores = [8, 7, 6, 9, 7, 8, 5];
  for (let i = -6; i <= 0; i++) {
    const key = addDays(t, i);
    const day = emptyDay(key);
    day.wakeUp = i % 2 === 0 ? "06:30" : "07:00";
    day.sleep = "23:00";
    day.mood = moods[(i + 14) % moods.length];
    day.exercised = i % 2 === 0;
    day.exerciseType = day.exercised ? "دویدن ۳۰ دقیقه" : "";
    day.wentOut = i % 3 === 0;
    day.outWhere = day.wentOut ? "کافه، خرید" : "";
    day.score = i === 0 ? undefined : scores[(i + 14) % scores.length];
    day.note = i === -1 ? "روز پرکاری بود ولی جلسه عصر عالی پیش رفت." : "";
    const n = 5 + ((i + 14) % 4);
    day.tasks = titles.slice(0, n).map((tt, idx) => ({
      id: uid(),
      title: tt.title,
      done: i === 0 ? idx < 2 : idx < n - 1 - (i % 2),
      priority: tt.pr,
      categoryId: tt.cat,
      plannedStart: idx === 0 ? "08:30" : idx === 1 ? "10:00" : undefined,
      plannedEnd: idx === 0 ? "09:30" : idx === 1 ? "12:00" : undefined,
      actualMinutes: idx < 2 ? 60 : undefined,
      note: idx === 1 ? "فاز اول تمام شد" : undefined,
    }));
    s.habits.forEach((h, hi) => { day.habits[h.id] = (hi + i) % 3 !== 0; });
    if (i === -1) { day.good1 = "جلسه عالی بود"; day.good2 = "ورزش کردم"; day.good3 = "خرید انجام شد"; day.improve = "تمرکز بعدازظهر کم بود"; day.lesson = "اول کارهای سخت، بعد آسان‌ها"; }
    s.days[key] = day;
  }
  const today = s.days[t];
  today.tomorrowTasks = [
    { id: uid(), title: "فصل ۴ کتاب", done: false },
    { id: uid(), title: "جلسه ساعت ۹ — بردن لپ‌تاپ", done: false },
  ];
  today.tomorrowNote = "فردا ساعت ۹ جلسه دارم، یادم نره گزارش را ببرم.";
  s.backlog = [
    { id: uid(), title: "نوشتن مقاله بلاگ", desc: "پیش‌نویس ۸۰۰ کلمه‌ای درباره تمرکز عمیق", priority: "q2", categoryId: "learn", createdAt: addDays(t, -4) },
    { id: uid(), title: "تماس با بیمه", desc: "پیگیری تمدید", priority: "q3", categoryId: "personal", createdAt: addDays(t, -3) },
    { id: uid(), title: "فاکتورهای مالیاتی", desc: "ددلاین آخر ماه", priority: "q1", categoryId: "work", createdAt: addDays(t, -5), deadline: addDays(t, 6) },
    { id: uid(), title: "مرتب کردن گالری عکس", desc: "", priority: "q4", categoryId: "home", createdAt: addDays(t, -2) },
    { id: uid(), title: "ثبت‌نام دوره زبان", desc: "مقایسه دو آموزشگاه", priority: "q2", categoryId: "learn", createdAt: addDays(t, -1) },
  ];
  return s;
}

export function loadStore(): Store {
  try {
    const raw = localStorage.getItem("rooznegar-v1");
    if (!raw) { const s = seedStore(); localStorage.setItem("rooznegar-v1", JSON.stringify(s)); return s; }
    const parsed = JSON.parse(raw);
    const d = defaultStore();
    return { ...d, ...parsed, settings: { ...d.settings, ...(parsed.settings || {}) } };
  } catch { return seedStore(); }
}

export function buildSummary(day: DayData, habits: Habit[]): string {
  const done = day.tasks.filter((x) => x.done).length;
  const total = day.tasks.length;
  const lines: string[] = [];
  lines.push(`گزارش روز: ${jalaliFull(day.date)}`);
  lines.push(`(${gregStr(day.date)})`);
  lines.push("━".repeat(24));
  lines.push("");
  const moodLabel = MOODS.find((m) => m.emoji === day.mood)?.label ?? "";
  lines.push(`⏰ بیدار شدن: ${day.wakeUp ? faPlain(day.wakeUp) : "—"} | خوابیدن: ${day.sleep ? faPlain(day.sleep) : "—"}`);
  lines.push(`حال: ${day.mood ?? "—"} ${moodLabel} | ⭐ نمره روز: ${day.score ? `${fa(day.score)}/۱۰` : "—"}`);
  lines.push(`ورزش: ${day.exercised ? `بله — ${day.exerciseType || ""}`.trim() : "خیر"}`);
  lines.push(`بیرون: ${day.wentOut ? (day.outWhere || "بله") : "خیر"}`);
  if (day.note) lines.push(`یادداشت: ${day.note}`);
  lines.push("");
  lines.push(`━━ تسک‌ها (${fa(done)}/${fa(total)} انجام شد) ━━`);
  if (total === 0) lines.push("تسکی ثبت نشده.");
  day.tasks.forEach((task) => { lines.push(`${task.done ? "✅" : "❌"} ${task.title}`); });
  lines.push("");
  lines.push("━━ عادت‌ها ━━");
  const active = habits.filter((h) => h.active);
  if (active.length === 0) lines.push("عادتی تعریف نشده.");
  else lines.push(active.map((h) => `${day.habits[h.id] ? "✅" : "❌"} ${h.name}`).join(" | "));
  lines.push("");
  lines.push("━━ بازتاب پایان روز ━━");
  const goods = [day.good1, day.good2, day.good3].filter(Boolean);
  lines.push(`خوب‌ها: ${goods.length ? goods.join("، ") : "—"}`);
  lines.push(`قابل بهبود: ${day.improve || "—"}`);
  lines.push(`درس: ${day.lesson || "—"}`);
  lines.push("");
  lines.push("━━ برنامه فردا ━━");
  if (day.tomorrowTasks.length === 0 && !day.tomorrowNote) lines.push("—");
  day.tomorrowTasks.forEach((x) => lines.push(`- ${x.title}`));
  if (day.tomorrowNote) lines.push(`یادداشت: ${day.tomorrowNote}`);
  return lines.join("\n");
}
