import { useRef, useState } from "react";
import { Download, Palette, Plus, Trash2, Upload } from "lucide-react";
import type { Category, Habit, Store } from "../lib/data";
import { fa, uid } from "../lib/data";
import { Card, Empty } from "./ui";

const COLORS = ["#3b82f6", "#8b5cf6", "#10b981", "#f59e0b", "#f43f5e", "#06b6d4", "#ec4899", "#84cc16"];
const ICONS = ["💼", "🌿", "💪", "📚", "🏠", "🎨", "✈️", "💰", "❤️", "🎯", "⚡", "🌙"];
const HABIT_ICONS = ["📖", "💧", "🧘", "💻", "💰", "🏃", "🥗", "😴", "🎵", "✍️", "🌅", "🧠"];

const inputCls = "rounded-xl border border-stone-200 dark:border-white/10 bg-stone-50/60 dark:bg-white/5 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40 transition placeholder:text-stone-400 text-stone-800 dark:text-stone-100";

export default function SettingsView({ store, setStore, toast }: { store: Store; setStore: (s: Store) => void; toast: (m: string) => void }) {
  const [catName, setCatName] = useState("");
  const [catColor, setCatColor] = useState(COLORS[0]);
  const [catIcon, setCatIcon] = useState(ICONS[0]);
  const [habitName, setHabitName] = useState("");
  const [habitIcon, setHabitIcon] = useState(HABIT_ICONS[0]);
  const fileRef = useRef<HTMLInputElement>(null);

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(store, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `rooznegar-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast("فایل بکاپ دانلود شد");
  };

  const importJSON = (f: File) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const data = JSON.parse(String(r.result));
        if (!data.days || !data.backlog) throw new Error("bad");
        if (!window.confirm("داده‌های فعلی جایگزین شوند؟")) return;
        setStore({ ...store, ...data });
        toast("بازیابی انجام شد");
      } catch { toast("فایل معتبر نیست"); }
    };
    r.readAsText(f);
  };

  const addCat = () => {
    if (!catName.trim()) return;
    const c: Category = { id: uid(), name: catName.trim(), color: catColor, icon: catIcon };
    setStore({ ...store, categories: [...store.categories, c] });
    setCatName(""); toast("دسته اضافه شد");
  };
  const addHabit = () => {
    if (!habitName.trim()) return;
    const h: Habit = { id: uid(), name: habitName.trim(), icon: habitIcon, active: true };
    setStore({ ...store, habits: [...store.habits, h] });
    setHabitName(""); toast("عادت اضافه شد");
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-black">تنظیمات و مدیریت داده</h2>

      <Card title="مدیریت دسته‌بندی‌ها" icon="🎨">
        <div className="flex flex-wrap gap-2 mb-3">
          {store.categories.map((c) => (
            <span key={c.id} className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold" style={{ color: c.color, borderColor: c.color + "55", background: c.color + "12" }}>
              {c.icon} {c.name}
              <button onClick={() => {
                if (store.categories.length <= 1) { toast("حداقل یک دسته لازم است"); return; }
                if (!window.confirm(`دسته «${c.name}» حذف شود؟`)) return;
                setStore({ ...store, categories: store.categories.filter((x) => x.id !== c.id) });
              }} className="opacity-50 hover:opacity-100 hover:text-red-500"><Trash2 size={12} /></button>
            </span>
          ))}
          {store.categories.length === 0 && <Empty text="دسته‌ای نیست" />}
        </div>
        <div className="rounded-2xl border border-dashed border-stone-300 dark:border-white/15 p-3 space-y-2.5">
          <div className="flex gap-2">
            <input value={catName} onChange={(e) => setCatName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addCat()} placeholder="نام دسته جدید…" className={`${inputCls} flex-1`} />
            <button onClick={addCat} className="rounded-xl bg-stone-900 dark:bg-white dark:text-stone-900 text-white px-4 text-sm font-black flex items-center gap-1"><Plus size={15} /> افزودن</button>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <Palette size={14} className="text-stone-400" />
            {COLORS.map((c) => <button key={c} onClick={() => setCatColor(c)} className={`w-7 h-7 rounded-full border-2 transition ${catColor === c ? "border-stone-900 dark:border-white scale-110" : "border-transparent"}`} style={{ background: c }} />)}
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            {ICONS.map((ic) => <button key={ic} onClick={() => setCatIcon(ic)} className={`w-9 h-9 grid place-items-center rounded-xl text-lg border transition ${catIcon === ic ? "border-emerald-500 bg-emerald-500/10" : "border-stone-200 dark:border-white/10"}`}>{ic}</button>)}
          </div>
        </div>
      </Card>

      <Card title="مدیریت عادت‌ها" icon="🌱" action={<span className="text-[11px] text-stone-400 font-bold">{fa(store.habits.filter((h) => h.active).length)} فعال</span>}>
        <div className="space-y-1.5 mb-3">
          {store.habits.map((h) => (
            <div key={h.id} className="flex items-center gap-2.5 rounded-xl border border-stone-200 dark:border-white/10 px-3 py-2">
              <span className="text-xl">{h.icon}</span>
              <span className="flex-1 text-sm font-bold">{h.name}</span>
              <button onClick={() => setStore({ ...store, habits: store.habits.map((x) => (x.id === h.id ? { ...x, active: !x.active } : x)) })}
                className={`text-[11px] font-black rounded-full px-3 py-1 transition ${h.active ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-stone-100 dark:bg-white/10 text-stone-400"}`}>{h.active ? "فعال" : "غیرفعال"}</button>
              <button onClick={() => { if (window.confirm(`عادت «${h.name}» حذف شود؟`)) setStore({ ...store, habits: store.habits.filter((x) => x.id !== h.id) }); }} className="text-stone-300 hover:text-red-500"><Trash2 size={14} /></button>
            </div>
          ))}
          {store.habits.length === 0 && <Empty text="عادتی نیست" />}
        </div>
        <div className="flex gap-2 flex-wrap">
          <div className="flex gap-1 flex-wrap">
            {HABIT_ICONS.slice(0, 6).map((ic) => <button key={ic} onClick={() => setHabitIcon(ic)} className={`w-9 h-9 grid place-items-center rounded-xl border text-lg ${habitIcon === ic ? "border-emerald-500 bg-emerald-500/10" : "border-stone-200 dark:border-white/10"}`}>{ic}</button>)}
          </div>
          <input value={habitName} onChange={(e) => setHabitName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addHabit()} placeholder="عادت جدید… مثلاً پیاده‌روی" className={`${inputCls} flex-1 min-w-[140px]`} />
          <button onClick={addHabit} className="rounded-xl bg-emerald-600 text-white px-4 text-sm font-black">+</button>
        </div>
      </Card>

      <Card title="تنظیمات ظاهری" icon="✨">
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <div className="text-[11px] font-bold text-stone-400 mb-1.5">تم</div>
            <div className="flex rounded-xl overflow-hidden border border-stone-200 dark:border-white/10 text-xs font-bold">
              {([["light", "روشن"], ["dark", "تاریک"]] as const).map(([k, l]) => (
                <button key={k} onClick={() => setStore({ ...store, settings: { ...store.settings, theme: k } })} className={`flex-1 px-3 py-2 ${store.settings.theme === k ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}>{l}</button>
              ))}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-bold text-stone-400 mb-1.5">زبان تقویم</div>
            <div className="flex rounded-xl overflow-hidden border border-stone-200 dark:border-white/10 text-xs font-bold">
              {([["jalali", "شمسی"], ["gregorian", "میلادی"]] as const).map(([k, l]) => (
                <button key={k} onClick={() => setStore({ ...store, settings: { ...store.settings, calendarLang: k } })} className={`flex-1 px-3 py-2 ${store.settings.calendarLang === k ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}>{l}</button>
              ))}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-bold text-stone-400 mb-1.5">شروع هفته</div>
            <div className="flex rounded-xl overflow-hidden border border-stone-200 dark:border-white/10 text-xs font-bold">
              {([["saturday", "شنبه"], ["monday", "دوشنبه"]] as const).map(([k, l]) => (
                <button key={k} onClick={() => setStore({ ...store, settings: { ...store.settings, weekStart: k } })} className={`flex-1 px-3 py-2 ${store.settings.weekStart === k ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}>{l}</button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      <Card title="پشتیبان‌گیری و بازیابی" icon="💾">
        <div className="grid sm:grid-cols-3 gap-2">
          <button onClick={exportJSON} className="flex items-center justify-center gap-2 rounded-2xl bg-emerald-600 text-white font-black text-sm py-3 hover:bg-emerald-500 transition"><Download size={16} /> خروجی JSON</button>
          <button onClick={() => fileRef.current?.click()} className="flex items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-stone-300 dark:border-white/15 font-black text-sm py-3 hover:border-emerald-500 transition"><Upload size={16} /> ورود فایل JSON</button>
          <button onClick={() => { if (window.confirm("همه داده‌ها پاک شود؟ این عمل برگشت‌ناپذیر است!")) { if (window.confirm("واقعاً مطمئنی؟ آخرین فرصت!")) { localStorage.removeItem("rooznegar-v1"); window.location.reload(); } } }} className="flex items-center justify-center gap-2 rounded-2xl bg-red-500/10 text-red-600 font-black text-sm py-3 hover:bg-red-500/20 transition"><Trash2 size={16} /> پاک کردن همه</button>
        </div>
        <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importJSON(f); e.target.value = ""; }} />
        <p className="text-[11px] text-stone-400 mt-2">همه داده‌ها فقط در مرورگر خودت (LocalStorage) ذخیره می‌شود — بدون سرور، بدون اینترنت. مرتب بکاپ بگیر.</p>
      </Card>
    </div>
  );
}
