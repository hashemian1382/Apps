import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpToLine, CalendarPlus, LayoutGrid, List, Search, Trash2 } from "lucide-react";
import type { BacklogItem, Category, Priority } from "../lib/data";
import { PRIORITIES, addDays, fa, faPlain, todayKey, uid } from "../lib/data";
import { Card, Empty } from "./ui";

interface Props {
  backlog: BacklogItem[];
  setBacklog: (b: BacklogItem[]) => void;
  categories: Category[];
  assignToDay: (item: BacklogItem, dateKey: string) => void;
  toast: (m: string) => void;
}

const inputCls = "rounded-xl border border-stone-200 dark:border-white/10 bg-stone-50/60 dark:bg-white/5 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40 transition placeholder:text-stone-400 text-stone-800 dark:text-stone-100";

export default function BacklogView({ backlog, setBacklog, categories, assignToDay, toast }: Props) {
  const [mode, setMode] = useState<"list" | "matrix">("list");
  const [q, setQ] = useState("");
  const [prF, setPrF] = useState<"all" | Priority>("all");
  const [catF, setCatF] = useState("all");
  const [sort, setSort] = useState<"new" | "priority" | "deadline">("priority");
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [pr, setPr] = useState<Priority>("q2");
  const [cat, setCat] = useState(categories[0]?.id ?? "work");
  const [assignId, setAssignId] = useState<string | null>(null);
  const [assignDate, setAssignDate] = useState(todayKey());
  const [dragId, setDragId] = useState<string | null>(null);

  const prRank: Record<Priority, number> = { q1: 0, q2: 1, q3: 2, q4: 3 };

  const filtered = useMemo(() => {
    const arr = backlog.filter((b) => {
      if (prF !== "all" && b.priority !== prF) return false;
      if (catF !== "all" && b.categoryId !== catF) return false;
      if (q && !(b.title + " " + (b.desc ?? "")).includes(q)) return false;
      return true;
    });
    return [...arr].sort((a, b) => {
      if (sort === "priority") return prRank[a.priority] - prRank[b.priority];
      if (sort === "deadline") return (a.deadline ?? "9999") < (b.deadline ?? "9999") ? -1 : 1;
      return b.createdAt.localeCompare(a.createdAt);
    });
  }, [backlog, q, prF, catF, sort]);

  const add = () => {
    if (!title.trim()) return;
    setBacklog([{ id: uid(), title: title.trim(), desc: desc.trim() || undefined, priority: pr, categoryId: cat, createdAt: todayKey() }, ...backlog]);
    setTitle(""); setDesc(""); toast("به بک‌لاگ اضافه شد");
  };

  const catOf = (id: string) => categories.find((c) => c.id === id);

  const doAssign = (item: BacklogItem) => {
    assignToDay(item, assignDate);
    setBacklog(backlog.filter((b) => b.id !== item.id));
    setAssignId(null);
    toast(`«${item.title}» به ${faPlain(assignDate)} اختصاص یافت`);
  };

  const quadrants = [
    { key: "q1" as Priority, title: "اول انجام بده", hint: "مهم + فوری", cls: "border-red-300 dark:border-red-500/30 bg-red-500/[0.05]" },
    { key: "q2" as Priority, title: "برنامه‌ریزی کن", hint: "مهم + غیرفوری", cls: "border-blue-300 dark:border-blue-500/30 bg-blue-500/[0.05]" },
    { key: "q3" as Priority, title: "واگذار / سریع بزن", hint: "غیرمهم + فوری", cls: "border-amber-300 dark:border-amber-500/30 bg-amber-500/[0.05]" },
    { key: "q4" as Priority, title: "حذف / بعدا", hint: "غیرمهم + غیرفوری", cls: "border-stone-300 dark:border-white/10 bg-stone-500/[0.05]" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="text-xl font-black flex items-center gap-2">بک‌لاگ <span className="text-xs font-bold text-stone-400">({fa(backlog.length)} مورد)</span></h2>
        <div className="mr-auto flex rounded-xl overflow-hidden border border-stone-200 dark:border-white/10 text-xs font-bold">
          <button onClick={() => setMode("list")} className={`flex items-center gap-1 px-3 py-2 ${mode === "list" ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}><List size={14} /> لیستی</button>
          <button onClick={() => setMode("matrix")} className={`flex items-center gap-1 px-3 py-2 ${mode === "matrix" ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}><LayoutGrid size={14} /> ماتریس آیزنهاور</button>
        </div>
      </div>

      <Card title="افزودن سریع به بک‌لاگ" icon="➕">
        <div className="grid sm:grid-cols-[1fr_1fr] gap-2">
          <input value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="عنوان کار… (Enter)" className={`${inputCls} w-full`} />
          <input value={desc} onChange={(e) => setDesc(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="توضیح کوتاه (اختیاری)…" className={`${inputCls} w-full`} />
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          <div className="flex gap-1 flex-wrap">
            {(Object.keys(PRIORITIES) as Priority[]).map((k) => (
              <button key={k} onClick={() => setPr(k)} className={`text-[11px] font-black border rounded-full px-2.5 py-1 transition ${pr === k ? PRIORITIES[k].bg + " " + PRIORITIES[k].color + " border-current" : "text-stone-400 border-stone-200 dark:border-white/10"}`}>{PRIORITIES[k].short}</button>
            ))}
          </div>
          <select value={cat} onChange={(e) => setCat(e.target.value)} className={`${inputCls} !py-1.5 !text-xs`}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
          </select>
          <button onClick={add} className="mr-auto rounded-xl bg-stone-900 dark:bg-white dark:text-stone-900 text-white text-sm font-black px-5 py-2 hover:opacity-90">افزودن</button>
        </div>
      </Card>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 rounded-xl border border-stone-200 dark:border-white/10 px-3 py-2 flex-1 min-w-[180px] bg-white dark:bg-white/5">
          <Search size={15} className="text-stone-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو در عنوان و توضیح…" className="bg-transparent outline-none text-sm flex-1 placeholder:text-stone-400" />
        </div>
        <select value={prF} onChange={(e) => setPrF(e.target.value as "all" | Priority)} className={`${inputCls} !text-xs`}>
          <option value="all">همه اولویت‌ها</option>
          {(Object.keys(PRIORITIES) as Priority[]).map((k) => <option key={k} value={k}>{PRIORITIES[k].label}</option>)}
        </select>
        <select value={catF} onChange={(e) => setCatF(e.target.value)} className={`${inputCls} !text-xs`}>
          <option value="all">همه دسته‌ها</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value as "new" | "priority" | "deadline")} className={`${inputCls} !text-xs`}>
          <option value="priority">مرتب: اولویت</option>
          <option value="new">مرتب: جدیدترین</option>
          <option value="deadline">مرتب: ددلاین</option>
        </select>
      </div>

      {mode === "list" ? (
        <div className="space-y-2">
          {filtered.length === 0 && <Card><Empty text="چیزی پیدا نشد — فیلترها را عوض کن" emoji="🔍" /></Card>}
          {filtered.map((b) => {
            const c = catOf(b.categoryId);
            const p = PRIORITIES[b.priority];
            return (
              <motion.div key={b.id} layout className="rounded-2xl border border-stone-200 dark:border-white/10 bg-white dark:bg-white/[0.04] p-3.5 hover:shadow-md transition">
                <div className="flex items-start gap-2.5">
                  <span className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${p.dot}`} />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm">{b.title}</div>
                    {b.desc && <div className="text-xs text-stone-500 mt-0.5">{b.desc}</div>}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className={`text-[10px] font-black border rounded-full px-2 py-0.5 ${p.bg} ${p.color}`}>{p.label} • {p.desc}</span>
                      {c && <span className="text-[10px] font-bold rounded-full px-2 py-0.5 border" style={{ color: c.color, borderColor: c.color + "55", background: c.color + "14" }}>{c.icon} {c.name}</span>}
                      <span className="text-[10px] text-stone-400">ساخته‌شده: {faPlain(b.createdAt)}</span>
                      {b.deadline && <span className="text-[10px] font-bold text-red-500 bg-red-500/10 rounded-full px-2 py-0.5">ددلاین: {faPlain(b.deadline)}</span>}
                    </div>
                    {assignId === b.id && (
                      <div className="flex flex-wrap items-center gap-2 mt-2 rounded-xl bg-stone-50 dark:bg-white/5 border border-stone-200 dark:border-white/10 p-2">
                        <input type="date" value={assignDate} onChange={(e) => setAssignDate(e.target.value)} className={`${inputCls} !py-1.5 !text-xs`} dir="ltr" />
                        <div className="flex gap-2">
                          <button onClick={() => setAssignDate(todayKey())} className="text-[11px] font-bold text-stone-500 hover:underline">امروز</button>
                          <button onClick={() => setAssignDate(addDays(todayKey(), 1))} className="text-[11px] font-bold text-stone-500 hover:underline">فردا</button>
                        </div>
                        <button onClick={() => doAssign(b)} className="rounded-lg bg-emerald-600 text-white text-xs font-black px-3 py-1.5">تأیید انتقال</button>
                        <button onClick={() => setAssignId(null)} className="text-xs text-stone-400">انصراف</button>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => { setAssignId(assignId === b.id ? null : b.id); setAssignDate(todayKey()); }} className="flex items-center gap-1 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-[11px] font-black px-2.5 py-1.5 hover:bg-emerald-500/20"><CalendarPlus size={13} /> به روز</button>
                    <button onClick={() => { if (window.confirm("از بک‌لاگ حذف شود؟")) setBacklog(backlog.filter((x) => x.id !== b.id)); }} className="p-1.5 rounded-lg hover:bg-red-500/10 text-red-400"><Trash2 size={14} /></button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div>
          <div className="hidden sm:grid grid-cols-[70px_1fr_1fr] gap-2 mb-2 text-center text-[11px] font-black text-stone-400">
            <div />
            <div className="rounded-lg bg-red-500/10 text-red-600 py-1.5">فوری</div>
            <div className="rounded-lg bg-stone-500/10 py-1.5">غیرفوری</div>
          </div>
          <div className="grid gap-2">
            {[{ label: "مهم", quads: [quadrants[0], quadrants[1]] }, { label: "غیرمهم", quads: [quadrants[2], quadrants[3]] }].map((row) => (
              <div key={row.label} className="grid sm:grid-cols-[70px_1fr_1fr] gap-2">
                <div className="hidden sm:grid place-items-center rounded-xl bg-stone-900 dark:bg-white text-white dark:text-stone-900 text-xs font-black p-2">{row.label}</div>
                {row.quads.map((qq) => {
                  const items = filtered.filter((b) => b.priority === qq.key);
                  return (
                    <div key={qq.key} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (dragId) { setBacklog(backlog.map((b) => (b.id === dragId ? { ...b, priority: qq.key } : b))); setDragId(null); } }}
                      className={`rounded-2xl border-2 border-dashed p-3 min-h-[170px] ${qq.cls}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-black text-sm">{qq.title}</div>
                        <div className="text-[11px] text-stone-400 font-bold">{qq.hint} • {fa(items.length)}</div>
                      </div>
                      <div className="space-y-1.5">
                        {items.map((b) => (
                          <div key={b.id} draggable onDragStart={() => setDragId(b.id)}
                            className="rounded-xl bg-white dark:bg-[#1d212b] border border-stone-200 dark:border-white/10 p-2.5 text-xs shadow-sm cursor-grab active:cursor-grabbing hover:shadow">
                            <div className="font-bold text-[13px]">{b.title}</div>
                            <div className="flex items-center gap-1.5 mt-1.5">
                              <button onClick={() => { setAssignId(b.id); setAssignDate(todayKey()); setMode("list"); }} className="flex items-center gap-1 text-[10px] font-black text-emerald-600 hover:underline"><ArrowUpToLine size={11} /> اختصاص به روز</button>
                              <button onClick={() => { if (window.confirm("حذف شود؟")) setBacklog(backlog.filter((x) => x.id !== b.id)); }} className="text-stone-300 hover:text-red-500 mr-auto"><Trash2 size={12} /></button>
                            </div>
                          </div>
                        ))}
                        {items.length === 0 && <div className="text-center text-[11px] text-stone-400 py-6">خالی — آیتم بکش اینجا</div>}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
