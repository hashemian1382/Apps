import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Archive, ArrowDownToLine, ArrowLeft, ArrowRight, CalendarCheck, Check, ChevronLeft, ChevronRight, Copy, ListPlus, Pencil, Sparkles, Trash2, X } from "lucide-react";
import type { Category, DayData, Habit, Priority, Task } from "../lib/data";
import { MOODS, PRIORITIES, addDays, buildSummary, fa, faPlain, gregStr, jalaliFull, todayKey, uid } from "../lib/data";
import { Card, Empty, FieldLabel, Progress } from "./ui";

interface Props {
  day: DayData;
  update: (patch: Partial<DayData>) => void;
  categories: Category[];
  habits: Habit[];
  selectedDate: string;
  setSelectedDate: (k: string) => void;
  moveToBacklog: (task: Task) => void;
  toast: (msg: string) => void;
}

const inputCls = "w-full rounded-xl border border-stone-200 dark:border-white/10 bg-stone-50/60 dark:bg-white/5 px-3 py-2 text-sm text-stone-800 dark:text-stone-100 outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500/50 transition placeholder:text-stone-400";

function catOf(categories: Category[], id: string) {
  return categories.find((c) => c.id === id) ?? categories[0];
}

export default function DailyView({ day, update, categories, habits, selectedDate, setSelectedDate, moveToBacklog, toast }: Props) {
  const isToday = selectedDate === todayKey();
  const done = day.tasks.filter((t) => t.done).length;
  const total = day.tasks.length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  const [quick, setQuick] = useState("");
  const [filter, setFilter] = useState<"all" | "done" | "todo">("all");
  const [catFilter, setCatFilter] = useState<string>("all");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [tomQuick, setTomQuick] = useState("");
  const quickRef = useRef<HTMLInputElement>(null);

  const visible = useMemo(() => day.tasks.filter((t) => {
    if (filter === "done" && !t.done) return false;
    if (filter === "todo" && t.done) return false;
    if (catFilter !== "all" && t.categoryId !== catFilter) return false;
    return true;
  }), [day.tasks, filter, catFilter]);

  const addTask = () => {
    const title = quick.trim();
    if (!title) return;
    update({ tasks: [...day.tasks, { id: uid(), title, done: false, priority: "q2", categoryId: categories[0]?.id ?? "work" }] });
    setQuick("");
    quickRef.current?.focus();
  };

  const patchTask = (id: string, patch: Partial<Task>) => {
    update({ tasks: day.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)) });
  };
  const removeTask = (id: string) => {
    if (!window.confirm("این تسک حذف شود؟")) return;
    update({ tasks: day.tasks.filter((t) => t.id !== id) });
  };
  const moveTaskTomorrow = (task: Task) => {
    update({ tasks: day.tasks.filter((t) => t.id !== task.id) });
    const nextKey = addDays(selectedDate, 1);
    try {
      const raw = localStorage.getItem("rooznegar-v1");
      if (raw) {
        const store = JSON.parse(raw);
        const nd = store.days[nextKey] ?? { date: nextKey, tasks: [], habits: {}, tomorrowTasks: [] };
        nd.tasks = [...(nd.tasks || []), { ...task, id: uid(), done: false }];
        store.days[nextKey] = nd;
        localStorage.setItem("rooznegar-v1", JSON.stringify(store));
      }
    } catch { /* noop */ }
    toast(`«${task.title}» به فردا منتقل شد`);
  };

  const reorder = (fromId: string, toId: string) => {
    if (fromId === toId) return;
    const arr = [...day.tasks];
    const fi = arr.findIndex((t) => t.id === fromId);
    const ti = arr.findIndex((t) => t.id === toId);
    if (fi < 0 || ti < 0) return;
    const [m] = arr.splice(fi, 1);
    arr.splice(ti, 0, m);
    update({ tasks: arr });
  };

  const copySummary = async () => {
    const text = buildSummary(day, habits);
    try { await navigator.clipboard.writeText(text); toast("خلاصه روز کپی شد ✅"); }
    catch {
      const ta = document.createElement("textarea");
      ta.value = text; document.body.appendChild(ta); ta.select();
      document.execCommand("copy"); ta.remove(); toast("خلاصه روز کپی شد ✅");
    }
  };

  const timed = day.tasks.filter((t) => t.plannedStart).sort((a, b) => (a.plannedStart ?? "").localeCompare(b.plannedStart ?? ""));

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-emerald-700/30 bg-gradient-to-l from-emerald-700 via-teal-700 to-emerald-800 text-white p-4 sm:p-5 shadow-lg relative overflow-hidden">
        <div className="absolute -left-10 -top-10 w-44 h-44 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute right-1/3 -bottom-14 w-56 h-56 rounded-full bg-yellow-300/20 blur-3xl" />
        <div className="relative flex flex-wrap items-center gap-3 justify-between">
          <div>
            <div className="flex items-center gap-2 text-emerald-100 text-xs font-semibold">
              <CalendarCheck size={14} />
              {isToday ? "امروز" : selectedDate < todayKey() ? "روز گذشته" : "روز آینده"}
              {!isToday && <button onClick={() => setSelectedDate(todayKey())} className="underline underline-offset-4 hover:text-white">برگرد به امروز</button>}
            </div>
            <h2 className="text-xl sm:text-2xl font-black mt-1">{jalaliFull(selectedDate)}</h2>
            <div className="text-emerald-100/90 text-xs mt-0.5">{faPlain(gregStr(selectedDate))} میلادی</div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setSelectedDate(addDays(selectedDate, -1))} className="flex items-center gap-1.5 rounded-xl bg-white/15 hover:bg-white/25 px-3 py-2 text-sm font-bold transition">
              <ChevronRight size={16} /> روز قبل
            </button>
            <button onClick={() => setSelectedDate(todayKey())} className="rounded-xl bg-white text-emerald-800 px-3 py-2 text-sm font-black hover:bg-emerald-50 transition">امروز</button>
            <button onClick={() => setSelectedDate(addDays(selectedDate, 1))} className="flex items-center gap-1.5 rounded-xl bg-white/15 hover:bg-white/25 px-3 py-2 text-sm font-bold transition">
              روز بعد <ChevronLeft size={16} />
            </button>
          </div>
        </div>
        <div className="relative mt-3 flex flex-wrap items-center gap-2">
          <button onClick={copySummary} className="flex items-center gap-2 rounded-xl bg-amber-300 text-stone-900 px-4 py-2 text-sm font-black hover:bg-amber-200 transition shadow">
            <Copy size={15} /> کپی خلاصه روز
          </button>
          <div className="flex items-center gap-2 text-xs bg-black/20 rounded-xl px-3 py-2">
            <span>✅ {fa(done)} از {fa(total)} تسک انجام شد ({fa(pct)}٪)</span>
          </div>
        </div>
      </div>

      <Card title="اطلاعات پایه روز" icon="🌅">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <FieldLabel>ساعت بیدار شدن</FieldLabel>
            <input type="time" value={day.wakeUp ?? ""} onChange={(e) => update({ wakeUp: e.target.value })} className={inputCls} dir="ltr" />
          </div>
          <div>
            <FieldLabel>ساعت خوابیدن</FieldLabel>
            <input type="time" value={day.sleep ?? ""} onChange={(e) => update({ sleep: e.target.value })} className={inputCls} dir="ltr" />
          </div>
          <div>
            <FieldLabel>ورزش کردم؟</FieldLabel>
            <div className="flex gap-2">
              <button onClick={() => update({ exercised: true })} className={`flex-1 rounded-xl px-2 py-2 text-sm font-bold border transition ${day.exercised ? "bg-emerald-500 text-white border-emerald-500" : "border-stone-200 dark:border-white/10 text-stone-500"}`}>بله</button>
              <button onClick={() => update({ exercised: false, exerciseType: "" })} className={`flex-1 rounded-xl px-2 py-2 text-sm font-bold border transition ${day.exercised === false ? "bg-stone-800 text-white border-stone-800 dark:bg-white dark:text-stone-900" : "border-stone-200 dark:border-white/10 text-stone-500"}`}>خیر</button>
            </div>
          </div>
          <div>
            <FieldLabel>بیرون رفتم؟</FieldLabel>
            <div className="flex gap-2">
              <button onClick={() => update({ wentOut: true })} className={`flex-1 rounded-xl px-2 py-2 text-sm font-bold border transition ${day.wentOut ? "bg-emerald-500 text-white border-emerald-500" : "border-stone-200 dark:border-white/10 text-stone-500"}`}>بله</button>
              <button onClick={() => update({ wentOut: false, outWhere: "" })} className={`flex-1 rounded-xl px-2 py-2 text-sm font-bold border transition ${day.wentOut === false ? "bg-stone-800 text-white border-stone-800 dark:bg-white dark:text-stone-900" : "border-stone-200 dark:border-white/10 text-stone-500"}`}>خیر</button>
            </div>
          </div>
        </div>
        <AnimatePresence>
          {(day.exercised || day.wentOut) && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="grid sm:grid-cols-2 gap-3 mt-3 overflow-hidden">
              {day.exercised ? <input value={day.exerciseType ?? ""} onChange={(e) => update({ exerciseType: e.target.value })} placeholder="نوع ورزش… مثلاً دویدن ۳۰ دقیقه" className={inputCls} /> : <span />}
              {day.wentOut ? <input value={day.outWhere ?? ""} onChange={(e) => update({ outWhere: e.target.value })} placeholder="کجا رفتی؟ مثلاً کافه، خرید" className={inputCls} /> : <span />}
            </motion.div>
          )}
        </AnimatePresence>
        <div className="mt-4 grid sm:grid-cols-2 gap-4">
          <div>
            <FieldLabel>حال کلی روز</FieldLabel>
            <div className="flex gap-1.5 flex-wrap">
              {MOODS.map((m) => (
                <button key={m.emoji} title={m.label} onClick={() => update({ mood: day.mood === m.emoji ? undefined : m.emoji })}
                  className={`w-11 h-11 grid place-items-center rounded-2xl text-2xl border transition hover:scale-110 ${day.mood === m.emoji ? "border-emerald-500 bg-emerald-500/10 scale-110 shadow" : "border-stone-200 dark:border-white/10 bg-stone-50 dark:bg-white/5 grayscale hover:grayscale-0"}`}>{m.emoji}</button>
              ))}
            </div>
          </div>
          <div>
            <FieldLabel>نمره کلی روز — {day.score ? `${fa(day.score)} از ۱۰` : "ثبت نشده"}</FieldLabel>
            <div className="flex gap-1 flex-wrap" dir="ltr">
              {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                <button key={n} onClick={() => update({ score: day.score === n ? undefined : n })}
                  className={`w-8 h-8 rounded-lg text-sm font-black border transition ${day.score && n <= day.score ? "bg-gradient-to-br from-amber-300 to-orange-400 text-white border-transparent shadow" : "border-stone-200 dark:border-white/10 text-stone-400 hover:border-amber-300"}`}>{fa(n)}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-3">
          <FieldLabel>یادداشت آزاد روز</FieldLabel>
          <textarea value={day.note ?? ""} onChange={(e) => update({ note: e.target.value })} rows={2} placeholder="هر چیزی که می‌خواهی درباره امروز بنویسی…" className={`${inputCls} resize-none`} />
        </div>
      </Card>

      <Card title="تسک‌های روز" icon="✅" action={<span className="text-xs font-bold text-stone-400">{fa(done)}/{fa(total)}</span>}>
        <Progress value={pct} />
        <div className="flex items-center gap-2 mt-3 rounded-2xl border-2 border-dashed border-emerald-500/30 bg-emerald-500/5 p-2 focus-within:border-emerald-500/60 transition">
          <ListPlus size={18} className="text-emerald-600 shrink-0 mr-1" />
          <input ref={quickRef} value={quick} onChange={(e) => setQuick(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addTask()}
            placeholder="تسک جدید بنویس و Enter بزن… (کلید N)" className="flex-1 bg-transparent outline-none text-sm py-1.5 placeholder:text-stone-400" />
          <button onClick={addTask} className="rounded-xl bg-emerald-600 text-white text-sm font-black px-4 py-2 hover:bg-emerald-500 transition">افزودن</button>
        </div>
        <div className="flex flex-wrap items-center gap-2 mt-3">
          <div className="flex rounded-xl overflow-hidden border border-stone-200 dark:border-white/10 text-xs font-bold">
            {( [["all", "همه"], ["todo", "انجام‌نشده"], ["done", "انجام‌شده"]] as const).map(([k, l]) => (
              <button key={k} onClick={() => setFilter(k)} className={`px-3 py-1.5 transition ${filter === k ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}>{l}</button>
            ))}
          </div>
          <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="rounded-xl border border-stone-200 dark:border-white/10 bg-transparent text-xs px-2 py-1.5 text-stone-600 dark:text-stone-300">
            <option value="all">همه دسته‌ها</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
          </select>
          <span className="mr-auto text-[11px] text-stone-400">بگیر و بکش برای تغییر ترتیب</span>
        </div>
        <div className="mt-3 space-y-2">
          {visible.length === 0 && <Empty text="تسکی نیست — یکی اضافه کن" emoji="✨" />}
          <AnimatePresence initial={false}>
            {visible.map((t) => {
              const cat = catOf(categories, t.categoryId);
              const pr = PRIORITIES[t.priority];
              const editing = editingId === t.id;
              return (
                <motion.div key={t.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }}
                  draggable={!editing}
                  onDragStart={() => setDragId(t.id)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => dragId && reorder(dragId, t.id)}
                  className={`group rounded-2xl border p-3 transition cursor-grab active:cursor-grabbing ${t.done ? "bg-stone-50 dark:bg-white/[0.03] border-stone-200/70 dark:border-white/5" : "bg-white dark:bg-white/[0.04] border-stone-200 dark:border-white/10 hover:border-emerald-500/40 hover:shadow-md"} ${dragId === t.id ? "opacity-50" : ""}`}>
                  <div className="flex items-start gap-2.5">
                    <button onClick={() => patchTask(t.id, { done: !t.done })}
                      className={`mt-0.5 w-6 h-6 rounded-lg border-2 grid place-items-center shrink-0 transition ${t.done ? "bg-emerald-500 border-emerald-500 text-white" : "border-stone-300 dark:border-white/20 hover:border-emerald-500"}`}>
                      {t.done && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }}><Check size={15} strokeWidth={3} /></motion.span>}
                    </button>
                    <div className="flex-1 min-w-0">
                      {editing ? (
                        <input autoFocus defaultValue={t.title} onBlur={(e) => { patchTask(t.id, { title: e.target.value || t.title }); setEditingId(null); }} onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }} className={inputCls} />
                      ) : (
                        <div onClick={() => setEditingId(t.id)} title="کلیک برای ویرایش"
                          className={`text-sm font-bold cursor-text leading-6 ${t.done ? "line-through text-stone-400" : "text-stone-800 dark:text-stone-100"}`}>{t.title}</div>
                      )}
                      <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                        <span className={`inline-flex items-center gap-1 text-[10px] font-black border rounded-full px-2 py-0.5 ${pr.bg} ${pr.color}`}><span className={`w-1.5 h-1.5 rounded-full ${pr.dot}`} />{pr.short}</span>
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold rounded-full px-2 py-0.5 border" style={{ color: cat.color, borderColor: cat.color + "55", background: cat.color + "14" }}>{cat.icon} {cat.name}</span>
                        {t.plannedStart && <span className="text-[10px] font-bold text-stone-500 bg-stone-100 dark:bg-white/10 rounded-full px-2 py-0.5" dir="ltr">{faPlain(t.plannedStart)}{t.plannedEnd ? `–${faPlain(t.plannedEnd)}` : ""}</span>}
                        {t.actualMinutes ? <span className="text-[10px] font-bold text-teal-700 dark:text-teal-300 bg-teal-500/10 rounded-full px-2 py-0.5">{fa(t.actualMinutes)} دقیقه</span> : null}
                      </div>
                      {editing && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                          <select value={t.priority} onChange={(e) => patchTask(t.id, { priority: e.target.value as Priority })} className={`${inputCls} !py-1.5 !text-xs`}>
                            {(Object.keys(PRIORITIES) as Priority[]).map((k) => <option key={k} value={k}>{PRIORITIES[k].label}</option>)}
                          </select>
                          <select value={t.categoryId} onChange={(e) => patchTask(t.id, { categoryId: e.target.value })} className={`${inputCls} !py-1.5 !text-xs`}>
                            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                          </select>
                          <input type="time" value={t.plannedStart ?? ""} onChange={(e) => patchTask(t.id, { plannedStart: e.target.value || undefined })} className={`${inputCls} !py-1.5 !text-xs`} dir="ltr" />
                          <input type="number" min={0} value={t.actualMinutes ?? ""} onChange={(e) => patchTask(t.id, { actualMinutes: e.target.value ? Number(e.target.value) : undefined })} placeholder="دقیقه واقعی" className={`${inputCls} !py-1.5 !text-xs`} />
                        </div>
                      )}
                      {editing && (
                        <input defaultValue={t.note ?? ""} onBlur={(e) => patchTask(t.id, { note: e.target.value || undefined })} placeholder="یادداشت کوتاه…" className={`${inputCls} !py-1.5 !text-xs mt-2`} />
                      )}
                      {!editing && t.note && <div className="text-[11px] text-stone-500 mt-1">{t.note}</div>}
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button title="ویرایش" onClick={() => setEditingId(editing ? null : t.id)} className="p-1.5 rounded-lg hover:bg-stone-100 dark:hover:bg-white/10 text-stone-400">{editing ? <X size={14} /> : <Pencil size={14} />}</button>
                      {!t.done && <button title="انتقال به فردا" onClick={() => moveTaskTomorrow(t)} className="p-1.5 rounded-lg hover:bg-blue-500/10 text-blue-500"><ArrowDownToLine size={14} /></button>}
                      {!t.done && <button title="انتقال به بک‌لاگ" onClick={() => { moveToBacklog(t); update({ tasks: day.tasks.filter((x) => x.id !== t.id) }); }} className="p-1.5 rounded-lg hover:bg-amber-500/10 text-amber-600"><Archive size={14} /></button>}
                      <button title="حذف" onClick={() => removeTask(t.id)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-red-500"><Trash2 size={14} /></button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </Card>

      <Card title="برنامه زمانی روز" icon="🕰" action={<span className="text-[11px] text-stone-400 font-bold">{fa(timed.length)} رویداد زمان‌دار</span>}>
        {timed.length === 0 && !day.wakeUp ? <Empty text="ساعتی برای تسک‌ها ثبت نشده — ساعت شروع را در ویرایش تسک بزن" emoji="🕰" /> : (
          <div className="relative pr-6">
            <div className="absolute right-[9px] top-2 bottom-2 w-0.5 bg-gradient-to-b from-emerald-400 via-teal-300 to-stone-200 dark:to-white/10 rounded" />
            <div className="space-y-3">
              {day.wakeUp && (
                <div className="relative flex items-center gap-3">
                  <span className="absolute -right-6 w-5 h-5 rounded-full bg-amber-300 border-2 border-white dark:border-stone-900 grid place-items-center text-[10px]">☀</span>
                  <span className="text-xs font-black text-stone-500 w-12" dir="ltr">{faPlain(day.wakeUp)}</span>
                  <span className="text-sm font-bold">بیدار شدن</span>
                </div>
              )}
              {timed.map((t) => (
                <div key={t.id} className="relative flex items-center gap-3">
                  <span className={`absolute -right-6 w-5 h-5 rounded-full border-2 border-white dark:border-stone-900 ${t.done ? "bg-emerald-500" : "bg-white dark:bg-stone-700 border-emerald-400"}`} />
                  <span className="text-xs font-black text-stone-500 w-12" dir="ltr">{faPlain(t.plannedStart!)}</span>
                  <div className={`flex-1 rounded-xl px-3 py-2 text-sm border ${t.done ? "bg-emerald-500/5 border-emerald-500/20" : "bg-stone-50 dark:bg-white/5 border-stone-200 dark:border-white/10"}`}>
                    <span className={`font-bold ${t.done ? "line-through text-stone-400" : ""}`}>{t.title}</span>
                    {t.plannedEnd && <span className="text-[11px] text-stone-400 mr-2" dir="ltr">تا {faPlain(t.plannedEnd)}</span>}
                  </div>
                </div>
              ))}
              {day.sleep && (
                <div className="relative flex items-center gap-3">
                  <span className="absolute -right-6 w-5 h-5 rounded-full bg-indigo-400 border-2 border-white dark:border-stone-900 grid place-items-center text-[10px]">☾</span>
                  <span className="text-xs font-black text-stone-500 w-12" dir="ltr">{faPlain(day.sleep)}</span>
                  <span className="text-sm font-bold">خوابیدن</span>
                </div>
              )}
            </div>
          </div>
        )}
      </Card>

      <Card title="عادت‌های روزانه" icon="🌱" action={<span className="text-[11px] font-black text-emerald-600">{fa(Object.values(day.habits).filter(Boolean).length)} انجام‌شده</span>}>
        {habits.filter((h) => h.active).length === 0 ? <Empty text="عادتی فعال نیست — از تنظیمات اضافه کن" /> : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {habits.filter((h) => h.active).map((h) => {
              const on = !!day.habits[h.id];
              return (
                <button key={h.id} onClick={() => update({ habits: { ...day.habits, [h.id]: !on } })}
                  className={`flex items-center gap-3 rounded-2xl border p-3 text-right transition hover:scale-[1.01] ${on ? "border-emerald-500/50 bg-emerald-500/[0.07]" : "border-stone-200 dark:border-white/10 hover:border-stone-300"}`}>
                  <span className="text-2xl">{h.icon}</span>
                  <span className="flex-1 text-sm font-bold">{h.name}</span>
                  <span className={`w-7 h-7 rounded-xl grid place-items-center font-black transition ${on ? "bg-emerald-500 text-white" : "bg-stone-100 dark:bg-white/10 text-stone-300"}`}>{on ? <Check size={16} strokeWidth={3} /> : ""}</span>
                </button>
              );
            })}
          </div>
        )}
      </Card>

      <Card title="برنامه فردا" icon="🌙" action={<span className="text-[11px] text-stone-400 font-bold">امشب بنویس، فردا بدرخش</span>}>
        <div className="flex gap-2">
          <input value={tomQuick} onChange={(e) => setTomQuick(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && tomQuick.trim()) { update({ tomorrowTasks: [...day.tomorrowTasks, { id: uid(), title: tomQuick.trim(), done: false }] }); setTomQuick(""); } }} placeholder="تسک فردا…" className={inputCls} />
          <button onClick={() => { if (tomQuick.trim()) { update({ tomorrowTasks: [...day.tomorrowTasks, { id: uid(), title: tomQuick.trim(), done: false }] }); setTomQuick(""); } }} className="rounded-xl bg-indigo-600 text-white text-sm font-black px-4 hover:bg-indigo-500 transition shrink-0">+</button>
        </div>
        <div className="mt-2 space-y-1.5">
          {day.tomorrowTasks.length === 0 && <div className="text-xs text-stone-400 py-2">هنوز برنامه‌ای برای فردا ننوشتی.</div>}
          {day.tomorrowTasks.map((t) => (
            <div key={t.id} className="flex items-center gap-2 rounded-xl border border-stone-200 dark:border-white/10 px-3 py-2 text-sm">
              <span className="text-indigo-500">•</span>
              <span className="flex-1 font-semibold">{t.title}</span>
              <button onClick={() => update({ tasks: [...day.tasks, { id: uid(), title: t.title, done: false, priority: "q2", categoryId: categories[0]?.id ?? "work" }] })} className="text-[11px] font-black text-emerald-600 hover:underline">به امروز</button>
              <button onClick={() => update({ tomorrowTasks: day.tomorrowTasks.filter((x) => x.id !== t.id) })} className="text-stone-300 hover:text-red-500"><Trash2 size={14} /></button>
            </div>
          ))}
        </div>
        <div className="mt-2">
          <FieldLabel>یادداشت فردا</FieldLabel>
          <textarea value={day.tomorrowNote ?? ""} onChange={(e) => update({ tomorrowNote: e.target.value })} rows={2} placeholder="مثلاً: فردا ساعت ۹ جلسه دارم، یادم نره…" className={`${inputCls} resize-none`} />
        </div>
      </Card>

      <Card title="یادداشت و گزارش پایان روز" icon="💭">
        <div className="grid sm:grid-cols-3 gap-2">
          {(["good1", "good2", "good3"] as const).map((k, i) => (
            <div key={k} className="rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.04] p-3">
              <div className="text-[11px] font-black text-emerald-700 dark:text-emerald-300 mb-1.5 flex items-center gap-1"><Sparkles size={12} /> چیز خوب {fa(i + 1)}</div>
              <input value={day[k] ?? ""} onChange={(e) => update({ [k]: e.target.value })} placeholder={i === 0 ? "جلسه عالی بود…" : i === 1 ? "ورزش کردم…" : "…"} className="w-full bg-transparent outline-none text-sm placeholder:text-stone-400" />
            </div>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 gap-2 mt-2">
          <div className="rounded-2xl border border-amber-500/25 bg-amber-500/[0.05] p-3">
            <div className="text-[11px] font-black text-amber-700 dark:text-amber-300 mb-1.5">یک چیز قابل بهبود</div>
            <input value={day.improve ?? ""} onChange={(e) => update({ improve: e.target.value })} placeholder="چه چیزی می‌توانست بهتر باشد؟" className="w-full bg-transparent outline-none text-sm placeholder:text-stone-400" />
          </div>
          <div className="rounded-2xl border border-violet-500/25 bg-violet-500/[0.05] p-3">
            <div className="text-[11px] font-black text-violet-700 dark:text-violet-300 mb-1.5">درس امروز</div>
            <input value={day.lesson ?? ""} onChange={(e) => update({ lesson: e.target.value })} placeholder="یک جمله‌ای که امروز یاد گرفتی…" className="w-full bg-transparent outline-none text-sm placeholder:text-stone-400" />
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between text-xs text-stone-400">
          <span className="flex items-center gap-1"><ArrowLeft size={13} /> همه‌چیز خودکار ذخیره می‌شود</span>
          <span className="hidden sm:flex items-center gap-1"><ArrowRight size={13} /> میانبر: N تسک جدید</span>
        </div>
      </Card>
    </div>
  );
}
