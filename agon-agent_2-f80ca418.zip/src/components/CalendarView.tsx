import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { jalaaliMonthLength, toGregorian } from "jalaali-js";
import type { Store } from "../lib/data";
import { GREG_MONTHS_FA, JALALI_MONTHS, fa, faPlain, jalaliOf, parseKey, todayKey, toKey } from "../lib/data";

function scoreColor(score?: number, hasData?: boolean): string {
  if (score !== undefined) {
    if (score >= 8) return "bg-emerald-500 text-white border-emerald-500";
    if (score >= 6) return "bg-emerald-400/80 text-white border-emerald-400";
    if (score >= 5) return "bg-amber-300 text-stone-900 border-amber-300";
    if (score >= 3) return "bg-orange-400 text-white border-orange-400";
    return "bg-red-400 text-white border-red-400";
  }
  if (hasData) return "bg-sky-100 dark:bg-sky-500/20 text-sky-800 dark:text-sky-200 border-sky-200 dark:border-sky-500/30";
  return "bg-white dark:bg-white/[0.03] text-stone-400 border-stone-200 dark:border-white/5 hover:border-stone-300";
}

export default function CalendarView({ store, goDay }: { store: Store; goDay: (k: string) => void }) {
  const jalaliMode = store.settings.calendarLang === "jalali";
  const [cursor, setCursor] = useState(todayKey());

  const cells = useMemo(() => {
    if (jalaliMode) {
      const { jy, jm } = jalaliOf(cursor);
      const len = jalaaliMonthLength(jy, jm);
      const g1 = toGregorian(jy, jm, 1);
      const first = new Date(g1.gy, g1.gm - 1, g1.gd);
      const lead = (first.getDay() + 1) % 7;
      const out: (string | null)[] = [];
      for (let i = 0; i < lead; i++) out.push(null);
      for (let d = 1; d <= len; d++) {
        const g = toGregorian(jy, jm, d);
        out.push(toKey(new Date(g.gy, g.gm - 1, g.gd)));
      }
      return { cells: out, label: `${JALALI_MONTHS[jm - 1]} ${fa(jy)}` };
    }
    const base = parseKey(cursor);
    const y = base.getFullYear(), m = base.getMonth();
    const len = new Date(y, m + 1, 0).getDate();
    const lead = (new Date(y, m, 1).getDay() + 1) % 7;
    const out: (string | null)[] = [];
    for (let i = 0; i < lead; i++) out.push(null);
    for (let d = 1; d <= len; d++) out.push(toKey(new Date(y, m, d)));
    return { cells: out, label: `${GREG_MONTHS_FA[m]} ${fa(y)}` };
  }, [cursor, jalaliMode]);

  const shiftMonth = (n: number) => {
    if (jalaliMode) {
      let { jy, jm } = jalaliOf(cursor);
      jm += n;
      while (jm > 12) { jm -= 12; jy++; }
      while (jm < 1) { jm += 12; jy--; }
      const g = toGregorian(jy, jm, 1);
      setCursor(toKey(new Date(g.gy, g.gm - 1, g.gd)));
    } else {
      const d = parseKey(cursor);
      setCursor(toKey(new Date(d.getFullYear(), d.getMonth() + n, 1)));
    }
  };

  const dayNum = (key: string) => (jalaliMode ? fa(jalaliOf(key).jd) : fa(parseKey(key).getDate()));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <h2 className="text-xl font-black">تقویم {jalaliMode ? "شمسی" : "میلادی"}</h2>
        <div className="mr-auto flex items-center gap-2">
          <button onClick={() => shiftMonth(-1)} className="p-2 rounded-xl border border-stone-200 dark:border-white/10 hover:bg-stone-100 dark:hover:bg-white/10"><ChevronRight size={16} /></button>
          <button onClick={() => setCursor(todayKey())} className="px-3 py-2 rounded-xl bg-stone-900 dark:bg-white dark:text-stone-900 text-white text-xs font-black">امروز</button>
          <span className="font-black text-sm min-w-[120px] text-center">{cells.label}</span>
          <button onClick={() => shiftMonth(1)} className="p-2 rounded-xl border border-stone-200 dark:border-white/10 hover:bg-stone-100 dark:hover:bg-white/10"><ChevronLeft size={16} /></button>
        </div>
      </div>

      <div className="rounded-2xl border border-stone-200 dark:border-white/10 bg-white dark:bg-white/[0.03] p-3 sm:p-4">
        <div className="grid grid-cols-7 gap-1.5 mb-1.5 text-center text-[11px] font-black text-stone-400">
          {["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"].map((w) => <div key={w} className="py-1">{w}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {cells.cells.map((key, i) => {
            if (!key) return <div key={i} />;
            const d = store.days[key];
            const total = d?.tasks.length ?? 0;
            const done = d?.tasks.filter((t) => t.done).length ?? 0;
            const isToday = key === todayKey();
            return (
              <button key={key} onClick={() => goDay(key)}
                className={`rounded-xl border p-1.5 sm:p-2 min-h-[64px] sm:min-h-[84px] text-right transition hover:scale-[1.03] hover:shadow-md ${scoreColor(d?.score, !!d)} ${isToday ? "ring-2 ring-stone-900 dark:ring-white ring-offset-2 ring-offset-transparent" : ""}`}>
                <div className="flex items-center justify-between gap-1">
                  <span className="text-sm sm:text-base font-black">{dayNum(key)}</span>
                  {isToday && <span className="text-[9px] font-black bg-stone-900 dark:bg-white dark:text-stone-900 text-white rounded-full px-1.5 py-0.5">امروز</span>}
                </div>
                <div className="text-[9px] sm:text-[10px] font-bold opacity-80 mt-0.5">
                  {total > 0 ? <span dir="ltr">{fa(done)}/{fa(total)}</span> : <span>·</span>}
                </div>
                {d?.score !== undefined && <div className="text-[9px] font-black mt-0.5">{fa(d.score)} ★</div>}
                {total > 0 && (
                  <div className="h-1 rounded-full bg-black/15 dark:bg-white/25 mt-1 overflow-hidden">
                    <div className="h-full bg-current rounded-full" style={{ width: `${(done / total) * 100}%` }} />
                  </div>
                )}
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap items-center gap-2 mt-3 text-[11px] font-bold text-stone-500">
          <span>راهنما:</span>
          {[["#10b981", "عالی (۸+)"], ["#34d399", "خوب (۶+)"], ["#fcd34d", "متوسط"], ["#fb923c", "ضعیف"], ["#f87171", "بد"]].map(([c, l]) => <span key={l} className="flex items-center gap-1"><span className="w-3 h-3 rounded" style={{ background: c }} />{fa(l)}</span>)}
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-sky-200" /> ثبت بدون نمره</span>
          <span className="mr-auto hidden sm:inline" dir="ltr">{faPlain(cells.cells.filter(Boolean).length)} روز</span>
        </div>
      </div>
    </div>
  );
}
