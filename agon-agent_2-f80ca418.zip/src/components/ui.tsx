import type { ReactNode } from "react";
import { motion } from "framer-motion";

export function Card({ title, icon, action, children, className = "" }: { title?: string; icon?: ReactNode; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className={`rounded-2xl border border-stone-200/80 dark:border-white/10 bg-white/90 dark:bg-[#171a21]/90 shadow-[0_8px_30px_-18px_rgba(0,0,0,0.35)] backdrop-blur overflow-hidden ${className}`}
    >
      {title && (
        <div className="flex items-center justify-between gap-3 px-5 pt-4 pb-3 border-b border-stone-100 dark:border-white/5">
          <h3 className="flex items-center gap-2 font-bold text-[15px] text-stone-800 dark:text-stone-100">
            <span className="grid place-items-center w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-lg">{icon}</span>
            {title}
          </h3>
          {action}
        </div>
      )}
      <div className="p-4 sm:p-5">{children}</div>
    </motion.section>
  );
}

export function FieldLabel({ children }: { children: ReactNode }) {
  return <div className="text-[11px] font-semibold text-stone-400 dark:text-stone-500 mb-1.5">{children}</div>;
}

export function Progress({ value }: { value: number }) {
  return (
    <div className="h-2 rounded-full bg-stone-100 dark:bg-white/10 overflow-hidden">
      <motion.div className="h-full rounded-full bg-gradient-to-l from-emerald-500 to-teal-400" initial={{ width: 0 }} animate={{ width: `${Math.min(100, Math.max(0, value))}%` }} transition={{ duration: 0.5 }} />
    </div>
  );
}

export function Empty({ text, emoji = "🌱" }: { text: string; emoji?: string }) {
  return (
    <div className="text-center py-8 text-stone-400 dark:text-stone-500">
      <div className="text-3xl mb-2">{emoji}</div>
      <div className="text-sm">{text}</div>
    </div>
  );
}
