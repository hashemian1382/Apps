import { useMemo, useState } from "react";
import { Award, CalendarDays, Dumbbell, Flame, Moon, TrendingUp } from "lucide-react";
import type { Store } from "../lib/data";
import { addDays, dateRangeKeys, fa, faPlain, jalaliStr, monthRangeGreg, monthRangeJalali, todayKey, weekRange } from "../lib/data";
import { Card, Empty } from "./ui";

function avg(nums: number[]): number { return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0; }
function toMin(t?: string): number | null { if (!t) return null; const [h, m] = t.split(":").map(Number); if (isNaN(h) || isNaN(m)) return null; return h * 60 + m; }
function minToStr(min: number): string {
  const h = Math.floor(min / 60) % 24; const m = Math.round(min % 60);
  return `${faPlain(String(h).padStart(2, "0"))}:${faPlain(String(m).padStart(2, "0"))}`;
}

export default function ReportsView({ store }: { store: Store }) {
  const [tab, setTab] = useState<"week" | "month" | "custom">("week");
  const [customFrom, setCustomFrom] = useState(addDays(todayKey(), -13));
  const [customTo, setCustomTo] = useState(todayKey());

  const range = useMemo(() => {
    if (tab === "week") { const w = weekRange(todayKey(), store.settings.weekStart); return { ...w, label: `هفته ${faPlain(w.start)} تا ${faPlain(w.end)}` }; }
    if (tab === "month") return store.settings.calendarLang === "jalali" ? monthRangeJalali(todayKey()) : monthRangeGreg(todayKey());
    return { start: customFrom <= customTo ? customFrom : customTo, end: customFrom <= customTo ? customTo : customFrom, label: "بازه سفارشی" };
  }, [tab, customFrom, customTo, store.settings]);

  const keys = useMemo(() => dateRangeKeys(range.start, range.end), [range]);
  const days = keys.map((k) => store.days[k]);

  const perDay = keys.map((k) => {
    const d = store.days[k];
    const total = d?.tasks.length ?? 0;
    const done = d?.tasks.filter((t) => t.done).length ?? 0;
    return { key: k, total, done, score: d?.score, pct: total ? Math.round((done / total) * 100) : 0 };
  });
  const totTasks = perDay.reduce((a, p) => a + p.total, 0);
  const doneTasks = perDay.reduce((a, p) => a + p.done, 0);
  const scores = perDay.map((p) => p.score).filter((x): x is number => typeof x === "number");
  const wakes = days.map((d) => toMin(d?.wakeUp)).filter((x): x is number => x !== null);
  const sleeps = days.map((d) => toMin(d?.sleep)).filter((x): x is number => x !== null);
  const sportDays = days.filter((d) => d?.exercised).length;

  const habitStats = store.habits.filter((h) => h.active).map((h) => {
    const filled = days.filter((d) => d?.habits[h.id]).length;
    return { habit: h, filled, total: keys.length };
  });

  const catCount: Record<string, number> = {};
  days.forEach((d) => d?.tasks.forEach((t) => { if (t.done) catCount[t.categoryId] = (catCount[t.categoryId] ?? 0) + 1; }));
  const topCat = Object.entries(catCount).sort((a, b) => b[1] - a[1])[0];
  const topCatName = topCat ? store.categories.find((c) => c.id === topCat[0])?.name ?? "—" : "—";

  const scored = perDay.filter((p) => typeof p.score === "number");
  const best = scored.length ? scored.reduce((a, b) => (b.score! > a.score! ? b : a)) : null;
  const worst = scored.length ? scored.reduce((a, b) => (b.score! < a.score! ? b : a)) : null;

  const maxDone = Math.max(1, ...perDay.map((p) => p.done));

  const streaks = useMemo(() => {
    const filled = (k: string) => { const d = store.days[k]; return !!(d && (d.tasks.length > 0 || d.score !== undefined || d.note)); };
    let s1 = 0;
    for (let i = 0; i < 365; i++) { if (filled(addDays(todayKey(), -i))) s1++; else break; }
    let s2 = 0;
    for (let i = 0; i < 365; i++) { const d = store.days[addDays(todayKey(), -i)]; if (d?.exercised) s2++; else break; }
    let s3 = 0;
    for (let i = 0; i < 365; i++) { const d = store.days[addDays(todayKey(), -i)]; if (d?.score !== undefined && d.score >= 7) s3++; else break; }
    let s4 = 0;
    for (let i = 0; i < 365; i++) {
      const d = store.days[addDays(todayKey(), -i)];
      const act = store.habits.filter((h) => h.active);
      if (!d || act.length === 0) break;
      if (act.every((h) => d.habits[h.id])) s4++; else break;
    }
    return [
      { label: "ثبت روزانه", value: s1, icon: "📝" },
      { label: "ورزش", value: s2, icon: "🏃" },
      { label: "نمره بالای ۷", value: s3, icon: "⭐" },
      { label: "همه عادت‌ها", value: s4, icon: "🌱" },
    ];
  }, [store]);

  const linePts = perDay.map((p, i) => {
    const x = perDay.length === 1 ? 50 : (i / (perDay.length - 1)) * 100;
    const y = p.score !== undefined ? 100 - (p.score / 10) * 100 : 100;
    return { x, y, ...p };
  });
  const path = linePts.filter((p) => p.score !== undefined).map((p, i) => `${i === 0 ? "M" : "L"} ${p.x},${p.y}`).join(" ");

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="text-xl font-black">گزارش‌ها و عملکرد</h2>
        <div className="mr-auto flex rounded-xl overflow-hidden border border-stone-200 dark:border-white/10 text-xs font-bold">
          {([["week", "هفتگی"], ["month", "ماهانه"], ["custom", "سفارشی"]] as const).map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`px-4 py-2 ${tab === k ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "text-stone-500"}`}>{l}</button>
          ))}
        </div>
      </div>

      <Card title={range.label} icon={<CalendarDays size={18} />} action={tab === "custom" ? (
        <div className="flex items-center gap-2 text-xs" dir="ltr">
          <input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} className="rounded-lg border border-stone-200 dark:border-white/10 bg-transparent px-2 py-1" />
          <span>تا</span>
          <input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} className="rounded-lg border border-stone-200 dark:border-white/10 bg-transparent px-2 py-1" />
        </div>
      ) : undefined}>
        {totTasks === 0 ? <Empty text="در این بازه داده‌ای نیست" /> : (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
              {[
                { icon: <TrendingUp size={17} />, label: "تکمیل تسک‌ها", value: `${fa(doneTasks)}/${fa(totTasks)}`, sub: `${fa(totTasks ? Math.round((doneTasks / totTasks) * 100) : 0)}٪`, bg: "from-emerald-500 to-teal-500" },
                { icon: <Award size={17} />, label: "میانگین نمره", value: scores.length ? fa(avg(scores).toFixed(1)) : "—", sub: scores.length ? `${fa(scores.length)} روز ثبت‌شده` : "ثبت نشده", bg: "from-amber-400 to-orange-500" },
                { icon: <Dumbbell size={17} />, label: "روزهای ورزش", value: `${fa(sportDays)} روز`, sub: `از ${fa(keys.length)} روز`, bg: "from-blue-500 to-indigo-500" },
                { icon: <Moon size={17} />, label: "میانگین بیداری / خواب", value: wakes.length ? minToStr(avg(wakes)) : "—", sub: sleeps.length ? `خواب ${minToStr(avg(sleeps))}` : "", bg: "from-violet-500 to-purple-500" },
              ].map((s, i) => (
                <div key={i} className="rounded-2xl border border-stone-200 dark:border-white/10 p-3.5 relative overflow-hidden">
                  <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-l ${s.bg}`} />
                  <div className="flex items-center gap-2 text-stone-400">{s.icon}<span className="text-[11px] font-bold">{s.label}</span></div>
                  <div className="text-2xl font-black mt-1">{s.value}</div>
                  <div className="text-[11px] text-stone-400 font-bold">{s.sub}</div>
                </div>
              ))}
            </div>

            <div className="grid lg:grid-cols-2 gap-4 mt-4">
              <div>
                <div className="text-sm font-black mb-2">تسک‌های انجام‌شده هر روز</div>
                <div className="flex items-end gap-1.5 h-36 rounded-2xl border border-stone-100 dark:border-white/5 bg-stone-50/60 dark:bg-white/[0.02] p-3" dir="ltr">
                  {perDay.map((p) => (
                    <div key={p.key} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group relative" title={`${p.key}: ${p.done}/${p.total}`}>
                      <span className="text-[10px] font-black text-stone-500">{p.done ? fa(p.done) : ""}</span>
                      <div className="w-full rounded-lg bg-gradient-to-t from-emerald-600 to-teal-300 transition-all group-hover:opacity-80" style={{ height: `${Math.max(4, (p.done / maxDone) * 70)}%`, opacity: p.total ? 1 : 0.25 }} />
                      <span className="text-[9px] font-bold text-stone-400">{faPlain(p.key.slice(8))}</span>
                    </div>
                  ))}
                </div>
                <div className="text-[11px] text-stone-400 mt-1">درصد تکمیل روزانه: {perDay.map((p) => fa(p.pct)).join("٪، ")}٪</div>
              </div>
              <div>
                <div className="text-sm font-black mb-2">روند نمره روزها</div>
                <div className="rounded-2xl border border-stone-100 dark:border-white/5 bg-stone-50/60 dark:bg-white/[0.02] p-3">
                  {scored.length < 2 ? <div className="text-xs text-stone-400 py-8 text-center">برای نمودار خطی حداقل ۲ روز نمره لازم است</div> : (
                    <svg viewBox="0 0 100 100" className="w-full h-36" preserveAspectRatio="none">
                      {[25, 50, 75].map((y) => <line key={y} x1="0" y1={y} x2="100" y2={y} stroke="currentColor" className="text-stone-200 dark:text-white/10" strokeWidth="0.5" strokeDasharray="2 2" />)}
                      <path d={path} fill="none" stroke="url(#rg)" strokeWidth="2.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
                      <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#10b981" /><stop offset="1" stopColor="#f59e0b" /></linearGradient></defs>
                      {linePts.filter((p) => p.score !== undefined).map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="2.5" fill={p.score! >= 7 ? "#10b981" : p.score! >= 5 ? "#f59e0b" : "#ef4444"} />)}
                    </svg>
                  )}
                  <div className="flex justify-between text-[10px] text-stone-400 font-bold mt-1" dir="ltr">
                    <span>{faPlain(range.start)}</span><span>{faPlain(range.end)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2.5 mt-4">
              <div className="rounded-2xl border border-stone-200 dark:border-white/10 p-3.5">
                <div className="text-xs font-black mb-2">خلاصه عادت‌ها</div>
                <div className="space-y-2">
                  {habitStats.map(({ habit: h, filled, total }) => (
                    <div key={h.id}>
                      <div className="flex justify-between text-[11px] font-bold"><span>{h.icon} {h.name}</span><span className="text-stone-500">{fa(filled)} از {fa(total)} روز</span></div>
                      <div className="h-1.5 rounded-full bg-stone-100 dark:bg-white/10 mt-1 overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${total ? (filled / total) * 100 : 0}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl border border-stone-200 dark:border-white/10 p-3.5">
                <div className="text-xs font-black mb-2">بهترین / بدترین</div>
                <div className="text-xs space-y-1.5">
                  <div className="rounded-xl bg-emerald-500/10 p-2.5">بهترین: <b>{best ? `${jalaliStr(best.key)} (نمره ${fa(best.score!)})` : "—"}</b></div>
                  <div className="rounded-xl bg-red-500/10 p-2.5">نیازمند توجه: <b>{worst ? `${jalaliStr(worst.key)} (نمره ${fa(worst.score!)})` : "—"}</b></div>
                  <div className="rounded-xl bg-blue-500/10 p-2.5">پرتکرارترین دسته موفق: <b>{topCatName}</b> {topCat ? `(${fa(topCat[1])} تسک)` : ""}</div>
                </div>
              </div>
              <div className="rounded-2xl border border-stone-200 dark:border-white/10 p-3.5">
                <div className="text-xs font-black mb-2">میانگین‌ها</div>
                <div className="text-xs space-y-1.5 font-bold text-stone-600 dark:text-stone-300">
                  <div className="flex justify-between"><span>بیدار شدن</span><span dir="ltr">{wakes.length ? minToStr(avg(wakes)) : "—"}</span></div>
                  <div className="flex justify-between"><span>خوابیدن</span><span dir="ltr">{sleeps.length ? minToStr(avg(sleeps)) : "—"}</span></div>
                  <div className="flex justify-between"><span>روزهای ورزش</span><span>{fa(sportDays)} از {fa(keys.length)}</span></div>
                </div>
              </div>
            </div>
          </>
        )}
      </Card>

      <Card title="استریک‌ها — زنجیره تداوم" icon={<Flame size={18} />}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
          {streaks.map((s, i) => (
            <div key={i} className="rounded-2xl p-4 text-center border border-orange-500/20 bg-gradient-to-b from-orange-500/[0.08] to-transparent">
              <div className="text-3xl">{s.icon}</div>
              <div className="text-3xl font-black mt-1 text-orange-600 dark:text-orange-300">{fa(s.value)}</div>
              <div className="text-[11px] font-black text-stone-500">روز متوالی {s.label}</div>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-stone-400 mt-2">استریک از امروز به عقب حساب می‌شود؛ هر روز که شرط برقرار باشد زنجیره ادامه دارد.</p>
      </Card>
    </div>
  );
}
