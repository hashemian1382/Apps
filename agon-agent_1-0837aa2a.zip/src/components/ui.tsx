import { useEffect, type ReactNode } from "react";
import { X } from "lucide-react";
import { fa } from "../lib/jalali";

/* ---------- Section card ---------- */
export function Section(props: {
  title: string;
  icon?: ReactNode;
  desc?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  id?: string;
}) {
  return (
    <section id={props.id} className={`card p-4 sm:p-5 ${props.className || ""}`}>
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5">
          {props.icon && (
            <span className="bg-accent-soft text-accent mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl">
              {props.icon}
            </span>
          )}
          <div>
            <h2 className="text-[0.95rem] font-extrabold">{props.title}</h2>
            {props.desc && <p className="muted mt-0.5 text-xs leading-5">{props.desc}</p>}
          </div>
        </div>
        {props.action && <div className="flex shrink-0 items-center gap-2">{props.action}</div>}
      </div>
      {props.children}
    </section>
  );
}

/* ---------- Modal ---------- */
export function Modal(props: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!props.open) return;
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape") props.onClose();
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.open]);
  if (!props.open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/45 p-3 backdrop-blur-[2px] sm:items-center"
      onClick={props.onClose}
    >
      <div
        className={`anim-pop card w-full ${props.wide ? "max-w-2xl" : "max-w-lg"} max-h-[90vh] overflow-y-auto p-5`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-extrabold">{props.title}</h3>
          <button className="icon-btn" onClick={props.onClose} aria-label="بستن">
            <X size={18} />
          </button>
        </div>
        {props.children}
      </div>
    </div>
  );
}

/* ---------- Confirm ---------- */
export function Confirm(props: {
  open: boolean;
  title: string;
  desc?: string;
  confirmLabel?: string;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  if (!props.open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4 backdrop-blur-[2px]"
      onClick={props.onCancel}
    >
      <div className="anim-pop card w-full max-w-sm p-5" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-base font-extrabold">{props.title}</h3>
        {props.desc && <p className="muted mt-1.5 text-sm leading-6">{props.desc}</p>}
        <div className="mt-4 flex gap-2">
          <button className="btn-ghost flex-1" onClick={props.onCancel}>
            انصراف
          </button>
          <button className="btn-danger flex-1" onClick={props.onConfirm}>
            {props.confirmLabel || "تأیید حذف"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- Progress bar ---------- */
export function Bar(props: { value: number; color?: string; h?: number }) {
  return (
    <div
      className="w-full overflow-hidden rounded-full"
      style={{ height: props.h || 8, background: "rgba(120,110,90,.14)" }}
    >
      <div
        className="h-full rounded-full transition-all duration-500"
        style={{
          width: `${Math.min(100, Math.max(0, props.value))}%`,
          background: props.color || "var(--accent)",
        }}
      />
    </div>
  );
}

/* ---------- Progress ring ---------- */
export function Ring(props: { value: number; size?: number; stroke?: number; label?: string }) {
  const s = props.size || 76;
  const st = props.stroke || 8;
  const r = (s - st) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.min(100, Math.max(0, props.value));
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: s, height: s }}>
      <svg width={s} height={s} className="-rotate-90">
        <circle cx={s / 2} cy={s / 2} r={r} fill="none" strokeWidth={st} stroke="rgba(120,110,90,.15)" />
        <circle
          cx={s / 2}
          cy={s / 2}
          r={r}
          fill="none"
          stroke="var(--accent)"
          strokeWidth={st}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (c * v) / 100}
          style={{ transition: "stroke-dashoffset .6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-lg leading-5 font-extrabold">{fa(v)}٪</span>
        {props.label && <span className="muted text-[0.65rem]">{props.label}</span>}
      </div>
    </div>
  );
}

/* ---------- Empty state ---------- */
export function Empty(props: { icon?: ReactNode; title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed px-4 py-8 text-center hairline">
      {props.icon && <div className="muted mb-2 opacity-60">{props.icon}</div>}
      <p className="text-sm font-bold">{props.title}</p>
      {props.desc && <p className="muted mt-1 max-w-xs text-xs leading-5">{props.desc}</p>}
      {props.action && <div className="mt-3">{props.action}</div>}
    </div>
  );
}

/* ---------- Segmented ---------- */
export function Seg<T extends string>(props: {
  options: { v: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="seg">
      {props.options.map((o) => (
        <button key={o.v} className={o.v === props.value ? "on" : ""} onClick={() => props.onChange(o.v)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* ---------- Energy dots ---------- */
export function EnergyDots(props: { value: number; onChange?: (v: number) => void; disabled?: boolean }) {
  return (
    <div className="flex items-center gap-1.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          disabled={props.disabled}
          onClick={() => props.onChange?.(n)}
          className="transition-transform hover:scale-110 active:scale-95 disabled:cursor-default"
          title={`${fa(n)} از ۵`}
          aria-label={`انرژی ${n}`}
        >
          <span
            className="block h-6 w-6 rounded-full border-2"
            style={{
              background: n <= props.value ? "var(--accent)" : "transparent",
              borderColor: n <= props.value ? "var(--accent)" : "#c9c2b2",
              opacity: n <= props.value ? 1 : 0.5,
            }}
          />
        </button>
      ))}
      <span className="muted mr-1 text-xs">{fa(props.value)} از ۵</span>
    </div>
  );
}

/* ---------- Score slider ---------- */
export function ScoreInput(props: {
  value?: number;
  onChange: (v: number | undefined) => void;
  disabled?: boolean;
}) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <span className="text-2xl font-black text-accent">
          {props.value === undefined ? "—" : `${fa(props.value)}/۱۰`}
        </span>
        {props.value !== undefined && !props.disabled && (
          <button className="muted text-xs underline" onClick={() => props.onChange(undefined)}>
            پاک کردن نمره
          </button>
        )}
      </div>
      <input
        type="range"
        min={1}
        max={10}
        step={1}
        disabled={props.disabled}
        value={props.value ?? 5}
        onChange={(e) => props.onChange(Number(e.target.value))}
        className="mt-2 w-full"
      />
      <div className="muted flex justify-between text-[0.65rem]">
        <span>{fa(1)}</span>
        <span>{fa(5)}</span>
        <span>{fa(10)}</span>
      </div>
    </div>
  );
}
