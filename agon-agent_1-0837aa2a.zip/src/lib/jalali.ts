/* Jalaali (Persian) calendar conversion — self-contained, no dependency. */

function div(a: number, b: number): number {
  return Math.floor(a / b);
}
function mod(a: number, b: number): number {
  return a - Math.floor(a / b) * b;
}

const BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
  2192, 2262, 2324, 2394, 2456, 3178,
];

export interface JalaliDate {
  jy: number;
  jm: number;
  jd: number;
}
export interface GregDate {
  gy: number;
  gm: number;
  gd: number;
}

function jalCal(jy: number): { leap: number; gy: number; march: number } {
  const bl = BREAKS.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = BREAKS[0];
  let jump = 0;
  if (jy < jp || jy >= BREAKS[bl - 1])
    throw new Error("Invalid Jalaali year " + jy);
  for (let i = 1; i < bl; i++) {
    const jm = BREAKS[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

export function isLeapJalaaliYear(jy: number): boolean {
  return jalCal(jy).leap === 0;
}

export function jalaaliMonthLength(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaaliYear(jy) ? 30 : 29;
}

function g2d(gy: number, gm: number, gd: number): number {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number): GregDate {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function j2d(jy: number, jm: number, jd: number): number {
  const r = jalCal(jy);
  return (
    g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1
  );
}

function d2j(jdn: number): JalaliDate {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let jd = jdn - jdn1f;
  let jm: number;
  if (jd >= 0) {
    if (jd <= 185) {
      jm = 1 + div(jd, 31);
      jd = mod(jd, 31) + 1;
      return { jy, jm, jd };
    }
    jd -= 186;
  } else {
    jy -= 1;
    jd += 179;
    if (r.leap === 1) jd += 1;
  }
  jm = 7 + div(jd, 30);
  jd = mod(jd, 30) + 1;
  return { jy, jm, jd };
}

export function toJalaali(gy: number, gm: number, gd: number): JalaliDate {
  return d2j(g2d(gy, gm, gd));
}

export function toGregorian(jy: number, jm: number, jd: number): GregDate {
  return d2g(j2d(jy, jm, jd));
}

/* ---------------- date-key helpers (gregorian yyyy-mm-dd) ---------------- */

export const pad2 = (n: number): string => String(n).padStart(2, "0");

export function dateKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export function parseKey(key: string): Date {
  const [y, m, dd] = key.split("-").map(Number);
  return new Date(y || 2000, (m || 1) - 1, dd || 1);
}

export function todayKey(now = new Date()): string {
  return dateKey(now);
}

export function addDays(key: string, n: number): string {
  const d = parseKey(key);
  d.setDate(d.getDate() + n);
  return dateKey(d);
}

export function rangeKeys(start: string, end: string): string[] {
  const out: string[] = [];
  let cur = start;
  let guard = 0;
  while (cur <= end && guard < 400) {
    out.push(cur);
    cur = addDays(cur, 1);
    guard++;
  }
  return out;
}

export function diffDays(a: string, b: string): number {
  return Math.round((parseKey(b).getTime() - parseKey(a).getTime()) / 86400000);
}

/* ---------------- Persian formatting ---------------- */

const FA_D = "۰۱۲۳۴۵۶۷۸۹";
export function fa(v: number | string): string {
  return String(v).replace(/[0-9]/g, (d) => FA_D[Number(d)]);
}

export const J_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

export const G_MONTHS_FA = [
  "ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن",
  "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر",
];

export const WEEKDAYS_FA = [
  "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه",
];

export function jalaliOf(key: string): JalaliDate {
  const d = parseKey(key);
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

export function weekdayFa(key: string): string {
  return WEEKDAYS_FA[parseKey(key).getDay()];
}

export function formatJalaliLong(key: string): string {
  const j = jalaliOf(key);
  return `${weekdayFa(key)} ${fa(j.jd)} ${J_MONTHS[j.jm - 1]} ${fa(j.jy)}`;
}

export function formatJalaliShort(key: string): string {
  const j = jalaliOf(key);
  return `${fa(j.jd)} ${J_MONTHS[j.jm - 1]}`;
}

export function formatGregorianFa(key: string): string {
  const d = parseKey(key);
  return `${fa(d.getDate())} ${G_MONTHS_FA[d.getMonth()]} ${fa(d.getFullYear())}`;
}

export function relDayLabel(key: string, today = todayKey()): string | null {
  if (key === today) return "امروز";
  if (key === addDays(today, -1)) return "دیروز";
  if (key === addDays(today, 1)) return "فردا";
  return null;
}

export function timeToMin(t: string): number {
  const [h, m] = t.split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minToTime(mins: number): string {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${pad2(h)}:${pad2(m)}`;
}

export function avgTime(times: string[]): string | null {
  if (!times.length) return null;
  const s = times.reduce((a, t) => a + timeToMin(t), 0);
  return minToTime(Math.round(s / times.length));
}

export function greetingByHour(h: number): string {
  if (h >= 5 && h < 12) return "صبح بخیر";
  if (h >= 12 && h < 15) return "ظهر بخیر";
  if (h >= 15 && h < 19) return "عصر بخیر";
  return "شب بخیر";
}

export interface CalCell {
  key: string;
  jd: number;
  inMonth: boolean;
}

export function monthGrid(jy: number, jm: number, weekStart = 6): CalCell[][] {
  const g = toGregorian(jy, jm, 1);
  const first = new Date(g.gy, g.gm - 1, g.gd);
  const lead = (first.getDay() - weekStart + 7) % 7;
  const len = jalaaliMonthLength(jy, jm);
  const cells: CalCell[] = [];
  for (let i = lead - 1; i >= 0; i--) {
    const d = new Date(first);
    d.setDate(d.getDate() - (i + 1));
    const k = dateKey(d);
    cells.push({ key: k, jd: jalaliOf(k).jd, inMonth: false });
  }
  for (let d = 1; d <= len; d++) {
    const gg = toGregorian(jy, jm, d);
    const k = `${gg.gy}-${pad2(gg.gm)}-${pad2(gg.gd)}`;
    cells.push({ key: k, jd: d, inMonth: true });
  }
  while (cells.length % 7 !== 0) {
    const last = parseKey(cells[cells.length - 1].key);
    last.setDate(last.getDate() + 1);
    const k = dateKey(last);
    cells.push({ key: k, jd: jalaliOf(k).jd, inMonth: false });
  }
  const weeks: CalCell[][] = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
  return weeks;
}

export function weekHeaderLabels(weekStart = 6): string[] {
  const names = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  const out: string[] = [];
  for (let i = 0; i < 7; i++) out.push(names[(weekStart + i) % 7]);
  return out;
}
