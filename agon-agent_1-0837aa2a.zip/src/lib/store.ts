import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  addDays,
  avgTime,
  dateKey,
  fa as faNum,
  formatJalaliLong,
  todayKey,
} from "./jalali";

export type Priority = "q1" | "q2" | "q3" | "q4";

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface HabitDef {
  id: string;
  name: string;
  emoji: string;
  active: boolean;
}

export interface Task {
  id: string;
  title: string;
  done: boolean;
  priority: Priority;
  categoryId: string;
  plannedStart?: string;
  plannedEnd?: string;
  actualMinutes?: number;
  note?: string;
}

export interface Slot {
  id: string;
  title: string;
  start: string;
  end: string;
}

export interface TomorrowTask {
  id: string;
  title: string;
  done: boolean;
}

export interface DayData {
  date: string;
  mainGoal: string;
  wakeUp: string;
  sleep: string;
  mood: string;
  energy: number;
  water: number;
  weight: string;
  score?: number;
  exercised: boolean;
  exerciseType: string;
  wentOut: boolean;
  outWhere: string;
  note: string;
  gratitude: string;
  good1: string;
  good2: string;
  good3: string;
  improve: string;
  lesson: string;
  endReport: string;
  closed: boolean;
  tasks: Task[];
  schedule: Slot[];
  habits: Record<string, boolean>;
  tomorrowTasks: TomorrowTask[];
  tomorrowNote: string;
}

export interface BacklogItem {
  id: string;
  title: string;
  desc: string;
  priority: Priority;
  categoryId: string;
  deadline?: string;
  createdAt: string;
}

export interface Settings {
  displayName: string;
  theme: "light" | "dark";
  accent: string;
  fontSize: "normal" | "large";
  weekStart: number;
  reminderTime: string;
}

export interface Store {
  settings: Settings;
  categories: Category[];
  habits: HabitDef[];
  days: Record<string, DayData>;
  backlog: BacklogItem[];
}

export const PRIORITIES: {
  v: Priority;
  label: string;
  short: string;
  desc: string;
  color: string;
  bg: string;
}[] = [
  { v: "q1", label: "فوری و مهم", short: "فوری · مهم", desc: "اول انجام بده", color: "#dc2626", bg: "rgba(220,38,38,.1)" },
  { v: "q2", label: "مهم، غیرفوری", short: "مهم", desc: "برنامه‌ریزی کن", color: "#d97706", bg: "rgba(217,119,6,.12)" },
  { v: "q3", label: "فوری، غیرمهم", short: "فوری", desc: "واگذار / سریع بزن", color: "#2563eb", bg: "rgba(37,99,235,.1)" },
  { v: "q4", label: "نه فوری، نه مهم", short: "کم‌اهمیت", desc: "حذف / بعداً", color: "#6b7280", bg: "rgba(107,114,128,.12)" },
];

export const prioOf = (p: Priority) =>
  PRIORITIES.find((x) => x.v === p) || PRIORITIES[1];

export const MOODS = [
  { emoji: "🤩", label: "فوق‌العاده" },
  { emoji: "😄", label: "عالی" },
  { emoji: "🙂", label: "خوب" },
  { emoji: "😐", label: "معمولی" },
  { emoji: "😟", label: "بد" },
  { emoji: "😞", label: "خیلی بد" },
];

export const ACCENTS = [
  { v: "#10b981", label: "سبز" },
  { v: "#0d9488", label: "فیروزه‌ای" },
  { v: "#3b82f6", label: "آبی" },
  { v: "#8b5cf6", label: "بنفش" },
  { v: "#f43f5e", label: "رز" },
  { v: "#f59e0b", label: "کهربایی" },
];

export const CAT_COLORS = [
  "#10b981", "#3b82f6", "#8b5cf6", "#f43f5e",
  "#f59e0b", "#0d9488", "#ec4899", "#64748b",
];

export const uid = (): string =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export const LS_KEY = "roozino-v1";

export function emptyDay(date: string): DayData {
  return {
    date,
    mainGoal: "",
    wakeUp: "",
    sleep: "",
    mood: "",
    energy: 3,
    water: 0,
    weight: "",
    score: undefined,
    exercised: false,
    exerciseType: "",
    wentOut: false,
    outWhere: "",
    note: "",
    gratitude: "",
    good1: "",
    good2: "",
    good3: "",
    improve: "",
    lesson: "",
    endReport: "",
    closed: false,
    tasks: [],
    schedule: [],
    habits: {},
    tomorrowTasks: [],
    tomorrowNote: "",
  };
}

function defaultStore(): Store {
  return {
    settings: {
      displayName: "",
      theme: "light",
      accent: "#10b981",
      fontSize: "normal",
      weekStart: 6,
      reminderTime: "",
    },
    categories: [
      { id: "work", name: "کار", color: "#3b82f6" },
      { id: "personal", name: "شخصی", color: "#8b5cf6" },
      { id: "health", name: "سلامت", color: "#10b981" },
      { id: "learn", name: "یادگیری", color: "#f59e0b" },
      { id: "home", name: "خانه", color: "#f43f5e" },
    ],
    habits: [
      { id: "h1", name: "مطالعه", emoji: "📚", active: true },
      { id: "h2", name: "آب کافی", emoji: "💧", active: true },
      { id: "h3", name: "مدیتیشن", emoji: "🧘", active: true },
      { id: "h4", name: "پیاده‌روی", emoji: "🚶", active: true },
      { id: "h5", name: "بدون قند", emoji: "🍬", active: false },
    ],
    days: {},
    backlog: [],
  };
}

function seedDemo(): Store {
  const s = defaultStore();
  const t = todayKey();
  const moods = ["🙂", "😄", "😐", "😄", "🙂", "🤩", "😐"];
  const scores = [8, 7, 6, 9, 7, 8, 5];
  const samples: { title: string; cat: string; pr: Priority }[] = [
    { title: "جلسه تیم محصول", cat: "work", pr: "q1" },
    { title: "کار روی پروژه ایکس", cat: "work", pr: "q1" },
    { title: "پاسخ ایمیل‌ها", cat: "work", pr: "q3" },
    { title: "مطالعه فصل ۳ کتاب", cat: "learn", pr: "q2" },
    { title: "دویدن ۳۰ دقیقه", cat: "health", pr: "q2" },
    { title: "خرید هفتگی", cat: "home", pr: "q3" },
    { title: "تمرین زبان", cat: "learn", pr: "q4" },
    { title: "مرتب کردن اتاق", cat: "home", pr: "q4" },
    { title: "تماس با خانواده", cat: "personal", pr: "q2" },
  ];
  for (let f = -6; f <= 0; f++) {
    const k = addDays(t, f);
    const d = emptyDay(k);
    d.wakeUp = f % 2 === 0 ? "06:30" : "07:00";
    d.sleep = "23:00";
    d.mood = moods[(f + 14) % moods.length];
    d.energy = 3 + ((f + 14) % 3);
    d.water = 4 + ((f + 14) % 5);
    d.exercised = f % 2 === 0;
    d.exerciseType = d.exercised ? "دویدن ۳۰ دقیقه" : "";
    d.wentOut = f % 3 === 0;
    d.outWhere = d.wentOut ? "کافه، خرید" : "";
    d.score = f === 0 ? undefined : scores[(f + 14) % scores.length];
    d.mainGoal = f === 0 ? "تمام کردن فصل ۴ کتاب" : samples[(f + 14) % samples.length].title;
    d.note = f === -1 ? "روز پرکاری بود ولی جلسه عصر عالی پیش رفت." : "";
    const n = 5 + ((f + 14) % 4);
    d.tasks = samples.slice(0, n).map((v, b) => ({
      id: `${uid()}-${b}`,
      title: v.title,
      done: f === 0 ? b < 2 : b < n - 1 - (Math.abs(f) % 2),
      priority: v.pr,
      categoryId: v.cat,
      plannedStart: b === 0 ? "08:30" : b === 1 ? "10:00" : undefined,
      plannedEnd: b === 0 ? "09:30" : b === 1 ? "12:00" : undefined,
      actualMinutes: b < 2 ? 60 : undefined,
      note: b === 1 ? "فاز اول تمام شد" : undefined,
    }));
    if (f === -2) {
      d.schedule = [
        { id: `${uid()}-s1`, title: "جلسه تیم محصول", start: "09:00", end: "10:00" },
        { id: `${uid()}-s2`, title: "مطالعه عمیق", start: "10:30", end: "12:00" },
        { id: `${uid()}-s3`, title: "ورزش", start: "18:00", end: "18:45" },
      ];
    }
    if (f === -1) {
      d.good1 = "جلسه عالی بود";
      d.good2 = "ورزش کردم";
      d.good3 = "خرید انجام شد";
      d.improve = "تمرکز بعدازظهر کم بود";
      d.lesson = "اول کارهای سخت، بعد آسان‌ها";
      d.gratitude = "سلامتی، خانواده، یک روز آفتابی";
      d.endReport = "روز پرکاری بود؛ بیشتر برنامه‌ها انجام شد.";
      d.closed = true;
    }
    s.habits.forEach((h, bi) => {
      d.habits[h.id] = (bi + f + 14) % 3 !== 0;
    });
    s.days[k] = d;
  }
  const m = s.days[t];
  m.tomorrowTasks = [
    { id: `${uid()}-t1`, title: "فصل ۴ کتاب", done: false },
    { id: `${uid()}-t2`, title: "جلسه ساعت ۹ — بردن لپ‌تاپ", done: false },
  ];
  m.tomorrowNote = "فردا ساعت ۹ جلسه دارم، یادم نره گزارش را ببرم.";
  s.backlog = [
    { id: `${uid()}-b1`, title: "نوشتن مقاله بلاگ", desc: "پیش‌نویس ۸۰۰ کلمه‌ای درباره تمرکز عمیق", priority: "q2", categoryId: "learn", createdAt: addDays(t, -4) },
    { id: `${uid()}-b2`, title: "تماس با بیمه", desc: "پیگیری تمدید", priority: "q3", categoryId: "personal", createdAt: addDays(t, -3) },
    { id: `${uid()}-b3`, title: "فاکتورهای مالیاتی", desc: "ددلاین آخر ماه", priority: "q1", categoryId: "work", createdAt: addDays(t, -5), deadline: addDays(t, 6) },
    { id: `${uid()}-b4`, title: "مرتب کردن گالری عکس", desc: "", priority: "q4", categoryId: "home", createdAt: addDays(t, -2) },
    { id: `${uid()}-b5`, title: "ثبت‌نام دوره زبان", desc: "مقایسه دو آموزشگاه", priority: "q2", categoryId: "learn", createdAt: addDays(t, -1) },
    { id: `${uid()}-b6`, title: "چکاپ سالانه", desc: "آزمایش خون + دندان‌پزشکی", priority: "q2", categoryId: "health", createdAt: addDays(t, -6), deadline: addDays(t, 12) },
  ];
  return s;
}

function migrate(raw: Partial<Store>): Store {
  const d = defaultStore();
  const out: Store = {
    settings: { ...d.settings, ...(raw.settings || {}) },
    categories:
      Array.isArray(raw.categories) && raw.categories.length
        ? raw.categories
        : d.categories,
    habits: Array.isArray(raw.habits) ? raw.habits : d.habits,
    days: raw.days || {},
    backlog: Array.isArray(raw.backlog) ? raw.backlog : [],
  };
  for (const k of Object.keys(out.days)) {
    const base = emptyDay(k);
    const cur = out.days[k] as Partial<DayData>;
    out.days[k] = {
      ...base,
      ...(cur as DayData),
      date: k,
      energy: typeof cur.energy === "number" ? cur.energy : 3,
      water: typeof cur.water === "number" ? cur.water : 0,
      tasks: Array.isArray(cur.tasks)
        ? cur.tasks.map((t) => {
            const tt = t as Partial<Task>;
            return {
              id: tt.id || uid(),
              title: tt.title || "",
              done: tt.done ?? false,
              priority: (tt.priority || "q2") as Priority,
              categoryId: tt.categoryId || "personal",
              plannedStart: tt.plannedStart,
              plannedEnd: tt.plannedEnd,
              actualMinutes: tt.actualMinutes,
              note: tt.note,
            } as Task;
          })
        : [],
      schedule: Array.isArray(cur.schedule) ? cur.schedule : [],
      habits: cur.habits || {},
      tomorrowTasks: Array.isArray(cur.tomorrowTasks) ? cur.tomorrowTasks : [],
    };
  }
  out.backlog = out.backlog.map((b) => {
    const bb = b as Partial<BacklogItem>;
    return {
      id: bb.id || uid(),
      title: bb.title || "",
      desc: bb.desc || "",
      priority: (bb.priority || "q2") as Priority,
      categoryId: bb.categoryId || "personal",
      deadline: bb.deadline,
      createdAt: bb.createdAt || todayKey(),
    } as BacklogItem;
  });
  return out;
}

function load(): Store {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) {
      const s = seedDemo();
      try {
        localStorage.setItem(LS_KEY, JSON.stringify(s));
      } catch {
        /* ignore */
      }
      return s;
    }
    return migrate(JSON.parse(raw) as Partial<Store>);
  } catch {
    return seedDemo();
  }
}

/* ---------------- progress helpers ---------------- */

export function taskProgress(d: DayData): number {
  if (!d.tasks.length) return 0;
  return Math.round(
    (d.tasks.filter((t) => t.done).length / d.tasks.length) * 100
  );
}

export function habitProgress(d: DayData, habits: HabitDef[]): number {
  const act = habits.filter((h) => h.active);
  if (!act.length) return 0;
  const done = act.filter((h) => d.habits[h.id]).length;
  return Math.round((done / act.length) * 100);
}

export function dayProgress(d: DayData, habits: HabitDef[]): number {
  const tp = taskProgress(d);
  const hp = habitProgress(d, habits);
  const hasT = d.tasks.length > 0;
  const hasH = habits.some((h) => h.active);
  if (hasT && hasH) return Math.round(tp * 0.65 + hp * 0.35);
  if (hasT) return tp;
  if (hasH) return hp;
  return d.closed ? 100 : 0;
}

export function isActiveDay(d: DayData, habits: HabitDef[]): boolean {
  return (
    d.tasks.length > 0 ||
    d.score !== undefined ||
    d.closed ||
    habits.some((h) => h.active && d.habits[h.id]) ||
    !!d.note ||
    !!d.endReport ||
    d.water > 0 ||
    !!d.wakeUp
  );
}

export function streakCount(
  days: Record<string, DayData>,
  pred: (d: DayData) => boolean,
  from = todayKey()
): number {
  let n = 0;
  let cur = from;
  const first = days[cur];
  if (!first || !pred(first)) cur = addDays(from, -1);
  let guard = 0;
  while (guard < 3650) {
    const d = days[cur];
    if (!d || !pred(d)) break;
    n++;
    cur = addDays(cur, -1);
    guard++;
  }
  return n;
}

export function avg(nums: number[]): number {
  if (!nums.length) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

/* ---------------- share text ---------------- */

export function buildDaySummary(d: DayData, store: Store): string {
  const lines: string[] = [];
  const catName = (id: string) =>
    store.categories.find((c) => c.id === id)?.name || "بدون دسته";
  lines.push(`خلاصه روز — ${formatJalaliLong(d.date)}`);
  lines.push("━".repeat(24));
  if (d.mainGoal) lines.push(`🎯 هدف اصلی: ${d.mainGoal}`);
  if (d.wakeUp || d.sleep)
    lines.push(`⏰ بیداری ${d.wakeUp || "—"} | خواب ${d.sleep || "—"}`);
  if (d.mood) {
    const m = MOODS.find((x) => x.emoji === d.mood);
    lines.push(
      `حال: ${d.mood} ${m?.label || ""} | انرژی: ${faNum(d.energy)}/۵ | آب: ${faNum(d.water)} لیوان`
    );
  }
  if (d.exercised) lines.push(`🏃 ورزش: بله${d.exerciseType ? ` — ${d.exerciseType}` : ""}`);
  if (d.weight) lines.push(`⚖️ وزن: ${d.weight} کیلو`);
  const done = d.tasks.filter((t) => t.done).length;
  lines.push(`━━ تسک‌ها (${faNum(done)}/${faNum(d.tasks.length)} انجام شد) ━━`);
  if (!d.tasks.length) lines.push("— تسکی ثبت نشده");
  d.tasks.forEach((t) =>
    lines.push(`${t.done ? "✅" : "⬜"} ${t.title} [${catName(t.categoryId)}]`)
  );
  if (d.schedule.length) {
    lines.push("━━ برنامه زمانی ━━");
    d.schedule.forEach((s) => lines.push(`▪️ ${s.start}–${s.end} ${s.title}`));
  }
  const act = store.habits.filter((h) => h.active);
  if (act.length) {
    lines.push("━━ عادت‌ها ━━");
    act.forEach((h) =>
      lines.push(`${d.habits[h.id] ? "✅" : "⬜"} ${h.emoji} ${h.name}`)
    );
  }
  if (d.good1 || d.good2 || d.good3)
    lines.push(`✨ خوب‌ها: ${[d.good1, d.good2, d.good3].filter(Boolean).join("، ")}`);
  if (d.improve) lines.push(`🔧 قابل بهبود: ${d.improve}`);
  if (d.lesson) lines.push(`📖 درس: ${d.lesson}`);
  if (d.gratitude) lines.push(`🙏 قدردانی: ${d.gratitude}`);
  if (d.note) lines.push(`📝 یادداشت: ${d.note}`);
  if (d.endReport) lines.push(`🌙 گزارش پایان روز: ${d.endReport}`);
  if (d.score !== undefined) lines.push(`⭐ امتیاز روز: ${faNum(d.score)}/۱۰`);
  if (d.tomorrowTasks.length) {
    lines.push("━━ برنامه فردا ━━");
    d.tomorrowTasks.forEach((t) => lines.push(`- ${t.title}`));
  }
  if (d.tomorrowNote) lines.push(`یادداشت فردا: ${d.tomorrowNote}`);
  return lines.join("\n");
}

/* ---------------- hook ---------------- */

export type ToastFn = (msg: string) => void;

export function useStore() {
  const [store, setStore] = useState<Store>(() => load());
  const [toasts, setToasts] = useState<{ id: string; msg: string }[]>([]);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      try {
        localStorage.setItem(LS_KEY, JSON.stringify(store));
      } catch {
        /* ignore */
      }
    }, 250);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [store]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", store.settings.theme === "dark");
    root.style.setProperty("--accent", store.settings.accent);
    root.style.setProperty("--accent-soft", store.settings.accent + "1f");
    document.body.style.fontSize =
      store.settings.fontSize === "large" ? "17.5px" : "";
  }, [store.settings.theme, store.settings.accent, store.settings.fontSize]);

  const toast: ToastFn = useCallback((msg: string) => {
    const id = uid();
    setToasts((p) => [...p.slice(-2), { id, msg }]);
    window.setTimeout(
      () => setToasts((p) => p.filter((t) => t.id !== id)),
      2800
    );
  }, []);

  const update = useCallback((fn: (s: Store) => Store) => {
    setStore((prev) => fn(structuredClone(prev)));
  }, []);

  const getDay = useCallback(
    (key: string): DayData => store.days[key] || emptyDay(key),
    [store.days]
  );

  const setDay = useCallback(
    (key: string, patch: Partial<DayData> | ((d: DayData) => DayData)) => {
      update((s) => {
        const cur = s.days[key] || emptyDay(key);
        const cloned = structuredClone(cur);
        const next =
          typeof patch === "function"
            ? (patch as (d: DayData) => DayData)(cloned)
            : { ...cloned, ...patch };
        next.date = key;
        s.days[key] = next;
        return s;
      });
    },
    [update]
  );

  const storageKB = useMemo(() => {
    try {
      const raw = localStorage.getItem(LS_KEY) || "";
      return (new Blob([raw]).size / 1024).toFixed(1);
    } catch {
      return "—";
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [store]);

  const stats = useMemo(() => {
    const keys = Object.keys(store.days);
    const wakes = keys
      .map((k) => store.days[k].wakeUp)
      .filter(Boolean) as string[];
    const sleeps = keys
      .map((k) => store.days[k].sleep)
      .filter(Boolean) as string[];
    return {
      totalDays: keys.length,
      avgWake: avgTime(wakes),
      avgSleep: avgTime(sleeps),
      todayStr: dateKey(new Date()),
    };
  }, [store.days]);

  return { store, setStore, update, getDay, setDay, toast, toasts, storageKB, stats };
}

export type StoreApi = ReturnType<typeof useStore>;
