import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlarmClock,
  ArrowLeft,
  ArrowRightLeft,
  BedDouble,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  CirclePlus,
  Clock,
  Copy,
  Dumbbell,
  Flag,
  GripVertical,
  Heart,
  Inbox,
  ListTodo,
  Lock,
  LockOpen,
  MapPin,
  Minus,
  MoonStar,
  NotebookPen,
  Pencil,
  Plus,
  Sparkles,
  Star,
  Sun,
  Target,
  Timer,
  Trash2,
  Droplets,
  Weight,
  Send,
  StickyNote,
} from "lucide-react";
import {
  addDays,
  fa,
  formatGregorianFa,
  formatJalaliLong,
  greetingByHour,
  relDayLabel,
  timeToMin,
  todayKey,
} from "../lib/jalali";
import {
  MOODS,
  PRIORITIES,
  buildDaySummary,
  dayProgress,
  emptyDay,
  habitProgress,
  prioOf,
  taskProgress,
  uid,
  type DayData,
  type Priority,
  type StoreApi,
  type Task,
} from "../lib/store";
import {
  Bar,
  Confirm,
  Empty,
  EnergyDots,
  Modal,
  Ring,
  ScoreInput,
  Section,
  Seg,
} from "../components/ui";

export default function DayPage(props: {
  api: StoreApi;
  dayKey: string;
  setDayKey: (k: string) => void;
  go: (tab: string) => void;
}) {
  const { api, dayKey, setDayKey } = props;
  const { store, setDay, toast } = api;
  const day: DayData = store.days[dayKey] || emptyDay(dayKey);
  const today = todayKey();
  const isToday = dayKey === today;
  const rel = relDayLabel(dayKey, today);
  const closed = day.closed;
  const name = store.settings.displayName;
  const hour = new Date().getHours();
  const greet = greetingByHour(hour);

  const tp = taskProgress(day);
  const hp = habitProgress(day, store.habits);
  const dp = dayProgress(day, store.habits);
  const doneCount = day.tasks.filter((t) => t.done).length;
  const activeHabits = store.habits.filter((h) => h.active);

  /* ---------- new task ---------- */
  const [newTitle, setNewTitle] = useState("");
  const [newPrio, setNewPrio] = useState<Priority>("q2");
  const [newCat, setNewCat] = useState(store.categories[0]?.id || "personal");
  const newInputRef = useRef<HTMLInputElement>(null);
  const [taskFilter, setTaskFilter] = useState<"all" | "open" | "done">("all");
  const [catFilter, setCatFilter] = useState<string>("all");

  useEffect(() => {
    setNewTitle("");
    setTaskFilter("all");
    setCatFilter("all");
  }, [dayKey]);

  // shortcut N → new task
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const typing = el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT");
      if ((e.key === "n" || e.key === "N" || e.key === "ی") && !typing && !closed) {
        e.preventDefault();
        newInputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [closed]);

  const addTask = () => {
    const t = newTitle.trim();
    if (!t) return;
    const task: Task = {
      id: uid(),
      title: t,
      done: false,
      priority: newPrio,
      categoryId: newCat,
    };
    setDay(dayKey, { tasks: [...day.tasks, task] });
    setNewTitle("");
    toast("تسک اضافه شد");
  };

  /* ---------- task edit modal ---------- */
  const [editing, setEditing] = useState<Task | null>(null);

  /* ---------- drag reorder ---------- */
  const [dragId, setDragId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);
  const reorder = (from: string, to: string) => {
    if (from === to) return;
    const list = [...day.tasks];
    const fi = list.findIndex((t) => t.id === from);
    const ti = list.findIndex((t) => t.id === to);
    if (fi < 0 || ti < 0) return;
    const [mv] = list.splice(fi, 1);
    list.splice(ti, 0, mv);
    setDay(dayKey, { tasks: list });
  };

  /* ---------- schedule ---------- */
  const [slotTitle, setSlotTitle] = useState("");
  const [slotStart, setSlotStart] = useState("");
  const [slotEnd, setSlotEnd] = useState("");
  const addSlot = () => {
    if (!slotTitle.trim() || !slotStart || !slotEnd) {
      toast("عنوان و ساعت شروع/پایان لازم است");
      return;
    }
    if (timeToMin(slotEnd) <= timeToMin(slotStart)) {
      toast("ساعت پایان باید بعد از شروع باشد");
      return;
    }
    setDay(dayKey, {
      schedule: [...day.schedule, { id: uid(), title: slotTitle.trim(), start: slotStart, end: slotEnd }],
    });
    setSlotTitle("");
    setSlotStart("");
    setSlotEnd("");
    toast("به برنامه اضافه شد");
  };

  const timeline = useMemo(() => {
    const items: { id: string; title: string; start: string; end?: string; kind: "slot" | "task"; done?: boolean }[] =
      day.schedule.map((s) => ({ id: s.id, title: s.title, start: s.start, end: s.end, kind: "slot" as const }));
    day.tasks.forEach((t) => {
      if (t.plannedStart)
        items.push({ id: `t-${t.id}`, title: t.title, start: t.plannedStart, end: t.plannedEnd, kind: "task", done: t.done });
    });
    return items.sort((a, b) => timeToMin(a.start) - timeToMin(b.start));
  }, [day.schedule, day.tasks]);

  /* ---------- tomorrow ---------- */
  const [tmTitle, setTmTitle] = useState("");
  const addTomorrow = () => {
    const t = tmTitle.trim();
    if (!t) return;
    setDay(dayKey, { tomorrowTasks: [...day.tomorrowTasks, { id: uid(), title: t, done: false }] });
    setTmTitle("");
  };

  const carryYesterday = () => {
    const y = addDays(dayKey, -1);
    const yd = store.days[y];
    if (!yd) {
      toast("کار ناتمامی از دیروز نیست 🎉");
      return;
    }
    const open = yd.tasks.filter((t) => !t.done);
    if (!open.length) {
      toast("کار ناتمامی از دیروز نیست 🎉");
      return;
    }
    const existing = new Set(day.tasks.map((t) => t.title.trim()));
    const fresh = open.filter((t) => !existing.has(t.title.trim())).map((t) => ({ ...t, id: uid(), done: false }));
    if (!fresh.length) {
      toast("همه کارهای دیروز قبلاً منتقل شده‌اند");
      return;
    }
    setDay(dayKey, { tasks: [...day.tasks, ...fresh] });
    toast(`${fa(fresh.length)} کار از دیروز منتقل شد`);
  };

  const buildTomorrowTasks = () => {
    if (!day.tomorrowTasks.length) {
      toast("برای فردا چیزی ننوشته‌ای");
      return;
    }
    const nk = addDays(dayKey, 1);
    const nd = store.days[nk] || emptyDay(nk);
    const existing = new Set(nd.tasks.map((t) => t.title.trim()));
    const fresh: Task[] = day.tomorrowTasks
      .filter((t) => !existing.has(t.title.trim()))
      .map((t) => ({ id: uid(), title: t.title, done: false, priority: "q2" as Priority, categoryId: store.categories[0]?.id || "personal" }));
    api.update((s) => {
      s.days[nk] = { ...nd, date: nk, tasks: [...nd.tasks, ...fresh] };
      return s;
    });
    toast(fresh.length ? `برنامه فردا ساخته شد (${fa(fresh.length)} تسک)` : "تسک‌های فردا قبلاً ساخته شده‌اند");
  };

  /* ---------- copy / close ---------- */
  const copySummary = async () => {
    const txt = buildDaySummary(day, store);
    try {
      await navigator.clipboard.writeText(txt);
      toast("خلاصه روز کپی شد ✅");
    } catch {
      const ta = document.createElement("textarea");
      ta.value = txt;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
        toast("خلاصه روز کپی شد ✅");
      } catch {
        toast("کپی نشد — مرورگر اجازه نداد");
      }
      document.body.removeChild(ta);
    }
  };

  const [closeAsk, setCloseAsk] = useState(false);
  const [delTaskId, setDelTaskId] = useState<string | null>(null);

  const catName = (id: string) => store.categories.find((c) => c.id === id)?.name || "بدون دسته";
  const catColor = (id: string) => store.categories.find((c) => c.id === id)?.color || "#8b5cf6";

  const visibleTasks = day.tasks.filter((t) => {
    if (taskFilter === "open" && t.done) return false;
    if (taskFilter === "done" && !t.done) return false;
    if (catFilter !== "all" && t.categoryId !== catFilter) return false;
    return true;
  });

  const ro = closed; // read-only when closed

  return (
    <div className="space-y-4">
      {/* ===== header ===== */}
      <div className="card anim-fade-up overflow-hidden">
        <div className="h-1.5 w-full" style={{ background: "linear-gradient(90deg, var(--accent), transparent)" }} />
        <div className="p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold text-accent">
                {greet}
                {name ? `، ${name}` : ""} 🌱
              </p>
              <h1 className="mt-1 text-lg font-black sm:text-xl">
                {formatJalaliLong(dayKey)}
                {rel && <span className="chip bg-accent-soft text-accent mr-2 align-middle">{rel}</span>}
                {closed && (
                  <span className="chip mr-2 align-middle" style={{ background: "rgba(16,185,129,.12)", color: "var(--accent)" }}>
                    <Lock size={11} /> بسته شده ✓
                  </span>
                )}
              </h1>
              <p className="muted mt-0.5 text-xs">{formatGregorianFa(dayKey)}</p>
            </div>
            <div className="no-print flex items-center gap-1.5">
              <button className="icon-btn border hairline" title="روز قبل" onClick={() => setDayKey(addDays(dayKey, -1))}>
                <ChevronRight size={18} />
              </button>
              {!isToday && (
                <button className="btn-ghost !py-1.5 !text-xs" onClick={() => setDayKey(today)}>
                  بازگشت به امروز
                </button>
              )}
              <button className="icon-btn border hairline" title="روز بعد" onClick={() => setDayKey(addDays(dayKey, 1))}>
                <ChevronLeft size={18} />
              </button>
              <button className="icon-btn border hairline" title="کپی خلاصه روز" onClick={copySummary}>
                <Copy size={16} />
              </button>
            </div>
          </div>

          {/* progress overview */}
          <div className="mt-4 flex flex-col items-center gap-4 sm:flex-row sm:gap-6">
            <Ring value={dp} size={92} label="پیشرفت روز" />
            <div className="w-full flex-1 space-y-2.5">
              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="font-bold">تسک‌ها: {fa(doneCount)} از {fa(day.tasks.length)}</span>
                  <span className="muted">{fa(tp)}٪</span>
                </div>
                <Bar value={tp} />
              </div>
              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="font-bold">عادت‌ها</span>
                  <span className="muted">{fa(hp)}٪</span>
                </div>
                <Bar value={hp} color="#8b5cf6" />
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1 text-[0.7rem]">
                {day.score !== undefined && (
                  <span className="chip" style={{ background: "rgba(245,158,11,.14)", color: "#b45309" }}>
                    <Star size={11} /> امتیاز {fa(day.score)}/۱۰
                  </span>
                )}
                {day.water > 0 && (
                  <span className="chip" style={{ background: "rgba(59,130,246,.12)", color: "#2563eb" }}>
                    <Droplets size={11} /> {fa(day.water)} لیوان آب
                  </span>
                )}
                {day.exercised && (
                  <span className="chip" style={{ background: "rgba(16,185,129,.12)", color: "var(--accent)" }}>
                    <Dumbbell size={11} /> ورزش ✓
                  </span>
                )}
                {day.mainGoal && (
                  <span className="chip" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                    <Target size={11} /> هدف ثبت شده
                  </span>
                )}
              </div>
            </div>
          </div>

          {!isToday && (
            <div className="mt-3 rounded-xl bg-amber-500/10 px-3 py-2 text-xs font-bold text-amber-700 dark:text-amber-300">
              {dayKey < today ? "در حال مشاهده روز گذشته — تغییرات هم ذخیره می‌شود." : "در حال مشاهده روز آینده — می‌توانی از الان برنامه بچینی."}
            </div>
          )}
          {closed && (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-xs font-bold" style={{ background: "var(--accent-soft)" }}>
              <span>🌙 روز بسته شد. فردا می‌بینمت.</span>
              <button className="btn-ghost !py-1 !text-xs" onClick={() => setDay(dayKey, { closed: false })}>
                <LockOpen size={14} /> بازگشایی روز برای ویرایش
              </button>
            </div>
          )}
        </div>
      </div>

      {/* quick actions */}
      {!ro && (
        <div className="anim-fade-up-1 flex flex-wrap gap-2">
          <button className="btn-ghost !text-xs" onClick={carryYesterday}>
            <ArrowRightLeft size={14} /> انتقال ناتمام‌های دیروز
          </button>
          <button className="btn-ghost !text-xs" onClick={buildTomorrowTasks}>
            <Send size={14} /> ساخت تسک‌های فردا
          </button>
          <button className="btn-ghost !text-xs" onClick={() => props.go("backlog")}>
            <Inbox size={14} /> رفتن به بک‌لاگ
          </button>
        </div>
      )}

      {/* ===== morning / base info ===== */}
      <Section
        title="اطلاعات پایه روز"
        desc="حال، انرژی و هدف امروز"
        icon={<Sun size={18} />}
        className="anim-fade-up-1"
      >
        <div className="mb-3">
          <label className="lbl flex items-center gap-1"><Target size={13} /> مهم‌ترین هدف امروز (فقط یکی!)</label>
          <input
            className="input font-bold"
            disabled={ro}
            placeholder="مثلاً: تمام کردن فصل ۴ کتاب…"
            value={day.mainGoal}
            onChange={(e) => setDay(dayKey, { mainGoal: e.target.value })}
          />
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div>
            <label className="lbl">ساعت بیداری</label>
            <input type="time" className="input" disabled={ro} value={day.wakeUp} onChange={(e) => setDay(dayKey, { wakeUp: e.target.value })} />
          </div>
          <div>
            <label className="lbl">ساعت خواب (دیشب)</label>
            <input type="time" className="input" disabled={ro} value={day.sleep} onChange={(e) => setDay(dayKey, { sleep: e.target.value })} />
          </div>
          <div>
            <label className="lbl flex items-center gap-1"><Weight size={13} /> وزن (کیلو)</label>
            <input className="input" disabled={ro} inputMode="decimal" placeholder="مثلاً ۷۰" value={day.weight} onChange={(e) => setDay(dayKey, { weight: e.target.value })} />
          </div>
          <div>
            <label className="lbl flex items-center gap-1"><Droplets size={13} /> آب (لیوان)</label>
            <div className="flex items-center gap-2">
              <button className="icon-btn border hairline" disabled={ro || day.water <= 0} onClick={() => setDay(dayKey, { water: Math.max(0, day.water - 1) })}>
                <Minus size={15} />
              </button>
              <span className="min-w-8 text-center text-lg font-black">{fa(day.water)}</span>
              <button className="icon-btn border hairline" disabled={ro} onClick={() => setDay(dayKey, { water: day.water + 1 })}>
                <Plus size={15} />
              </button>
            </div>
          </div>
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="lbl flex items-center gap-1"><Heart size={13} /> حالت امروز چطوره؟</label>
            <div className="flex flex-wrap gap-1.5">
              {MOODS.map((m) => (
                <button
                  key={m.emoji}
                  disabled={ro}
                  title={m.label}
                  onClick={() => setDay(dayKey, { mood: day.mood === m.emoji ? "" : m.emoji })}
                  className={`flex h-11 w-11 items-center justify-center rounded-xl border-2 text-xl transition-all hover:scale-110 ${day.mood === m.emoji ? "border-accent bg-accent-soft scale-110" : "hairline opacity-70 hover:opacity-100"}`}
                >
                  {m.emoji}
                </button>
              ))}
            </div>
            {day.mood && <p className="muted mt-1 text-xs">حال امروز: {MOODS.find((m) => m.emoji === day.mood)?.label}</p>}
          </div>
          <div>
            <label className="lbl">انرژی</label>
            <EnergyDots value={day.energy} disabled={ro} onChange={(v) => setDay(dayKey, { energy: v })} />
            <div className="mt-3 space-y-2">
              <label className="flex cursor-pointer items-center gap-2 text-sm font-bold">
                <input type="checkbox" className="chk" disabled={ro} checked={day.exercised} onChange={(e) => setDay(dayKey, { exercised: e.target.checked })} />
                <Dumbbell size={15} className="text-accent" /> ورزش کردم؟
              </label>
              {day.exercised && (
                <input className="input !text-xs" disabled={ro} placeholder="نوع ورزش… مثلاً دویدن ۳۰ دقیقه" value={day.exerciseType} onChange={(e) => setDay(dayKey, { exerciseType: e.target.value })} />
              )}
              <label className="flex cursor-pointer items-center gap-2 text-sm font-bold">
                <input type="checkbox" className="chk" disabled={ro} checked={day.wentOut} onChange={(e) => setDay(dayKey, { wentOut: e.target.checked })} />
                <MapPin size={15} className="text-accent" /> بیرون رفتم؟
              </label>
              {day.wentOut && (
                <input className="input !text-xs" disabled={ro} placeholder="کجا رفتی؟ مثلاً کافه، خرید" value={day.outWhere} onChange={(e) => setDay(dayKey, { outWhere: e.target.value })} />
              )}
            </div>
          </div>
        </div>
      </Section>

      {/* ===== habits ===== */}
      <Section
        title="عادت‌های روزانه"
        icon={<Check size={18} />}
        action={<button className="btn-ghost !py-1 !text-xs" onClick={() => props.go("settings")}>مدیریت عادت‌ها</button>}
        className="anim-fade-up-2"
      >
        {activeHabits.length === 0 ? (
          <Empty title="عادتی فعال نیست" desc="از بخش تنظیمات چند عادت بساز تا اینجا ردیابی بشن" />
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {activeHabits.map((h) => {
              const on = !!day.habits[h.id];
              return (
                <button
                  key={h.id}
                  disabled={ro}
                  onClick={() => setDay(dayKey, (d) => ({ ...d, habits: { ...d.habits, [h.id]: !d.habits[h.id] } }))}
                  className={`flex items-center gap-2 rounded-xl border-2 px-3 py-2.5 text-sm font-bold transition-all active:scale-[0.98] ${on ? "border-accent bg-accent-soft" : "hairline opacity-75 hover:opacity-100"}`}
                >
                  <span className="text-lg">{h.emoji}</span>
                  <span className="flex-1 text-right">{h.name}</span>
                  <span className={`flex h-5 w-5 items-center justify-center rounded-full text-[0.65rem] text-white ${on ? "bg-accent" : "bg-stone-300 dark:bg-slate-600"}`}>
                    {on && <Check size={12} strokeWidth={3} />}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </Section>

      {/* ===== tasks ===== */}
      <Section
        title="تسک‌های روز"
        desc="بگیر و بکش برای تغییر ترتیب • کلید N تسک جدید"
        icon={<ListTodo size={18} />}
        className="anim-fade-up-2"
        action={
          <Seg
            value={taskFilter}
            onChange={setTaskFilter}
            options={[
              { v: "all", label: `همه (${fa(day.tasks.length)})` },
              { v: "open", label: "باز" },
              { v: "done", label: "شده ✓" },
            ]}
          />
        }
      >
        {!ro && (
          <div className="mb-3 space-y-2">
            <div className="flex gap-2">
              <input
                ref={newInputRef}
                className="input"
                placeholder="کار جدید… + Enter"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addTask()}
              />
              <button className="btn-accent" onClick={addTask}>
                <Plus size={16} /> افزودن
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex gap-1">
                {PRIORITIES.map((p) => (
                  <button
                    key={p.v}
                    title={p.label}
                    onClick={() => setNewPrio(p.v)}
                    className={`chip cursor-pointer border-2 ${newPrio === p.v ? "" : "opacity-50 hover:opacity-90"}`}
                    style={newPrio === p.v ? { background: p.bg, color: p.color, borderColor: p.color } : undefined}
                  >
                    {p.short}
                  </button>
                ))}
              </div>
              <select className="input !w-auto !py-1 !text-xs" value={newCat} onChange={(e) => setNewCat(e.target.value)}>
                {store.categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <select className="input !w-auto !py-1 !text-xs" value={catFilter} onChange={(e) => setCatFilter(e.target.value)}>
                <option value="all">همه دسته‌ها</option>
                {store.categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>
        )}

        {visibleTasks.length === 0 ? (
          <Empty
            icon={<ListTodo size={30} />}
            title={day.tasks.length === 0 ? "هنوز تسکی نداری" : "موردی با این فیلتر نیست"}
            desc={day.tasks.length === 0 ? "یک کار کوچک بنویس و شروع کن؛ حرکت، انگیزه می‌سازد 🌱" : undefined}
          />
        ) : (
          <ul className="space-y-1.5">
            {visibleTasks.map((t) => {
              const p = prioOf(t.priority);
              return (
                <li
                  key={t.id}
                  draggable={!ro}
                  onDragStart={() => setDragId(t.id)}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setOverId(t.id);
                  }}
                  onDragEnd={() => {
                    setDragId(null);
                    setOverId(null);
                  }}
                  onDrop={(e) => {
                    e.preventDefault();
                    if (dragId) reorder(dragId, t.id);
                    setDragId(null);
                    setOverId(null);
                  }}
                  className={`group flex items-center gap-2 rounded-xl border px-2.5 py-2 transition-all hairline ${t.done ? "opacity-70" : ""} ${overId === t.id && dragId ? "border-accent bg-accent-soft" : ""} ${dragId === t.id ? "opacity-40" : ""}`}
                  style={{ borderRight: `3px solid ${p.color}` }}
                >
                  {!ro && (
                    <span className="muted cursor-grab opacity-40 hover:opacity-100" title="بگیر و بکش">
                      <GripVertical size={15} />
                    </span>
                  )}
                  <input
                    type="checkbox"
                    className="chk"
                    disabled={ro}
                    checked={t.done}
                    onChange={() =>
                      setDay(dayKey, (d) => ({
                        ...d,
                        tasks: d.tasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)),
                      }))
                    }
                  />
                  <div className="min-w-0 flex-1">
                    <p className={`truncate text-sm font-bold ${t.done ? "task-done-title" : ""}`}>{t.title}</p>
                    <div className="mt-0.5 flex flex-wrap items-center gap-1">
                      <span className="chip !px-1.5 !py-0 !text-[0.62rem]" style={{ background: p.bg, color: p.color }}>
                        {p.short}
                      </span>
                      <span className="chip !px-1.5 !py-0 !text-[0.62rem]" style={{ background: `${catColor(t.categoryId)}1a`, color: catColor(t.categoryId) }}>
                        {catName(t.categoryId)}
                      </span>
                      {t.plannedStart && (
                        <span className="muted flex items-center gap-0.5 text-[0.65rem]" dir="ltr">
                          <Clock size={10} /> {t.plannedStart}{t.plannedEnd ? `–${t.plannedEnd}` : ""}
                        </span>
                      )}
                      {t.actualMinutes ? <span className="muted text-[0.65rem]">{fa(t.actualMinutes)} دقیقه واقعی</span> : null}
                      {t.note && <StickyNote size={11} className="muted" />}
                    </div>
                  </div>
                  {!ro && (
                    <div className="flex shrink-0 items-center gap-0.5 opacity-100 sm:opacity-0 sm:group-hover:opacity-100">
                      <button className="icon-btn !h-8 !w-8" title="ویرایش" onClick={() => setEditing({ ...t })}>
                        <Pencil size={14} />
                      </button>
                      <button
                        className="icon-btn !h-8 !w-8"
                        title="انتقال به فردا"
                        onClick={() => {
                          setDay(dayKey, (d) => ({
                            ...d,
                            tasks: d.tasks.filter((x) => x.id !== t.id),
                            tomorrowTasks: [...d.tomorrowTasks, { id: uid(), title: t.title, done: false }],
                          }));
                          toast(`«${t.title}» به فردا منتقل شد`);
                        }}
                      >
                        <ArrowLeft size={14} />
                      </button>
                      <button
                        className="icon-btn !h-8 !w-8"
                        title="انتقال به بک‌لاگ"
                        onClick={() => {
                          api.update((s) => {
                            const d = s.days[dayKey];
                            if (d) d.tasks = d.tasks.filter((x) => x.id !== t.id);
                            s.backlog.unshift({
                              id: uid(),
                              title: t.title,
                              desc: t.note || "",
                              priority: t.priority,
                              categoryId: t.categoryId,
                              createdAt: dayKey,
                            });
                            return s;
                          });
                          toast("به بک‌لاگ منتقل شد");
                        }}
                      >
                        <Inbox size={14} />
                      </button>
                      <button className="icon-btn !h-8 !w-8 hover:!text-red-500" title="حذف" onClick={() => setDelTaskId(t.id)}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      {/* ===== schedule ===== */}
      <Section
        title="برنامه زمانی روز"
        desc="بلوک‌های زمانی‌ات را بچین — تسک‌های ساعتی هم اینجا دیده می‌شن"
        icon={<CalendarDays size={18} />}
        className="anim-fade-up-3"
      >
        {!ro && (
          <div className="mb-3 flex flex-col gap-2 sm:flex-row">
            <input className="input flex-1" placeholder="عنوان برنامه… مثلاً جلسه، مطالعه" value={slotTitle} onChange={(e) => setSlotTitle(e.target.value)} />
            <div className="flex items-center gap-2">
              <input type="time" className="input !w-28" value={slotStart} onChange={(e) => setSlotStart(e.target.value)} />
              <span className="muted text-xs">تا</span>
              <input type="time" className="input !w-28" value={slotEnd} onChange={(e) => setSlotEnd(e.target.value)} />
              <button className="btn-accent" onClick={addSlot}>
                <Plus size={15} />
              </button>
            </div>
          </div>
        )}
        {timeline.length === 0 ? (
          <Empty icon={<Clock size={30} />} title="برنامه‌ای ثبت نشده" desc="روزت را به بلوک‌های ۱–۲ ساعته تقسیم کن؛ مغز عاشق ساختار است 🧠" />
        ) : (
          <div className="relative space-y-0 pr-1">
            <div className="timeline-line absolute top-2 right-[27px] bottom-2 w-[2px]" />
            <div className="space-y-2">
              {timeline.map((it) => {
                const dur = it.end ? Math.max(0, timeToMin(it.end) - timeToMin(it.start)) : null;
                return (
                  <div key={it.id} className="relative flex items-start gap-3 pr-0">
                    <div className="z-10 flex w-14 shrink-0 flex-col items-center pt-1">
                      <span className="rounded-lg bg-accent-soft px-1.5 py-0.5 text-[0.68rem] font-black text-accent" dir="ltr">
                        {it.start}
                      </span>
                      {it.end && <span className="muted text-[0.62rem]" dir="ltr">{it.end}</span>}
                    </div>
                    <div className={`card-hover flex flex-1 items-center gap-2 rounded-xl border px-3 py-2 hairline ${it.kind === "task" && it.done ? "opacity-60" : ""}`}>
                      <span className={`h-8 w-1.5 shrink-0 rounded-full ${it.kind === "slot" ? "bg-accent" : ""}`} style={it.kind === "task" ? { background: "#8b5cf6" } : undefined} />
                      <div className="min-w-0 flex-1">
                        <p className={`truncate text-sm font-bold ${it.kind === "task" && it.done ? "task-done-title" : ""}`}>{it.title}</p>
                        <p className="muted text-[0.65rem]">
                          {it.kind === "slot" ? "بلوک زمانی" : "تسک ساعتی"}
                          {dur !== null && dur > 0 ? ` • ${fa(dur)} دقیقه` : ""}
                        </p>
                      </div>
                      {it.kind === "slot" && !ro && (
                        <button
                          className="icon-btn !h-7 !w-7 hover:!text-red-500"
                          onClick={() => setDay(dayKey, { schedule: day.schedule.filter((s) => s.id !== it.id) })}
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </Section>

      {/* ===== tomorrow ===== */}
      <Section
        title="برنامه فردا"
        desc="امشب بنویس، صبح آماده‌ای 🌙"
        icon={<MoonStar size={18} />}
        action={
          !ro && day.tomorrowTasks.length > 0 ? (
            <button className="btn-ghost !py-1 !text-xs" onClick={buildTomorrowTasks}>
              <Send size={13} /> ساخت تسک‌های فردا <ArrowLeft size={13} />
            </button>
          ) : undefined
        }
      >
        {!ro && (
          <div className="mb-2 flex gap-2">
            <input
              className="input"
              placeholder="فردا چه کارهایی؟ + Enter"
              value={tmTitle}
              onChange={(e) => setTmTitle(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addTomorrow()}
            />
            <button className="btn-accent" onClick={addTomorrow}>
              <Plus size={15} />
            </button>
          </div>
        )}
        {day.tomorrowTasks.length === 0 ? (
          <p className="muted py-2 text-center text-xs">هنوز برای فردا چیزی ننوشته‌ای — ۳ کار مهم فردا را از همین امشب مشخص کن ✨</p>
        ) : (
          <ul className="space-y-1.5">
            {day.tomorrowTasks.map((t) => (
              <li key={t.id} className="flex items-center gap-2 rounded-xl border px-2.5 py-1.5 hairline">
                <input
                  type="checkbox"
                  className="chk !h-4 !w-4"
                  disabled={ro}
                  checked={t.done}
                  onChange={() =>
                    setDay(dayKey, (d) => ({
                      ...d,
                      tomorrowTasks: d.tomorrowTasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)),
                    }))
                  }
                />
                <span className={`flex-1 text-sm ${t.done ? "task-done-title" : ""}`}>{t.title}</span>
                {!ro && (
                  <>
                    <button
                      className="icon-btn !h-7 !w-7"
                      title="انتقال به تسک‌های امروز"
                      onClick={() => {
                        setDay(dayKey, (d) => ({
                          ...d,
                          tomorrowTasks: d.tomorrowTasks.filter((x) => x.id !== t.id),
                          tasks: [...d.tasks, { id: uid(), title: t.title, done: false, priority: "q2" as Priority, categoryId: store.categories[0]?.id || "personal" }],
                        }));
                        toast("به تسک‌های امروز اضافه شد");
                      }}
                    >
                      <CirclePlus size={14} />
                    </button>
                    <button
                      className="icon-btn !h-7 !w-7 hover:!text-red-500"
                      onClick={() => setDay(dayKey, { tomorrowTasks: day.tomorrowTasks.filter((x) => x.id !== t.id) })}
                    >
                      <Trash2 size={13} />
                    </button>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
        <div className="mt-2">
          <textarea
            className="input min-h-14 !text-xs"
            disabled={ro}
            placeholder="یادداشت برای فردا… (مثلاً: صبح زود بیدار شو، لباس ورزش آماده است)"
            value={day.tomorrowNote}
            onChange={(e) => setDay(dayKey, { tomorrowNote: e.target.value })}
          />
        </div>
      </Section>

      {/* ===== reflection ===== */}
      <Section
        title="یادداشت و گزارش پایان روز"
        desc="شب، روزت را مرور و ببند 📝"
        icon={<NotebookPen size={18} />}
      >
        <div className="grid gap-3 sm:grid-cols-3">
          {(
            [
              ["good1", "چیز خوب ۱", "جلسه عالی بود…"],
              ["good2", "چیز خوب ۲", "ورزش کردم…"],
              ["good3", "چیز خوب ۳", "…"],
            ] as const
          ).map(([k, l, ph]) => (
            <div key={k}>
              <label className="lbl">✨ {l}</label>
              <input className="input !text-xs" disabled={ro} placeholder={ph} value={day[k]} onChange={(e) => setDay(dayKey, { [k]: e.target.value } as Partial<DayData>)} />
            </div>
          ))}
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="lbl">🔧 یک چیز قابل بهبود</label>
            <input className="input !text-xs" disabled={ro} placeholder="چه چیزی می‌توانست بهتر باشد؟" value={day.improve} onChange={(e) => setDay(dayKey, { improve: e.target.value })} />
          </div>
          <div>
            <label className="lbl">📖 درس امروز</label>
            <input className="input !text-xs" disabled={ro} placeholder="یک جمله‌ای که امروز یاد گرفتی…" value={day.lesson} onChange={(e) => setDay(dayKey, { lesson: e.target.value })} />
          </div>
        </div>
        <div className="mt-3">
          <label className="lbl">🙏 سه خط قدردانی</label>
          <input className="input !text-xs" disabled={ro} placeholder="بابت چی شکرگزاری؟" value={day.gratitude} onChange={(e) => setDay(dayKey, { gratitude: e.target.value })} />
        </div>
        <div className="mt-3">
          <label className="lbl">یادداشت‌های طول روز</label>
          <textarea
            className="input min-h-16 !text-xs"
            disabled={ro}
            placeholder="ایده‌ها، اتفاق‌ها، حرف‌های نگفته…"
            value={day.note}
            onChange={(e) => setDay(dayKey, { note: e.target.value })}
          />
        </div>
        <div className="mt-3">
          <label className="lbl">🌙 گزارش پایان روز</label>
          <textarea
            className="input min-h-16 !text-xs"
            disabled={ro}
            placeholder="امروز چی شد؟ چی یاد گرفتی؟ فردا چی را بهتر می‌کنی؟"
            value={day.endReport}
            onChange={(e) => setDay(dayKey, { endReport: e.target.value })}
          />
        </div>
        <div className="mt-4 grid gap-4 rounded-2xl border p-4 hairline sm:grid-cols-2">
          <div>
            <label className="lbl flex items-center gap-1"><Star size={13} /> امتیاز امروز</label>
            <ScoreInput value={day.score} disabled={ro} onChange={(v) => setDay(dayKey, { score: v })} />
          </div>
          <div className="flex flex-col justify-end gap-2">
            <div className="flex flex-wrap gap-2">
              <button className="btn-ghost !text-xs" onClick={copySummary}>
                <Copy size={14} /> کپی خلاصه روز
              </button>
              {!closed ? (
                <button className="btn-accent !text-xs" onClick={() => setCloseAsk(true)}>
                  <Lock size={14} /> بستن و پایان روز
                </button>
              ) : (
                <button className="btn-ghost !text-xs" onClick={() => setDay(dayKey, { closed: false })}>
                  <LockOpen size={14} /> بازگشایی روز
                </button>
              )}
            </div>
            <p className="muted text-[0.68rem] leading-5">
              💡 جریان پیشنهادی: صبح هدف و ساعت بیداری را ثبت کن ← طول روز تسک و عادت بزن ← شب بازتاب بنویس، امتیاز بده و روز را ببند.
            </p>
          </div>
        </div>
      </Section>

      {/* ===== task edit modal ===== */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title="ویرایش تسک">
        {editing && (
          <div className="space-y-3">
            <div>
              <label className="lbl">عنوان</label>
              <input className="input" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            </div>
            <div>
              <label className="lbl flex items-center gap-1"><Flag size={13} /> اولویت (ماتریس آیزنهاور)</label>
              <div className="grid grid-cols-2 gap-1.5">
                {PRIORITIES.map((p) => (
                  <button
                    key={p.v}
                    onClick={() => setEditing({ ...editing, priority: p.v })}
                    className={`rounded-xl border-2 px-2 py-1.5 text-right transition-all ${editing.priority === p.v ? "scale-[1.02]" : "opacity-60 hover:opacity-100"}`}
                    style={editing.priority === p.v ? { borderColor: p.color, background: p.bg } : undefined}
                  >
                    <span className="block text-xs font-black" style={{ color: p.color }}>{p.label}</span>
                    <span className="muted block text-[0.65rem]">{p.desc}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="lbl">دسته</label>
                <select className="input" value={editing.categoryId} onChange={(e) => setEditing({ ...editing, categoryId: e.target.value })}>
                  {store.categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="lbl flex items-center gap-1"><Timer size={13} /> دقایق واقعی</label>
                <input
                  type="number"
                  min={0}
                  className="input"
                  placeholder="دقیقه"
                  value={editing.actualMinutes ?? ""}
                  onChange={(e) => setEditing({ ...editing, actualMinutes: e.target.value ? Number(e.target.value) : undefined })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="lbl">شروع برنامه‌ریزی</label>
                <input type="time" className="input" value={editing.plannedStart || ""} onChange={(e) => setEditing({ ...editing, plannedStart: e.target.value || undefined })} />
              </div>
              <div>
                <label className="lbl">پایان برنامه‌ریزی</label>
                <input type="time" className="input" value={editing.plannedEnd || ""} onChange={(e) => setEditing({ ...editing, plannedEnd: e.target.value || undefined })} />
              </div>
            </div>
            <div>
              <label className="lbl">یادداشت کوتاه</label>
              <input className="input" placeholder="یادداشت کوتاه…" value={editing.note || ""} onChange={(e) => setEditing({ ...editing, note: e.target.value })} />
            </div>
            <div className="flex gap-2 pt-1">
              <button className="btn-ghost flex-1" onClick={() => setEditing(null)}>انصراف</button>
              <button
                className="btn-accent flex-1"
                onClick={() => {
                  if (!editing.title.trim()) {
                    toast("عنوان تسک را بنویس");
                    return;
                  }
                  setDay(dayKey, (d) => ({
                    ...d,
                    tasks: d.tasks.map((x) => (x.id === editing.id ? { ...editing, title: editing.title.trim() } : x)),
                  }));
                  setEditing(null);
                  toast("ویرایش شد");
                }}
              >
                <Check size={15} /> ذخیره
              </button>
            </div>
          </div>
        )}
      </Modal>

      <Confirm
        open={closeAsk}
        title="بستن و پایان روز؟"
        desc="روز بسته می‌شود و برای ویرایش باید دوباره بازش کنی. فردا می‌بینمت 🌙"
        confirmLabel="مطمئنم، ببندش"
        onCancel={() => setCloseAsk(false)}
        onConfirm={() => {
          setDay(dayKey, { closed: true });
          setCloseAsk(false);
          toast("روز بسته شد. فردا می‌بینمت 🌙");
        }}
      />
      <Confirm
        open={!!delTaskId}
        title="این تسک حذف شود؟"
        onCancel={() => setDelTaskId(null)}
        onConfirm={() => {
          setDay(dayKey, { tasks: day.tasks.filter((t) => t.id !== delTaskId) });
          setDelTaskId(null);
        }}
      />

      {/* meta strip */}
      <div className="muted flex items-center justify-center gap-3 pb-2 text-[0.68rem]">
        <span className="flex items-center gap-1"><Sun size={11} /> بیداری {day.wakeUp || "—"}</span>
        <span className="flex items-center gap-1"><BedDouble size={11} /> خواب {day.sleep || "—"}</span>
        <span className="flex items-center gap-1"><AlarmClock size={11} /> همه‌چیز خودکار ذخیره می‌شود</span>
      </div>
    </div>
  );
}
