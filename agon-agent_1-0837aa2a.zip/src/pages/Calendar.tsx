import { useMemo, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight } from "lucide-react";
import {
  addDays,
  fa,
  formatJalaliShort,
  jalaliOf,
  J_MONTHS,
  jalaaliMonthLength,
  monthGrid,
  pad2,
  toGregorian,
  todayKey,
  weekHeaderLabels,
} from "../lib/jalali";
import { dayProgress, isActiveDay, type StoreApi } from "../lib/store";
import { Section } from "../components/ui";

export default function CalendarPage(props: {
  api: StoreApi;
  goDay: (key: string) => void;
}) {
  const { api, goDay } = props;
  const { store } = api;
  const today = todayKey();
  const tj = jalaliOf(today);
  const [jy, setJy] = useState(tj.jy);
  const [jm, setJm] = useState(tj.jm);
  const [sel, setSel] = useState<string | null>(null);

  const weeks = useMemo(
    () => monthGrid(jy, jm, store.settings.weekStart),
    [jy, jm, store.settings.weekStart]
  );
  const headers = useMemo(
    () => weekHeaderLabels(store.settings.weekStart),
    [store.settings.weekStart]
  );

  const move = (d: number) => {
    let y = jy;
    let m = jm + d;
    while (m < 1) {
      m += 12;
      y -= 1;
    }
    while (m > 12) {
      m -= 12;
      y += 1;
    }
    setJy(y);
    setJm(m);
  };

  const colorOf = (key: string): string | null => {
    const d = store.days[key];
    if (!d || !isActiveDay(d, store.habits)) return null;
    if (d.closed || (d.score !== undefined && d.score >= 8)) return "#10b981";
    const p = dayProgress(d, store.habits);
    if (p >= 60) return "#10b981";
    if (p >= 35) return "#f59e0b";
    return "#f43f5e";
  };

  const selDay = sel ? store.days[sel] : undefined;

  const monthLen = jalaaliMonthLength(jy, jm);
  const activeCount = useMemo(() => {
    let n = 0;
    for (let d = 1; d <= monthLen; d++) {
      const g = toGregorian(jy, jm, d);
      const k = `${g.gy}-${pad2(g.gm)}-${pad2(g.gd)}`;
      const dd = store.days[k];
      if (dd && isActiveDay(dd, store.habits)) n++;
    }
    return n;
  }, [jy, jm, monthLen, store.days, store.habits]);

  const isCur = jy === tj.jy && jm === tj.jm;

  return (
    <div className="space-y-4">
      <Section
        title={`تقویم ${J_MONTHS[jm - 1]} ${fa(jy)}`}
        desc={`${fa(activeCount)} روز فعال از ${fa(monthLen)} روز • برای مشاهده روز، روی خانه‌اش بزن`}
        icon={<CalendarDays size={18} />}
        className="anim-fade-up"
        action={
          <div className="flex items-center gap-1.5">
            {!isCur && (
              <button className="btn-ghost !py-1 !text-xs" onClick={() => { setJy(tj.jy); setJm(tj.jm); }}>
                پرش به ماه جاری
              </button>
            )}
            <button className="icon-btn border hairline" onClick={() => move(-1)} title="ماه قبل">
              <ChevronRight size={17} />
            </button>
            <button className="icon-btn border hairline" onClick={() => move(1)} title="ماه بعد">
              <ChevronLeft size={17} />
            </button>
          </div>
        }
      >
        {/* weekday header */}
        <div className="mb-1 grid grid-cols-7 gap-1 text-center">
          {headers.map((h, i) => (
            <span key={h + i} className={`py-1 text-[0.7rem] font-black ${i === 6 ? "text-red-500" : "muted"}`}>
              {h}
            </span>
          ))}
        </div>
        <div className="space-y-1">
          {weeks.map((w, wi) => (
            <div key={wi} className="grid grid-cols-7 gap-1">
              {w.map((c) => {
                const col = colorOf(c.key);
                const isToday = c.key === today;
                const isSel = sel === c.key;
                const fri = new Date(c.key + "T12:00:00").getDay() === 5;
                return (
                  <button
                    key={c.key}
                    onClick={() => setSel(isSel ? null : c.key)}
                    onDoubleClick={() => goDay(c.key)}
                    title={formatJalaliShort(c.key)}
                    className={`relative flex min-h-14 flex-col items-center justify-center rounded-xl border p-1 transition-all hover:scale-[1.03] sm:min-h-16 ${
                      isSel ? "border-accent" : "hairline"
                    } ${c.inMonth ? "" : "opacity-40"} ${isToday ? "bg-accent-soft" : ""}`}
                    style={isSel ? { boxShadow: "0 0 0 2px var(--accent-soft)" } : undefined}
                  >
                    <span className={`text-sm font-black sm:text-base ${fri && c.inMonth ? "text-red-500" : ""} ${isToday ? "text-accent" : ""}`}>
                      {fa(c.jd)}
                    </span>
                    {isToday && <span className="text-[0.58rem] font-black text-accent">امروز</span>}
                    {col ? (
                      <span className="mt-1 flex items-center gap-0.5">
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: col }} />
                        {store.days[c.key]?.closed && <span className="text-[0.55rem]">✓</span>}
                        {store.days[c.key]?.score !== undefined && (
                          <span className="muted text-[0.55rem]">{fa(store.days[c.key].score!)}</span>
                        )}
                      </span>
                    ) : (
                      <span className="mt-1 h-1.5" />
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        <div className="muted mt-3 flex flex-wrap items-center gap-3 text-[0.68rem]">
          <span className="font-black">راهنما:</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" /> عالی / بسته ✓</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" /> متوسط</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-rose-500" /> ضعیف</span>
          <span>دابل‌کلیک = باز کردن روز</span>
        </div>

        {sel && (
          <div className="anim-pop mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border p-3 hairline">
            {selDay && isActiveDay(selDay, store.habits) ? (
              <div className="text-xs">
                <span className="font-black">{formatJalaliShort(sel)}</span>
                <span className="muted mr-2">
                  پیشرفت {fa(dayProgress(selDay, store.habits))}٪ • {fa(selDay.tasks.filter((t) => t.done).length)} از {fa(selDay.tasks.length)} تسک
                  {selDay.score !== undefined ? ` • امتیاز ${fa(selDay.score)}` : ""}
                  {selDay.closed ? " • ✓ بسته" : ""}
                </span>
              </div>
            ) : (
              <span className="muted text-xs">این روز خالی است — {formatJalaliShort(sel)}</span>
            )}
            <button className="btn-accent !py-1.5 !text-xs" onClick={() => goDay(sel)}>
              {sel < today ? "مشاهده روز ←" : sel === today ? "رفتن به امروز ←" : "برنامه‌ریزی این روز ←"}
            </button>
          </div>
        )}

        {/* quick jump months */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {J_MONTHS.map((m, i) => (
            <button
              key={m}
              onClick={() => setJm(i + 1)}
              className={`rounded-lg px-2 py-1 text-[0.7rem] font-bold transition-all ${jm === i + 1 ? "bg-accent text-white" : "muted hover:bg-black/5 dark:hover:bg-white/5"}`}
            >
              {m}
            </button>
          ))}
          <div className="mr-auto flex items-center gap-1">
            <button className="icon-btn border hairline !h-7 !w-7" onClick={() => setJy(jy - 1)}>−</button>
            <span className="min-w-12 text-center text-xs font-black">{fa(jy)}</span>
            <button className="icon-btn border hairline !h-7 !w-7" onClick={() => setJy(jy + 1)}>+</button>
          </div>
        </div>

        <p className="muted mt-2 text-center text-[0.65rem]">
          نکته: برای رفتن به فردا یا دیروز، از دکمه‌های «روز قبل/بعد» در صفحه روز استفاده کن — یا {formatJalaliShort(addDays(today, 1))} را اینجا لمس کن.
        </p>
      </Section>
    </div>
  );
}
