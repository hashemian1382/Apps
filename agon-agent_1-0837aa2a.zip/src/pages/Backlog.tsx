import { useMemo, useState } from "react";
import {
  CalendarPlus,
  Inbox,
  LayoutGrid,
  List,
  Pencil,
  Plus,
  Search,
  Sun,
  Trash2,
} from "lucide-react";
import { addDays, fa, formatJalaliShort, todayKey } from "../lib/jalali";
import {
  PRIORITIES,
  prioOf,
  uid,
  type BacklogItem,
  type Priority,
  type StoreApi,
} from "../lib/store";
import { Confirm, Empty, Modal, Section } from "../components/ui";

type View = "list" | "matrix";
type Sort = "prio" | "new" | "deadline";

const PRIO_ORDER: Record<Priority, number> = { q1: 0, q2: 1, q3: 2, q4: 3 };

export default function BacklogPage(props: {
  api: StoreApi;
  goDay: (key: string) => void;
}) {
  const { api, goDay } = props;
  const { store, toast } = api;
  const today = todayKey();

  const [view, setView] = useState<View>("list");
  const [q, setQ] = useState("");
  const [prioFilter, setPrioFilter] = useState<"all" | Priority>("all");
  const [catFilter, setCatFilter] = useState("all");
  const [sort, setSort] = useState<Sort>("prio");

  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [prio, setPrio] = useState<Priority>("q2");
  const [cat, setCat] = useState(store.categories[0]?.id || "personal");
  const [deadline, setDeadline] = useState("");

  const [editing, setEditing] = useState<BacklogItem | null>(null);
  const [delId, setDelId] = useState<string | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overQ, setOverQ] = useState<Priority | null>(null);

  const catName = (id: string) =>
    store.categories.find((c) => c.id === id)?.name || "بدون دسته";
  const catColor = (id: string) =>
    store.categories.find((c) => c.id === id)?.color || "#8b5cf6";

  const counts = useMemo(() => {
    const c: Record<Priority, number> = { q1: 0, q2: 0, q3: 0, q4: 0 };
    store.backlog.forEach((b) => {
      c[b.priority] = (c[b.priority] || 0) + 1;
    });
    return c;
  }, [store.backlog]);

  const filtered = useMemo(() => {
    const needle = q.trim();
    let list = store.backlog.filter((b) => {
      if (prioFilter !== "all" && b.priority !== prioFilter) return false;
      if (catFilter !== "all" && b.categoryId !== catFilter) return false;
      if (needle && !(b.title.includes(needle) || (b.desc || "").includes(needle)))
        return false;
      return true;
    });
    list = [...list].sort((a, b) => {
      if (sort === "prio") return PRIO_ORDER[a.priority] - PRIO_ORDER[b.priority];
      if (sort === "deadline")
        return (a.deadline || "9999") < (b.deadline || "9999") ? -1 : 1;
      return b.createdAt.localeCompare(a.createdAt);
    });
    return list;
  }, [store.backlog, q, prioFilter, catFilter, sort]);

  const addItem = () => {
    const t = title.trim();
    if (!t) {
      toast("عنوان کار را بنویس");
      return;
    }
    api.update((s) => {
      s.backlog.unshift({
        id: uid(),
        title: t,
        desc: desc.trim(),
        priority: prio,
        categoryId: cat,
        deadline: deadline || undefined,
        createdAt: today,
      });
      return s;
    });
    setTitle("");
    setDesc("");
    setDeadline("");
    toast("به بک‌لاگ اضافه شد");
  };

  const moveToToday = (b: BacklogItem) => {
    api.update((s) => {
      const d = s.days[today] || {
        date: today, mainGoal: "", wakeUp: "", sleep: "", mood: "", energy: 3,
        water: 0, weight: "", exercised: false, exerciseType: "", wentOut: false,
        outWhere: "", note: "", gratitude: "", good1: "", good2: "", good3: "",
        improve: "", lesson: "", endReport: "", closed: false, tasks: [],
        schedule: [], habits: {}, tomorrowTasks: [], tomorrowNote: "",
      };
      const exists = d.tasks.some((t) => t.title.trim() === b.title.trim());
      if (!exists)
        d.tasks.push({ id: uid(), title: b.title, done: false, priority: b.priority, categoryId: b.categoryId, note: b.desc || undefined });
      s.days[today] = d;
      s.backlog = s.backlog.filter((x) => x.id !== b.id);
      return s;
    });
    toast("به تسک‌های امروز منتقل شد");
    goDay(today);
  };

  const planTomorrow = (b: BacklogItem) => {
    const nk = addDays(today, 1);
    api.update((s) => {
      const d = s.days[nk] || {
        date: nk, mainGoal: "", wakeUp: "", sleep: "", mood: "", energy: 3,
        water: 0, weight: "", exercised: false, exerciseType: "", wentOut: false,
        outWhere: "", note: "", gratitude: "", good1: "", good2: "", good3: "",
        improve: "", lesson: "", endReport: "", closed: false, tasks: [],
        schedule: [], habits: {}, tomorrowTasks: [], tomorrowNote: "",
      };
      const exists = d.tomorrowTasks.some((t) => t.title.trim() === b.title.trim());
      if (!exists) d.tomorrowTasks.push({ id: uid(), title: b.title, done: false });
      s.days[nk] = d;
      return s;
    });
    toast("برای فردا برنامه‌ریزی شد");
  };

  const setPrioOf = (id: string, p: Priority) => {
    api.update((s) => {
      const b = s.backlog.find((x) => x.id === id);
      if (b) b.priority = p;
      return s;
    });
  };

  const renderCard = (b: BacklogItem) => {
    const p = prioOf(b.priority);
    const overdue = b.deadline && b.deadline < today;
    return (
      <div
        key={b.id}
        draggable
        onDragStart={() => setDragId(b.id)}
        onDragEnd={() => {
          setDragId(null);
          setOverQ(null);
        }}
        className={`card-hover rounded-2xl border bg-white/60 p-3 dark:bg-white/[0.03] hairline ${dragId === b.id ? "opacity-40" : ""}`}
        style={{ borderRight: `3px solid ${p.color}` }}
      >
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm leading-6 font-bold">{b.title}</p>
          <div className="flex shrink-0 items-center">
            <button className="icon-btn !h-7 !w-7" title="ویرایش" onClick={() => setEditing({ ...b })}>
              <Pencil size={13} />
            </button>
            <button className="icon-btn !h-7 !w-7 hover:!text-red-500" title="حذف" onClick={() => setDelId(b.id)}>
              <Trash2 size={13} />
            </button>
          </div>
        </div>
        {b.desc && <p className="muted mt-0.5 line-clamp-2 text-xs leading-5">{b.desc}</p>}
        <div className="mt-2 flex flex-wrap items-center gap-1">
          <span className="chip !text-[0.62rem]" style={{ background: p.bg, color: p.color }}>
            {p.short}
          </span>
          <span className="chip !text-[0.62rem]" style={{ background: `${catColor(b.categoryId)}1a`, color: catColor(b.categoryId) }}>
            {catName(b.categoryId)}
          </span>
          {b.deadline && (
            <span
              className="chip !text-[0.62rem]"
              style={overdue ? { background: "rgba(220,38,38,.12)", color: "#dc2626" } : { background: "rgba(120,110,90,.1)", color: "inherit" }}
            >
              ددلاین: {formatJalaliShort(b.deadline)}
              {overdue ? " ⚠️" : ""}
            </span>
          )}
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          <button className="btn-ghost !px-2 !py-1 !text-[0.7rem]" onClick={() => moveToToday(b)}>
            <Sun size={12} /> به امروز
          </button>
          <button className="btn-ghost !px-2 !py-1 !text-[0.7rem]" onClick={() => planTomorrow(b)}>
            <CalendarPlus size={12} /> فردا
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="card anim-fade-up p-4 sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="bg-accent-soft text-accent flex h-10 w-10 items-center justify-center rounded-xl">
              <Inbox size={20} />
            </span>
            <div>
              <h1 className="text-lg font-black">بک‌لاگ <span className="text-accent">({fa(store.backlog.length)} کار باز)</span></h1>
              <p className="muted mt-0.5 text-xs">مخزن همه کارهایی که باید روزی انجام شوند — با ماتریس آیزنهاور اولویت بده</p>
            </div>
          </div>
          <div className="seg no-print">
            <button className={view === "list" ? "on" : ""} onClick={() => setView("list")}>
              <span className="flex items-center gap-1"><List size={13} /> لیستی</span>
            </button>
            <button className={view === "matrix" ? "on" : ""} onClick={() => setView("matrix")}>
              <span className="flex items-center gap-1"><LayoutGrid size={13} /> ماتریس آیزنهاور</span>
            </button>
          </div>
        </div>

        {/* quadrant mini stats */}
        <div className="mt-3 grid grid-cols-2 gap-1.5 sm:grid-cols-4">
          {PRIORITIES.map((p) => (
            <button
              key={p.v}
              onClick={() => {
                setPrioFilter(prioFilter === p.v ? "all" : p.v);
                setView("list");
              }}
              className="rounded-xl border px-2 py-1.5 text-right transition-transform hover:scale-[1.02] hairline"
              style={{ background: p.bg }}
            >
              <span className="block text-xs font-black" style={{ color: p.color }}>
                {p.label} • {fa(counts[p.v])}
              </span>
              <span className="muted block text-[0.65rem]">{p.desc}</span>
            </button>
          ))}
        </div>

        {/* quick add */}
        <div className="mt-3 rounded-2xl border p-3 hairline">
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              className="input flex-1"
              placeholder="عنوان کار… مثلاً: تمدید بیمه ماشین (Enter)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addItem()}
            />
            <button className="btn-accent" onClick={addItem}>
              <Plus size={16} /> افزودن
            </button>
          </div>
          <div className="mt-2 flex flex-col gap-2 sm:flex-row sm:items-center">
            <input
              className="input flex-1 !text-xs"
              placeholder="توضیح کوتاه (اختیاری)…"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addItem()}
            />
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex gap-1">
                {PRIORITIES.map((p) => (
                  <button
                    key={p.v}
                    title={p.label}
                    onClick={() => setPrio(p.v)}
                    className={`chip cursor-pointer border-2 ${prio === p.v ? "" : "opacity-50 hover:opacity-90"}`}
                    style={prio === p.v ? { background: p.bg, color: p.color, borderColor: p.color } : undefined}
                  >
                    {p.short}
                  </button>
                ))}
              </div>
              <select className="input !w-auto !py-1.5 !text-xs" value={cat} onChange={(e) => setCat(e.target.value)}>
                {store.categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <input
                type="date"
                className="input !w-auto !py-1.5 !text-xs"
                title="ددلاین (اختیاری)"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* filters */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-40">
            <Search size={15} className="muted absolute top-1/2 right-3 -translate-y-1/2" />
            <input
              className="input !pr-9 !text-xs"
              placeholder="جستجو در عنوان و توضیح…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <select className="input !w-auto !py-1.5 !text-xs" value={prioFilter} onChange={(e) => setPrioFilter(e.target.value as "all" | Priority)}>
            <option value="all">همه اولویت‌ها</option>
            {PRIORITIES.map((p) => (
              <option key={p.v} value={p.v}>{p.label}</option>
            ))}
          </select>
          <select className="input !w-auto !py-1.5 !text-xs" value={catFilter} onChange={(e) => setCatFilter(e.target.value)}>
            <option value="all">همه دسته‌ها</option>
            {store.categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <select className="input !w-auto !py-1.5 !text-xs" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
            <option value="prio">مرتب: اولویت</option>
            <option value="new">مرتب: جدیدترین</option>
            <option value="deadline">مرتب: ددلاین</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Section title="بک‌لاگ" icon={<Inbox size={18} />}>
          <Empty
            icon={<Inbox size={32} />}
            title={store.backlog.length === 0 ? "چیزی اینجا نیست 🎉" : "چیزی پیدا نشد"}
            desc={store.backlog.length === 0 ? "ذهنت را خالی کن: اولین کار بک‌لاگ را بالا اضافه کن" : "فیلترها را عوض کن"}
          />
        </Section>
      ) : view === "list" ? (
        <div className="anim-fade-up-1 grid gap-2 sm:grid-cols-2">
          {filtered.map(renderCard)}
        </div>
      ) : (
        <div className="anim-fade-up-1 grid gap-2 sm:grid-cols-2">
          {PRIORITIES.map((p) => {
            const items = filtered.filter((b) => b.priority === p.v);
            return (
              <div
                key={p.v}
                onDragOver={(e) => {
                  e.preventDefault();
                  setOverQ(p.v);
                }}
                onDragLeave={() => setOverQ(null)}
                onDrop={(e) => {
                  e.preventDefault();
                  if (dragId) {
                    setPrioOf(dragId, p.v);
                    toast(`به «${p.label}» منتقل شد`);
                  }
                  setDragId(null);
                  setOverQ(null);
                }}
                className={`rounded-2xl border-2 p-3 transition-all ${overQ === p.v ? "border-accent scale-[1.01]" : "hairline"}`}
                style={{ background: `${p.color}08` }}
              >
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="text-sm font-black" style={{ color: p.color }}>
                    {p.v === "q1" ? "۱. " : p.v === "q2" ? "۲. " : p.v === "q3" ? "۳. " : "۴. "}
                    {p.label}
                  </h3>
                  <span className="chip" style={{ background: p.bg, color: p.color }}>
                    {fa(items.length)} مورد
                  </span>
                </div>
                <p className="muted mb-2 text-[0.68rem]">{p.desc}</p>
                {items.length === 0 ? (
                  <p className="muted rounded-xl border border-dashed py-4 text-center text-xs hairline">
                    خالی — آیتم بکش اینجا
                  </p>
                ) : (
                  <div className="space-y-2">{items.map(renderCard)}</div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <p className="muted text-center text-[0.68rem]">
        💡 راهنما: آیتم‌ها را بین خانه‌های ماتریس بکش تا اولویت‌شان عوض شود • «به امروز» آیتم را به تسک‌های امروز می‌برد • «فردا» برای برنامه فردا نگهش می‌دارد
      </p>

      {/* edit modal */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title="ویرایش بک‌لاگ">
        {editing && (
          <div className="space-y-3">
            <div>
              <label className="lbl">عنوان</label>
              <input className="input" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            </div>
            <div>
              <label className="lbl">توضیح</label>
              <textarea className="input min-h-16" value={editing.desc} onChange={(e) => setEditing({ ...editing, desc: e.target.value })} />
            </div>
            <div>
              <label className="lbl">اولویت</label>
              <div className="grid grid-cols-2 gap-1.5">
                {PRIORITIES.map((p) => (
                  <button
                    key={p.v}
                    onClick={() => setEditing({ ...editing, priority: p.v })}
                    className={`rounded-xl border-2 px-2 py-1.5 text-right ${editing.priority === p.v ? "" : "opacity-60 hover:opacity-100"}`}
                    style={editing.priority === p.v ? { borderColor: p.color, background: p.bg } : undefined}
                  >
                    <span className="block text-xs font-black" style={{ color: p.color }}>{p.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="lbl">دسته</label>
                <select className="input" value={editing.categoryId} onChange={(e) => setEditing({ ...editing, categoryId: e.target.value })}>
                  {store.categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="lbl">ددلاین</label>
                <input type="date" className="input" value={editing.deadline || ""} onChange={(e) => setEditing({ ...editing, deadline: e.target.value || undefined })} />
              </div>
            </div>
            <div className="flex gap-2">
              <button className="btn-ghost flex-1" onClick={() => setEditing(null)}>انصراف</button>
              <button
                className="btn-accent flex-1"
                onClick={() => {
                  if (!editing.title.trim()) {
                    toast("عنوان کار را بنویس");
                    return;
                  }
                  api.update((s) => {
                    const i = s.backlog.findIndex((x) => x.id === editing.id);
                    if (i >= 0) s.backlog[i] = { ...editing, title: editing.title.trim() };
                    return s;
                  });
                  setEditing(null);
                  toast("ویرایش شد");
                }}
              >
                ذخیره
              </button>
            </div>
          </div>
        )}
      </Modal>

      <Confirm
        open={!!delId}
        title="از بک‌لاگ حذف شود؟"
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          api.update((s) => {
            s.backlog = s.backlog.filter((x) => x.id !== delId);
            return s;
          });
          setDelId(null);
        }}
      />
    </div>
  );
}
