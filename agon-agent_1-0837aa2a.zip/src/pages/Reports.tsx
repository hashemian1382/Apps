import { useMemo, useState } from "react";
import {
  BarChart3,
  CalendarDays,
  Droplets,
  Dumbbell,
  Flame,
  Star,
  Target,
  Trophy,
  TrendingUp,
  TriangleAlert,
} from "lucide-react";
import {
  addDays,
  fa,
  formatJalaliShort,
  jalaliOf,
  J_MONTHS,
  rangeKeys,
  todayKey,
} from "../lib/jalali";
import {
  avg,
  dayProgress,
  habitProgress,
  isActiveDay,
  streakCount,
  taskProgress,
  type StoreApi,
} from "../lib/store";
import { Bar, Empty, Section, Seg } from "../components/ui";

type Preset = "7" | "30" | "custom";

export default function ReportsPage(props: {
  api: StoreApi;
  goDay: (key: string) => void;
}) {
  const { api, goDay } = props;
  const { store } = api;
  const today = todayKey();
  const [preset, setPreset] = useState<Preset>("7");
  const [customStart, setCustomStart] = useState(addDays(today, -13));
  const [customEnd, setCustomEnd] = useState(today);
  const [selDay, setSelDay] = useState<string | null>(null);

  const start = preset === "7" ? addDays(today, -6) : preset === "30" ? addDays(today, -29) : customStart;
  const end = preset === "custom" ? customEnd : today;
  const keys = useMemo(
    () => (start <= end ? rangeKeys(start, end) : []),
    [start, end]
  );

  const rows = useMemo(
    () =>
      keys.map((k) => {
        const d = store.days[k];
        if (!d)
          return {
            key: k,
            active: false,
            progress: 0,
            tp: 0,
            hp: 0,
            score: undefined as number | undefined,
            tasksDone: 0,
            water: 0,
            exercised: false,
            closed: false,
          };
        return {
          key: k,
          active: isActiveDay(d, store.habits),
          progress: dayProgress(d, store.habits),
          tp: taskProgress(d),
          hp: habitProgress(d, store.habits),
          score: d.score,
          tasksDone: d.tasks.filter((t) => t.done).length,
          water: d.water,
          exercised: d.exercised,
          closed: d.closed,
        };
      }),
    [keys, store.days, store.habits]
  );

  const active = rows.filter((r) => r.active);
  const scores = rows.map((r) => r.score).filter((s): s is number => s !== undefined);
  const best = active.length ? [...active].sort((a, b) => b.progress - a.progress)[0] : null;
  const worst = active.length ? [...active].sort((a, b) => a.progress - b.progress)[0] : null;
  const bestScore = scores.length ? Math.max(...scores) : null;

  const kpis = [
    {
      icon: <TrendingUp size={17} />,
      label: "میانگین پیشرفت",
      value: active.length ? `${fa(Math.round(avg(active.map((r) => r.progress))))}٪` : "—",
      color: "var(--accent)",
      bg: "var(--accent-soft)",
    },
    {
      icon: <Target size={17} />,
      label: "میانگین تسک",
      value: active.length ? `${fa(Math.round(avg(active.map((r) => r.tp))))}٪` : "—",
      color: "#3b82f6",
      bg: "rgba(59,130,246,.12)",
    },
    {
      icon: <CalendarDays size={17} />,
      label: "میانگین عادت",
      value: active.length ? `${fa(Math.round(avg(active.map((r) => r.hp))))}٪` : "—",
      color: "#8b5cf6",
      bg: "rgba(139,92,246,.12)",
    },
    {
      icon: <Star size={17} />,
      label: "میانگین امتیاز",
      value: scores.length ? `${fa((avg(scores)).toFixed(1))}/۱۰` : "—",
      color: "#d97706",
      bg: "rgba(217,119,6,.12)",
    },
    {
      icon: <BarChart3 size={17} />,
      label: "تسک انجام‌شده",
      value: fa(active.reduce((a, r) => a + r.tasksDone, 0)),
      color: "#0d9488",
      bg: "rgba(13,148,136,.12)",
    },
    {
      icon: <Droplets size={17} />,
      label: "آب (مجموع)",
      value: active.length ? `${fa(active.reduce((a, r) => a + r.water, 0))} لیوان` : "—",
      color: "#2563eb",
      bg: "rgba(37,99,235,.1)",
    },
  ];

  // habits summary
  const habitRows = useMemo(
    () =>
      store.habits
        .filter((h) => h.active)
        .map((h) => {
          const daysWith = active.length;
          const done = active.filter((r) => store.days[r.key]?.habits[h.id]).length;
          return { ...h, pct: daysWith ? Math.round((done / daysWith) * 100) : 0, done, daysWith };
        })
        .sort((a, b) => b.pct - a.pct),
    [store.habits, store.days, active]
  );

  // category success
  const catStat = useMemo(() => {
    const map: Record<string, { done: number; total: number }> = {};
    active.forEach((r) => {
      const d = store.days[r.key];
      if (!d) return;
      d.tasks.forEach((t) => {
        map[t.categoryId] = map[t.categoryId] || { done: 0, total: 0 };
        map[t.categoryId].total++;
        if (t.done) map[t.categoryId].done++;
      });
    });
    const entries = Object.entries(map).sort(
      (a, b) => b[1].done / Math.max(1, b[1].total) - a[1].done / Math.max(1, a[1].total)
    );
    if (!entries.length) return null;
    const [id, v] = entries[0];
    const c = store.categories.find((x) => x.id === id);
    return { name: c?.name || "—", color: c?.color || "#8b5cf6", done: v.done, total: v.total };
  }, [active, store.days, store.categories]);

  // streaks
  const streaks = useMemo(
    () => [
      {
        label: "استریک روزهای فعال",
        value: streakCount(store.days, (d) => isActiveDay(d, store.habits)),
        color: "var(--accent)",
      },
      {
        label: "استریک تکمیل تسک‌ها",
        value: streakCount(store.days, (d) => d.tasks.length > 0 && d.tasks.every((t) => t.done)),
        color: "#3b82f6",
      },
      {
        label: "استریک همه عادت‌ها",
        value: streakCount(
          store.days,
          (d) => store.habits.filter((h) => h.active).length > 0 && store.habits.filter((h) => h.active).every((h) => d.habits[h.id])
        ),
        color: "#8b5cf6",
      },
      {
        label: "استریک بستن روز",
        value: streakCount(store.days, (d) => d.closed),
        color: "#d97706",
      },
      {
        label: "استریک ورزش",
        value: streakCount(store.days, (d) => d.exercised),
        color: "#f43f5e",
      },
    ],
    [store.days, store.habits]
  );

  // score trend points
  const scorePts = rows.filter((r) => r.score !== undefined);
  const maxBar = Math.max(1, ...rows.map((r) => r.tasksDone));

  const sel = selDay ? store.days[selDay] : undefined;

  return (
    <div className="space-y-4">
      <div className="card anim-fade-up p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="bg-accent-soft text-accent flex h-10 w-10 items-center justify-center rounded-xl">
              <BarChart3 size={20} />
            </span>
            <div>
              <h1 className="text-lg font-black">گزارش‌ها و عملکرد</h1>
              <p className="muted mt-0.5 text-xs">
                {active.length
                  ? `${fa(active.length)} روز ثبت‌شده در این بازه`
                  : "روند پیشرفتت را ببین"}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Seg
              value={preset}
              onChange={setPreset}
              options={[
                { v: "7", label: "۷ روز گذشته" },
                { v: "30", label: "۳۰ روز گذشته" },
                { v: "custom", label: "سفارشی" },
              ]}
            />
            {preset === "custom" && (
              <div className="flex items-center gap-1.5 text-xs">
                <input type="date" className="input !w-auto !py-1.5 !text-xs" value={customStart} max={customEnd} onChange={(e) => setCustomStart(e.target.value)} />
                <span className="muted">تا</span>
                <input type="date" className="input !w-auto !py-1.5 !text-xs" value={customEnd} min={customStart} max={today} onChange={(e) => setCustomEnd(e.target.value)} />
              </div>
            )}
          </div>
        </div>

        {/* KPIs */}
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
          {kpis.map((k) => (
            <div key={k.label} className="rounded-2xl border p-3 hairline" style={{ background: k.bg }}>
              <span style={{ color: k.color }}>{k.icon}</span>
              <p className="mt-1.5 text-base font-black">{k.value}</p>
              <p className="muted text-[0.68rem]">{k.label}</p>
            </div>
          ))}
        </div>
      </div>

      {active.length === 0 ? (
        <Section title="نمودارها" icon={<TrendingUp size={18} />}>
          <Empty
            icon={<BarChart3 size={32} />}
            title="در این بازه داده‌ای نیست"
            desc="چند روز را ثبت کن تا نمودار شکل بگیرد 🌱"
          />
        </Section>
      ) : (
        <>
          {/* daily progress bars */}
          <Section
            title="پیشرفت روزانه"
            desc="برای دیدن جزئیات هر روز، رویش بزن"
            icon={<BarChart3 size={18} />}
            className="anim-fade-up-1"
          >
            <div className="flex items-end gap-1 overflow-x-auto pb-1" dir="ltr">
              {rows.map((r) => {
                const j = jalaliOf(r.key);
                const isSel = selDay === r.key;
                return (
                  <button
                    key={r.key}
                    onClick={() => setSelDay(isSel ? null : r.key)}
                    className="flex min-w-9 flex-1 flex-col items-center gap-1 rounded-lg p-1 transition-all hover:bg-black/5 dark:hover:bg-white/5"
                    title={`${formatJalaliShort(r.key)} — ${fa(r.progress)}٪`}
                  >
                    <span className="text-[0.6rem] font-black">{r.active ? `${fa(r.progress)}` : "·"}</span>
                    <div className="flex h-28 w-full items-end justify-center rounded-lg bg-black/[0.05] dark:bg-white/[0.06]">
                      <div
                        className="w-full max-w-6 rounded-lg transition-all"
                        style={{
                          height: `${Math.max(r.active ? 6 : 2, r.progress)}%`,
                          background: isSel
                            ? "var(--accent)"
                            : r.progress >= 80
                              ? "#10b981"
                              : r.progress >= 50
                                ? "#f59e0b"
                                : r.active
                                  ? "#f43f5e"
                                  : "transparent",
                          outline: isSel ? "2px solid var(--accent)" : "none",
                          outlineOffset: 1,
                        }}
                      />
                    </div>
                    <span className="muted text-[0.6rem]">{fa(j.jd)}</span>
                  </button>
                );
              })}
            </div>
            {sel && selDay && (
              <div className="anim-pop mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border p-3 hairline">
                <div className="text-xs">
                  <span className="font-black">{formatJalaliShort(selDay)}</span>
                  <span className="muted mr-2">
                    پیشرفت {fa(dayProgress(sel, store.habits))}٪ • تسک {fa(sel.tasks.filter((t) => t.done).length)} از {fa(sel.tasks.length)}
                    {sel.score !== undefined ? ` • امتیاز ${fa(sel.score)}/۱۰` : ""}
                    {sel.exercised ? " • 🏃 ورزش" : ""}
                    {sel.closed ? " • ✓ بسته" : ""}
                  </span>
                </div>
                <button className="btn-ghost !py-1 !text-xs" onClick={() => goDay(selDay)}>
                  مشاهده روز ←
                </button>
              </div>
            )}
            {/* tasks done bars */}
            <div className="mt-4">
              <p className="lbl">تسک‌های انجام‌شده هر روز</p>
              <div className="flex items-end gap-1 overflow-x-auto" dir="ltr">
                {rows.map((r) => (
                  <div key={r.key} className="flex min-w-9 flex-1 flex-col items-center gap-1" title={`${formatJalaliShort(r.key)}: ${fa(r.tasksDone)} تسک`}>
                    <div className="flex h-14 w-full items-end justify-center rounded-lg bg-black/[0.05] dark:bg-white/[0.06]">
                      <div
                        className="w-full max-w-6 rounded-lg"
                        style={{
                          height: `${Math.max(3, (r.tasksDone / maxBar) * 100)}%`,
                          background: "#3b82f6",
                          opacity: r.active ? 1 : 0.15,
                        }}
                      />
                    </div>
                    <span className="muted text-[0.6rem]">{fa(r.tasksDone)}</span>
                  </div>
                ))}
              </div>
            </div>
          </Section>

          {/* score trend */}
          <Section title="روند نمره روزها" icon={<Star size={18} />} className="anim-fade-up-2">
            {scorePts.length < 2 ? (
              <p className="muted py-2 text-center text-xs">برای نمودار خطی حداقل ۲ روز نمره لازم است</p>
            ) : (
              <div dir="ltr">
                <svg viewBox="0 0 600 160" className="w-full" style={{ maxHeight: 200 }}>
                  {[2, 4, 6, 8, 10].map((g) => (
                    <g key={g}>
                      <line x1={0} y1={150 - g * 13} x2={600} y2={150 - g * 13} stroke="currentColor" strokeOpacity={0.08} />
                      <text x={4} y={150 - g * 13 - 3} fontSize={9} fill="currentColor" opacity={0.4}>
                        {g}
                      </text>
                    </g>
                  ))}
                  <polyline
                    fill="none"
                    stroke="var(--accent)"
                    strokeWidth={2.5}
                    strokeLinejoin="round"
                    strokeLinecap="round"
                    points={scorePts
                      .map((r, i) => {
                        const x = scorePts.length === 1 ? 300 : (i / (scorePts.length - 1)) * 580 + 10;
                        const y = 150 - (r.score || 0) * 13;
                        return `${x},${y}`;
                      })
                      .join(" ")}
                  />
                  {scorePts.map((r, i) => {
                    const x = scorePts.length === 1 ? 300 : (i / (scorePts.length - 1)) * 580 + 10;
                    const y = 150 - (r.score || 0) * 13;
                    return (
                      <g key={r.key}>
                        <circle cx={x} cy={y} r={5} fill="var(--accent)" stroke="#fff" strokeWidth={2}>
                          <title>{`${formatJalaliShort(r.key)}: ${r.score}/۱۰`}</title>
                        </circle>
                      </g>
                    );
                  })}
                </svg>
                <div className="muted mt-1 flex justify-between text-[0.65rem]" dir="rtl">
                  <span>{formatJalaliShort(scorePts[0].key)}</span>
                  <span>{formatJalaliShort(scorePts[scorePts.length - 1].key)}</span>
                </div>
              </div>
            )}
            {bestScore !== null && best && (
              <div className="mt-2 flex flex-wrap gap-2 text-xs">
                <span className="chip" style={{ background: "rgba(245,158,11,.14)", color: "#b45309" }}>
                  <Trophy size={12} /> بهترین روز این بازه: {formatJalaliShort(best.key)} با {fa(best.progress)}٪ پیشرفت
                </span>
                {worst && worst.key !== best.key && (
                  <span className="chip" style={{ background: "rgba(120,110,90,.12)", color: "inherit" }}>
                    <TriangleAlert size={12} /> نیازمند توجه: {formatJalaliShort(worst.key)} ({fa(worst.progress)}٪)
                  </span>
                )}
              </div>
            )}
          </Section>

          {/* habits + category + streaks */}
          <div className="grid gap-4 lg:grid-cols-2">
            <Section title="خلاصه عادت‌ها" desc="کدام عادت قوی‌تر است؟" icon={<Flame size={18} />} className="anim-fade-up-2">
              {habitRows.length === 0 ? (
                <p className="muted py-2 text-center text-xs">عادت فعالی نیست</p>
              ) : (
                <div className="space-y-2.5">
                  {habitRows.map((h) => (
                    <div key={h.id}>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="font-bold">
                          {h.emoji} {h.name}
                        </span>
                        <span className="muted">
                          {fa(h.done)}/{fa(h.daysWith)} روز • {fa(h.pct)}٪
                        </span>
                      </div>
                      <Bar value={h.pct} color={h.pct >= 70 ? "var(--accent)" : h.pct >= 40 ? "#f59e0b" : "#f43f5e"} />
                    </div>
                  ))}
                  <p className="rounded-xl bg-black/[0.04] p-2.5 text-[0.7rem] leading-5 dark:bg-white/[0.05]">
                    💡 نکته مربی: برای هفته آینده فقط روی ضعیف‌ترین عادت تمرکز کن؛ یک عادت، یک برد کوچک، هر روز.
                  </p>
                </div>
              )}
            </Section>

            <div className="space-y-4">
              <Section title="استریک‌ها — زنجیره تداوم" desc="استریک از امروز به عقب حساب می‌شود" icon={<Flame size={18} />} className="anim-fade-up-3">
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {streaks.map((s) => (
                    <div key={s.label} className="rounded-xl border p-2.5 text-center hairline">
                      <p className="text-xl font-black" style={{ color: s.color }}>
                        {fa(s.value)}
                      </p>
                      <p className="muted text-[0.65rem] leading-4">{s.label}</p>
                      <p className="muted text-[0.6rem]">روز متوالی</p>
                    </div>
                  ))}
                  <div className="rounded-xl border p-2.5 text-center hairline">
                    <p className="text-xl font-black text-accent">
                      <Dumbbell size={18} className="inline" />
                    </p>
                    <p className="muted mt-1 text-[0.65rem] leading-4">
                      روزهای ورزش این بازه: {fa(active.filter((r) => r.exercised).length)}
                    </p>
                  </div>
                </div>
              </Section>

              <Section title="بهترین / بدترین" icon={<Trophy size={18} />} className="anim-fade-up-3">
                {best ? (
                  <div className="space-y-2 text-xs">
                    <button onClick={() => goDay(best.key)} className="flex w-full items-center justify-between rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 transition-transform hover:scale-[1.01]">
                      <span className="font-black text-emerald-700 dark:text-emerald-300">
                        🏆 بهترین: {formatJalaliShort(best.key)} (پیشرفت {fa(best.progress)}٪)
                      </span>
                      <span className="text-emerald-700 dark:text-emerald-300">←</span>
                    </button>
                    {worst && worst.key !== best.key && (
                      <button onClick={() => goDay(worst.key)} className="flex w-full items-center justify-between rounded-xl border px-3 py-2 hairline transition-transform hover:scale-[1.01]">
                        <span className="font-bold">نیازمند توجه: {formatJalaliShort(worst.key)} (پیشرفت {fa(worst.progress)}٪)</span>
                        <span>←</span>
                      </button>
                    )}
                    {catStat && (
                      <p className="rounded-xl bg-black/[0.04] px-3 py-2 dark:bg-white/[0.05]">
                        پرتکرارترین دسته موفق: <b style={{ color: catStat.color }}>{catStat.name}</b> ({fa(catStat.done)} تسک موفق)
                      </p>
                    )}
                    <div className="muted">
                      میانگین بیداری این بازه: {(() => {
                        const ws = active.map((r) => store.days[r.key]?.wakeUp).filter(Boolean) as string[];
                        if (!ws.length) return "—";
                        const m = Math.round(ws.reduce((a, t) => a + Number(t.slice(0, 2)) * 60 + Number(t.slice(3)), 0) / ws.length);
                        return fa(`${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`);
                      })()}
                    </div>
                  </div>
                ) : (
                  <p className="muted text-xs">داده‌ای نیست</p>
                )}
              </Section>
            </div>
          </div>

          {/* month summary strip */}
          <Section
            title={`گزارش ماه ${J_MONTHS[jalaliOf(today).jm - 1]} ${fa(jalaliOf(today).jy)}`}
            icon={<CalendarDays size={18} />}
          >
            <MonthStrip goDay={goDay} />
          </Section>
        </>
      )}
    </div>
  );
}

function MonthStrip(props: { goDay: (k: string) => void }) {
  const today = todayKey();
  const j = jalaliOf(today);
  const keys = rangeKeys(addDays(today, -40), today).filter((k) => {
    const jj = jalaliOf(k);
    return jj.jy === j.jy && jj.jm === j.jm;
  });
  if (!keys.length) return <p className="muted text-xs">—</p>;
  return (
    <div className="flex flex-wrap gap-1.5">
      {keys.map((k) => {
        const jj = jalaliOf(k);
        return (
          <button
            key={k}
            onClick={() => props.goDay(k)}
            className={`flex h-10 w-10 flex-col items-center justify-center rounded-xl border text-xs font-black transition-transform hover:scale-105 hairline ${k === today ? "border-accent bg-accent-soft text-accent" : ""}`}
            title={formatJalaliShort(k)}
          >
            {fa(jj.jd)}
          </button>
        );
      })}
    </div>
  );
}
