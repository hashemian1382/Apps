import { useMemo, useRef, useState } from "react";
import {
  Bell,
  Database,
  Download,
  Eye,
  FolderKanban,
  Moon,
  Palette,
  Plus,
  Settings as SettingsIcon,
  Sparkles,
  Sun,
  Tags,
  Trash2,
  Upload,
  User,
  TriangleAlert,
} from "lucide-react";
import { fa } from "../lib/jalali";
import {
  ACCENTS,
  CAT_COLORS,
  emptyDay,
  LS_KEY,
  uid,
  type StoreApi,
} from "../lib/store";
import { Confirm, Empty, Modal, Section } from "../components/ui";

const EMOJIS = ["📚", "💧", "🧘", "🚶", "🏃", "✍️", "📖", "🎯", "💪", "🍬", "🥗", "😴", "🌅", "🎨", "🎵", "🧹", "💰", "📵", "🤝", "🌱"];

export default function SettingsPage(props: { api: StoreApi }) {
  const { api } = props;
  const { store, toast, storageKB } = api;

  const [catName, setCatName] = useState("");
  const [catColor, setCatColor] = useState(CAT_COLORS[0]);
  const [habitName, setHabitName] = useState("");
  const [habitEmoji, setHabitEmoji] = useState("🌱");
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [wipeStep, setWipeStep] = useState(0);
  const [demoAsk, setDemoAsk] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const dayCount = Object.keys(store.days).length;

  const exportJSON = () => {
    try {
      const raw = localStorage.getItem(LS_KEY) || JSON.stringify(store);
      const blob = new Blob([raw], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `roozino-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
      toast("فایل بکاپ دانلود شد");
    } catch {
      toast("خطا در ساخت بکاپ");
    }
  };

  const doImportText = (txt: string) => {
    try {
      const parsed = JSON.parse(txt);
      if (!parsed || typeof parsed !== "object" || (!parsed.days && !parsed.backlog && !parsed.settings)) {
        toast("فایل معتبر نیست");
        return false;
      }
      api.update((s) => {
        if (parsed.settings) s.settings = { ...s.settings, ...parsed.settings };
        if (Array.isArray(parsed.categories) && parsed.categories.length) s.categories = parsed.categories;
        if (Array.isArray(parsed.habits)) s.habits = parsed.habits;
        if (parsed.days && typeof parsed.days === "object") {
          for (const k of Object.keys(parsed.days)) {
            s.days[k] = { ...emptyDay(k), ...parsed.days[k], date: k };
          }
        }
        if (Array.isArray(parsed.backlog)) s.backlog = parsed.backlog;
        return s;
      });
      toast("بازیابی انجام شد ✓");
      return true;
    } catch {
      toast("فایل انتخاب‌شده معتبر نیست");
      return false;
    }
  };

  const onFile = (f: File | undefined) => {
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      if (typeof r.result === "string" && doImportText(r.result)) setImportOpen(false);
    };
    r.readAsText(f);
  };

  const preview = useMemo(() => {
    if (!importText.trim()) return null;
    try {
      const p = JSON.parse(importText);
      const dc = p.days ? Object.keys(p.days).length : 0;
      const bc = Array.isArray(p.backlog) ? p.backlog.length : 0;
      return `${fa(dc)} روز • ${fa(bc)} آیتم بک‌لاگ`;
    } catch {
      return "نامعتبر";
    }
  }, [importText]);

  const usedCats = useMemo(() => {
    const set = new Set<string>();
    Object.values(store.days).forEach((d) => d.tasks.forEach((t) => set.add(t.categoryId)));
    store.backlog.forEach((b) => set.add(b.categoryId));
    return set;
  }, [store.days, store.backlog]);

  return (
    <div className="space-y-4">
      {/* profile + appearance */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="پروفایل" desc="برنامه با نام تو صحبت می‌کند" icon={<User size={18} />} className="anim-fade-up">
          <label className="lbl">نام نمایشی</label>
          <input
            className="input"
            placeholder="اسمت چیه؟"
            value={store.settings.displayName}
            onChange={(e) =>
              api.update((s) => {
                s.settings.displayName = e.target.value;
                return s;
              })
            }
          />
          <div className="mt-3">
            <label className="lbl flex items-center gap-1"><Bell size={13} /> یادآور روزانه (فقط نمایشی)</label>
            <div className="flex gap-2">
              <input
                type="time"
                className="input"
                value={store.settings.reminderTime}
                onChange={(e) =>
                  api.update((s) => {
                    s.settings.reminderTime = e.target.value;
                    return s;
                  })
                }
              />
              <button
                className="btn-ghost shrink-0"
                onClick={() =>
                  toast(
                    store.settings.reminderTime
                      ? `یادآور روی ${fa(store.settings.reminderTime)} تنظیم شد (در این نسخه فقط ذخیره می‌شود)`
                      : "اول یک ساعت انتخاب کن"
                  )
                }
              >
                ثبت
              </button>
            </div>
            <p className="muted mt-1.5 text-[0.68rem] leading-5">
              اعلان واقعی مرورگر نیاز به باز بودن صفحه دارد؛ این ساعت فقط ذخیره می‌شود.
            </p>
          </div>
        </Section>

        <Section title="تنظیمات ظاهری" desc="تم، رنگ و اندازه فونت" icon={<Palette size={18} />} className="anim-fade-up-1">
          <label className="lbl">حالت نمایش</label>
          <div className="seg">
            <button className={store.settings.theme === "light" ? "on" : ""} onClick={() => api.update((s) => { s.settings.theme = "light"; return s; })}>
              <span className="flex items-center gap-1"><Sun size={13} /> روشن</span>
            </button>
            <button className={store.settings.theme === "dark" ? "on" : ""} onClick={() => api.update((s) => { s.settings.theme = "dark"; return s; })}>
              <span className="flex items-center gap-1"><Moon size={13} /> تیره</span>
            </button>
          </div>
          <label className="lbl mt-3">رنگ اصلی برنامه</label>
          <div className="flex flex-wrap gap-2">
            {ACCENTS.map((a) => (
              <button
                key={a.v}
                title={a.label}
                onClick={() => api.update((s) => { s.settings.accent = a.v; return s; })}
                className={`flex h-10 w-10 items-center justify-center rounded-xl text-white transition-transform hover:scale-110 ${store.settings.accent === a.v ? "ring-2 ring-offset-2" : "opacity-70 hover:opacity-100"}`}
                style={{ background: a.v, ["--tw-ring-color" as string]: a.v }}
              >
                {store.settings.accent === a.v ? "✓" : ""}
              </button>
            ))}
          </div>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {ACCENTS.map((a) => (
              <span key={a.v} className={`text-[0.65rem] ${store.settings.accent === a.v ? "font-black" : "muted"}`}>{a.label}</span>
            ))}
          </div>
          <label className="lbl mt-3">اندازه فونت</label>
          <div className="seg">
            <button className={store.settings.fontSize === "normal" ? "on" : ""} onClick={() => api.update((s) => { s.settings.fontSize = "normal"; return s; })}>
              معمولی
            </button>
            <button className={store.settings.fontSize === "large" ? "on" : ""} onClick={() => api.update((s) => { s.settings.fontSize = "large"; return s; })}>
              درشت‌تر
            </button>
          </div>
          <label className="lbl mt-3">شروع هفته در تقویم</label>
          <div className="seg">
            <button className={store.settings.weekStart === 6 ? "on" : ""} onClick={() => api.update((s) => { s.settings.weekStart = 6; return s; })}>
              شنبه
            </button>
            <button className={store.settings.weekStart === 0 ? "on" : ""} onClick={() => api.update((s) => { s.settings.weekStart = 0; return s; })}>
              یکشنبه
            </button>
            <button className={store.settings.weekStart === 1 ? "on" : ""} onClick={() => api.update((s) => { s.settings.weekStart = 1; return s; })}>
              دوشنبه
            </button>
          </div>
        </Section>
      </div>

      {/* categories + habits */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Section
          title="مدیریت دسته‌بندی‌ها"
          desc="دسته‌ها در تسک‌ها، بک‌لاگ و گزارش‌ها استفاده می‌شن"
          icon={<Tags size={18} />}
          className="anim-fade-up-1"
        >
          <div className="space-y-1.5">
            {store.categories.map((c) => {
              const used = usedCats.has(c.id) ? ` • ${fa(Object.values(store.days).reduce((a, d) => a + d.tasks.filter((t) => t.categoryId === c.id).length, 0) + store.backlog.filter((b) => b.categoryId === c.id).length)} استفاده` : "";
              return (
                <div key={c.id} className="flex items-center gap-2 rounded-xl border px-2.5 py-1.5 hairline">
                  <span className="h-4 w-4 shrink-0 rounded-full" style={{ background: c.color }} />
                  <span className="flex-1 text-sm font-bold">{c.name}<span className="muted text-[0.65rem]">{used}</span></span>
                  {store.categories.length > 1 && (
                    <button
                      className="icon-btn !h-7 !w-7 hover:!text-red-500"
                      title="حذف دسته"
                      onClick={() => {
                        if (!window.confirm(`دسته «${c.name}» حذف شود؟ تسک‌هایش بدون دسته می‌مانند.`)) return;
                        api.update((s) => {
                          s.categories = s.categories.filter((x) => x.id !== c.id);
                          return s;
                        });
                      }}
                    >
                      <Trash2 size={13} />
                    </button>
                  )}
                </div>
              );
            })}
            {store.categories.length === 0 && <Empty title="دسته‌ای نیست" />}
          </div>
          <div className="mt-2.5 flex gap-2">
            <input
              className="input flex-1 !text-xs"
              placeholder="نام دسته جدید…"
              value={catName}
              onChange={(e) => setCatName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && catName.trim()) {
                  api.update((s) => {
                    s.categories.push({ id: uid(), name: catName.trim(), color: catColor });
                    return s;
                  });
                  setCatName("");
                  toast("دسته اضافه شد");
                }
              }}
            />
            <div className="flex items-center gap-1">
              {CAT_COLORS.slice(0, 6).map((col) => (
                <button
                  key={col}
                  onClick={() => setCatColor(col)}
                  className={`h-6 w-6 rounded-full transition-transform hover:scale-110 ${catColor === col ? "ring-2 ring-offset-1" : "opacity-60"}`}
                  style={{ background: col }}
                />
              ))}
            </div>
            <button
              className="btn-accent !px-3"
              onClick={() => {
                if (!catName.trim()) {
                  toast("نام دسته را بنویس");
                  return;
                }
                api.update((s) => {
                  s.categories.push({ id: uid(), name: catName.trim(), color: catColor });
                  return s;
                });
                setCatName("");
                toast("دسته اضافه شد");
              }}
            >
              <Plus size={15} />
            </button>
          </div>
        </Section>

        <Section
          title="مدیریت عادت‌ها"
          desc="فقط عادت‌های فعال در صفحه روز ردیابی می‌شن"
          icon={<FolderKanban size={18} />}
          className="anim-fade-up-2"
        >
          <div className="space-y-1.5">
            {store.habits.map((h) => (
              <div key={h.id} className="flex items-center gap-2 rounded-xl border px-2.5 py-1.5 hairline">
                <span className="text-lg">{h.emoji}</span>
                <span className="flex-1 text-sm font-bold">{h.name}</span>
                <button
                  className={`chip cursor-pointer !text-[0.65rem] ${h.active ? "" : "opacity-60"}`}
                  style={h.active ? { background: "var(--accent-soft)", color: "var(--accent)" } : { background: "rgba(120,110,90,.12)" }}
                  onClick={() =>
                    api.update((s) => {
                      const x = s.habits.find((y) => y.id === h.id);
                      if (x) x.active = !x.active;
                      return s;
                    })
                  }
                >
                  {h.active ? "فعال" : "غیرفعال"}
                </button>
                <button
                  className="icon-btn !h-7 !w-7 hover:!text-red-500"
                  title="حذف عادت"
                  onClick={() => {
                    if (!window.confirm(`عادت «${h.name}» حذف شود؟`)) return;
                    api.update((s) => {
                      s.habits = s.habits.filter((x) => x.id !== h.id);
                      return s;
                    });
                  }}
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
            {store.habits.length === 0 && <Empty title="عادتی نیست" />}
          </div>
          <div className="mt-2.5 space-y-2">
            <div className="flex gap-2">
              <input
                className="input flex-1 !text-xs"
                placeholder="نام عادت جدید… مثلاً پیاده‌روی"
                value={habitName}
                onChange={(e) => setHabitName(e.target.value)}
              />
              <button
                className="btn-accent !px-3"
                onClick={() => {
                  if (!habitName.trim()) {
                    toast("نام عادت را بنویس");
                    return;
                  }
                  api.update((s) => {
                    s.habits.push({ id: uid(), name: habitName.trim(), emoji: habitEmoji, active: true });
                    return s;
                  });
                  setHabitName("");
                  toast("عادت جدید اضافه شد");
                }}
              >
                <Plus size={15} /> افزودن عادت
              </button>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="lbl !mb-0">ایموجی:</span>
              <div className="flex flex-wrap gap-1">
                {EMOJIS.map((e) => (
                  <button
                    key={e}
                    onClick={() => setHabitEmoji(e)}
                    className={`flex h-8 w-8 items-center justify-center rounded-lg text-base transition-all hover:scale-110 ${habitEmoji === e ? "bg-accent-soft ring-2" : "opacity-70 hover:opacity-100"}`}
                    style={habitEmoji === e ? ({ "--tw-ring-color": "var(--accent)" } as React.CSSProperties) : undefined}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Section>
      </div>

      {/* backup */}
      <Section
        title="پشتیبان‌گیری و بازیابی"
        desc="داده فقط روی همین مرورگر است — مراقبش باش"
        icon={<Database size={18} />}
        className="anim-fade-up-2"
      >
        <div className="muted mb-3 flex flex-wrap gap-x-4 gap-y-1 text-xs">
          <span>حجم داده ذخیره‌شده: <b>{fa(storageKB)} کیلوبایت</b></span>
          <span><b>{fa(dayCount)}</b> روز • <b>{fa(store.backlog.length)}</b> آیتم بک‌لاگ</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-accent !text-xs" onClick={exportJSON}>
            <Download size={14} /> دانلود بکاپ (JSON)
          </button>
          <button className="btn-ghost !text-xs" onClick={() => fileRef.current?.click()}>
            <Upload size={14} /> بازیابی از فایل
          </button>
          <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }} />
          <button className="btn-ghost !text-xs" onClick={() => setImportOpen(true)}>
            <Eye size={14} /> درج دستی JSON
          </button>
          <button className="btn-ghost !text-xs" onClick={() => setDemoAsk(true)}>
            <Sparkles size={14} /> بارگذاری داده نمایشی
          </button>
        </div>
        <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-500/10 p-3 text-[0.72rem] leading-5 text-amber-800 dark:text-amber-200">
          <TriangleAlert size={15} className="mt-0.5 shrink-0" />
          <span>⚠️ پاک شدن حافظه مرورگر = از دست رفتن داده. پیشنهاد: هفته‌ای یک‌بار «دانلود بکاپ» را بزن و فایل را نگه دار.</span>
        </div>
        <div className="mt-3 border-t pt-3 hairline">
          {wipeStep === 0 ? (
            <button className="btn-danger !text-xs" onClick={() => setWipeStep(1)}>
              <Trash2 size={14} /> حذف همه داده‌ها
            </button>
          ) : (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-black text-red-600">واقعاً مطمئنی؟ آخرین فرصت!</span>
              <button className="btn-ghost !text-xs" onClick={() => setWipeStep(0)}>انصراف</button>
              <button
                className="btn-danger !text-xs"
                onClick={() => {
                  localStorage.removeItem(LS_KEY);
                  api.update(() => ({
                    settings: store.settings,
                    categories: [
                      { id: "work", name: "کار", color: "#3b82f6" },
                      { id: "personal", name: "شخصی", color: "#8b5cf6" },
                      { id: "health", name: "سلامت", color: "#10b981" },
                      { id: "learn", name: "یادگیری", color: "#f59e0b" },
                      { id: "home", name: "خانه", color: "#f43f5e" },
                    ],
                    habits: [],
                    days: {},
                    backlog: [],
                  }));
                  setWipeStep(0);
                  toast("همه داده‌ها پاک و از نو شروع شد");
                }}
              >
                مطمئنم، حذف کن
              </button>
            </div>
          )}
        </div>
      </Section>

      {/* about */}
      <Section title="درباره روزینو" icon={<SettingsIcon size={18} />} className="anim-fade-up-3">
        <p className="text-xs leading-6">
          <b>نسخه ۲٫۰ • آفلاین • محلی.</b> «روزینو» ابزار یکپارچه مدیریت روز است که بهترین ایده‌های دو نسل قبل را ترکیب می‌کند:
          صبح هدف بگذار، طول روز تسک و عادت بزن، برنامه زمانی بچین، شب گزارش بنویس، امتیاز بده و روز را ببند.
          بک‌لاگ با ماتریس آیزنهاور، تقویم شمسی، گزارش عملکرد و استریک‌ها — همه در یک‌جا.
          بدون حساب کاربری، بدون سرور؛ همه‌چیز در LocalStorage همین مرورگر.
        </p>
        <p className="muted mt-2 text-[0.7rem] leading-5">
          همه داده‌ها فقط در مرورگر خودت ذخیره می‌شود — بدون سرور، بدون اینترنت. مرتب بکاپ بگیر. با «حذف داده مرورگر» همه‌چیز پاک می‌شود؛ بکاپ هفتگی را فراموش نکن.
        </p>
      </Section>

      {/* manual import modal */}
      <Modal open={importOpen} onClose={() => setImportOpen(false)} title="بازیابی از متن JSON">
        <p className="muted mb-2 text-xs">محتوای فایل بکاپ را اینجا بچسبان؛ داده‌های فعلی <b>جایگزین</b> می‌شوند.</p>
        <textarea
          className="input min-h-36 font-mono !text-[0.7rem]"
          dir="ltr"
          placeholder='{"settings": …}'
          value={importText}
          onChange={(e) => setImportText(e.target.value)}
        />
        {preview && <p className="mt-1 text-xs font-bold">پیش‌نمایش: {preview}</p>}
        <div className="mt-3 flex gap-2">
          <button className="btn-ghost flex-1" onClick={() => setImportOpen(false)}>انصراف</button>
          <button
            className="btn-accent flex-1"
            onClick={() => {
              if (doImportText(importText)) {
                setImportOpen(false);
                setImportText("");
              }
            }}
          >
            بازیابی
          </button>
        </div>
      </Modal>

      <Confirm
        open={demoAsk}
        title="بارگذاری داده نمایشی؟"
        desc="یک هفته داده نمونه اضافه می‌شود تا نمودارها و تقویم را ببینی. داده فعلی‌ات سر جایش می‌ماند."
        confirmLabel="باشه، اضافه کن"
        onCancel={() => setDemoAsk(false)}
        onConfirm={() => {
          api.update((s) => {
            const t = new Date();
            const key = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
            const moods = ["🙂", "😄", "😐"];
            for (let f = -6; f <= -1; f++) {
              const d = new Date(t);
              d.setDate(d.getDate() + f);
              const k = key(d);
              if (s.days[k]) continue;
              const dd = emptyDay(k);
              dd.wakeUp = "07:00";
              dd.sleep = "23:00";
              dd.mood = moods[(f + 9) % 3];
              dd.score = 6 + ((f + 9) % 4);
              dd.tasks = [{ id: uid(), title: "کار نمونه نمایشی", done: true, priority: "q2", categoryId: s.categories[0]?.id || "personal" }];
              s.days[k] = dd;
            }
            return s;
          });
          setDemoAsk(false);
          toast("داده نمایشی بارگذاری شد");
        }}
      />
    </div>
  );
}
