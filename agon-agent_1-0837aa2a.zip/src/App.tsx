import { useEffect, useState } from "react";
import {
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Inbox,
  Moon,
  Settings as SettingsIcon,
  Sun,
  Download,
} from "lucide-react";
import { fa, todayKey } from "./lib/jalali";
import { useStore } from "./lib/store";
import DayPage from "./pages/Day";
import BacklogPage from "./pages/Backlog";
import ReportsPage from "./pages/Reports";
import CalendarPage from "./pages/Calendar";
import SettingsPage from "./pages/Settings";

type Tab = "day" | "backlog" | "reports" | "calendar" | "settings";

const TABS: { v: Tab; label: string; desc: string; icon: React.ReactNode }[] = [
  { v: "day", label: "روز جاری", desc: "قلب برنامه", icon: <CheckCircle2 size={19} /> },
  { v: "backlog", label: "بک‌لاگ", desc: "مخزن کارها", icon: <Inbox size={19} /> },
  { v: "reports", label: "گزارش و عملکرد", desc: "هفتگی • ماهانه", icon: <BarChart3 size={19} /> },
  { v: "calendar", label: "تقویم", desc: "نمای ماهانه", icon: <CalendarDays size={19} /> },
  { v: "settings", label: "تنظیمات", desc: "داده و ظاهر", icon: <SettingsIcon size={19} /> },
];

export default function App() {
  const api = useStore();
  const { store, toast, toasts } = api;
  const [tab, setTab] = useState<Tab>("day");
  const [dayKey, setDayKey] = useState(todayKey());

  const go = (t: string) => setTab(t as Tab);
  const goDay = (k: string) => {
    setDayKey(k);
    setTab("day");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    document.title = "روزینو | سامانه یکپارچه مدیریت روزانه";
  }, []);

  const toggleTheme = () =>
    api.update((s) => {
      s.settings.theme = s.settings.theme === "dark" ? "light" : "dark";
      return s;
    });

  const quickBackup = () => {
    try {
      const raw = localStorage.getItem("roozino-v1") || "{}";
      const blob = new Blob([raw], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `roozino-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
      toast("بکاپ دانلود شد");
    } catch {
      toast("خطا در ساخت بکاپ");
    }
  };

  const openCount = store.backlog.length;

  return (
    <div className="min-h-screen">
      {/* ===== top navbar ===== */}
      <nav className="sticky top-0 z-40 border-b backdrop-blur-xl hairline" style={{ background: "color-mix(in srgb, var(--accent) 5%, transparent)", backdropFilter: "blur(16px)" }}>
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-3 py-2.5 sm:px-5">
          <button onClick={() => goDay(todayKey())} className="flex items-center gap-2.5 text-right">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl text-white shadow-lg" style={{ background: "linear-gradient(135deg, #34d399, #0d9488)" }}>
              <Sun size={20} />
            </span>
            <span>
              <span className="block text-base leading-5 font-black">
                🌿 روزینو
                {store.settings.displayName && (
                  <span className="muted text-xs font-bold"> • {store.settings.displayName}</span>
                )}
              </span>
              <span className="muted block text-[0.65rem]">سامانه یکپارچه مدیریت روزانه</span>
            </span>
          </button>
          <div className="no-print flex items-center gap-1.5">
            {openCount > 0 && (
              <button
                onClick={() => setTab("backlog")}
                className="chip hidden !py-1.5 sm:inline-flex"
                style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                title="کارهای باز بک‌لاگ"
              >
                <Inbox size={12} /> {fa(openCount)} کار باز
              </button>
            )}
            <button className="icon-btn border hairline" title="بکاپ سریع" onClick={quickBackup}>
              <Download size={17} />
            </button>
            <button className="icon-btn border hairline" title="حالت شب / روز" onClick={toggleTheme}>
              {store.settings.theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
          </div>
        </div>
        {/* desktop tabs */}
        <div className="mx-auto hidden max-w-6xl gap-1 px-5 pb-2 md:flex">
          {TABS.map((t) => (
            <button
              key={t.v}
              onClick={() => {
                setTab(t.v);
                window.scrollTo({ top: 0 });
              }}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-bold transition-all ${
                tab === t.v ? "text-white shadow-md" : "muted hover:bg-black/5 dark:hover:bg-white/5"
              }`}
              style={tab === t.v ? { background: "var(--accent)" } : undefined}
            >
              {t.icon}
              {t.label}
              {t.v === "backlog" && openCount > 0 && (
                <span className={`chip !px-1.5 !text-[0.62rem] ${tab === t.v ? "bg-white/25 text-white" : ""}`} style={tab === t.v ? undefined : { background: "var(--accent-soft)", color: "var(--accent)" }}>
                  {fa(openCount)}
                </span>
              )}
            </button>
          ))}
          <button
            onClick={() => goDay(todayKey())}
            className="muted mr-auto rounded-xl px-3 py-2 text-xs font-bold hover:bg-black/5 dark:hover:bg-white/5"
          >
            برو به امروز ←
          </button>
        </div>
      </nav>

      {/* ===== main ===== */}
      <main className="mx-auto max-w-6xl px-3 pt-4 pb-28 sm:px-5 md:pb-12">
        {tab === "day" && (
          <DayPage key={dayKey} api={api} dayKey={dayKey} setDayKey={setDayKey} go={go} />
        )}
        {tab === "backlog" && <BacklogPage api={api} goDay={goDay} />}
        {tab === "reports" && <ReportsPage api={api} goDay={goDay} />}
        {tab === "calendar" && <CalendarPage api={api} goDay={goDay} />}
        {tab === "settings" && <SettingsPage api={api} />}

        <footer className="muted mt-8 border-t pt-4 pb-2 text-center text-[0.68rem] leading-5 hairline">
          🌿 روزینو — همه داده‌ها محلی در مرورگر تو ذخیره می‌شود · بدون سرور · بدون اینترنت
          <br />
          ذهن خالی، روز روشن ✨
        </footer>
      </main>

      {/* ===== mobile bottom nav ===== */}
      <nav className="no-print fixed inset-x-0 bottom-0 z-40 border-t px-2 pt-1.5 md:hidden hairline" style={{ background: "color-mix(in srgb, #fffdf8 88%, transparent)" }}>
        <div className="mx-auto grid max-w-lg grid-cols-5 gap-0.5" style={{ paddingBottom: "max(0.6rem, env(safe-area-inset-bottom))" }}>
          {TABS.map((t) => {
            const on = tab === t.v;
            return (
              <button
                key={t.v}
                onClick={() => {
                  setTab(t.v);
                  window.scrollTo({ top: 0 });
                }}
                className="relative flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[0.62rem] font-bold transition-all"
                style={on ? { color: "var(--accent)" } : { color: "#78716c" }}
              >
                {on && (
                  <span className="absolute -top-1.5 h-1 w-8 rounded-full" style={{ background: "var(--accent)" }} />
                )}
                <span className="relative">
                  {t.icon}
                  {t.v === "backlog" && openCount > 0 && (
                    <span className="absolute -top-1.5 -left-2.5 flex h-4 min-w-4 items-center justify-center rounded-full px-0.5 text-[0.55rem] font-black text-white" style={{ background: "var(--accent)" }}>
                      {fa(openCount > 99 ? "۹۹+" : openCount)}
                    </span>
                  )}
                </span>
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>

      {/* dark-mode fix for mobile nav bg */}
      <style>{`html.dark nav.fixed{ background: color-mix(in srgb, #131920 90%, transparent) !important; }`}</style>

      {/* ===== toasts ===== */}
      <div className="pointer-events-none fixed bottom-20 left-1/2 z-50 flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-2 px-4 md:bottom-6">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="anim-toast pointer-events-auto flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold text-white shadow-2xl"
            style={{ background: "#1c1917" }}
          >
            <CheckCircle2 size={16} style={{ color: "var(--accent)" }} />
            {t.msg}
          </div>
        ))}
      </div>
    </div>
  );
}
